// memory.js — 长期记忆：规则式自动提取（不额外调模型，省成本）+ 关键词检索
// 信号：重要人物/关系、约定（时间/地点/一起做某事）、偏好（喜欢/不喜欢/爱吃/爱玩）、
//       反复话题、重要经历。普通闲聊（下课啦/接了杯水/打王者）不保存。
import { query, run, insertReturning, nowIso } from './db.js';

export const MEMORY_CATEGORIES = ['人物关系', '约定', '偏好', '经历', '话题'];

// 信号规则：每条 { category, patterns, importance: [min, max], confidence }
const SIGNAL_RULES = [
  {
    category: '约定',
    patterns: [/明天/, /后天/, /下周/, /周[一二三四五六日]/, /约好/, /一起(去|玩|吃|看)/, /等我/, /到时候/, /\d+点/, /几点/],
    importance: [70, 90],
    confidence: 0.7,
  },
  {
    category: '偏好',
    patterns: [/喜欢/, /不喜欢/, /讨厌/, /爱吃/, /爱玩/, /最爱/, /不爱/, /想吃/, /想去/, /习惯/],
    importance: [70, 90],
    confidence: 0.7,
  },
  {
    category: '人物关系',
    patterns: [/我(妈|爸|哥|姐|弟|妹|室友|朋友|同学|老师)/, /姐姐/, /我女朋友/, /我对象/, /我家/, /我们班/, /我同桌/],
    importance: [60, 80],
    confidence: 0.6,
  },
  {
    category: '经历',
    patterns: [/今天.*(发生|遇到|碰到)/, /刚才.*(摔|丢|坏|错)/, /考试/, /生病/, /感冒/, /发烧/, /受伤/, /第一次/, /上次/],
    importance: [50, 70],
    confidence: 0.6,
  },
];

// 明确不保存的普通闲聊（命中则跳过，即使有别的弱信号）。
// ANY：在正文任何位置出现即判定为闲聊汇报；SHORT：整条就是简短回应。
const CHITCHAT_ANY = /打王者|接了杯水|下课啦|已经上床了|打完了|刷牙洗澡|冷死了|还下雨了|毛毛雨/;
const CHITCHAT_SHORT = /^(没有|嗯呐|OK啦|对呀对呀|嘻嘻|知道啦|怎么啦|真的呀|在干嘛)/;
const isChitchat = (text) => CHITCHAT_ANY.test(text) || CHITCHAT_SHORT.test(text);

/** 规范化：去标点/空格，用于去重比较 */
export function normalizeText(text) {
  return (text || '')
    .replace(/[\s，。、！？!?,.~～…·'’"“”（）()\[\]]/g, '')
    .toLowerCase();
}

function tokenSet(text) {
  const norm = normalizeText(text);
  const set = new Set();
  for (let i = 0; i < norm.length; i++) set.add(norm[i]);
  for (let i = 0; i + 1 < norm.length; i++) set.add(norm.slice(i, i + 2));
  return set;
}

/** Jaccard 相似度（单字 + 双字 gram） */
export function jaccard(a, b) {
  const sa = tokenSet(a);
  const sb = tokenSet(b);
  if (sa.size === 0 || sb.size === 0) return 0;
  let inter = 0;
  for (const t of sa) if (sb.has(t)) inter++;
  return inter / (sa.size + sb.size - inter);
}

function isDuplicate(a, b) {
  const na = normalizeText(a);
  const nb = normalizeText(b);
  if (!na || !nb) return false;
  // 正负翻转不是重复：先交给冲突处理，绝不能当成去重吞掉
  if (hasContradiction(a, b)) return false;
  if (na.includes(nb) || nb.includes(na)) return true;
  return jaccard(a, b) > 0.7;
}

// 极性词（按长度降序匹配，避免“喜欢”先吞掉“不喜欢”）
const NEG_WORDS = ['不喜欢', '讨厌', '不爱', '不想', '不要', '不是'];
const POS_WORDS = ['喜欢', '爱吃', '爱玩', '最爱', '想吃', '想去'];
const POLARITY_WORDS = [...NEG_WORDS, ...POS_WORDS].sort((a, b) => b.length - a.length);

function polarityOf(text) {
  if (NEG_WORDS.some((w) => text.includes(w))) return 'neg';
  if (POS_WORDS.some((w) => text.includes(w))) return 'pos';
  return null;
}

/** 话题 = 极性词之后的内容（去掉前置动词），如“我不喜欢吃麻辣烫”→“麻辣烫” */
function extractTopic(text) {
  for (const w of POLARITY_WORDS) {
    const i = text.indexOf(w);
    if (i >= 0) {
      return normalizeText(text.slice(i + w.length)).replace(/^[吃打玩去看的了\s]+/, '');
    }
  }
  return '';
}

function topicOverlap(a, b) {
  if (!a || !b) return false;
  if (a === b || a.includes(b) || b.includes(a)) return true;
  const grams = (s) => {
    const set = new Set();
    for (let i = 0; i + 1 < s.length; i++) set.add(s.slice(i, i + 2));
    return set;
  };
  const ga = grams(a);
  const gb = grams(b);
  if (ga.size === 0 || gb.size === 0) return false;
  let inter = 0;
  for (const g of ga) if (gb.has(g)) inter++;
  return inter / Math.min(ga.size, gb.size) >= 0.5;
}

/** 只有“同一话题 + 正负相反”才算矛盾；不同对象（羽毛球 vs 拉面）不算 */
function hasContradiction(oldContent, newContent) {
  const po = polarityOf(oldContent);
  const pn = polarityOf(newContent);
  if (!po || !pn || po === pn) return false;
  return topicOverlap(extractTopic(oldContent), extractTopic(newContent));
}

/** 关键词集合（去标点后的单字/双字 gram + 高频词原形），用于检索打分 */
export function keywords(text) {
  const norm = normalizeText(text);
  const set = new Set();
  for (let i = 0; i < norm.length; i++) set.add(norm[i]);
  for (let i = 0; i + 1 < norm.length; i++) set.add(norm.slice(i, i + 2));
  return set;
}

/**
 * 从用户消息中提取记忆候选（规则式，不调模型）。
 * @param {Array<{role:string, content:string}>} messages  recent user messages
 * @returns {Array<{content:string, category:string, confidence:number, importance:number, source:string, status:string}>}
 */
export function extractCandidates(messages) {
  const out = [];
  for (const m of messages || []) {
    if (!m || m.role !== 'user') continue;
    const text = (m.content || '').trim();
    if (!text || text.length < 2) continue;
    if (isChitchat(text)) continue;

    for (const rule of SIGNAL_RULES) {
      if (rule.patterns.some((re) => re.test(text))) {
        const importance = rule.importance[0] + Math.floor(Math.random() * (rule.importance[1] - rule.importance[0] + 1));
        out.push({
          content: text,
          category: rule.category,
          confidence: rule.confidence,
          importance,
          source: 'auto',
          status: importance >= 40 ? 'active' : 'pending',
        });
        break; // 一条消息只归一个最先命中的分类
      }
    }
  }
  return out;
}

/**
 * 保存候选记忆：去重 / 冲突处理。
 * - 与现有 active/pending 记忆相似度高：只更新 updated_at，不新增
 * - 同一分类、关键词重叠且正负相反：旧的 status=conflict，新记 status=pending
 * - 手动记忆（source=manual）永不自动覆盖
 * - importance < 40 不保存
 * @returns {Promise<{saved:number, updated:number, pending:number, conflict:number}>}
 */
export async function saveCandidates(candidates) {
  const stats = { saved: 0, updated: 0, pending: 0, conflict: 0 };
  for (const c of candidates || []) {
    if (c.importance < 40) continue;
    const existing = await query(
      "SELECT * FROM memories WHERE category = ? AND status IN ('active', 'pending') ORDER BY importance DESC, updated_at DESC",
      [c.category]
    );

    // 冲突检查先于去重：正负翻转（如喜欢→不喜欢吃麻辣烫）绝不能被当成重复吞掉
    let status = c.status || 'active';
    for (const old of existing) {
      if (old.source === 'manual') continue; // 手动记忆永不自动覆盖
      if (hasContradiction(old.content, c.content)) {
        await run("UPDATE memories SET status = 'conflict', updated_at = ? WHERE id = ?", [nowIso(), old.id]);
        status = 'pending';
        stats.conflict++;
        break;
      }
    }

    if (status === 'pending') {
      // 已判定冲突：直接存为 pending，不再走去重分支
    } else {
      let handled = false;
      for (const old of existing) {
        if (old.source === 'manual') continue; // 手动记忆永不自动覆盖
        if (isDuplicate(old.content, c.content)) {
          await run('UPDATE memories SET updated_at = ? WHERE id = ?', [nowIso(), old.id]);
          stats.updated++;
          handled = true;
          break;
        }
      }
      if (handled) continue;
    }

    const now = nowIso();
    await insertReturning(
      'INSERT INTO memories (content, category, created_at, updated_at, source, confidence, importance, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [c.content, c.category, now, now, c.source || 'auto', c.confidence ?? 0.5, c.importance, status]
    );
    if (status === 'pending') stats.pending++;
    else stats.saved++;
  }
  return stats;
}

/**
 * 跨会话检索：关键词匹配，按与 userText 的交集排序。
 * @returns {Promise<{memories: Array, samples: Array}>} 各最多 limit 条
 */
export async function retrieveRelevant(sessionId, userText, limit = 5) {
  const keys = keywords(userText || '');
  const score = (content) => {
    const ks = keywords(content || '');
    let s = 0;
    for (const k of ks) if (keys.has(k)) s += k.length === 2 ? 2 : 1;
    return s;
  };

  const mems = await query("SELECT * FROM memories WHERE status = 'active' ORDER BY importance DESC, updated_at DESC");
  const memories = mems
    .map((m) => ({ ...m, _s: score(m.content) }))
    .sort((a, b) => b._s - a._s || b.importance - a.importance)
    .slice(0, limit)
    .map(({ _s, ...m }) => m);

  const samples = await query('SELECT * FROM language_samples ORDER BY id');
  const ranked = samples
    .map((s) => ({ ...s, _s: score(s.content) }))
    .sort((a, b) => b._s - a._s)
    .slice(0, limit)
    .map(({ _s, ...s }) => s);

  return { memories, samples: ranked };
}
