// drift.js — 漂移防护：检测回复是否偏离固定人格
// 检测：客套话、超长说教、过度热情、虚构共同经历。
// 返回 { drift: boolean, reasons: string[]}；路由生成后自查，drift 时记日志并在下一条
// 系统提示中加强固定人格重载（不自动改提示词文件、不改写已生成的回复）。

const POLITE_PHRASES = [
'您好', '请问有什么可以帮助您', '有什么可以帮助您', '很高兴为您服务',
'作为 ai', '作为ai', '我是一个 ai', '我是一个ai', '作为人工智能',
'我是 ai', '我是ai', '很荣幸', '竭诚为您', '请问您需要',
];

const OVER_ENTHUSIASM = [
'永远陪着你', '我最爱你', '永远爱你', '我会一直陪着你', '永远在你身边',
];

/**
* @param {string} text 生成的回复文本
* @param {string[]} historyTexts 该会话历史消息内容（用于判断"我们上次一起…"是否虚构）
*/
export function checkDrift(text, historyTexts = []) {
const reasons = [];
if (!text || typeof text!== 'string') return { drift: false, reasons};

for (const p of POLITE_PHRASES) {
if (text.toLowerCase().includes(p.toLowerCase())) {
reasons.push(`客套话/出戏：含"${p}"`);
break;
}
}

// 超长说教：>200 字且含说教词
if (text.length > 200 && /(应该|建议你|你应该|首先|其次|总之|综上)/.test(text)) {
reasons.push('超长说教：超过 200 字且含说教措辞');
}

// 过度热情：连续感叹号，或"永远…"类套话
if (/！！|!!|！{2,}|!{2,}/.test(text)) reasons.push('过度热情：连续感叹号');
for (const p of OVER_ENTHUSIASM) {
if (text.includes(p)) {
reasons.push(`过度热情/套路话：含"${p}"`);
break;
}
}

// 虚构共同经历："我们上次一起…"但历史里没有与之对应的记录
const m = text.match(/我们(上次|之前|那天)一起[^，。！？]{2,}/);
if (m) {
const key = m[0].replace(/^我们(上次|之前|那天)一起/, '');
const inHistory = historyTexts.some((h) => h && key.length >= 2 && h.includes(key.slice(0, 4)));
if (!inHistory) reasons.push(`疑似虚构共同经历："${m[0]}"在历史中无记录`);
}

return { drift: reasons.length > 0, reasons};
}

// 每会话的漂移计数（内存态，重启清零；仅用于下一条系统提示加强重载）
const driftCounts = new Map();

export function recordDrift(sessionId, result) {
if (!result.drift) return;
driftCounts.set(sessionId, (driftCounts.get(sessionId) || 0) + 1);
console.warn(`[drift] session=${sessionId} reasons=${result.reasons.join(' | ')}`);
}

export function getDriftCount(sessionId) {
return driftCounts.get(sessionId) || 0;
}

export function driftReinforcement(sessionId) {
const n = getDriftCount(sessionId);
if (n === 0) return '';
return `\n\n上一条回复出现 ${n} 次偏离固定人格（客服腔/说教/套路甜话/虚构经历）。请严格回到固定人格：短句、口语、一到两句，不说教，不用"您好/作为AI/很高兴为您服务"这类话，不编造没有发生过的事。`;
}
