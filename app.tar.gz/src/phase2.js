// phase2.js — V4.0 第二阶段后端逻辑：爱心记账 / 收藏 / 换装 / 房间 / 花园 / 心动事件 / 神秘信箱
// 只依赖 src/db.js 与 src/cat.js（addHearts / todayStr / shanghaiDayRange）。
// 不碰人格、样本、记忆写入、漂移、DeepSeek 配置；不读旧项目任何数据；不引入付费服务。
// 收藏写入与 cat.js 的 insertCollection 是同一张表、同一条 SQL（两处各写一次，避免循环引用）。
import { get, query, run, insertReturning, nowIso } from './db.js';
import { addHearts, todayStr, shanghaiDayRange } from './cat.js';

function fail(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}

// ---------- 爱心记账 / 收藏 ----------

/** 最近记账（按 id 倒序），limit 默认 20，夹在 1–200。 */
export async function getLedger(limit = 20) {
  const n = Math.min(Math.max(Number(limit) || 20, 1), 200);
  return query('SELECT * FROM heart_ledger ORDER BY id DESC LIMIT ' + n, []);
}

/** 收藏写入：同一 (kind, item_id) 只收一条。返回是否新收。 */
export async function addToCollection(kind, itemId) {
  const r = await run(
    'INSERT INTO collection (kind, item_id, acquired_at) VALUES (?, ?, ?) ON CONFLICT(kind, item_id) DO NOTHING',
    [kind, itemId, nowIso()]
  );
  return { added: r.changes > 0 };
}

export async function listCollection(kind) {
  if (kind) return query('SELECT * FROM collection WHERE kind = ? ORDER BY id', [kind]);
  return query('SELECT * FROM collection ORDER BY id', []);
}

// ---------- 换装 ----------

export const OUTFIT_BG = ['bedroom', 'starry', 'garden', 'dessert', 'moon'];
export const OUTFIT_POSES = ['sit', 'lie', 'stand'];
export const OUTFIT_BOOL_KEYS = ['bow', 'hat', 'scarf', 'dress', 'glasses'];
export const DEFAULT_OUTFIT = { bow: null, hat: null, scarf: null, dress: null, glasses: null, bg: 'bedroom', pose: 'sit' };

/** 校验 outfit（只校验传入的字段，未传的字段保持原值）。非法值抛 bad_request。 */
export function validateOutfit(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw fail('bad_request', 'outfit 应为对象');
  for (const k of Object.keys(input)) {
    if (OUTFIT_BOOL_KEYS.includes(k)) {
      const v = input[k];
      if (!(v === null || typeof v === 'boolean')) throw fail('bad_request', `outfit.${k} 只许 true/false/null`);
    } else if (k === 'bg') {
      if (!OUTFIT_BG.includes(input.bg)) throw fail('bad_request', `outfit.bg 只许 ${OUTFIT_BG.join('/')}`);
    } else if (k === 'pose') {
      if (!OUTFIT_POSES.includes(input.pose)) throw fail('bad_request', `outfit.pose 只许 ${OUTFIT_POSES.join('/')}`);
    } else {
      throw fail('bad_request', `outfit 不支持的字段：${k}`);
    }
  }
  return { ...input };
}

export async function getOutfit() {
  const row = await get('SELECT outfit FROM dress_state WHERE id = 1');
  let saved = {};
  if (row?.outfit) { try { saved = JSON.parse(row.outfit) || {}; } catch { saved = {}; } }
  const out = { ...DEFAULT_OUTFIT };
  for (const k of Object.keys(DEFAULT_OUTFIT)) if (k in saved) out[k] = saved[k];
  return out;
}

export async function setOutfit(input) {
  const patch = validateOutfit(input);
  const outfit = { ...await getOutfit(), ...patch };
  const now = nowIso();
  await run(
    'INSERT INTO dress_state (id, outfit, updated_at) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET outfit = EXCLUDED.outfit, updated_at = EXCLUDED.updated_at',
    [JSON.stringify(outfit), now]
  );
  return outfit;
}

// ---------- 房间 ----------

export const ROOM_WALLPAPERS = ['pink', 'sakura', 'lavender', 'peach', 'starry'];
export const ROOM_BEDS = ['pink', 'white', 'lavender'];
export const ROOM_PLUSHIES = ['bear', 'bunny', 'cat', 'none'];
export const ROOM_PAINTINGS = ['none', 'cat', 'flower', 'heart'];
export const ROOM_THEMES = ['home', 'chat', 'memories', 'park', 'mine'];
export const DEFAULT_ROOM = { wallpaper: 'pink', bed: 'pink', plushies: [], lamp: false, flowers: false, painting: 'none', theme: 'home' };

/** 校验 room（只校验传入的字段）。非法值抛 bad_request。
 * 规范字段是 lamp（前端一直发 lamp）；旧字段 lights 仍接受，归一化为 lamp
 * （两者同传时以 lamp 为准），不再原样透传 lights。 */
export function validateRoom(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw fail('bad_request', 'room 应为对象');
  const out = {};
  for (const k of Object.keys(input)) {
    const v = input[k];
    if (k === 'wallpaper') {
      if (!ROOM_WALLPAPERS.includes(v)) throw fail('bad_request', `room.wallpaper 只许 ${ROOM_WALLPAPERS.join('/')}`);
      out.wallpaper = v;
    } else if (k === 'bed') {
      if (!ROOM_BEDS.includes(v)) throw fail('bad_request', `room.bed 只许 ${ROOM_BEDS.join('/')}`);
      out.bed = v;
    } else if (k === 'plushies') {
      if (!Array.isArray(v)) throw fail('bad_request', 'room.plushies 应为数组');
      for (const p of v) {
        if (!ROOM_PLUSHIES.includes(p)) throw fail('bad_request', `room.plushies 元素只许 ${ROOM_PLUSHIES.join('/')}`);
      }
      out.plushies = v;
    } else if (k === 'lamp' || k === 'flowers') {
      if (typeof v !== 'boolean') throw fail('bad_request', `room.${k} 只许 true/false`);
      out[k] = v;
    } else if (k === 'lights') {
      // 旧字段：只接受布尔值，归一化为 lamp；与 lamp 同传时 lamp 优先。
      if (typeof v !== 'boolean') throw fail('bad_request', 'room.lights 只许 true/false');
      if (!('lamp' in out)) out.lamp = v;
    } else if (k === 'painting') {
      if (!ROOM_PAINTINGS.includes(v)) throw fail('bad_request', `room.painting 只许 ${ROOM_PAINTINGS.join('/')}`);
      out.painting = v;
    } else if (k === 'theme') {
      if (!ROOM_THEMES.includes(v)) throw fail('bad_request', `room.theme 只许 ${ROOM_THEMES.join('/')}`);
      out.theme = v;
    } else {
      throw fail('bad_request', `room 不支持的字段：${k}`);
    }
  }
  return out;
}

export async function getRoom() {
  const row = await get('SELECT room FROM room_state WHERE id = 1');
  let saved = {};
  if (row?.room) { try { saved = JSON.parse(row.room) || {}; } catch { saved = {}; } }
  // 兼容旧数据：已存的 lights 映射为 lamp（线上保存一直失败，旧数据很少，但不要丢）；
  // 同存 lamp 时以 lamp 为准；返回里永远不再出现 lights。
  if (!('lamp' in saved) && typeof saved.lights === 'boolean') saved.lamp = saved.lights;
  const out = { ...DEFAULT_ROOM, plushies: [...DEFAULT_ROOM.plushies] };
  for (const k of Object.keys(DEFAULT_ROOM)) {
    if (k in saved) out[k] = Array.isArray(saved[k]) ? [...saved[k]] : saved[k];
  }
  return out;
}

export async function setRoom(input) {
  const patch = validateRoom(input);
  const room = { ...await getRoom(), ...patch };
  const now = nowIso();
  await run(
    'INSERT INTO room_state (id, room, updated_at) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET room = EXCLUDED.room, updated_at = EXCLUDED.updated_at',
    [JSON.stringify(room), now]
  );
  return room;
}

// ---------- 花园 ----------

/** 花种：growMs 为浇水后长满所需毫秒。 */
export const FLOWERS = {
  daisy: { name: '雏菊', growMs: 2 * 3600 * 1000 },
  rose: { name: '玫瑰', growMs: 6 * 3600 * 1000 },
  tulip: { name: '郁金香', growMs: 12 * 3600 * 1000 },
  sunflower: { name: '向日葵', growMs: 24 * 3600 * 1000 },
};

export const GARDEN_SLOTS = [0, 1, 2];
export const GARDEN_HARVEST_HEARTS = 2;
export const POT_THRESHOLDS = { pink: 3, gold: 8 };

/**
 * 按真实时间算生长阶段（纯计算，now 可注入）。
 * 未浇水 → seed（progress 0）；浇水后按 elapsed/growMs 推进，
 * <1/3 sprout，<2/3 bud，[2/3,1) 仍为 bud，>=1 bloom（ready=true）。
 * progress 是 0–100 的整数百分比（前端直接拼 '%' 显示；0–1 小数会显示成 0.5%）。
 */
export function flowerStage(flowerId, wateredAt, now = new Date()) {
  if (!FLOWERS[flowerId]) throw fail('bad_request', `未知花种：${flowerId}`);
  if (!wateredAt) return { stage: 'seed', progress: 0, ready: false };
  const at = now instanceof Date ? now : new Date(now);
  const elapsed = at.getTime() - new Date(wateredAt).getTime();
  const frac = Math.min(1, Math.max(0, elapsed / FLOWERS[flowerId].growMs));
  let stage = 'bud';
  if (frac < 1 / 3) stage = 'sprout';
  else if (frac >= 1) stage = 'bloom';
  return { stage, progress: Math.round(frac * 100), ready: frac >= 1 };
}

/** 槽位当前未收获的花行（或 undefined）。 */
async function activePlot(slot) {
  return get('SELECT * FROM garden_plots WHERE slot = ? AND harvested_at IS NULL ORDER BY id DESC', [slot]);
}

function checkSlot(slot) {
  if (!Number.isInteger(slot) || !GARDEN_SLOTS.includes(slot)) throw fail('bad_request', 'slot 只许 0/1/2');
}

export async function getHarvestCount() {
  const row = await get('SELECT COUNT(*) AS n FROM garden_plots WHERE harvested_at IS NOT NULL');
  return Number(row?.n || 0);
}

export function potsFor(harvests) {
  return [
    { id: 'clay', name: '陶土花盆', unlocked: true },
    { id: 'pink', name: '粉色花盆', unlocked: harvests >= POT_THRESHOLDS.pink },
    { id: 'gold', name: '金色花盆', unlocked: harvests >= POT_THRESHOLDS.gold },
  ];
}

export async function getGarden(now = new Date()) {
  const plots = [];
  for (const slot of GARDEN_SLOTS) {
    const p = await activePlot(slot);
    if (!p) {
      plots.push({ slot, flower: null, flower_name: null, planted_at: null, watered_at: null, stage: 'empty', progress: 0, ready: false });
      continue;
    }
    const s = flowerStage(p.flower, p.watered_at, now);
    plots.push({
      slot,
      flower: p.flower,
      flower_name: FLOWERS[p.flower]?.name || p.flower,
      planted_at: p.planted_at,
      watered_at: p.watered_at,
      stage: s.stage,
      progress: s.progress,
      ready: s.ready,
    });
  }
  const harvests = await getHarvestCount();
  return { plots, pots: potsFor(harvests), harvests };
}

export async function plantFlower(slot, flower) {
  checkSlot(slot);
  if (!FLOWERS[flower]) throw fail('bad_request', `未知花种：${flower}`);
  const existing = await activePlot(slot);
  if (existing) throw fail('conflict', `槽位 ${slot} 已有花`);
  const now = nowIso();
  const id = await insertReturning(
    'INSERT INTO garden_plots (slot, flower, planted_at, watered_at, harvested_at, created_at) VALUES (?, ?, ?, NULL, NULL, ?)',
    [slot, flower, now, now]
  );
  return { id, slot, flower, flower_name: FLOWERS[flower].name, planted_at: now, watered_at: null, stage: 'seed', progress: 0, ready: false };
}

export async function waterPlot(slot, now = new Date()) {
  checkSlot(slot);
  const p = await activePlot(slot);
  if (!p) throw fail('not_found', `槽位 ${slot} 没有花`);
  const at = (now instanceof Date ? now : new Date(now)).toISOString();
  await run('UPDATE garden_plots SET watered_at = ? WHERE id = ?', [at, p.id]);
  const s = flowerStage(p.flower, at, now);
  return { slot, flower: p.flower, flower_name: FLOWERS[p.flower].name, planted_at: p.planted_at, watered_at: at, stage: s.stage, progress: s.progress, ready: s.ready };
}

export async function harvestPlot(slot, now = new Date()) {
  checkSlot(slot);
  const p = await activePlot(slot);
  if (!p) throw fail('not_found', `槽位 ${slot} 没有花`);
  const at = (now instanceof Date ? now : new Date(now)).toISOString();
  const s = flowerStage(p.flower, p.watered_at, now);
  if (!s.ready) throw fail('not_ready', '花还没长好');
  await run('UPDATE garden_plots SET harvested_at = ? WHERE id = ?', [at, p.id]);
  const cat = await addHearts(GARDEN_HARVEST_HEARTS, 'garden:harvest');
  const decor = `花朵·${FLOWERS[p.flower].name}`;
  await addToCollection('decor', decor);
  const harvests = await getHarvestCount();
  return { slot, flower: p.flower, flower_name: FLOWERS[p.flower].name, decor, hearts: GARDEN_HARVEST_HEARTS, cat, harvests, pots: potsFor(harvests) };
}

// ---------- 心动事件 ----------

/** 6 条心动事件：原创通用文案，不编造任何真实回忆。 */
export const EVENTS = [
  { id: 'cat-cuddle', title: '小猫跑过来蹭你', text: '小猫跑过来蹭了蹭你，轻轻叫了一声，像在说今天也要一起加油', anim: 'cuddle' },
  { id: 'flower-gift', title: '小猫叼来一朵花', text: '小猫叼来一朵花放在你面前，尾巴摇得飞快', anim: 'flower' },
  { id: 'pink-rain', title: '窗外下起粉色梦幻雨', text: '窗外忽然下起粉色的梦幻雨，整个房间都变得亮晶晶的', anim: 'rain' },
  { id: 'mystery-note', title: '收到一张神秘小纸条', text: '桌上多了一张神秘小纸条，上面画着一只笑眯眯的小猫', anim: 'note' },
  { id: 'gift-box', title: '小猫躲进礼物盒里', text: '小猫躲进了礼物盒里，只露出一个毛茸茸的小脑袋', anim: 'box' },
  { id: 'heart-appear', title: '房间里突然出现一颗爱心', text: '房间里突然出现一颗亮晶晶的爱心，飘到你面前停了下来', anim: 'heart' },
];

export const EVENT_DAILY_LIMIT = 5;

/** 随机取一条心动事件并落库（每天上限 5 次，超了抛 event_limit）。 */
export async function nextEvent(date = todayStr()) {
  const [s, e] = shanghaiDayRange(date);
  const row = await get('SELECT COUNT(*) AS n FROM event_log WHERE created_at >= ? AND created_at < ?', [s, e]);
  if (Number(row?.n || 0) >= EVENT_DAILY_LIMIT) throw fail('event_limit', '今日心动事件已达 5 次上限');
  const ev = EVENTS[Math.floor(Math.random() * EVENTS.length)];
  await run('INSERT INTO event_log (event_id, created_at, favorited) VALUES (?, ?, 0)', [ev.id, nowIso()]);
  return { ...ev };
}

/** 收藏/取消收藏某条心动事件（写最近一条 event_log 的 favorited；无记录时补记一条）。 */
export async function favoriteEvent(eventId, favorite) {
  const ev = EVENTS.find((e) => e.id === eventId);
  if (!ev) throw fail('not_found', `未知事件：${eventId}`);
  if (typeof favorite !== 'boolean') throw fail('bad_request', 'favorite 应为 true/false');
  const row = await get('SELECT * FROM event_log WHERE event_id = ? ORDER BY id DESC', [eventId]);
  if (row) {
    await run('UPDATE event_log SET favorited = ? WHERE id = ?', [favorite ? 1 : 0, row.id]);
  } else {
    await run('INSERT INTO event_log (event_id, created_at, favorited) VALUES (?, ?, ?)', [eventId, nowIso(), favorite ? 1 : 0]);
  }
  return { event_id: eventId, favorited: favorite };
}

// ---------- 神秘信箱（绝不编造） ----------

/** 通用小纸条池：8 条原创通用文案，不含任何真实记忆、真实情节。 */
export const LETTER_POOL = [
  { title: '神秘小纸条', text: '今天也要好好吃饭，好好休息，小猫在家里等你回来' },
  { title: '神秘小纸条', text: '（猫猫探头）不管今天顺不顺利，回来都有小猫陪着你' },
  { title: '神秘小纸条', text: '慢慢来也没关系，今天的小确幸正在路上' },
  { title: '神秘小纸条', text: '记得多喝水，出门看一眼天气，别让小猫担心' },
  { title: '神秘小纸条', text: '今天也要记得笑一笑，小猫最喜欢看你笑的样子' },
  { title: '神秘小纸条', text: '累了就早点休息，明天精神会更好，小猫陪你一起睡' },
  { title: '神秘小纸条', text: '出门时抬头看看天，回来告诉小猫你看到了什么' },
  { title: '神秘小纸条', text: '今天也要加油呀，小猫把攒起来的喜欢都送给你' },
];

/** 未删除的信（status != 'deleted'），按 id 倒序。 */
export async function listLetters() {
  return query("SELECT * FROM letters WHERE status != 'deleted' ORDER BY id DESC");
}

/**
 * 抽一封信并立即落库（status='new'）。
 * 先只读 memories 表 confirmed=1 的记忆（只读 id/content/category/created_at）；
 * 有且随机命中时生成 source='ai' 的信：内容只能是通用引导句 + 记忆原文引用
 * （格式固定：“小猪记得：{记忆原文}”，不许改写、不许加情节），ref_memory_id 记上；
 * 否则从通用池随机抽一条 source='generic'。
 * 注意：confirmed 是 memories 表的独立标记列（db.js 启动时幂等新增）；
 * 旧 status 字段受 CHECK 约束只允许 active/pending/conflict，写不出 'confirmed'，
 * 所以“已确认”用这一列表示，不动原 CHECK 约束。
 */
export async function drawLetter() {
  const confirmed = await query('SELECT id, content, category, created_at FROM memories WHERE confirmed = 1 ORDER BY updated_at DESC');
  let source = 'generic';
  let title;
  let content;
  let refId = null;
  if (confirmed.length > 0 && Math.random() < 0.5) {
    const m = confirmed[Math.floor(Math.random() * confirmed.length)];
    source = 'ai';
    title = '来自记忆的小纸条';
    content = `翻到了一条以前的记忆，想和你分享一下\n小猪记得：${m.content}`;
    refId = m.id;
  } else {
    const pick = LETTER_POOL[Math.floor(Math.random() * LETTER_POOL.length)];
    title = pick.title;
    content = pick.text;
  }
  const now = nowIso();
  const id = await insertReturning(
    'INSERT INTO letters (source, title, content, ref_memory_id, status, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    [source, title, content, refId, 'new', now]
  );
  return { id, source, title, content, ref_memory_id: refId, status: 'new', created_at: now };
}

/** 信的状态切换：save → 'saved'，delete → 'deleted'。不存在抛 not_found。 */
export async function setLetterStatus(id, status) {
  const row = await get('SELECT * FROM letters WHERE id = ?', [id]);
  if (!row) throw fail('not_found', `信不存在：${id}`);
  await run('UPDATE letters SET status = ? WHERE id = ?', [status, id]);
  return { ...row, status };
}
