// deepseek.js — DeepSeek 官方 API 代理（只后端调）
// Key 只读 process.env.DEEPSEEK_API_KEY，绝不写前端/源码/日志/git。
// 无 Key / 401 / 402 / 超时 / 断网一律诚实返回错误码，禁止 fallback 假回复、禁止写死 canned 回复。
// 支持 stream:true 解析 SSE。

export const ERROR_CODES = {
  NO_API_KEY: 'DEEPSEEK_API_KEY 未配置（只放服务器环境变量）',
  DEEPSEEK_401: 'DeepSeek 鉴权失败（401，Key 无效或过期）',
  DEEPSEEK_402: 'DeepSeek 余额不足（402）',
  DEEPSEEK_TIMEOUT: 'DeepSeek 请求超时',
  DEEPSEEK_ERROR: 'DeepSeek 请求失败',
};

export function makeDeepSeekError(code, detail = '') {
  const err = new Error(`${ERROR_CODES[code] || code}${detail ? `：${detail}` : ''}`);
  err.code = code;
  return err;
}

/** 大致 token 估算：按字符数 / 4 */
export function estimateTokens(text) {
  if (!text) return 0;
  return Math.ceil(text.length / 4);
}

function resolveConfig(cfg = {}) {
  return {
    model: cfg.model || 'deepseek-flash',
    baseUrl: (cfg.baseUrl || 'https://api.deepseek.com').replace(/\/$/, ''),
    temperature: cfg.temperature ?? 0.8,
    maxTokens: cfg.maxTokens ?? 1000,
    timeoutMs: cfg.timeoutMs ?? 60000,
  };
}

/**
 * 流式 chat completion。
 * @param {object} opts
 * @param {string} opts.systemPrompt 系统提示（固定人格全文 + 记忆 + 样本 + 摘要）
 * @param {Array<{role:string,content:string}>} opts.messages 最近消息
 * @param {object} [opts.config] 模型配置（model/baseUrl/temperature/maxTokens/timeoutMs）
 * @param {(delta:string)=>void} [opts.onDelta] 每段增量回调
 * @returns {Promise<{text:string, promptTokensEstimate:number, model:string}>}
 * @throws {Error} err.code 为 NO_API_KEY / DEEPSEEK_401 / DEEPSEEK_402 / DEEPSEEK_TIMEOUT / DEEPSEEK_ERROR
 */
export async function chatCompletionStream({ systemPrompt, messages, config = {}, onDelta }) {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) throw makeDeepSeekError('NO_API_KEY');

  const { model, baseUrl, temperature, maxTokens, timeoutMs } = resolveConfig(config);
  const url = `${baseUrl}/v1/chat/completions`;
  const promptText = [systemPrompt, ...messages.map((m) => m.content)].join('\n');
  const promptTokensEstimate = estimateTokens(promptText);

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'system', content: systemPrompt }, ...messages],
        temperature,
        max_tokens: maxTokens,
        // deepseek-flash 默认开启思考模式；本项目要旧 deepseek-chat 那种快而短的
        // 非思考回复，故显式关闭思考（官方文档 thinking 参数）。
        thinking: { type: 'disabled' },
        stream: true,
      }),
      signal: controller.signal,
    });
  } catch (e) {
    clearTimeout(timer);
    if (e?.name === 'AbortError') throw makeDeepSeekError('DEEPSEEK_TIMEOUT');
    throw makeDeepSeekError('DEEPSEEK_ERROR', String(e?.message || e));
  } finally {
    clearTimeout(timer);
  }

  if (!res.ok) {
    let detail = '';
    try {
      const body = await res.text();
      detail = body.slice(0, 200);
    } catch { /* ignore */ }
    if (res.status === 401) throw makeDeepSeekError('DEEPSEEK_401', detail);
    if (res.status === 402) throw makeDeepSeekError('DEEPSEEK_402', detail);
    throw makeDeepSeekError('DEEPSEEK_ERROR', `HTTP ${res.status} ${detail}`);
  }

  // 解析 SSE
  let full = '';
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = '';
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split('\n');
      buf = lines.pop();
      for (const line of lines) {
        const t = line.trim();
        if (!t.startsWith('data:')) continue;
        const payload = t.slice(5).trim();
        if (payload === '[DONE]') continue;
        try {
          const json = JSON.parse(payload);
          const delta = json?.choices?.[0]?.delta?.content || '';
          if (delta) {
            full += delta;
            onDelta?.(delta);
          }
        } catch { /* 跳过无法解析的行 */ }
      }
    }
  } catch (e) {
    if (e?.name === 'AbortError') throw makeDeepSeekError('DEEPSEEK_TIMEOUT');
    throw makeDeepSeekError('DEEPSEEK_ERROR', String(e?.message || e));
  }

  return { text: full, promptTokensEstimate, model };
}
