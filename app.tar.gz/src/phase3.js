// phase3.js — V4.0 第三阶段后端逻辑：手动回忆 / 消息收藏 / 纪念日 /
// 情绪上下文（只作一次聊天的上下文）/ 睡前故事·晚安信 / 每日报告。
// 只依赖本项目自己的表与模块（db/cat/phase2/seed/deepseek）；不读旧项目任何数据；
// 不改 buildSystemPrompt 与系统提示词；所有报告数字只读真实记录，不编造。
import { get, query, run, insertReturning, nowIso} from './db.js';
import { todayStr, shanghaiDayRange, seededPick, getDaily, getCat} from './cat.js';
import { getGarden, FLOWERS} from './phase2.js';
import { getPersonaSections} from './seed.js';
import { chatCompletionStream} from './deepseek.js';

function fail(code, message) {
const e = new Error(message);
e.code = code;
return e;
}

/** 校验 YYYY-MM-DD（与 src/cat.js 的 isValidDateStr 同口径：格式 + 真实日期往返）。 */
export function isValidDateStr(s) {
if (typeof s!== 'string' ||!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
const d = new Date(`${s}T00:00:00+08:00`);
if (Number.isNaN(d.getTime())) return false; // 如 2026-13-01：Intl.format 会直接抛错，须先拦
return todayStr(d) === s;
}

function requireNonEmpty(v, label) {
if (!v || typeof v!== 'string' ||!v.trim()) throw fail('bad_request', `${label}不能为空`);
return v.trim();
}

function requireValidDate(v) {
if (!isValidDateStr(v)) throw fail('bad_request', `日期应为合法 YYYY-MM-DD：${v}`);
return v;
}

/** 纪念日距今天数：当天 0，过去为负。按 Asia/Shanghai 日期算。 */
export function daysLeft(dateStr) {
const dayMs = 24 * 60 * 60 * 1000;
const target = Date.parse(`${dateStr}T00:00:00+08:00`);
const today = Date.parse(`${todayStr()}T00:00:00+08:00`);
return Math.round((target - today) / dayMs);
}

// ---------- 情绪上下文 ----------

/** 情绪取值 → 中文名（与前端 emotionPicker 的 8 个取值一致）。 */
export const EMOTION_LABELS = {
happy: '今天很开心',
sad: '今天有点难过',
wronged: '今天很委屈',
irritated: '有点烦躁',
praise: '想被夸奖',
clingy: '想撒娇',
talk: '想找人聊天',
quiet: '想安静待一会儿',
};

/** 追加给 DeepSeek 的 ONE 条 user 角色上下文消息（绝不写入 messages 表）。 */
export function emotionContextText(emotion) {
const label = EMOTION_LABELS[emotion];
if (!label) throw fail('bad_request', `emotion 只许 ${Object.keys(EMOTION_LABELS).join('/')}`);
return ``;
}

// ---------- 手动回忆 ----------

function publicManualMemory(r) {
return { id: r.id, title: r.title, date: r.date, text: r.text, created_at: r.created_at};
}

export async function listManualMemories() {
const rows = await query('SELECT * FROM manual_memories ORDER BY date DESC, id DESC');
return rows.map(publicManualMemory);
}

export async function createManualMemory({ title, date, text}) {
const t = requireNonEmpty(title, 'title');
const d = requireValidDate(date);
const x = requireNonEmpty(text, 'text');
const id = await insertReturning(
'INSERT INTO manual_memories (title, date, text, created_at) VALUES (?,?,?,?)',
[t, d, x, nowIso()]
);
return publicManualMemory(await get('SELECT * FROM manual_memories WHERE id =?', [id]));
}

export async function updateManualMemory(id, patch) {
const existing = await get('SELECT * FROM manual_memories WHERE id =?', [id]);
if (!existing) throw fail('not_found', `手动回忆不存在：${id}`);
const next = {
title: patch.title === undefined? existing.title: requireNonEmpty(patch.title, 'title'),
date: patch.date === undefined? existing.date: requireValidDate(patch.date),
text: patch.text === undefined? existing.text: requireNonEmpty(patch.text, 'text'),
};
await run(
'UPDATE manual_memories SET title =?, date =?, text =? WHERE id =?',
[next.title, next.date, next.text, id]
);
return publicManualMemory(await get('SELECT * FROM manual_memories WHERE id =?', [id]));
}

export async function deleteManualMemory(id) {
await run('DELETE FROM manual_memories WHERE id =?', [id]);
return { ok: true};
}

// ---------- 重要聊天收藏 ----------

/** 收藏/取消收藏一条消息（消息须属于该会话，否则 404）。 */
export async function setMessageFavorite(sessionId, messageId, favorite) {
if (typeof favorite!== 'boolean') throw fail('bad_request', 'favorite 应为 true/false');
const row = await get('SELECT * FROM messages WHERE id =? AND session_id =?', [messageId, sessionId]);
if (!row) throw fail('not_found', `消息不存在：${messageId}`);
await run('UPDATE messages SET favorite =? WHERE id =?', [favorite? 1: 0, messageId]);
return { ok: true, favorite};
}

/** 已收藏的消息，按 created_at 倒序。 */
export async function listFavorites() {
const rows = await query(
'SELECT id, session_id, role, content, created_at FROM messages WHERE favorite = 1 ORDER BY created_at DESC, id DESC'
);
return rows;
}

// ---------- 纪念日 ----------

function publicAnniversary(r) {
return { id: r.id, name: r.name, date: r.date, created_at: r.created_at, days_left: daysLeft(r.date)};
}

export async function listAnniversaries() {
const rows = await query('SELECT * FROM anniversaries ORDER BY date ASC, id ASC');
return rows.map(publicAnniversary);
}

export async function createAnniversary({ name, date}) {
const n = requireNonEmpty(name, 'name');
const d = requireValidDate(date);
const id = await insertReturning(
'INSERT INTO anniversaries (name, date, created_at) VALUES (?,?,?)',
[n, d, nowIso()]
);
return publicAnniversary(await get('SELECT * FROM anniversaries WHERE id =?', [id]));
}

export async function updateAnniversary(id, patch) {
const existing = await get('SELECT * FROM anniversaries WHERE id =?', [id]);
if (!existing) throw fail('not_found', `纪念日不存在：${id}`);
const next = {
name: patch.name === undefined? existing.name: requireNonEmpty(patch.name, 'name'),
date: patch.date === undefined? existing.date: requireValidDate(patch.date),
};
await run('UPDATE anniversaries SET name =?, date =? WHERE id =?', [next.name, next.date, id]);
return publicAnniversary(await get('SELECT * FROM anniversaries WHERE id =?', [id]));
}

export async function deleteAnniversary(id) {
await run('DELETE FROM anniversaries WHERE id =?', [id]);
return { ok: true};
}

// ---------- 睡前故事 / 晚安信 ----------

/** 本地睡前小故事池：4 篇原创，温柔简短，每篇 80–150 字（字数已核对）。 */
export const BEDTIME_STORIES = [
'夜深了，小猫爬上屋顶，抱着月亮打了个哈欠。月亮问它怎么还不睡，小猫说，它在等你的一声晚安。风把星星一颗颗点亮，像有人在天上轻轻说了句睡吧。小猫闭上眼睛，尾巴搭在月亮上，梦里全是你白天摸它头时暖暖的手。',
'从前有一只小猪，住在云朵做的小屋里，每天晚上都要数星星才能睡着。它数到第九十九颗时，总会想起白天发生的好事，好吃的饭，暖暖的太阳，还有你发来的消息。数着数着，它就笑了，抱着星星睡着了，梦里也在偷偷开心。',
'小河边的萤火虫今晚开了一场小小的灯会，一闪一闪地给路过的小动物们照明。走累的小兔子靠在蘑菇上睡着了，萤火虫就围在它身边，轻轻地飞，不吵它。风也放轻了脚步，整条小河都在说，晚安，晚安，明天见。',
'天上的云今晚变成了一床软软的被子，盖住了整个小镇。窗台上的小花合上花瓣，屋顶上的小鸟收起翅膀，连月亮都打了个哈欠，轻轻地说该睡觉啦。你也闭上眼睛吧，什么都不用想，梦里会有人给你留一盏暖暖的灯。',
];

/** 通用晚安小纸条池：6 条原创，每条一两句，不含任何真实回忆。 */
export const GOODNIGHT_NOTES = [
'晚安啦，今天辛苦了，好好睡一觉，明天又是新的一天',
'天黑了就早点睡，小猫在梦里陪你，不会让你一个人',
'把今天的烦心事都留在白天吧，晚上只装好梦',
'睡吧睡吧，明天醒来又是被喜欢的一天',
'盖好被子别着凉，晚安，明天见',
'今晚月亮很亮，替你守着夜，安心睡吧',
];

/** 本地故事：按日期确定性轮换（同一天同一篇）。 */
export function localBedtimeStory(date = todayStr()) {
return { story: seededPick(BEDTIME_STORIES, `bedtime:${date}`), source: 'local'};
}

/** 晚安小纸条：按日期确定性挑一条（同一天同一条）。 */
export function goodnightLetter(date = todayStr()) {
return { letter: seededPick(GOODNIGHT_NOTES, `goodnight:${date}`), source: 'generic'};
}

/**
* 睡前故事的系统提示：只取 persona_config A–I 九节原文（与 buildSystemPrompt
* 拼人格全文的方式相同），再加一句睡前故事要求；绝不改 buildSystemPrompt，
* 也不把它的“只回一到两句短句”收尾 instruction 搬过来（故事要 80–150 字）。
*/
export async function bedtimeSystemPrompt() {
const sections = await getPersonaSections();
const personaText = sections.map((s) => `\n${s.content}`).join('\n\n');
return `${personaText}\n\n你现在要讲一个睡前小故事：80–150 字，温柔简短，适合睡前，用小猪的人格口吻，只讲故事本身，不要多余解释，不要说教。`;
}

/**
* 睡前故事：有 Key 且 DeepSeek 成功 → 真 AI 故事（source:'deepseek'）；
* 无 Key 或调用失败（401/402/超时/断网）→ 本地原创故事池（source:'local'），
* 绝不把调用失败伪装成 AI 故事。
*/
export async function generateBedtimeStory(cfg) {
if (!cfg?.hasKey) return localBedtimeStory();
try {
const systemPrompt = await bedtimeSystemPrompt();
const result = await chatCompletionStream({
systemPrompt,
messages: [{ role: 'user', content: '讲一个睡前小故事'}],
config: {...cfg, maxTokens: 400},
});
const story = (result.text || '').trim();
if (!story) return localBedtimeStory();
return { story, source: 'deepseek'};
} catch {
return localBedtimeStory();
}
}

// ---------- 每日报告 ----------

/**
* 每日报告（只读真实记录，缺项诚实为 0/null/[]）。
* 口径：
* - chat：messages 表 created_at 落在上海日期窗口内的 user/assistant 条数。
* - mood：mood_entries 当天那行（{mood, note}），无则 null。
* - tasks：每日任务共 5 个（TASKS），done/claimed 直接取 getDaily(date) 的结果：
* done 由 checkTaskDone 按真实记录判定（pet=当日 interact 记录、chat=当日 user 消息、
* surprise=当日 surprise 已领、game=当日 game_scores、mood=当日 mood_entries），
* claimed 为 daily_records 当天 kind=`task:<id>` 的记录数。
* - surprise.claimed：daily_records 当天 kind='surprise' 是否存在。
* - games：game_scores 当天记录（played_at 在窗口内），按 id 升序。
* - cat.hearts/intimacy：cat_state 当前值；heartsToday：heart_ledger 当天 delta 求和；
* intimacyToday：亲密度变化没有单独记账（heart_ledger 只记爱心），算不出，恒为 null。
* - garden.growing：garden_plots 未收获的（getGarden 的 plots 里 flower 非空者）；
* harvested：garden_plots 当天 harvested_at 的行。
* - letters.drawn：letters 表当天 created_at 的条数（不限 status，删掉的也算画过）；
* letters.saved：其中 status='saved' 的条数（只计当天创建又当天已收藏的；
* 隔天收藏的不计入当天——letters 表没有 status 变更时间，算不出跨天收藏）。
*/
export async function getDailyReport(date = todayStr()) {
if (!isValidDateStr(date)) throw fail('bad_request', `日期格式应为 YYYY-MM-DD：${date}`);
const [start, end] = shanghaiDayRange(date);

const chatRows = await query(
"SELECT role, COUNT(*) AS n FROM messages WHERE created_at >=? AND created_at <? GROUP BY role",
[start, end]
);
const chat = { user: 0, assistant: 0};
for (const r of chatRows) {
if (r.role === 'user') chat.user = Number(r.n || 0);
if (r.role === 'assistant') chat.assistant = Number(r.n || 0);
}

const moodRow = await get('SELECT mood, note FROM mood_entries WHERE date =?', [date]);
const mood = moodRow? { mood: moodRow.mood, note: moodRow.note}: null;

const daily = await getDaily(date);
const tasks = {
total: daily.tasks.length,
done: daily.tasks.filter((t) => t.done).length,
claimed: daily.tasks.filter((t) => t.claimed).length,
};
const surprise = { claimed: daily.surprise.claimed};

const gameRows = await query(
'SELECT game, score, played_at FROM game_scores WHERE played_at >=? AND played_at <? ORDER BY id ASC',
[start, end]
);
const games = gameRows.map((r) => ({ game: r.game, score: r.score, played_at: r.played_at}));

const cat = await getCat();
const heartsRow = await get(
'SELECT COALESCE(SUM(delta), 0) AS n FROM heart_ledger WHERE created_at >=? AND created_at <?',
[start, end]
);
const catOut = {
hearts: cat.hearts,
intimacy: cat.intimacy,
heartsToday: Number(heartsRow?.n || 0),
intimacyToday: null, // 亲密度变化没有单独记账，算不出，不编造
};

const garden = await getGarden();
const growing = garden.plots
.filter((p) => p.flower)
.map((p) => ({ flower: p.flower, stage: p.stage, progress: p.progress}));
const harvestedRows = await query(
'SELECT flower, harvested_at FROM garden_plots WHERE harvested_at >=? AND harvested_at <? ORDER BY id ASC',
[start, end]
);
const gardenOut = {
harvested: harvestedRows.map((r) => ({
flower: r.flower,
flower_name: FLOWERS[r.flower]?.name || r.flower,
harvested_at: r.harvested_at,
})),
growing,
};

const drawnRow = await get(
'SELECT COUNT(*) AS n FROM letters WHERE created_at >=? AND created_at <?',
[start, end]
);
const savedRow = await get(
"SELECT COUNT(*) AS n FROM letters WHERE created_at >=? AND created_at <? AND status = 'saved'",
[start, end]
);
const letters = { drawn: Number(drawnRow?.n || 0), saved: Number(savedRow?.n || 0)};

return { date, chat, mood, tasks, surprise, games, cat: catOut, garden: gardenOut, letters};
}
