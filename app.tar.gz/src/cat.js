// cat.js — V4.0 第一阶段后端逻辑：猫咪小屋 / 每日惊喜·任务·幸运签 / 小游戏分数·转盘 / 心情记录
// 只依赖 src/db.js（query/get/run/insertReturning，`?` 占位符双向兼容 SQLite/PG）。
// 不碰人格、样本、记忆、漂移、DeepSeek 配置；不读旧项目任何数据。
import { get, query, run, insertReturning, nowIso } from './db.js';

// ---------- 时间：统一用 Asia/Shanghai 算“今天” ----------

/** 真实日期（Asia/Shanghai），格式 YYYY-MM-DD。默认当前时间。 */
export function todayStr(date = new Date()) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(date instanceof Date ? date : new Date(date));
}

/** 上海时间当天的小时（0–23），用于 deriveState 的夜间判断。 */
export function shanghaiHour(date = new Date()) {
  return Number(new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Shanghai', hour: 'numeric', hourCycle: 'h23',
  }).format(date instanceof Date ? date : new Date(date)));
}

/** 上海日期 dateStr 对应的 UTC 时间窗口 [start, end)，用于查 messages/game_scores
 *  这类以 UTC ISO（nowIso）存时间的表：上海 00:00 = 前一日 16:00 UTC。 */
export function shanghaiDayRange(dateStr) {
  const start = new Date(`${dateStr}T00:00:00+08:00`);
  const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
  return [start.toISOString(), end.toISOString()];
}

function isValidDateStr(s) {
  if (typeof s !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  return todayStr(new Date(`${s}T00:00:00+08:00`)) === s;
}

// ---------- 确定性随机 ----------

export function hashSeed(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seededIndex(n, seed) {
  const s = typeof seed === 'number' ? seed : hashSeed(String(seed));
  return Math.floor(mulberry32(s)() * n);
}

export function seededPick(arr, seed) {
  return arr[seededIndex(arr.length, seed)];
}

// ---------- 静态内容：原创通用文案，不编造任何真实回忆 ----------

/** 每日惊喜池（6 种）。hearts 为领取时顺带加的爱心（0 表示只得物品本身）。 */
export const SURPRISE_POOL = [
  { kind: 'note', title: '小纸条', text: '今天也要好好吃饭，好好休息，等你回来跟小猫讲讲今天的事', hearts: 0 },
  { kind: 'card', title: '表情卡', text: '（猫猫探头）今天有小猫陪着你，不用一个人扛着', hearts: 0 },
  { kind: 'heart', title: '爱心', text: '小猫把今天攒的喜欢都送给你，爱心+5', hearts: 5 },
  { kind: 'sticker', title: '贴纸·星星', text: '获得一枚星星贴纸，贴在今天的好心情上', hearts: 0 },
  { kind: 'quote', title: '幸运语录', text: '慢慢来也没关系，今天的小确幸正在路上', hearts: 0 },
  { kind: 'task', title: '小任务', text: '今天的小任务：出门时抬头看看天，回来告诉小猫你看到了什么', hearts: 0 },
];

/** 幸运签（8 条，通用文案）。 */
export const FORTUNES = [
  '今日宜慢慢来，好事正在路上',
  '会有意想不到的小确幸出现',
  '今天适合给喜欢的人发一条消息',
  '宜吃点好吃的，犒劳一下自己',
  '会遇到一件让你笑出来的小事',
  '宜早点休息，明天精神会更好',
  '今天的你，比昨天更厉害一点',
  '宜出门走走，换个心情',
];

/** 转盘 8 格。hearts 为爱心奖励；无 hearts 的格子给物品（sticker/kind）。 */
export const WHEEL_PRIZES = [
  { id: 'heart5', label: '爱心+5', hearts: 5 },
  { id: 'heart10', label: '爱心+10', hearts: 10 },
  { id: 'sticker-star', label: '贴纸·星星', sticker: '星星' },
  { id: 'sticker-bow', label: '贴纸·蝴蝶结', sticker: '蝴蝶结' },
  { id: 'note', label: '小纸条', kind: 'note' },
  { id: 'quote', label: '幸运语录', kind: 'quote' },
  { id: 'heart2', label: '爱心+2', hearts: 2 },
  { id: 'heart1', label: '爱心+1', hearts: 1 },
];

/** 每日固定任务（5 个）。reward.hearts 为完成后领取的爱心数。 */
export const TASKS = [
  { id: 'pet', title: '摸摸小猫', desc: '摸摸小猫、喂它或陪它玩一次', reward: { hearts: 3 } },
  { id: 'chat', title: '和 AI 聊聊天', desc: '和 AI 说上一句话', reward: { hearts: 3 } },
  { id: 'surprise', title: '打开今日惊喜', desc: '打开一次今日惊喜盒', reward: { hearts: 3 } },
  { id: 'game', title: '玩一个小游戏', desc: '玩任意一个小游戏', reward: { hearts: 3 } },
  { id: 'mood', title: '写下今日心情', desc: '记录一下今天的心情', reward: { hearts: 2 } },
];

/** 亲密度阶段（按阈值从低到高）。 */
export const STAGES = [
  { min: 0, name: '初次见面' },
  { min: 30, name: '熟悉阶段' },
  { min: 80, name: '亲密阶段' },
  { min: 150, name: '最好的伙伴' },
];

export function stageFor(intimacy) {
  let name = STAGES[0].name;
  for (const s of STAGES) if (intimacy >= s.min) name = s.name;
  return name;
}

/** 等级 = floor(亲密度/40)+1，上限 10。 */
export function levelFor(intimacy) {
  return Math.min(10, Math.max(1, Math.floor(intimacy / 40) + 1));
}

// ---------- 猫咪互动奖励 ----------

/** 互动奖励：hearts 爱心 / intimacy 亲密度 / state 互动后的即时状态。 */
export const interactGains = {
  pet: { hearts: 2, intimacy: 3, state: '开心' },
  feed: { hearts: 3, intimacy: 3, state: '满足' },
  sleep: { hearts: 1, intimacy: 2, state: '困倦' },
  play: { hearts: 3, intimacy: 4, state: '兴奋' },
};

export const INTERACT_COOLDOWN_MS = 10 * 1000; // 同一动作 10 秒内重复不重复给奖励
const RECENT_INTERACT_MS = 30 * 60 * 1000; // 互动后 30 分钟内，deriveState 优先用互动后状态
const IDLE_HUNGRY_MS = 6 * 60 * 60 * 1000; // 空闲 >= 6 小时 → 饥饿

/**
 * 派生猫咪当前状态（纯计算）。
 * 顺序：互动后 30 分钟内 → 互动后状态；空闲 >= 6 小时 → 饥饿；
 * 上海时间 22:00–07:00 → 困倦；否则好奇。
 */
export function deriveState(cat, now = new Date()) {
  const at = now instanceof Date ? now : new Date(now);
  if (cat?.last_interact_at) {
    const gap = at.getTime() - new Date(cat.last_interact_at).getTime();
    if (gap >= 0 && gap < RECENT_INTERACT_MS) return cat.state || '开心';
    if (gap >= IDLE_HUNGRY_MS) return '饥饿';
  }
  const h = shanghaiHour(at);
  if (h >= 22 || h < 7) return '困倦';
  return '好奇';
}

// ---------- 错误 ----------

function fail(code, message) {
  const e = new Error(message);
  e.code = code;
  return e;
}

// ---------- 猫咪状态读写 ----------

function normalizeCat(row) {
  if (!row) return null;
  let lastActions = {};
  try { lastActions = JSON.parse(row.last_actions || '{}') || {}; } catch { lastActions = {}; }
  return {
    id: row.id,
    state: row.state,
    mood: row.mood,
    intimacy: row.intimacy,
    hearts: row.hearts,
    last_interact_at: row.last_interact_at,
    last_actions: lastActions,
    updated_at: row.updated_at,
  };
}

/** 取猫咪单行（id=1）；无行则建默认行（state 开心）。返回归一化对象。 */
export async function getCat() {
  let row = await get('SELECT * FROM cat_state WHERE id = 1');
  if (!row) {
    const now = nowIso();
    await run(
      "INSERT INTO cat_state (id, state, mood, intimacy, hearts, last_interact_at, last_actions, updated_at) VALUES (1, '开心', '开心', 0, 0, NULL, '{}', ?) ON CONFLICT(id) DO NOTHING",
      [now]
    );
    row = await get('SELECT * FROM cat_state WHERE id = 1');
  }
  return normalizeCat(row);
}

async function addHearts(n) {
  if (!n) return getCat();
  await getCat(); // 确保行存在
  await run('UPDATE cat_state SET hearts = hearts + ?, updated_at = ? WHERE id = 1', [n, nowIso()]);
  return getCat();
}

/**
 * 互动。now 仅供测试注入时间，默认当前时间。
 * 返回 { cat, gained: {hearts, intimacy}, rewarded }。
 * 同一动作 10 秒内重复：状态照常更新，但不重复给奖励（滑动窗口：每次互动都刷新该动作时间戳）。
 * 发奖时顺手在 daily_records 写 kind='interact:<action>'（(date, kind) 主键去重，同日同动作只记一条）。
 */
export async function doInteract(action, now = new Date()) {
  const gains = interactGains[action];
  if (!gains) throw fail('bad_request', `未知互动动作：${action}`);
  const at = now instanceof Date ? now : new Date(now);
  const atIso = at.toISOString();
  const cat = await getCat();
  const last = cat.last_actions?.[action];
  const rewarded = !(last && (at.getTime() - new Date(last).getTime()) < INTERACT_COOLDOWN_MS);
  const actions = { ...cat.last_actions, [action]: atIso };
  const hearts = cat.hearts + (rewarded ? gains.hearts : 0);
  const intimacy = cat.intimacy + (rewarded ? gains.intimacy : 0);
  await run(
    'UPDATE cat_state SET state = ?, mood = ?, intimacy = ?, hearts = ?, last_interact_at = ?, last_actions = ?, updated_at = ? WHERE id = 1',
    [gains.state, gains.state, intimacy, hearts, atIso, JSON.stringify(actions), atIso]
  );
  if (rewarded) {
    const date = todayStr(at);
    await run(
      'INSERT INTO daily_records (date, kind, payload, created_at) VALUES (?, ?, ?, ?) ON CONFLICT(date, kind) DO NOTHING',
      [date, `interact:${action}`, JSON.stringify({ action, date }), atIso]
    );
  }
  return {
    cat: await getCat(),
    gained: rewarded ? { hearts: gains.hearts, intimacy: gains.intimacy } : { hearts: 0, intimacy: 0 },
    rewarded,
  };
}

// ---------- 每日 ----------

/**
 * 任务完成条件校验（只查真实记录）：
 * - pet：以 daily_records 当日 kind='interact:pet' / 'interact:feed' / 'interact:play' 为准
 *   （doInteract 发奖时写，(date, kind) 主键保证同日同动作只记一条）。
 * - chat：当日（上海日期窗口）messages 表 role='user' >= 1 条。
 * - surprise：当日 daily_records kind='surprise' 已领。
 * - game：当日（上海日期窗口）game_scores >= 1 条。
 * - mood：当日 mood_entries 有记录。
 */
export async function checkTaskDone(date, taskId) {
  if (!isValidDateStr(date)) throw fail('bad_request', `日期格式应为 YYYY-MM-DD：${date}`);
  if (taskId === 'pet') {
    const row = await get(
      "SELECT 1 AS x FROM daily_records WHERE date = ? AND kind IN ('interact:pet', 'interact:feed', 'interact:play') LIMIT 1",
      [date]
    );
    return !!row;
  }
  if (taskId === 'chat') {
    const [s, e] = shanghaiDayRange(date);
    const row = await get(
      "SELECT COUNT(*) AS n FROM messages WHERE role = 'user' AND created_at >= ? AND created_at < ?",
      [s, e]
    );
    return Number(row?.n || 0) > 0;
  }
  if (taskId === 'surprise') {
    const row = await get("SELECT 1 AS x FROM daily_records WHERE date = ? AND kind = 'surprise' LIMIT 1", [date]);
    return !!row;
  }
  if (taskId === 'game') {
    const [s, e] = shanghaiDayRange(date);
    const row = await get(
      'SELECT COUNT(*) AS n FROM game_scores WHERE played_at >= ? AND played_at < ?',
      [s, e]
    );
    return Number(row?.n || 0) > 0;
  }
  if (taskId === 'mood') {
    const row = await get('SELECT 1 AS x FROM mood_entries WHERE date = ? LIMIT 1', [date]);
    return !!row;
  }
  throw fail('bad_request', `未知任务：${taskId}`);
}

/** 当日总览：{ date, surprise: {claimed, reward}, tasks: [{id,title,desc,done,claimed,reward}], fortune: {drawn, text} } */
export async function getDaily(date = todayStr()) {
  if (!isValidDateStr(date)) throw fail('bad_request', `日期格式应为 YYYY-MM-DD：${date}`);
  const sRow = await get("SELECT payload FROM daily_records WHERE date = ? AND kind = 'surprise'", [date]);
  const fRow = await get("SELECT payload FROM daily_records WHERE date = ? AND kind = 'fortune'", [date]);
  const tasks = [];
  for (const t of TASKS) {
    const done = await checkTaskDone(date, t.id);
    const cRow = await get('SELECT 1 AS x FROM daily_records WHERE date = ? AND kind = ?', [date, `task:${t.id}`]);
    tasks.push({ id: t.id, title: t.title, desc: t.desc, done, claimed: !!cRow, reward: t.reward });
  }
  let surpriseReward = null;
  if (sRow) { try { surpriseReward = JSON.parse(sRow.payload).reward; } catch { surpriseReward = null; } }
  let fortuneText = null;
  if (fRow) { try { fortuneText = JSON.parse(fRow.payload).text; } catch { fortuneText = null; } }
  return {
    date,
    surprise: { claimed: !!sRow, reward: surpriseReward },
    tasks,
    fortune: { drawn: !!fRow, text: fortuneText },
  };
}

/** 领今日惊喜：同日只能领一次（daily_records (date, kind) 唯一键原子防重），奖励按日期确定性抽取。 */
export async function claimSurprise(date = todayStr()) {
  if (!isValidDateStr(date)) throw fail('bad_request', `日期格式应为 YYYY-MM-DD：${date}`);
  const reward = seededPick(SURPRISE_POOL, `surprise:${date}`);
  const r = await run(
    'INSERT INTO daily_records (date, kind, payload, created_at) VALUES (?, ?, ?, ?) ON CONFLICT(date, kind) DO NOTHING',
    [date, 'surprise', JSON.stringify({ reward }), nowIso()]
  );
  if (r.changes === 0) throw fail('already_claimed', '今日惊喜已领取');
  if (reward.hearts) await addHearts(reward.hearts);
  return { date, reward };
}

/** 领任务奖励：先校验完成条件（真实记录），再发奖；(date, kind) 唯一键防重复领。 */
export async function claimTask(date = todayStr(), taskId) {
  if (!isValidDateStr(date)) throw fail('bad_request', `日期格式应为 YYYY-MM-DD：${date}`);
  const task = TASKS.find((t) => t.id === taskId);
  if (!task) throw fail('bad_request', `未知任务：${taskId}`);
  if (!(await checkTaskDone(date, taskId))) throw fail('not_ready', `任务尚未完成：${taskId}`);
  const r = await run(
    'INSERT INTO daily_records (date, kind, payload, created_at) VALUES (?, ?, ?, ?) ON CONFLICT(date, kind) DO NOTHING',
    [date, `task:${taskId}`, JSON.stringify({ taskId, reward: task.reward }), nowIso()]
  );
  if (r.changes === 0) throw fail('already_claimed', `任务奖励今日已领取：${taskId}`);
  const cat = await addHearts(task.reward.hearts);
  return { date, taskId, reward: task.reward, cat };
}

/** 抽幸运签：同日同签（按日期确定性抽取并落库，重复抽返回已存的同一条）。 */
export async function drawFortune(date = todayStr()) {
  if (!isValidDateStr(date)) throw fail('bad_request', `日期格式应为 YYYY-MM-DD：${date}`);
  const index = seededIndex(FORTUNES.length, `fortune:${date}`);
  const text = FORTUNES[index];
  const r = await run(
    'INSERT INTO daily_records (date, kind, payload, created_at) VALUES (?, ?, ?, ?) ON CONFLICT(date, kind) DO NOTHING',
    [date, 'fortune', JSON.stringify({ text, index }), nowIso()]
  );
  if (r.changes === 0) {
    const row = await get("SELECT payload FROM daily_records WHERE date = ? AND kind = 'fortune'", [date]);
    try {
      const p = JSON.parse(row.payload);
      return { date, text: p.text, index: p.index, drawn: true };
    } catch { /* 落库损坏时返回本次抽取 */ }
  }
  return { date, text, index, drawn: true };
}

// ---------- 小游戏 ----------

/** 记一条游戏分数。detail 可为字符串或对象（对象存 JSON）。返回新行。 */
export async function recordGameScore(game, score, detail) {
  if (!game || typeof game !== 'string') throw fail('bad_request', '需要 game');
  if (typeof score !== 'number' || !Number.isFinite(score) || score < 0) {
    throw fail('bad_request', 'score 应为 >= 0 的数字');
  }
  const detailStr = detail == null ? null : (typeof detail === 'string' ? detail : JSON.stringify(detail));
  const playedAt = nowIso();
  const id = await insertReturning(
    'INSERT INTO game_scores (game, score, detail, played_at) VALUES (?, ?, ?, ?)',
    [game, Math.trunc(score), detailStr, playedAt]
  );
  return { id, game, score: Math.trunc(score), detail: detailStr, played_at: playedAt };
}

export async function listGameScores(game, limit = 50) {
  const n = Math.min(Math.max(Number(limit) || 50, 1), 200);
  if (game) return query('SELECT * FROM game_scores WHERE game = ? ORDER BY id DESC LIMIT ' + n, [game]);
  return query('SELECT * FROM game_scores ORDER BY id DESC LIMIT ' + n, []);
}

// 转盘服务端冷却（进程内记忆上次转动时间）。
let lastSpinAtMs = 0;
export const WHEEL_COOLDOWN_MS = 3000;

/** 转盘：服务端 3 秒冷却；结果写入 game_scores（game='wheel'），爱心奖励加到猫咪身上。 */
export async function spinWheel() {
  const nowMs = Date.now();
  if (nowMs - lastSpinAtMs < WHEEL_COOLDOWN_MS) throw fail('cooldown', '转盘冷却中，请稍后再试');
  lastSpinAtMs = nowMs;
  const prize = WHEEL_PRIZES[Math.floor(Math.random() * WHEEL_PRIZES.length)];
  await recordGameScore('wheel', prize.hearts || 0, prize);
  const cat = prize.hearts ? await addHearts(prize.hearts) : await getCat();
  return { prize, cat };
}

// ---------- 心情 ----------

/** 保存当日心情：同日 upsert（mood_entries.date 唯一）。返回该行。 */
export async function saveMood(date = todayStr(), mood, note) {
  if (!isValidDateStr(date)) throw fail('bad_request', `日期格式应为 YYYY-MM-DD：${date}`);
  if (!mood || typeof mood !== 'string') throw fail('bad_request', '需要 mood');
  const now = nowIso();
  await run(
    'INSERT INTO mood_entries (date, mood, note, created_at, updated_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(date) DO UPDATE SET mood = EXCLUDED.mood, note = EXCLUDED.note, updated_at = EXCLUDED.updated_at',
    [date, mood, note || null, now, now]
  );
  return get('SELECT * FROM mood_entries WHERE date = ?', [date]);
}

/** 最近 7 天的心情（按日期升序，便于前端直接画走势）。 */
export async function getMoods() {
  const rows = await query('SELECT * FROM mood_entries ORDER BY date DESC LIMIT 7');
  return rows.reverse();
}
