// auth.js — 极简访问控制
// token = 密码 sha256 hex；密码 hash 只存 model_config 表（key=auth_password_hash）。
// 无密码时开放；设密码后除 /healthz、/api/auth/* 外所有 /api/* 需 Authorization: Bearer <token>。
import crypto from 'node:crypto';
import { get, run, nowIso } from './db.js';

export function sha256Hex(text) {
  return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

export async function getPasswordHash() {
  const row = await get("SELECT value FROM model_config WHERE key = 'auth_password_hash'");
  return row?.value || null;
}

export async function hasPassword() {
  return (await getPasswordHash()) !== null;
}

export function tokensEqual(a, b) {
  if (!a || !b) return false;
  const ba = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

export async function setPassword(password) {
  const hash = sha256Hex(password);
  const now = nowIso();
  const existing = await getPasswordHash();
  if (existing) {
    await run("UPDATE model_config SET value = ?, updated_at = ? WHERE key = 'auth_password_hash'", [hash, now]);
  } else {
    await run("INSERT INTO model_config (key, value, updated_at) VALUES ('auth_password_hash', ?, ?)", [hash, now]);
  }
  return hash;
}

/** Express 中间件：需要鉴权时校验 Bearer token */
export function authMiddleware(req, res, next) {
  if (req.path === '/healthz' || req.path.startsWith('/api/auth/')) return next();
  if (req.path === '/' || !req.path.startsWith('/api/')) return next();
  getPasswordHash()
    .then((hash) => {
      if (!hash) return next();
      const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
      if (!tokensEqual(token, hash)) {
        return res.status(401).json({ error: 'unauthorized', message: '需要登录（Authorization: Bearer <token>）' });
      }
      return next();
    })
    .catch(next);
}
