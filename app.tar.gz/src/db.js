// db.js — 数据库适配层
// DATABASE_URL 以 postgres:// 开头时用 pg（生产），否则用 Node 内置 node:sqlite（本地，数据在 data/app.db）。
// 对外统一用 `?` 占位符；pg 一侧自动转成 $1..$n。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(__dirname, '..');

export const dialect = (process.env.DATABASE_URL || '').startsWith('postgres://') ? 'pg' : 'sqlite';

let sqliteDb = null;
let pgPool = null;

function readSchema() {
  const file = dialect === 'pg' ? 'schema.pg.sql' : 'schema.sqlite.sql';
  return fs.readFileSync(path.join(APP_ROOT, 'db', file), 'utf8');
}

export async function initDb() {
  if (dialect === 'pg') {
    const { Pool } = await import('pg');
    pgPool = new Pool({ connectionString: process.env.DATABASE_URL });
    await pgPool.query(readSchema());
  } else {
    const dataDir = path.join(APP_ROOT, 'data');
    fs.mkdirSync(dataDir, { recursive: true });
    sqliteDb = new DatabaseSync(path.join(dataDir, 'app.db'));
    sqliteDb.exec(readSchema());
  }
  const { seedIfEmpty } = await import('./seed.js');
  await seedIfEmpty();
}

function toPg(sql, params) {
  let i = 0;
  return { text: sql.replace(/\?/g, () => `$${++i}`), values: params };
}

/** SELECT -> 行数组 */
export async function query(sql, params = []) {
  if (dialect === 'pg') {
    const { text, values } = toPg(sql, params);
    const res = await pgPool.query(text, values);
    return res.rows;
  }
  return sqliteDb.prepare(sql).all(...params);
}

/** SELECT 单行（或 undefined） */
export async function get(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0];
}

/** INSERT/UPDATE/DELETE -> { changes, lastInsertRowid } */
export async function run(sql, params = []) {
  if (dialect === 'pg') {
    const { text, values } = toPg(sql, params);
    const res = await pgPool.query(text, values);
    return { changes: res.rowCount ?? 0, lastInsertRowid: res.rows?.[0]?.id ?? null };
  }
  const info = sqliteDb.prepare(sql).run(...params);
  return { changes: info.changes, lastInsertRowid: info.lastInsertRowid ?? null };
}

/** INSERT 并返回新行 id；pg 一侧自动追加 RETURNING id */
export async function insertReturning(sql, params = []) {
  if (dialect === 'pg') {
    const { text, values } = toPg(sql.replace(/;?\s*$/, ' RETURNING id'), params);
    const res = await pgPool.query(text, values);
    return res.rows[0]?.id;
  }
  const info = sqliteDb.prepare(sql).run(...params);
  return info.lastInsertRowid;
}

export function nowIso() {
  return new Date().toISOString();
}

export async function closeDb() {
  if (pgPool) await pgPool.end();
  if (sqliteDb) sqliteDb.close();
}
