// server.js — ai-boy-v3 后端入口（V3.0 独立 AI 男生）
// 只服务本项目；不共用小米/可爱的乖乖的 Key、数据库、数据。
import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initDb, dialect, query, get, run, insertReturning, nowIso } from './src/db.js';
import { getPersonaSections, DEFAULT_MODEL_CONFIG } from './src/seed.js';
import { chatCompletionStream, estimateTokens, makeDeepSeekError } from './src/deepseek.js';
import { extractCandidates, saveCandidates, retrieveRelevant } from './src/memory.js';
import { checkDrift, recordDrift, driftReinforcement } from './src/drift.js';
import { authMiddleware, hasPassword, setPassword, sha256Hex, tokensEqual, getPasswordHash } from './src/auth.js';
import { getCat, doInteract, getDaily, claimSurprise, claimTask, drawFortune, recordGameScore, listGameScores, spinWheel, saveMood, getMoods, deriveState, levelFor, stageFor, todayStr } from './src/cat.js';
import { getLedger, getOutfit, setOutfit, getRoom, setRoom, getGarden, plantFlower, waterPlot, harvestPlot, nextEvent, favoriteEvent, listLetters, drawLetter, setLetterStatus } from './src/phase2.js';
import {
  EMOTION_LABELS, emotionContextText,
  listManualMemories, createManualMemory, updateManualMemory, deleteManualMemory,
  setMessageFavorite, listFavorites,
  listAnniversaries, createAnniversary, updateAnniversary, deleteAnniversary,
  generateBedtimeStory, goodnightLetter, getDailyReport,
} from './src/phase3.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3100);
const VERSION = '1.0.0';

const app = express();
app.use(express.json({ limit: '1mb' }));

// ---------- 静态服务：public 由前端子代理写；不存在也不 500 ----------
const publicDir = path.join(__dirname, 'public');
app.use(express.static(publicDir));
app.get('/', (req, res) => {
  const index = path.join(publicDir, 'index.html');
  if (fs.existsSync(index)) return res.sendFile(index);
  return res.type('html').send(
    '<!doctype html><meta charset="utf-8"><title>ai-boy-v3</title><h1>ai-boy-v3 后端运行中</h1><p>前端 public/ 尚未就绪；API 见 /healthz。</p>'
  );
});

app.get('/healthz', (req, res) => res.json({ ok: true, service: 'ai-boy-v3', version: VERSION }));

// ---------- 鉴权 ----------
app.use(authMiddleware);

app.get('/api/auth/status', async (req, res) => {
  const hp = await hasPassword();
  res.json({ hasPassword: hp, locked: hp });
});

app.post('/api/auth/setup', async (req, res) => {
  if (await hasPassword()) return res.status(400).json({ error: 'password_already_set', message: '密码已设置' });
  const { password } = req.body || {};
  if (!password || typeof password !== 'string' || password.length < 4) {
    return res.status(400).json({ error: 'bad_password', message: '密码至少 4 位' });
  }
  const token = await setPassword(password);
  res.json({ token });
});

app.post('/api/auth/login', async (req, res) => {
  const { password } = req.body || {};
  const hash = await getPasswordHash();
  if (!hash) return res.json({ token: null, message: '未设置密码，直接开放' });
  if (!password || !tokensEqual(sha256Hex(password), hash)) {
    return res.status(401).json({ error: 'bad_password', message: '密码错误' });
  }
  res.json({ token: hash });
});

// ---------- 人格 ----------
app.get('/api/persona', async (req, res) => {
  const sections = await getPersonaSections();
  res.json({ sections: sections.map((s) => ({ key: s.key, title: s.title, content: s.content })) });
});

app.put('/api/persona', async (req, res) => {
  const { key, content } = req.body || {};
  if (!key || typeof content !== 'string') return res.status(400).json({ error: 'bad_request', message: '需要 key 和 content' });
  const existing = await get('SELECT key FROM persona_config WHERE key = ?', [key]);
  if (!existing) return res.status(404).json({ error: 'not_found', message: `没有 ${key} 这一节` });
  await run('UPDATE persona_config SET content = ?, updated_at = ? WHERE key = ?', [content, nowIso(), key]);
  res.json({ ok: true, key });
});

// ---------- 模型配置 ----------
async function readModelConfig() {
  const rows = await query('SELECT key, value FROM model_config');
  const cfg = { ...DEFAULT_MODEL_CONFIG };
  for (const r of rows) cfg[r.key] = r.value;
  return {
    hasKey: Boolean(process.env.DEEPSEEK_API_KEY),
    model: cfg.model,
    baseUrl: cfg.baseUrl,
    temperature: Number(cfg.temperature),
    maxTokens: Number(cfg.maxTokens),
    timeoutMs: Number(cfg.timeoutMs),
  };
}

app.get('/api/config', async (req, res) => res.json(await readModelConfig()));

app.put('/api/config', async (req, res) => {
  const { model, baseUrl, temperature, maxTokens, timeoutMs } = req.body || {};
  const updates = { model, baseUrl, temperature, maxTokens, timeoutMs };
  const now = nowIso();
  for (const [k, v] of Object.entries(updates)) {
    if (v === undefined) continue;
    const val = String(v);
    const existing = await get('SELECT key FROM model_config WHERE key = ?', [k]);
    if (existing) await run('UPDATE model_config SET value = ?, updated_at = ? WHERE key = ?', [val, now, k]);
    else await run('INSERT INTO model_config (key, value, updated_at) VALUES (?, ?, ?)', [k, val, now]);
  }
  res.json(await readModelConfig());
});

// ---------- 会话 ----------
function newSessionId() {
  return crypto.randomUUID();
}

app.get('/api/sessions', async (req, res) => {
  const rows = await query('SELECT * FROM sessions ORDER BY updated_at DESC');
  res.json(rows);
});

app.post('/api/sessions', async (req, res) => {
  const { title } = req.body || {};
  const id = newSessionId();
  const now = nowIso();
  await run('INSERT INTO sessions (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)', [id, title || '新的聊天', now, now]);
  res.status(201).json({ id, title: title || '新的聊天', created_at: now, updated_at: now });
});

app.get('/api/sessions/:id', async (req, res) => {
  const s = await get('SELECT * FROM sessions WHERE id = ?', [req.params.id]);
  if (!s) return res.status(404).json({ error: 'not_found', message: '会话不存在' });
  res.json(s);
});

app.delete('/api/sessions/:id', async (req, res) => {
  await run('DELETE FROM messages WHERE session_id = ?', [req.params.id]);
  await run('DELETE FROM summaries WHERE session_id = ?', [req.params.id]);
  await run('DELETE FROM sessions WHERE id = ?', [req.params.id]);
  res.json({ ok: true });
});

app.post('/api/sessions/:id/clear', async (req, res) => {
  await run('DELETE FROM messages WHERE session_id = ?', [req.params.id]);
  await run("UPDATE sessions SET updated_at = ? WHERE id = ?", [nowIso(), req.params.id]);
  res.json({ ok: true });
});

// ---------- 消息 ----------
function publicMessage(m) {
  return { id: m.id, session_id: m.session_id, role: m.role, content: m.content, created_at: m.created_at };
}

app.get('/api/sessions/:id/messages', async (req, res) => {
  const rows = await query('SELECT * FROM messages WHERE session_id = ? ORDER BY id ASC', [req.params.id]);
  res.json(rows.map(publicMessage));
});

app.delete('/api/sessions/:id/messages/:mid', async (req, res) => {
  await run('DELETE FROM messages WHERE id = ? AND session_id = ?', [req.params.mid, req.params.id]);
  res.json({ ok: true });
});

// ---------- 系统提示组装 ----------
async function buildSystemPrompt(sessionId, userText) {
const sections = await getPersonaSections();
const personaText = sections.map((s) => `\n${s.content}`).join('\n\n');

const { memories, samples} = await retrieveRelevant(sessionId, userText, 5);
const summaryRow = await get('SELECT content FROM summaries WHERE session_id =?', [sessionId]);

let prompt = personaText;
if (memories.length > 0) {
prompt += '\n\n\n' + memories.map((m) => `- [${m.category}] ${m.content}`).join('\n');
}
if (samples.length > 0) {
prompt += '\n\n\n' + samples.map((s) => `- [${s.category}] ${s.content}`).join('\n');
}
if (summaryRow?.content) {
prompt += `\n\n\n${summaryRow.content}`;
}
prompt += driftReinforcement(sessionId);

prompt += '\n\n只回一到两句短句，口语，不加句号，不说教，不用客服腔。情绪或事情多时可拆成用换行分隔的几条短句。';
return prompt;
}

// ---------- 聊天（SSE 流式） ----------
// emotion（可选）：只作这一次聊天的上下文——往发给 DeepSeek 的 messages 数组里
// 追加 ONE 条 user 角色上下文消息，绝不写入 messages 表、不污染聊天历史；
// buildSystemPrompt 与系统提示词完全不动；没有 emotion 时行为与以前完全一致。
async function runChat(sessionId, userContent, clientId, res, emotion = null) {
const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);
const cfg = await readModelConfig();

// 1) clientId 去重：同一 clientId 重复提交不建第二条用户消息、不重复调模型，直接返回原结果
if (clientId) {
const priorUser = await get('SELECT * FROM messages WHERE session_id =? AND client_id =? AND role =? ORDER BY id ASC', [sessionId, clientId, 'user']);
if (priorUser) {
const priorAssistant = await get('SELECT * FROM messages WHERE session_id =? AND client_id =? AND role =? ORDER BY id ASC', [sessionId, clientId, 'assistant']);
if (priorAssistant) {
// 重放原结果（分块发 delta，保持前端行为一致）
const text = priorAssistant.content || '';
for (let i = 0; i < text.length; i += 20) send({ type: 'delta', text: text.slice(i, i + 20)});
let memN = 0;
try { memN = JSON.parse(priorAssistant.meta || '{}').memoryCandidates || 0;} catch { /* ignore */}
send({ type: 'done', messageId: String(priorAssistant.id), memoryCandidates: memN, deduped: true});
return res.end();
}
// 只有用户消息、尚无 AI 回复：说明上一次生成中断，直接继续生成（不重复建用户消息）
}
}

// 2) 无 Key 时直接诚实报错，不建消息、不编假回复
if (!cfg.hasKey) {
send({ type: 'error', code: 'NO_API_KEY', message: '未配置 DEEPSEEK_API_KEY（只放服务器环境变量），无法聊天'});
return res.end();
}

// 3) 保存用户消息（去重情况下不重复建）
let userMsgId = null;
if (clientId) {
const priorUser = await get('SELECT * FROM messages WHERE session_id =? AND client_id =? AND role =? ORDER BY id ASC', [sessionId, clientId, 'user']);
if (priorUser) userMsgId = priorUser.id;
}
if (!userMsgId) {
userMsgId = await insertReturning(
'INSERT INTO messages (session_id, role, content, client_id, meta, created_at) VALUES (?,?,?,?,?,?)',
[sessionId, 'user', userContent, clientId || null, null, nowIso()]
);
}
await run('UPDATE sessions SET updated_at =? WHERE id =?', [nowIso(), sessionId]);

// 4) 组装上下文并调 DeepSeek（流式）
const history = await query('SELECT role, content FROM messages WHERE session_id =? ORDER BY id DESC LIMIT 12', [sessionId]);
history.reverse();
const systemPrompt = await buildSystemPrompt(sessionId, userContent);
// 情绪上下文只追加到发给模型的数组里，不落库（见 runChat 头注释）。
const apiMessages = history.map((m) => ({ role: m.role, content: m.content }));
if (emotion) apiMessages.push({ role: 'user', content: emotionContextText(emotion) });

let full = '';
let promptTokensEstimate = 0;
try {
const result = await chatCompletionStream({
systemPrompt,
messages: apiMessages,
config: cfg,
onDelta: (delta) => {
full += delta;
send({ type: 'delta', text: delta});
},
});
promptTokensEstimate = result.promptTokensEstimate;
} catch (e) {
const code = e?.code || 'DEEPSEEK_ERROR';
send({ type: 'error', code, message: e?.message || 'DeepSeek 请求失败'});
return res.end();
}

if (!full.trim()) {
send({ type: 'error', code: 'DEEPSEEK_ERROR', message: 'DeepSeek 返回了空回复'});
return res.end();
}

// 5) 漂移自查：只记日志 + 加强下一条系统提示，不改写已生成的回复
const historyTexts = history.map((m) => m.content);
const drift = checkDrift(full, historyTexts);
if (drift.drift) recordDrift(sessionId, drift);

// 6) 保存 AI 回复 + 自动提取记忆候选
const assistantId = await insertReturning(
'INSERT INTO messages (session_id, role, content, client_id, meta, created_at) VALUES (?,?,?,?,?,?)',
[sessionId, 'assistant', full, clientId || null, JSON.stringify({ promptTokensEstimate, drift: drift.drift}), nowIso()]
);

const candidates = extractCandidates([{ role: 'user', content: userContent}]);
const stats = await saveCandidates(candidates);
const memoryCandidates = candidates.length;

send({ type: 'done', messageId: String(assistantId), memoryCandidates, promptTokensEstimate, drift: drift.drift, memoryStats: stats});
return res.end();
}

app.post('/api/sessions/:id/chat', async (req, res) => {
const { content, clientId, emotion } = req.body || {};
if (!content || typeof content!== 'string' ||!content.trim()) {
return res.status(400).json({ error: 'bad_request', message: '需要 content'});
}
if (emotion !== undefined && emotion !== null && !(emotion in EMOTION_LABELS)) {
return res.status(400).json({ error: 'bad_request', message: `emotion 只许 ${Object.keys(EMOTION_LABELS).join('/')}` });
}
const session = await get('SELECT id FROM sessions WHERE id =?', [req.params.id]);
if (!session) return res.status(404).json({ error: 'not_found', message: '会话不存在'});

res.writeHead(200, {
'Content-Type': 'text/event-stream',
'Cache-Control': 'no-cache',
Connection: 'keep-alive',
});
try {
await runChat(req.params.id, content.trim(), clientId || null, res, emotion || null);
} catch (e) {
console.error('[chat]', e);
try {
res.write(`data: ${JSON.stringify({ type: 'error', code: 'DEEPSEEK_ERROR', message: String(e?.message || e)})}\n\n`);
res.end();
} catch { /* 连接已断 */}
}
});

// ---------- regenerate ----------
app.post('/api/sessions/:id/regenerate', async (req, res) => {
const { messageId} = req.body || {};
let target = null;
if (messageId) {
target = await get('SELECT * FROM messages WHERE id =? AND session_id =? AND role =?', [messageId, req.params.id, 'assistant']);
} else {
target = await get('SELECT * FROM messages WHERE session_id =? AND role =? ORDER BY id DESC', [req.params.id, 'assistant']);
}
if (!target) return res.status(404).json({ error: 'not_found', message: '没有可重新生成的 AI 回复'});

// 找到它之前最后一条用户消息
const lastUser = await get('SELECT * FROM messages WHERE session_id =? AND role =? AND id <? ORDER BY id DESC', [req.params.id, 'user', target.id]);
if (!lastUser) return res.status(400).json({ error: 'bad_request', message: '找不到对应的用户消息'});

await run('DELETE FROM messages WHERE id =?', [target.id]);

res.writeHead(200, {
'Content-Type': 'text/event-stream',
'Cache-Control': 'no-cache',
Connection: 'keep-alive',
});
try {
await runChat(req.params.id, lastUser.content, null, res);
} catch (e) {
console.error('[regenerate]', e);
try {
res.write(`data: ${JSON.stringify({ type: 'error', code: 'DEEPSEEK_ERROR', message: String(e?.message || e)})}\n\n`);
res.end();
} catch { /* ignore */}
}
});

// ---------- 记忆 ----------
app.get('/api/memories', async (req, res) => {
const { status, category} = req.query;
let sql = 'SELECT * FROM memories WHERE 1=1';
const params = [];
if (status) { sql += ' AND status =?'; params.push(status);}
if (category) { sql += ' AND category =?'; params.push(category);}
sql += ' ORDER BY importance DESC, updated_at DESC';
res.json(await query(sql, params));
});

app.get('/api/memories/pending', async (req, res) => {
res.json(await query("SELECT * FROM memories WHERE status = 'pending' ORDER BY updated_at DESC"));
});

app.post('/api/memories', async (req, res) => {
const { content, category, confidence, importance, source, status, confirmed} = req.body || {};
if (!content ||!category) return res.status(400).json({ error: 'bad_request', message: '需要 content 和 category'});
const now = nowIso();
// confirmed=1 表示这条记忆由用户亲口确认过（信箱 AI 信只读这类记忆）。
// 兼容前端表单的 status:'confirmed' 写法；status 本身仍按原有约束只存 'active'。
const isConfirmed = (status === 'confirmed' || confirmed === 1 || confirmed === true || confirmed === '1') ? 1 : 0;
const id = await insertReturning(
'INSERT INTO memories (content, category, created_at, updated_at, source, confidence, importance, status, confirmed) VALUES (?,?,?,?,?,?,?,?,?)',
[content, category, now, now, source || 'manual', confidence?? 1, importance?? 70, 'active', isConfirmed]
);
res.status(201).json(await get('SELECT * FROM memories WHERE id =?', [id]));
});

app.put('/api/memories/:id', async (req, res) => {
const { content, category, confidence, importance, status, source, confirmed} = req.body || {};
const existing = await get('SELECT * FROM memories WHERE id =?', [req.params.id]);
if (!existing) return res.status(404).json({ error: 'not_found', message: '记忆不存在'});
// confirmed 显式传入时更新（0/1）；status 保持原有 CHECK 允许的值，不在此处改写。
const nextConfirmed = confirmed === undefined ? (existing.confirmed ?? 0)
  : (confirmed === 1 || confirmed === true || confirmed === '1' ? 1 : 0);
await run(
'UPDATE memories SET content =?, category =?, confidence =?, importance =?, status =?, source =?, confirmed =?, updated_at =? WHERE id =?',
[
content?? existing.content,
category?? existing.category,
confidence?? existing.confidence,
importance?? existing.importance,
status?? existing.status,
source?? existing.source,
nextConfirmed,
nowIso(),
req.params.id,
]
);
res.json(await get('SELECT * FROM memories WHERE id =?', [req.params.id]));
});

app.delete('/api/memories/:id', async (req, res) => {
await run('DELETE FROM memories WHERE id =?', [req.params.id]);
res.json({ ok: true});
});

// ---------- 语言样本 ----------
app.get('/api/samples', async (req, res) => {
const { category} = req.query;
if (category) return res.json(await query('SELECT * FROM language_samples WHERE category =? ORDER BY id', [category]));
res.json(await query('SELECT * FROM language_samples ORDER BY id'));
});

app.post('/api/samples', async (req, res) => {
const { category, content, context} = req.body || {};
if (!category ||!content) return res.status(400).json({ error: 'bad_request', message: '需要 category 和 content'});
const id = await insertReturning(
'INSERT INTO language_samples (category, content, context, source, created_at) VALUES (?,?,?,?,?)',
[category, content, context || null, '用户补充', nowIso()]
);
res.status(201).json(await get('SELECT * FROM language_samples WHERE id =?', [id]));
});

// ---------- 摘要 ----------
function localSummary(messages) {
const userLines = messages.filter((m) => m.role === 'user').map((m) => m.content);
const asstLines = messages.filter((m) => m.role === 'assistant').map((m) => m.content);
const lines = [
`本会话共 ${messages.length} 条消息（用户 ${userLines.length} 条，AI ${asstLines.length} 条）。`,
];
if (userLines.length > 0) lines.push('用户最近聊到：' + userLines.slice(-5).join(' / '));
if (asstLines.length > 0) lines.push('AI 最近回复：' + asstLines.slice(-3).join(' / '));
return lines.join('\n');
}

app.get('/api/sessions/:id/summary', async (req, res) => {
const row = await get('SELECT * FROM summaries WHERE session_id =?', [req.params.id]);
if (!row) return res.status(404).json({ error: 'not_found', message: '暂无摘要'});
res.json({ session_id: req.params.id, content: row.content, updated_at: row.updated_at});
});

app.post('/api/sessions/:id/summary', async (req, res) => {
const session = await get('SELECT id FROM sessions WHERE id =?', [req.params.id]);
if (!session) return res.status(404).json({ error: 'not_found', message: '会话不存在'});
const messages = await query('SELECT role, content FROM messages WHERE session_id =? ORDER BY id ASC', [req.params.id]);
const content = localSummary(messages);
const now = nowIso();
const existing = await get('SELECT id FROM summaries WHERE session_id =?', [req.params.id]);
if (existing) await run('UPDATE summaries SET content =?, updated_at =? WHERE session_id =?', [content, now, req.params.id]);
else await run('INSERT INTO summaries (session_id, content, created_at, updated_at) VALUES (?,?,?,?)', [req.params.id, content, now, now]);
res.json({ session_id: req.params.id, content, updated_at: now});
});

// ---------- 导出 / 备份 / 恢复 ----------
function formatTranscript(sessionTitle, messages) {
  const lines = [`【${sessionTitle || '聊天记录'}】`, ''];
for (const m of messages) {
const who = m.role === 'user'? '我': 'AI';
lines.push(`[${m.created_at}] ${who}：${m.content}`);
}
return lines.join('\n');
}

app.get('/api/export', async (req, res) => {
const { sessionId, all} = req.query;
let sessions = [];
if (all === '1') {
sessions = await query('SELECT * FROM sessions ORDER BY created_at ASC');
} else if (sessionId) {
const s = await get('SELECT * FROM sessions WHERE id =?', [sessionId]);
if (!s) return res.status(404).json({ error: 'not_found', message: '会话不存在'});
sessions = [s];
} else {
return res.status(400).json({ error: 'bad_request', message: '需要 sessionId 或 all=1'});
}
const parts = [];
for (const s of sessions) {
const msgs = await query('SELECT * FROM messages WHERE session_id =? ORDER BY id ASC', [s.id]);
parts.push(formatTranscript(s.title, msgs));
}
const filename = all === '1'? 'ai-boy-v3-全部聊天记录.txt': `ai-boy-v3-${sessionId}.txt`;
res.json({ format: 'txt', filename, content: parts.join('\n\n')});
});

const BACKUP_TABLES = ['users', 'sessions', 'messages', 'persona_config', 'memories', 'language_samples', 'summaries', 'model_config', 'cat_state', 'daily_records', 'game_scores', 'mood_entries', 'heart_ledger', 'collection', 'dress_state', 'room_state', 'garden_plots', 'letters', 'event_log', 'manual_memories', 'anniversaries'];

app.post('/api/backup', async (req, res) => {
const data = { service: 'ai-boy-v3', version: VERSION, exported_at: nowIso(), tables: {}};
for (const t of BACKUP_TABLES) {
data.tables[t] = await query(`SELECT * FROM ${t}`);
}
res.json(data);
});

app.post('/api/restore', async (req, res) => {
const { data} = req.body || {};
if (!data ||!data.tables) return res.status(400).json({ error: 'bad_request', message: '需要 { data: { tables: {...}}}'});
const restored = {};
for (const t of BACKUP_TABLES) {
const rows = data.tables[t];
if (!Array.isArray(rows)) continue;
// 先清空再写入（恢复是全量覆盖）
await run(`DELETE FROM ${t}`);
let count = 0;
for (const row of rows) {
const cols = Object.keys(row);
const placeholders = cols.map(() => '?').join(', ');
try {
await run(`INSERT INTO ${t} (${cols.join(', ')}) VALUES (${placeholders})`, cols.map((c) => row[c]));
count++;
} catch (e) {
console.warn(`[restore] skip ${t} row:`, e.message);
}
}
restored[t] = count;
}
res.json({ ok: true, restored});
});

// ---------- V4.0 第一阶段：猫咪小屋 / 每日 / 小游戏 / 心情（只追加，不动已有路由） ----------
function publicCat(cat) {
  return {
    id: cat.id,
    state: deriveState(cat),
    mood: cat.mood,
    intimacy: cat.intimacy,
    hearts: cat.hearts,
    level: levelFor(cat.intimacy),
    stage: stageFor(cat.intimacy),
    last_interact_at: cat.last_interact_at,
    last_actions: cat.last_actions,
    updated_at: cat.updated_at,
  };
}

function catError(res, e) {
  if (e?.code === 'already_claimed') return res.status(409).json({ error: 'already_claimed', message: e.message || '今日已领取' });
  if (e?.code === 'not_ready') return res.status(400).json({ error: 'not_ready', message: e.message || '任务尚未完成' });
  if (e?.code === 'cooldown') return res.status(429).json({ error: 'cooldown', message: e.message || '冷却中，请稍后再试' });
  if (e?.code === 'conflict') return res.status(409).json({ error: 'conflict', message: e.message || '冲突' });
  if (e?.code === 'event_limit') return res.status(409).json({ error: 'event_limit', message: e.message || '今日心动事件已达上限' });
  if (e?.code === 'not_found') return res.status(404).json({ error: 'not_found', message: e.message || '不存在' });
  if (e?.code === 'bad_request') return res.status(400).json({ error: 'bad_request', message: e.message || '请求不合法' });
  console.error('[cat]', e);
  return res.status(500).json({ error: 'internal_error', message: '服务器内部错误' });
}

function catDateParam(req) {
  const d = req.body?.date || req.query?.date;
  return d === undefined ? todayStr() : d;
}

app.get('/api/cat', async (req, res) => {
  try { res.json(publicCat(await getCat())); } catch (e) { catError(res, e); }
});

app.post('/api/cat/interact', async (req, res) => {
  try {
    const { action } = req.body || {};
    if (!action || typeof action !== 'string') return res.status(400).json({ error: 'bad_request', message: '需要 action' });
    const r = await doInteract(action);
    res.json({ cat: publicCat(r.cat), gained: r.gained, rewarded: r.rewarded, stageUp: r.stageUp || null });
  } catch (e) { catError(res, e); }
});

app.get('/api/daily', async (req, res) => {
  try { res.json(await getDaily(catDateParam(req))); } catch (e) { catError(res, e); }
});

app.post('/api/daily/surprise', async (req, res) => {
  try {
    const r = await claimSurprise(catDateParam(req));
    res.json({ date: r.date, claimed: true, reward: r.reward });
  } catch (e) { catError(res, e); }
});

app.post('/api/daily/tasks/:id/claim', async (req, res) => {
  try {
    const r = await claimTask(catDateParam(req), req.params.id);
    res.json({ date: r.date, id: r.taskId, claimed: true, reward: r.reward, hearts: r.cat.hearts });
  } catch (e) { catError(res, e); }
});

app.post('/api/daily/fortune', async (req, res) => {
  try {
    const r = await drawFortune(catDateParam(req));
    res.json({ date: r.date, drawn: true, text: r.text });
  } catch (e) { catError(res, e); }
});

app.get('/api/mood', async (req, res) => {
  try { res.json(await getMoods()); } catch (e) { catError(res, e); }
});

app.post('/api/mood', async (req, res) => {
  try {
    const { mood, note } = req.body || {};
    if (!mood || typeof mood !== 'string') return res.status(400).json({ error: 'bad_request', message: '需要 mood' });
    res.json(await saveMood(catDateParam(req), mood, note));
  } catch (e) { catError(res, e); }
});

app.post('/api/games/score', async (req, res) => {
  try {
    const { game, score, detail } = req.body || {};
    const row = await recordGameScore(game, score, detail);
    res.status(201).json(row);
  } catch (e) { catError(res, e); }
});

app.get('/api/games/scores', async (req, res) => {
  try { res.json(await listGameScores(req.query.game || null, req.query.limit)); } catch (e) { catError(res, e); }
});

app.post('/api/games/wheel', async (req, res) => {
  try {
    const r = await spinWheel();
    res.json({ prize: r.prize, cat: publicCat(r.cat), hearts: r.cat.hearts, collected: r.collected || null });
  } catch (e) { catError(res, e); }
});

// ---------- V4.0 第二阶段：爱心记账 / 换装 / 房间 / 花园 / 心动事件 / 神秘信箱（只追加，不动已有路由） ----------
app.get('/api/cat/ledger', async (req, res) => {
  try { res.json(await getLedger(req.query.limit)); } catch (e) { catError(res, e); }
});

app.get('/api/cat/outfit', async (req, res) => {
  try { res.json(await getOutfit()); } catch (e) { catError(res, e); }
});

app.put('/api/cat/outfit', async (req, res) => {
  try { res.json(await setOutfit(req.body?.outfit ?? req.body ?? {})); } catch (e) { catError(res, e); }
});

app.get('/api/room', async (req, res) => {
  try { res.json(await getRoom()); } catch (e) { catError(res, e); }
});

app.put('/api/room', async (req, res) => {
  try { res.json(await setRoom(req.body?.room ?? req.body ?? {})); } catch (e) { catError(res, e); }
});

app.get('/api/garden', async (req, res) => {
  try { res.json(await getGarden()); } catch (e) { catError(res, e); }
});

app.post('/api/garden/plant', async (req, res) => {
  try {
    const { slot, flower } = req.body || {};
    res.json(await plantFlower(slot, flower));
  } catch (e) { catError(res, e); }
});

app.post('/api/garden/water', async (req, res) => {
  try {
    const { slot } = req.body || {};
    res.json(await waterPlot(slot));
  } catch (e) { catError(res, e); }
});

app.post('/api/garden/harvest', async (req, res) => {
  try {
    const { slot } = req.body || {};
    const r = await harvestPlot(slot);
    res.json({ ...r, cat: publicCat(r.cat) });
  } catch (e) { catError(res, e); }
});

app.get('/api/events/next', async (req, res) => {
  try { res.json(await nextEvent()); } catch (e) { catError(res, e); }
});

app.post('/api/events/:id/favorite', async (req, res) => {
  try {
    const { favorite } = req.body || {};
    res.json(await favoriteEvent(req.params.id, favorite));
  } catch (e) { catError(res, e); }
});

app.get('/api/letters', async (req, res) => {
  try { res.json(await listLetters()); } catch (e) { catError(res, e); }
});

app.post('/api/letters/draw', async (req, res) => {
  try { res.status(201).json(await drawLetter()); } catch (e) { catError(res, e); }
});

app.post('/api/letters/:id/save', async (req, res) => {
  try { res.json(await setLetterStatus(Number(req.params.id), 'saved')); } catch (e) { catError(res, e); }
});

app.post('/api/letters/:id/delete', async (req, res) => {
  try { res.json(await setLetterStatus(Number(req.params.id), 'deleted')); } catch (e) { catError(res, e); }
});

// ---------- V4.0 第三阶段：手动回忆 / 收藏 / 纪念日 / 睡前 / 每日报告（只追加，不动已有路由） ----------
app.get('/api/manual-memories', async (req, res) => {
  try { res.json({ memories: await listManualMemories() }); } catch (e) { catError(res, e); }
});

app.post('/api/manual-memories', async (req, res) => {
  try { res.status(201).json(await createManualMemory(req.body || {})); } catch (e) { catError(res, e); }
});

app.put('/api/manual-memories/:id', async (req, res) => {
  try { res.json(await updateManualMemory(Number(req.params.id), req.body || {})); } catch (e) { catError(res, e); }
});

app.delete('/api/manual-memories/:id', async (req, res) => {
  try { res.json(await deleteManualMemory(Number(req.params.id))); } catch (e) { catError(res, e); }
});

app.post('/api/sessions/:id/messages/:mid/favorite', async (req, res) => {
  try { res.json(await setMessageFavorite(req.params.id, Number(req.params.mid), req.body?.favorite)); } catch (e) { catError(res, e); }
});

app.get('/api/favorites', async (req, res) => {
  try { res.json({ favorites: await listFavorites() }); } catch (e) { catError(res, e); }
});

app.get('/api/anniversaries', async (req, res) => {
  try { res.json({ anniversaries: await listAnniversaries() }); } catch (e) { catError(res, e); }
});

app.post('/api/anniversaries', async (req, res) => {
  try { res.status(201).json(await createAnniversary(req.body || {})); } catch (e) { catError(res, e); }
});

app.put('/api/anniversaries/:id', async (req, res) => {
  try { res.json(await updateAnniversary(Number(req.params.id), req.body || {})); } catch (e) { catError(res, e); }
});

app.delete('/api/anniversaries/:id', async (req, res) => {
  try { res.json(await deleteAnniversary(Number(req.params.id))); } catch (e) { catError(res, e); }
});

app.post('/api/bedtime/story', async (req, res) => {
  try { res.json(await generateBedtimeStory(await readModelConfig())); } catch (e) { catError(res, e); }
});

app.get('/api/bedtime/letter', async (req, res) => {
  try { res.json(goodnightLetter()); } catch (e) { catError(res, e); }
});

app.get('/api/report', async (req, res) => {
  try { res.json(await getDailyReport(req.query.date || todayStr())); } catch (e) { catError(res, e); }
});

// ---------- 启动 ----------
async function main() {
await initDb();
app.listen(PORT, () => {
console.log(`[ai-boy-v3] listening on http://localhost:${PORT} (dialect=${dialect})`);
});
}

main().catch((e) => {
console.error('[ai-boy-v3] 启动失败', e);
process.exit(1);
});
