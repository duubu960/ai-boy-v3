'use strict';
/* Mimi Cat · V4.0 第一阶段前端：导航、猫咪小屋、每日、乐园游戏、我的页。
 * 聊天逻辑（SSE、会话、记忆、样本、配置、导出、备份）全在 app.js 里，这里一律不动。
 * 后端契约按 /api/cat、/api/daily、/api/mood、/api/games/* 写 fetch；后端未实现或出错时诚实提示，不编假数据。 */

const $m = (id) => document.getElementById(id);
const escM = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
/* 奖励可能是字符串或对象 {hearts/title/text/label}，一律格式化成文本，绝不直接拼对象（否则显示 [object Object]） */
function formatReward(r) {
  if (r == null) return '';
  if (typeof r === 'string' || typeof r === 'number') return String(r);
  if (typeof r === 'object') {
    const parts = [];
    if (r.title) parts.push(r.title);
    if (r.label) parts.push(r.label);
    if (r.text) parts.push(r.text);
    if (r.hearts) parts.push('爱心 +' + r.hearts);
    const s = parts.join(' · ');
    return s || '奖励';
  }
  return String(r);
}

function mimiToast(msg) {
  if (typeof window.toast === 'function') { window.toast(msg); return; }
  const t = $m('toast');
  if (!t) return;
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(t._timer);
  t._timer = setTimeout(() => { t.hidden = true; }, 1800);
}

async function mimiApi(path, opts = {}) {
  if (typeof window.api === 'function') return window.api(path, opts);
  const headers = { 'Content-Type': 'application/json' };
  const token = localStorage.getItem('v3_token') || '';
  if (token) headers.Authorization = 'Bearer ' + token;
  const res = await fetch(path, { ...opts, headers });
  if (!res.ok) {
    let msg = '请求失败（' + res.status + '）';
    try { const j = await res.json(); if (j && (j.message || j.error)) msg = j.message || j.error; } catch (e) { /* 非 JSON 忽略 */ }
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }
  return res.json();
}

function asArrayM(v) {
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object') {
    for (const k of ['tasks', 'scores', 'recent', 'sessions', 'messages', 'memories', 'samples', 'items', 'data', 'list']) {
      if (Array.isArray(v[k])) return v[k];
    }
  }
  return [];
}
function fmtDateM(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  if (isNaN(d)) return '';
  return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' +
    String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}
function fmtTimeM(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  if (isNaN(d)) return '';
  return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

/* ---------- 底部导航：只做视图切换，不丢聊天状态 ---------- */
const PAGES = ['home', 'chat', 'memories', 'park', 'mine'];
let currentPage = 'home';

function showPage(name) {
  if (!PAGES.includes(name)) name = 'home';
  currentPage = name;
  document.body.dataset.page = name;
  for (const p of PAGES) {
    const el = $m('page-' + p);
    if (el) el.hidden = (p !== name);
  }
  document.querySelectorAll('.nav-btn').forEach((b) => {
    const on = b.dataset.page === name;
    b.classList.toggle('active', on);
    if (on) b.setAttribute('aria-current', 'page');
    else b.removeAttribute('aria-current');
  });
  if (name === 'home') refreshHome();
  if (name === 'memories') refreshMemoriesPage();
  if (name === 'park') { loadScores('memory', $m('memoryScores')); loadScores('wheel', $m('wheelScores')); }
  if (name === 'mine') refreshMinePage();
  window.dispatchEvent(new CustomEvent('mimi:pagechange', { detail: { page: name } }));
}
window.MimiCat = { showPage, get currentPage() { return currentPage; } };

/* ---------- 首页时钟 ---------- */
function updateClock() {
  const el = $m('homeClock');
  if (!el) return;
  const d = new Date();
  const week = ['日', '一', '二', '三', '四', '五', '六'][d.getDay()];
  el.textContent = (d.getMonth() + 1) + '月' + d.getDate() + '日 星期' + week + ' ' + fmtTimeM(d);
}

/* ---------- 猫咪 ---------- */
const CAT_MOOD_LABELS = { happy: '开心', sleepy: '困倦', hungry: '饥饿', spoiled: '撒娇', curious: '好奇', playful: '想玩耍', calm: '平静', excited: '兴奋' };
const CAT_STATE_LABELS = { happy: '开心', sleepy: '困倦', hungry: '饥饿', spoiled: '撒娇', curious: '好奇', playful: '想玩耍', calm: '平静', sleeping: '睡觉中', eating: '吃饭中' };
const CAT_ACTION_CLASS = { pet: 'is-pet', feed: 'is-eating', sleep: 'is-sleeping', play: 'is-playing' };
const CAT_ACTION_MESSAGE = { pet: '小猫蹭了蹭你的手', feed: '小猫吃得香香的', sleep: '小猫缩成一团睡着了', play: '小猫玩得好开心' };

function renderCat(cat) {
  if (!cat || typeof cat !== 'object') return;
  const moodEl = $m('catMoodText');
  const stateEl = $m('catStatusText');
  if (moodEl) moodEl.textContent = '心情：' + (CAT_MOOD_LABELS[cat.mood] || cat.mood || '未知');
  if (stateEl) stateEl.textContent = '状态：' + (CAT_STATE_LABELS[cat.state] || cat.state || '未知');
  if ($m('catHearts')) $m('catHearts').textContent = cat.hearts ?? '–';
  if ($m('catIntimacy')) $m('catIntimacy').textContent = cat.intimacy ?? '–';
  if ($m('catLevelText')) $m('catLevelText').textContent = cat.level != null ? '等级 Lv.' + cat.level : '';
  if ($m('catStageText')) $m('catStageText').textContent = cat.stage ? ' · ' + cat.stage : '';
}

async function loadCat() {
  try {
    const d = await mimiApi('/api/cat');
    renderCat(d && d.cat ? d.cat : d);
  } catch (e) {
    if ($m('catStatusText')) $m('catStatusText').textContent = '猫咪状态读不到：' + (e.message || '后端未连接');
  }
}

async function catInteract(action, btn) {
  const fig = $m('catFigure');
  const cls = CAT_ACTION_CLASS[action];
  if (fig && cls) fig.classList.add(cls);
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/cat/interact', { method: 'POST', body: JSON.stringify({ action }) });
    renderCat(r && r.cat ? r.cat : r);
    /* 后端返回 {cat, gained:{hearts,intimacy}, rewarded}（无 message/gainedHearts 字段），按实际形状读 */
    const gained = (r && r.gained && r.gained.hearts != null) ? r.gained.hearts : (r && r.gainedHearts != null ? r.gainedHearts : null);
    const msg = (r && r.message) || CAT_ACTION_MESSAGE[action] || '';
    if ($m('catMessage')) $m('catMessage').textContent = msg;
    if (gained != null && gained > 0) mimiToast('爱心 +' + gained + (msg ? ' · ' + msg : ''));
    else if (msg) mimiToast(msg);
  } catch (e) {
    mimiToast('互动失败：' + (e.message || '后端未连接'));
  } finally {
    setTimeout(() => { if (fig && cls) fig.classList.remove(cls); }, action === 'sleep' ? 4000 : 2500);
    if (btn) btn.disabled = false;
  }
}

/* ---------- 今日心情 ---------- */
function renderTodayMood(today) {
  const mood = typeof today === 'string' ? today : (today && (today.mood || today.today));
  const box = $m('moodPicker');
  if (box) {
    box.querySelectorAll('.mood-btn').forEach((b) => b.classList.toggle('selected', b.dataset.mood === mood));
  }
  if ($m('todayMoodText')) {
    $m('todayMoodText').textContent = mood ? '今日心情：' + mood + ' · 已保存' : '今天还没有选心情，点一个告诉小猪吧';
  }
}
async function loadMood() {
  try {
    const d = await mimiApi('/api/mood');
    renderTodayMood(d && d.today !== undefined ? d.today : d);
    return d;
  } catch (e) {
    if ($m('todayMoodText')) $m('todayMoodText').textContent = '心情读不到：' + (e.message || '后端未连接');
    return null;
  }
}
async function saveMood(mood, btn) {
  if (btn) btn.disabled = true;
  try {
    await mimiApi('/api/mood', { method: 'POST', body: JSON.stringify({ mood, note: '' }) });
    renderTodayMood(mood);
    mimiToast('今日心情已保存：' + mood);
  } catch (e) {
    mimiToast('保存失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ---------- 每日：任务 / 盲盒 / 幸运签 ---------- */
let dailyCache = null;

function renderDailyTasks(tasks) {
  const ul = $m('dailyTasksList');
  if (!ul) return;
  ul.innerHTML = '';
  if (!tasks.length) { ul.innerHTML = '<li class="hint">今天还没有任务</li>'; return; }
  for (const t of tasks) {
    const li = document.createElement('li');
    if (t.done) li.classList.add('done');
    const head = document.createElement('div');
    head.className = 'task-head';
    head.innerHTML = '<span class="t-title">' + escM(t.title || '任务') + '</span>' +
      '<span class="t-state">' + (t.claimed ? '已领取' : t.done ? '已完成' : '未完成') + '</span>';
    li.appendChild(head);
    if (t.desc) {
      const d = document.createElement('div');
      d.className = 'task-desc';
      d.textContent = t.desc;
      li.appendChild(d);
    }
    if (t.reward) {
      const r = document.createElement('div');
      r.className = 'task-desc';
      r.textContent = '奖励：' + formatReward(t.reward);
      li.appendChild(r);
    }
    if (!t.claimed) {
      const b = document.createElement('button');
      b.className = 'btn task-claim';
      b.textContent = t.done ? '领取奖励' : '未完成，暂不能领';
      b.disabled = !t.done;
      b.addEventListener('click', () => claimTask(t.id, b));
      li.appendChild(b);
    }
    ul.appendChild(li);
  }
}
async function claimTask(id, btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/daily/tasks/' + encodeURIComponent(id) + '/claim', { method: 'POST', body: JSON.stringify({}) });
    mimiToast(r && r.reward ? '已领取奖励：' + formatReward(r.reward) : '奖励已领取');
    await loadDaily();
  } catch (e) {
    mimiToast('领取失败：' + (e.message || '后端未连接'));
    if (btn) btn.disabled = false;
  }
}
function renderSurprise(surprise) {
  const btn = $m('surpriseBtn');
  const txt = $m('surpriseText');
  if (!btn || !txt) return;
  if (surprise && surprise.claimed) {
    btn.disabled = true;
    btn.textContent = '今日已领取';
    txt.textContent = '今日盲盒已开：' + (surprise.reward ? formatReward(surprise.reward) : '（已领取）');
  } else {
    btn.disabled = false;
    btn.textContent = '打开今日盲盒';
    txt.textContent = '每天可以开一次，看看今天藏了什么惊喜';
  }
}
function renderFortune(fortune) {
  const btn = $m('fortuneBtn');
  const txt = $m('fortuneText');
  if (!btn || !txt) return;
  if (fortune && fortune.drawn) {
    txt.textContent = fortune.text || '今日已抽';
    btn.disabled = true;
    btn.textContent = '今日已抽';
  } else {
    txt.textContent = '还没抽今天的签';
    btn.disabled = false;
    btn.textContent = '抽今日幸运签';
  }
}
async function loadDaily() {
  try {
    const d = await mimiApi('/api/daily');
    dailyCache = d;
    renderDailyTasks(asArrayM(d && d.tasks !== undefined ? d.tasks : d));
    renderSurprise(d ? d.surprise : null);
    renderFortune(d ? d.fortune : null);
    return d;
  } catch (e) {
    const ul = $m('dailyTasksList');
    if (ul) ul.innerHTML = '<li class="hint">今日任务读不到：' + escM(e.message || '后端未连接') + '</li>';
    return null;
  }
}
async function openSurprise(btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/daily/surprise', { method: 'POST', body: JSON.stringify({}) });
    mimiToast('盲盒奖励：' + (r && r.reward ? formatReward(r.reward) : '已领取'));
    await loadDaily();
  } catch (e) {
    if (e.status === 409) {
      mimiToast('今日盲盒已领过');
      await loadDaily();
    } else {
      mimiToast('开盲盒失败：' + (e.message || '后端未连接'));
      if (btn) btn.disabled = false;
    }
  }
}
async function drawFortune(btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/daily/fortune', { method: 'POST', body: JSON.stringify({}) });
    const text = (r && (r.text || r.fortune)) || '';
    if ($m('fortuneText')) $m('fortuneText').textContent = text || '抽到了，但后端没有给签文';
    if (btn) btn.textContent = '今日已抽';
    mimiToast('今日幸运签已抽到');
  } catch (e) {
    mimiToast('抽签失败：' + (e.message || '后端未连接'));
    await loadDaily();
  }
}

/* ---------- 回忆：记忆 / 心情 / 会话（只放真实数据） ---------- */
async function loadMemoriesData() {
  try {
    const d = await mimiApi('/api/memories');
    const list = asArrayM(d).slice().sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
    return list;
  } catch (e) {
    return null;
  }
}
function memStatusLabel(s) {
  return s === 'pending' ? '待确认' : s === 'confirmed' ? '已确认' : s === 'rejected' ? '已拒绝' : (s || '');
}
function renderHomeRecentMemories(list) {
  const ul = $m('homeRecentMemories');
  if (!ul) return;
  ul.innerHTML = '';
  if (list === null) { ul.innerHTML = '<li class="hint">回忆读不到，后端未连接</li>'; return; }
  if (!list.length) { ul.innerHTML = '<li class="hint">还没有回忆</li>'; return; }
  for (const m of list.slice(0, 3)) {
    const li = document.createElement('li');
    li.innerHTML = '<div>' + escM(m.content || '') + '</div>' +
      '<div class="m-date">' + escM(m.category || '未分类') + ' · ' + escM(fmtDateM(m.created_at)) + '</div>';
    ul.appendChild(li);
  }
}
function renderMemTimeline(list) {
  const ul = $m('memTimeline');
  if (!ul) return;
  ul.innerHTML = '';
  if (list === null) { ul.innerHTML = '<li class="hint">记忆读不到，后端未连接</li>'; return; }
  if (!list.length) { ul.innerHTML = '<li class="hint">还没有回忆</li>'; return; }
  for (const m of list.slice(0, 30)) {
    const li = document.createElement('li');
    li.innerHTML = '<div>' + escM(m.content || '') + '</div>' +
      '<div class="m-date">' + escM(m.category || '未分类') + ' · ' + escM(memStatusLabel(m.status)) + ' · ' + escM(fmtDateM(m.created_at)) + '</div>';
    ul.appendChild(li);
  }
}
async function loadRecentSessions() {
  const ul = $m('recentSessionsList');
  try {
    const d = await mimiApi('/api/sessions');
    const list = asArrayM(d).slice(0, 5);
    if (!ul) return;
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">还没有会话</li>'; return; }
    for (const s of list) {
      const li = document.createElement('li');
      li.innerHTML = '<div class="m-title">' + escM(s.title || s.name || '新的聊天') + '</div>' +
        '<div class="m-date">' + escM(fmtDateM(s.updated_at || s.created_at)) + '</div>';
      li.style.cursor = 'pointer';
      li.addEventListener('click', async () => {
        if (typeof window.switchSession === 'function') {
          await window.switchSession(s.id);
          showPage('chat');
        } else {
          mimiToast('打不开这个会话，请去设置里找历史聊天');
        }
      });
      ul.appendChild(li);
    }
  } catch (e) {
    if (ul) ul.innerHTML = '<li class="hint">会话读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
async function loadMoodRecent() {
  const ul = $m('moodRecentList');
  try {
    const d = await mimiApi('/api/mood');
    const list = asArrayM(d && d.recent !== undefined ? d.recent : d).slice(0, 7);
    if (!ul) return;
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">最近 7 天还没有心情记录</li>'; return; }
    for (const r of list) {
      const li = document.createElement('li');
      const mood = r.mood || r.today || r;
      li.innerHTML = '<div class="m-title">' + escM(typeof mood === 'string' ? mood : (mood.mood || '')) + '</div>' +
        '<div class="m-date">' + escM(fmtDateM(r.created_at || r.date)) + (r.note ? ' · ' + escM(r.note) : '') + '</div>';
      ul.appendChild(li);
    }
  } catch (e) {
    if (ul) ul.innerHTML = '<li class="hint">心情记录读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
async function refreshMemoriesPage() {
  const list = await loadMemoriesData();
  renderMemTimeline(list);
  loadMoodRecent();
  loadRecentSessions();
}
async function refreshHome() {
  loadCat();
  loadMood();
  loadDaily();
  renderHomeRecentMemories(await loadMemoriesData());
}

/* ---------- 乐园：成绩榜 ---------- */
async function loadScores(game, ul) {
  if (!ul) return;
  try {
    const d = await mimiApi('/api/games/scores?game=' + encodeURIComponent(game));
    const list = asArrayM(d).slice(0, 5);
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">还没有记录</li>'; return; }
    for (const s of list) {
      const li = document.createElement('li');
      const detail = s.detail && typeof s.detail === 'object' ? JSON.stringify(s.detail) : (s.detail || '');
      li.innerHTML = '<div class="m-title">得分 ' + escM(s.score ?? '–') + '</div>' +
        '<div class="m-date">' + escM(fmtDateM(s.created_at)) + (detail ? ' · ' + escM(detail) : '') + '</div>';
      ul.appendChild(li);
    }
  } catch (e) {
    ul.innerHTML = '<li class="hint">成绩读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
async function recordScore(game, score, detail) {
  try {
    await mimiApi('/api/games/score', { method: 'POST', body: JSON.stringify({ game, score, detail }) });
    return true;
  } catch (e) {
    mimiToast('成绩没记上：' + (e.message || '后端未连接'));
    return false;
  }
}

/* ---------- 乐园：记忆翻牌 ---------- */
const MEMORY_SYMBOLS = ['🐱', '🌸', '🐟', '🍰', '⭐', '🎀', '🍓', '🌙'];
const memoryGame = { state: 'idle', deck: [], first: null, lock: false, matched: 0, steps: 0, seconds: 0, timer: null };

function memoryStopTimer() {
  if (memoryGame.timer) { clearInterval(memoryGame.timer); memoryGame.timer = null; }
}
function memoryRenderBoard() {
  const board = $m('memoryBoard');
  if (!board) return;
  board.innerHTML = '';
  memoryGame.deck.forEach((sym, idx) => {
    const b = document.createElement('button');
    b.className = 'memory-card';
    b.type = 'button';
    b.textContent = '🐾';
    b.setAttribute('aria-label', '翻牌 ' + (idx + 1));
    b.addEventListener('click', () => memoryFlip(idx, b));
    board.appendChild(b);
  });
}
function memoryUpdateStats() {
  if ($m('memorySteps')) $m('memorySteps').textContent = '步数 ' + memoryGame.steps;
  if ($m('memoryTime')) $m('memoryTime').textContent = '用时 ' + memoryGame.seconds + ' 秒';
}
function memoryStart() {
  memoryStopTimer();
  const deck = [...MEMORY_SYMBOLS, ...MEMORY_SYMBOLS];
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  memoryGame.deck = deck;
  memoryGame.first = null;
  memoryGame.lock = false;
  memoryGame.matched = 0;
  memoryGame.steps = 0;
  memoryGame.seconds = 0;
  memoryGame.state = 'playing';
  memoryRenderBoard();
  memoryUpdateStats();
  if ($m('memoryStatus')) $m('memoryStatus').textContent = '翻牌吧，找到相同的两张';
  memoryGame.timer = setInterval(() => {
    if (memoryGame.state !== 'playing') return;
    memoryGame.seconds += 1;
    memoryUpdateStats();
  }, 1000);
}
function memoryFlip(idx, btn) {
  if (memoryGame.state !== 'playing' || memoryGame.lock) return;
  if (btn.classList.contains('flipped') || btn.classList.contains('matched')) return;
  btn.classList.add('flipped');
  btn.textContent = memoryGame.deck[idx];
  if (memoryGame.first === null) {
    memoryGame.first = { idx, btn };
    return;
  }
  memoryGame.steps += 1;
  memoryUpdateStats();
  const first = memoryGame.first;
  memoryGame.first = null;
  if (memoryGame.deck[first.idx] === memoryGame.deck[idx]) {
    first.btn.classList.add('matched');
    btn.classList.add('matched');
    memoryGame.matched += 1;
    if (memoryGame.matched === MEMORY_SYMBOLS.length) memoryFinish();
  } else {
    memoryGame.lock = true;
    setTimeout(() => {
      first.btn.classList.remove('flipped');
      first.btn.textContent = '🐾';
      btn.classList.remove('flipped');
      btn.textContent = '🐾';
      memoryGame.lock = false;
    }, 700);
  }
}
async function memoryFinish() {
  memoryGame.state = 'done';
  memoryStopTimer();
  const score = Math.max(100, 1600 - memoryGame.steps * 20 - memoryGame.seconds * 5);
  if ($m('memoryStatus')) {
    $m('memoryStatus').textContent = '完成！步数 ' + memoryGame.steps + '，用时 ' + memoryGame.seconds + ' 秒，得分 ' + score;
  }
  mimiToast('翻牌完成，得分 ' + score);
  await recordScore('memory', score, { steps: memoryGame.steps, seconds: memoryGame.seconds });
  loadScores('memory', $m('memoryScores'));
}
function memoryEnd() {
  if (memoryGame.state !== 'playing') return;
  memoryGame.state = 'ended';
  memoryStopTimer();
  const board = $m('memoryBoard');
  if (board) board.querySelectorAll('.memory-card').forEach((b) => { b.disabled = true; });
  if ($m('memoryStatus')) $m('memoryStatus').textContent = '已结束，点「开始」可以再来一局';
}

/* ---------- 乐园：幸运转盘 ---------- */
let wheelSpinning = false;
let wheelRotation = 0;
async function spinWheel(btn) {
  if (wheelSpinning) return;
  wheelSpinning = true;
  if (btn) btn.disabled = true;
  let result = null;
  try {
    result = await mimiApi('/api/games/wheel', { method: 'POST', body: JSON.stringify({}) });
  } catch (e) {
    mimiToast('抽奖失败：' + (e.message || '后端未连接'));
    wheelSpinning = false;
    if (btn) btn.disabled = false;
    return;
  }
  const wheel = $m('wheel');
  wheelRotation += 1800 + Math.floor(Math.random() * 360);
  if (wheel) wheel.style.transform = 'rotate(' + wheelRotation + 'deg)';
  if ($m('wheelResult')) $m('wheelResult').textContent = '转盘转起来了…';
  setTimeout(async () => {
    const prize = result.prize || result.reward || '未知奖品';
    /* 奖品名只取 label/title（formatReward 会把 label 与 hearts 都拼上，造成三重重复） */
    const prizeText = (prize && typeof prize === 'object') ? (prize.label || prize.title || formatReward(prize)) : String(prize);
    /* 后端 hearts 是猫咪爱心总数，不是本次得的；本次所得只取 prize.hearts */
    const hearts = (prize && typeof prize === 'object' && prize.hearts != null) ? prize.hearts : null;
    if ($m('wheelResult')) {
      $m('wheelResult').textContent = '抽中：' + prizeText + (hearts != null ? '（爱心 +' + hearts + '）' : '');
    }
    mimiToast('抽中：' + prizeText);
    await recordScore('wheel', hearts != null ? hearts : 0, { prize });
    loadScores('wheel', $m('wheelScores'));
    wheelSpinning = false;
    if (btn) btn.disabled = false;
  }, 3000);
}

/* ---------- 我的页 ---------- */
function openSettingsSection(name) {
  if (typeof window.openSettings === 'function' && typeof window.showSection === 'function') {
    window.openSettings();
    window.showSection(name);
    return;
  }
  const overlay = $m('settingsOverlay');
  if (overlay) overlay.hidden = false;
  const item = document.querySelector('.menu-item[data-section="' + name + '"]');
  if (item) item.click();
  else mimiToast('打不开这个设置分区');
}
function applySceneTheme() {
  const sel = $m('sceneThemeSelect');
  const home = $m('page-home');
  if (!sel || !home) return;
  const v = sel.value || 'auto';
  home.className = 'page scene-' + (v === 'auto' ? 'home' : v);
}
async function refreshMinePage() {
  loadScores('memory', $m('myGameScores'));
  const box = $m('myDailyRecords');
  if (!box) return;
  try {
    const d = dailyCache || await mimiApi('/api/daily');
    const tasks = asArrayM(d && d.tasks !== undefined ? d.tasks : d);
    const done = tasks.filter((t) => t.done).length;
    const claimed = tasks.filter((t) => t.claimed).length;
    box.innerHTML = '<p>今日任务：' + done + ' / ' + tasks.length + ' 已完成，' + claimed + ' 已领取' +
      (d && d.surprise ? ' · 盲盒：' + (d.surprise.claimed ? '已领（' + escM(formatReward(d.surprise.reward)) + '）' : '未领') : '') +
      (d && d.fortune ? ' · 幸运签：' + (d.fortune.drawn ? '已抽' : '未抽') : '') + '</p>';
  } catch (e) {
    box.innerHTML = '<p class="hint">每日记录读不到：' + escM(e.message || '后端未连接') + '</p>';
  }
}

/* ---------- 初始化 ---------- */
function initMimi() {
  document.querySelectorAll('.nav-btn').forEach((b) =>
    b.addEventListener('click', () => showPage(b.dataset.page)));
  document.querySelectorAll('[data-nav]').forEach((b) =>
    b.addEventListener('click', () => showPage(b.dataset.nav)));
  document.querySelectorAll('[data-open-section]').forEach((b) =>
    b.addEventListener('click', () => openSettingsSection(b.dataset.openSection)));

  updateClock();
  setInterval(updateClock, 30000);

  document.querySelectorAll('[data-cat-action]').forEach((b) =>
    b.addEventListener('click', () => catInteract(b.dataset.catAction, b)));
  document.querySelectorAll('.mood-btn').forEach((b) =>
    b.addEventListener('click', () => saveMood(b.dataset.mood, b)));

  const surpriseBtn = $m('surpriseBtn');
  if (surpriseBtn) surpriseBtn.addEventListener('click', () => openSurprise(surpriseBtn));
  const fortuneBtn = $m('fortuneBtn');
  if (fortuneBtn) fortuneBtn.addEventListener('click', () => drawFortune(fortuneBtn));

  const memStart = $m('memoryStartBtn');
  if (memStart) memStart.addEventListener('click', memoryStart);
  const memRestart = $m('memoryRestartBtn');
  if (memRestart) memRestart.addEventListener('click', memoryStart);
  const memEnd = $m('memoryEndBtn');
  if (memEnd) memEnd.addEventListener('click', memoryEnd);
  const wheelBtn = $m('wheelSpinBtn');
  if (wheelBtn) wheelBtn.addEventListener('click', () => spinWheel(wheelBtn));

  const themeSel = $m('sceneThemeSelect');
  if (themeSel) {
    try {
      const saved = localStorage.getItem('v3_scene_theme');
      if (saved) themeSel.value = saved;
    } catch (e) { /* 忽略 */ }
    themeSel.addEventListener('change', () => {
      try { localStorage.setItem('v3_scene_theme', themeSel.value); } catch (e) { /* 忽略 */ }
      applySceneTheme();
      mimiToast('首页场景已切换');
    });
    applySceneTheme();
  }

  showPage('home');
}

document.addEventListener('DOMContentLoaded', initMimi);
