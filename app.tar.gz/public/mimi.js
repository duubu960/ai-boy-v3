'use strict';
/* Mimi Cat · V4.0 第一阶段前端：导航、猫咪小屋、每日、乐园游戏、我的页。
 * 聊天逻辑（SSE、会话、记忆、样本、配置、导出、备份）全在 app.js 里，这里一律不动。
 * 后端契约按 /api/cat、/api/daily、/api/mood、/api/games/* 写 fetch；后端未实现或出错时诚实提示，不编假数据。 */

const $m = (id) => document.getElementById(id);
const escM = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
/* 奖励可能是字符串或对象 {hearts/title/text/label}，一律格式化成文本，绝不直接拼对象（否则显示 [object Object]） */
function formatReward(r) {
  if (r == null) return '';
  if (typeof r === 'string' || typeof r === 'number') return String(r);
  if (typeof r === 'object') {
    const parts = [];
    if (r.title) parts.push(r.title);
    if (r.label) parts.push(r.label);
    if (r.text) parts.push(r.text);
    if (r.hearts) parts.push('爱心 +' + r.hearts);
    const s = parts.join(' · ');
    return s || '奖励';
  }
  return String(r);
}

function mimiToast(msg) {
  if (typeof window.toast === 'function') { window.toast(msg); return; }
  const t = $m('toast');
  if (!t) return;
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(t._timer);
  t._timer = setTimeout(() => { t.hidden = true; }, 1800);
}

async function mimiApi(path, opts = {}) {
  if (typeof window.api === 'function') return window.api(path, opts);
  const headers = { 'Content-Type': 'application/json' };
  const token = localStorage.getItem('v3_token') || '';
  if (token) headers.Authorization = 'Bearer ' + token;
  const res = await fetch(path, { ...opts, headers });
  if (!res.ok) {
    let msg = '请求失败（' + res.status + '）';
    try { const j = await res.json(); if (j && (j.message || j.error)) msg = j.message || j.error; } catch (e) { /* 非 JSON 忽略 */ }
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }
  return res.json();
}

function asArrayM(v) {
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object') {
    for (const k of ['tasks', 'scores', 'recent', 'sessions', 'messages', 'memories', 'samples', 'items', 'data', 'list', 'letters', 'favorites', 'anniversaries']) {
      if (Array.isArray(v[k])) return v[k];
    }
  }
  return [];
}
function fmtDateM(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  if (isNaN(d)) return '';
  return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' +
    String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}
function fmtTimeM(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  if (isNaN(d)) return '';
  return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

/* ---------- 底部导航：只做视图切换，不丢聊天状态 ---------- */
const PAGES = ['home', 'chat', 'memories', 'park', 'mine'];
let currentPage = 'home';

function showPage(name) {
  if (!PAGES.includes(name)) name = 'home';
  currentPage = name;
  document.body.dataset.page = name;
  for (const p of PAGES) {
    const el = $m('page-' + p);
    if (el) el.hidden = (p !== name);
  }
  document.querySelectorAll('.nav-btn').forEach((b) => {
    const on = b.dataset.page === name;
    b.classList.toggle('active', on);
    if (on) b.setAttribute('aria-current', 'page');
    else b.removeAttribute('aria-current');
  });
  if (name === 'home') refreshHome();
  if (name === 'memories') { refreshMemoriesPage(); loadLetters(); }
  if (name === 'park') { loadScores('memory', $m('memoryScores')); loadScores('wheel', $m('wheelScores')); loadOutfit(); loadRoom(); loadGarden(); }
  if (name === 'mine') refreshMinePage();
  if (name === 'chat') { loadChatFavorites(); attachFavoriteButtons(); }
  window.dispatchEvent(new CustomEvent('mimi:pagechange', { detail: { page: name } }));
}
window.MimiCat = { showPage, renderCat, get currentPage() { return currentPage; } };

/* ---------- 首页时钟 ---------- */
function updateClock() {
  const el = $m('homeClock');
  if (!el) return;
  const d = new Date();
  const week = ['日', '一', '二', '三', '四', '五', '六'][d.getDay()];
  el.textContent = (d.getMonth() + 1) + '月' + d.getDate() + '日 星期' + week + ' ' + fmtTimeM(d);
}

/* ---------- 猫咪 ---------- */
const CAT_MOOD_LABELS = { happy: '开心', sleepy: '困倦', hungry: '饥饿', spoiled: '撒娇', curious: '好奇', playful: '想玩耍', calm: '平静', excited: '兴奋' };
const CAT_STATE_LABELS = { happy: '开心', sleepy: '困倦', hungry: '饥饿', spoiled: '撒娇', curious: '好奇', playful: '想玩耍', calm: '平静', sleeping: '睡觉中', eating: '吃饭中' };
const CAT_ACTION_CLASS = { pet: 'is-pet', feed: 'is-eating', sleep: 'is-sleeping', play: 'is-playing', bath: 'is-bath' };
const CAT_ACTION_MESSAGE = { pet: '小猫蹭了蹭你的手', feed: '小猫吃得香香的', sleep: '小猫缩成一团睡着了', play: '小猫玩得好开心', bath: '小猫洗了个香香的澡' };

function renderCat(cat) {
  if (!cat || typeof cat !== 'object') return;
  const moodEl = $m('catMoodText');
  const stateEl = $m('catStatusText');
  if (moodEl) moodEl.textContent = '心情：' + (CAT_MOOD_LABELS[cat.mood] || cat.mood || '未知');
  if (stateEl) stateEl.textContent = '状态：' + (CAT_STATE_LABELS[cat.state] || cat.state || '未知');
  if ($m('catHearts')) $m('catHearts').textContent = cat.hearts ?? '–';
  if ($m('catIntimacy')) $m('catIntimacy').textContent = cat.intimacy ?? '–';
  if ($m('catLevelText')) $m('catLevelText').textContent = cat.level != null ? '等级 Lv.' + cat.level : '';
  if ($m('catStageText')) $m('catStageText').textContent = cat.stage ? ' · ' + cat.stage : '';
  /* 状态机联动：按后端 state/mood 给猫一个基础状态，只在当前为 idle 且没有正在播的
   * 按钮互动动画时切换，不打断用户正在看的互动。 */
  try {
    const CS = window.CatState;
    const f = $m('catFigure');
    if (CS && f) {
      const busy = ['is-pet', 'is-eating', 'is-sleeping', 'is-playing', 'is-bath']
        .some((c) => f.classList.contains(c));
      if (!busy && CS.get() === 'idle') {
        const base = catBaseState(cat);
        if (base && base !== 'idle') CS.set(base);
      }
    }
  } catch (e) { /* 联动失败不影响文字渲染 */ }
}

/* 后端心情/状态 → CatState 基础状态（开心→happy、困倦→sleepy、饥饿→sad、满足→happy、兴奋→play、好奇→curious） */
function catBaseState(cat) {
  if (!cat || typeof cat !== 'object') return null;
  if (cat.state === 'sleeping') return 'sleep';
  if (cat.state === 'eating') return 'eat';
  if (cat.state === 'playful') return 'play';
  if (cat.state === 'sleepy') return 'sleepy';
  const m = { happy: 'happy', sleepy: 'sleepy', hungry: 'sad', spoiled: 'happy', curious: 'curious', playful: 'play', excited: 'play' };
  return m[cat.mood] || null;
}

/* 首页与换装的两只猫都用同一模板渲染（catstate.js 的 buildCatSVG），且都带
 * withAccessories:true：首页猫也有 acc-* 五组饰品层，与换装猫共用同一 dressOutfit。
 * catstate.js 未加载时留用 index.html 里的静态 SVG 兜底，不报错。
 * 渲染后把饰品显隐按当前 outfit 重应用。 */
function renderCatFigure() {
  if (typeof window.buildCatSVG !== 'function') return;
  const f = $m('catFigure');
  if (f) {
    f.innerHTML = '<svg viewBox="0 0 220 200" class="cat-svg" aria-hidden="true">' +
      window.buildCatSVG({ withAccessories: true, suffix: 'home' }) + '</svg>';
  }
  const dress = $m('dressCatSvg');
  if (dress) dress.innerHTML = window.buildCatSVG({ withAccessories: true, suffix: 'dress' });
  try { if (window.CatState && window.CatState.refresh) window.CatState.refresh(); } catch (e) { /* 忽略 */ }
  applyOutfit();
}

async function loadCat() {
  try {
    const d = await mimiApi('/api/cat');
    renderCat(d && d.cat ? d.cat : d);
  } catch (e) {
    if ($m('catStatusText')) $m('catStatusText').textContent = '猫咪状态读不到：' + (e.message || '后端未连接');
  }
}

async function catInteract(action, btn) {
  const fig = $m('catFigure');
  const cls = CAT_ACTION_CLASS[action];
  const startedAt = Date.now();
  if (fig && cls) fig.classList.add(cls);
  /* 状态机映射：is-* 动整个 .cat-svg，st-* 动内部表情层，两者共存不打架。
   * pet→happy（摸头闭眼蹭蹭，眼睛换开心弧线）、feed→eat、sleep→sleep、play→play；
   * bath 先播 is-bath 抖动，1 秒后再切 happy。keepInteraction:true 保留刚挂上的 is-*。 */
  try {
    if (window.CatState) {
      if (action === 'bath') {
        setTimeout(() => { try { if (window.CatState.get() === 'idle') window.CatState.set('happy'); } catch (e) { /* 忽略 */ } }, 1000);
      } else {
        const stMap = { pet: 'happy', feed: 'eat', sleep: 'sleep', play: 'play' };
        if (stMap[action]) window.CatState.set(stMap[action], { keepInteraction: true });
      }
    }
  } catch (e) { /* 状态机失败不影响互动流程 */ }
  /* 音效：只在用户点击后调用，AudioContext 在此时才创建/恢复；失败静默，不显示“已播放” */
  try { if (window.CatFX) window.CatFX.play(action); } catch (e) { /* 静默失败 */ }
  /* 猫身上方飘爱心（CSS ::after 已有一颗，这里再补一颗随机爱心） */
  if (fig) {
    const heart = document.createElement('span');
    heart.className = 'float-heart';
    heart.textContent = Math.random() < 0.5 ? '❤' : '💗';
    heart.setAttribute('aria-hidden', 'true');
    fig.appendChild(heart);
    setTimeout(() => { heart.remove(); }, 1000);
  }
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/cat/interact', { method: 'POST', body: JSON.stringify({ action }) });
    renderCat(r && r.cat ? r.cat : r);
    /* 后端返回 {cat, gained:{hearts,intimacy}, rewarded}（无 message/gainedHearts 字段），按实际形状读 */
    const gained = (r && r.gained && r.gained.hearts != null) ? r.gained.hearts : (r && r.gainedHearts != null ? r.gainedHearts : null);
    const msg = (r && r.message) || CAT_ACTION_MESSAGE[action] || '';
    if ($m('catMessage')) $m('catMessage').textContent = msg;
    if (gained != null && gained > 0) mimiToast('爱心 +' + gained + (msg ? ' · ' + msg : ''));
    else if (msg) mimiToast(msg);
  } catch (e) {
    mimiToast('互动失败：' + (e.message || '后端未连接'));
  } finally {
    /* fetch 完成且动作至少可见 1.2 秒后再移除 class；sleep 仍保留 4 秒 */
    const minMs = action === 'sleep' ? 4000 : 1200;
    const wait = Math.max(0, minMs - (Date.now() - startedAt));
    setTimeout(() => { if (fig && cls) fig.classList.remove(cls); }, wait);
    if (btn) btn.disabled = false;
  }
}

/* ---------- 音效开关 ---------- */
function updateSoundToggleBtn() {
  const btn = $m('soundToggleBtn');
  if (!btn) return;
  const muted = window.CatFX ? window.CatFX.isMuted() : false;
  btn.textContent = muted ? '🔇 音效关' : '🔊 音效开';
  btn.setAttribute('aria-pressed', String(!muted));
}
function toggleSound() {
  if (!window.CatFX) { mimiToast('音效还没加载好'); return; }
  window.CatFX.setMuted(!window.CatFX.isMuted());
  updateSoundToggleBtn();
}

/* ---------- 今日心情 ---------- */
function renderTodayMood(today) {
  const mood = typeof today === 'string' ? today : (today && (today.mood || today.today));
  const box = $m('moodPicker');
  if (box) {
    box.querySelectorAll('.mood-btn').forEach((b) => b.classList.toggle('selected', b.dataset.mood === mood));
  }
  if ($m('todayMoodText')) {
    $m('todayMoodText').textContent = mood ? '今日心情：' + mood + ' · 已保存' : '今天还没有选心情，点一个告诉小猪吧';
  }
}
/* GET /api/mood 返回最近 7 天的记录数组（按日期升序），不是 {today} 对象：
 * 之前 loadMood 把整个数组直接传给 renderTodayMood，数组上取不到 mood，
 * 于是每次回首页（showPage('home') → refreshHome → loadMood）和整页刷新，
 * 心情区都被刷回「今天还没有选心情」，哪怕心情早已保存成功。
 * 这里只挑出 date 等于今天本地日期的那一行；当天没有记录时返回 null。 */
function pickTodayMood(d) {
  const list = Array.isArray(d) ? d : (d && Array.isArray(d.recent) ? d.recent : []);
  const today = todayStrLocal();
  const row = list.find((r) => r && String(r.date || '').slice(0, 10) === today);
  const mood = row ? (row.mood || row.today || null) : null;
  return typeof mood === 'string' ? mood : null;
}
async function loadMood() {
  try {
    const d = await mimiApi('/api/mood');
    renderTodayMood(pickTodayMood(d));
    return d;
  } catch (e) {
    if ($m('todayMoodText')) $m('todayMoodText').textContent = '心情读不到：' + (e.message || '后端未连接');
    return null;
  }
}
async function saveMood(mood, btn) {
  /* 防御：mood 为空时不发请求——空 body 会被后端 400「需要 mood」拒收，
   * 之前情绪入口按钮复用 .mood-btn 样式、没有 data-mood，就是这么误触的。 */
  if (!mood || typeof mood !== 'string') return;
  if (btn) btn.disabled = true;
  try {
    await mimiApi('/api/mood', { method: 'POST', body: JSON.stringify({ mood, note: '' }) });
    renderTodayMood(mood);
    mimiToast('今日心情已保存：' + mood);
  } catch (e) {
    mimiToast('保存失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ---------- 每日：任务 / 盲盒 / 幸运签 ---------- */
let dailyCache = null;

function renderDailyTasks(tasks) {
  const ul = $m('dailyTasksList');
  if (!ul) return;
  ul.innerHTML = '';
  if (!tasks.length) { ul.innerHTML = '<li class="hint">今天还没有任务</li>'; return; }
  for (const t of tasks) {
    const li = document.createElement('li');
    if (t.done) li.classList.add('done');
    const head = document.createElement('div');
    head.className = 'task-head';
    head.innerHTML = '<span class="t-title">' + escM(t.title || '任务') + '</span>' +
      '<span class="t-state">' + (t.claimed ? '已领取' : t.done ? '已完成' : '未完成') + '</span>';
    li.appendChild(head);
    if (t.desc) {
      const d = document.createElement('div');
      d.className = 'task-desc';
      d.textContent = t.desc;
      li.appendChild(d);
    }
    if (t.reward) {
      const r = document.createElement('div');
      r.className = 'task-desc';
      r.textContent = '奖励：' + formatReward(t.reward);
      li.appendChild(r);
    }
    if (!t.claimed) {
      const b = document.createElement('button');
      b.className = 'btn task-claim';
      b.textContent = t.done ? '领取奖励' : '未完成，暂不能领';
      b.disabled = !t.done;
      b.addEventListener('click', () => claimTask(t.id, b));
      li.appendChild(b);
    }
    ul.appendChild(li);
  }
}
async function claimTask(id, btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/daily/tasks/' + encodeURIComponent(id) + '/claim', { method: 'POST', body: JSON.stringify({}) });
    mimiToast(r && r.reward ? '已领取奖励：' + formatReward(r.reward) : '奖励已领取');
    await loadDaily();
  } catch (e) {
    mimiToast('领取失败：' + (e.message || '后端未连接'));
    if (btn) btn.disabled = false;
  }
}
function renderSurprise(surprise) {
  const btn = $m('surpriseBtn');
  const txt = $m('surpriseText');
  if (!btn || !txt) return;
  if (surprise && surprise.claimed) {
    btn.disabled = true;
    btn.textContent = '今日已领取';
    txt.textContent = '今日盲盒已开：' + (surprise.reward ? formatReward(surprise.reward) : '（已领取）');
  } else {
    btn.disabled = false;
    btn.textContent = '打开今日盲盒';
    txt.textContent = '每天可以开一次，看看今天藏了什么惊喜';
  }
}
function renderFortune(fortune) {
  const btn = $m('fortuneBtn');
  const txt = $m('fortuneText');
  if (!btn || !txt) return;
  if (fortune && fortune.drawn) {
    txt.textContent = fortune.text || '今日已抽';
    btn.disabled = true;
    btn.textContent = '今日已抽';
  } else {
    txt.textContent = '还没抽今天的签';
    btn.disabled = false;
    btn.textContent = '抽今日幸运签';
  }
}
async function loadDaily() {
  try {
    const d = await mimiApi('/api/daily');
    dailyCache = d;
    renderDailyTasks(asArrayM(d && d.tasks !== undefined ? d.tasks : d));
    renderSurprise(d ? d.surprise : null);
    renderFortune(d ? d.fortune : null);
    return d;
  } catch (e) {
    const ul = $m('dailyTasksList');
    if (ul) ul.innerHTML = '<li class="hint">今日任务读不到：' + escM(e.message || '后端未连接') + '</li>';
    return null;
  }
}
async function openSurprise(btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/daily/surprise', { method: 'POST', body: JSON.stringify({}) });
    mimiToast('盲盒奖励：' + (r && r.reward ? formatReward(r.reward) : '已领取'));
    await loadDaily();
  } catch (e) {
    if (e.status === 409) {
      mimiToast('今日盲盒已领过');
      await loadDaily();
    } else {
      mimiToast('开盲盒失败：' + (e.message || '后端未连接'));
      if (btn) btn.disabled = false;
    }
  }
}
async function drawFortune(btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/daily/fortune', { method: 'POST', body: JSON.stringify({}) });
    const text = (r && (r.text || r.fortune)) || '';
    if ($m('fortuneText')) $m('fortuneText').textContent = text || '抽到了，但后端没有给签文';
    if (btn) btn.textContent = '今日已抽';
    mimiToast('今日幸运签已抽到');
  } catch (e) {
    mimiToast('抽签失败：' + (e.message || '后端未连接'));
    await loadDaily();
  }
}

/* ---------- 回忆：记忆 / 心情 / 会话（只放真实数据） ---------- */
async function loadMemoriesData() {
  try {
    const d = await mimiApi('/api/memories');
    const list = asArrayM(d).slice().sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
    return list;
  } catch (e) {
    return null;
  }
}
function memStatusLabel(s) {
  return s === 'pending' ? '待确认' : s === 'confirmed' ? '已确认' : s === 'rejected' ? '已拒绝' : (s || '');
}
function renderHomeRecentMemories(list) {
  const ul = $m('homeRecentMemories');
  if (!ul) return;
  ul.innerHTML = '';
  if (list === null) { ul.innerHTML = '<li class="hint">回忆读不到，后端未连接</li>'; return; }
  if (!list.length) { ul.innerHTML = '<li class="hint">还没有回忆</li>'; return; }
  for (const m of list.slice(0, 3)) {
    const li = document.createElement('li');
    li.innerHTML = '<div>' + escM(m.content || '') + '</div>' +
      '<div class="m-date">' + escM(m.category || '未分类') + ' · ' + escM(fmtDateM(m.created_at)) + '</div>';
    ul.appendChild(li);
  }
}
function renderMemTimeline(list) {
  const ul = $m('memTimeline');
  if (!ul) return;
  ul.innerHTML = '';
  if (list === null) { ul.innerHTML = '<li class="hint">记忆读不到，后端未连接</li>'; return; }
  if (!list.length) { ul.innerHTML = '<li class="hint">还没有回忆</li>'; return; }
  for (const m of list.slice(0, 30)) {
    const li = document.createElement('li');
    li.innerHTML = '<div>' + escM(m.content || '') + '</div>' +
      '<div class="m-date">' + escM(m.category || '未分类') + ' · ' + escM(memStatusLabel(m.status)) + ' · ' + escM(fmtDateM(m.created_at)) + '</div>';
    ul.appendChild(li);
  }
}
async function loadRecentSessions() {
  const ul = $m('recentSessionsList');
  try {
    const d = await mimiApi('/api/sessions');
    const list = asArrayM(d).slice(0, 5);
    if (!ul) return;
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">还没有会话</li>'; return; }
    for (const s of list) {
      const li = document.createElement('li');
      li.innerHTML = '<div class="m-title">' + escM(s.title || s.name || '新的聊天') + '</div>' +
        '<div class="m-date">' + escM(fmtDateM(s.updated_at || s.created_at)) + '</div>';
      li.style.cursor = 'pointer';
      li.addEventListener('click', async () => {
        if (typeof window.switchSession === 'function') {
          await window.switchSession(s.id);
          showPage('chat');
        } else {
          mimiToast('打不开这个会话，请去设置里找历史聊天');
        }
      });
      ul.appendChild(li);
    }
  } catch (e) {
    if (ul) ul.innerHTML = '<li class="hint">会话读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
async function loadMoodRecent() {
  const ul = $m('moodRecentList');
  try {
    const d = await mimiApi('/api/mood');
    const list = asArrayM(d && d.recent !== undefined ? d.recent : d).slice(0, 7);
    if (!ul) return;
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">最近 7 天还没有心情记录</li>'; return; }
    for (const r of list) {
      const li = document.createElement('li');
      const mood = r.mood || r.today || r;
      li.innerHTML = '<div class="m-title">' + escM(typeof mood === 'string' ? mood : (mood.mood || '')) + '</div>' +
        '<div class="m-date">' + escM(fmtDateM(r.created_at || r.date)) + (r.note ? ' · ' + escM(r.note) : '') + '</div>';
      ul.appendChild(li);
    }
  } catch (e) {
    if (ul) ul.innerHTML = '<li class="hint">心情记录读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
async function refreshMemoriesPage() {
  const list = await loadMemoriesData();
  renderMemTimeline(list);
  loadMoodRecent();
  loadRecentSessions();
  loadManualMemories();
  loadFavoritesList();
  loadAnniversaries();
  loadReport();
}
async function refreshHome() {
  loadCat();
  loadMood();
  loadDaily();
  renderHomeRecentMemories(await loadMemoriesData());
}

/* ---------- 乐园：成绩榜 ---------- */
const GAME_NAMES = { memory: '记忆翻牌', wheel: '幸运转盘', fortune: '今日幸运签' };
/* detail 可能是对象，也可能是 JSON 字符串（含 {prize:{label,hearts}} 或 {steps,seconds}），
 * 解析失败按原样显示；渲染一律可读文字，绝不出现 JSON.stringify 的原始文本。 */
function parseScoreDetail(detail) {
  if (detail == null) return null;
  if (typeof detail === 'object') return detail;
  if (typeof detail === 'string') {
    try { return JSON.parse(detail); } catch (e) { return detail; }
  }
  return detail;
}
function formatScoreLine(game, s) {
  const d = parseScoreDetail(s.detail);
  const score = s.score ?? '–';
  const title = (GAME_NAMES[game] || game) + ' · 得分 ' + score;
  let sub = '';
  if (d && typeof d === 'object') {
    if (game === 'wheel' && d.prize) {
      const p = d.prize;
      const label = (p && typeof p === 'object') ? (p.label || p.title || '') : String(p);
      sub = label ? label + ' · 得分 ' + score : '得分 ' + score;
    } else if (game === 'memory' && (d.steps != null || d.seconds != null)) {
      sub = '步数 ' + (d.steps ?? '–') + ' · 用时 ' + (d.seconds ?? '–') + ' 秒 · 得分 ' + score;
    } else if (typeof d === 'object') {
      const bits = [];
      if (d.steps != null) bits.push('步数 ' + d.steps);
      if (d.seconds != null) bits.push('用时 ' + d.seconds + ' 秒');
      sub = bits.length ? bits.join(' · ') + ' · 得分 ' + score : '得分 ' + score;
    }
  } else if (typeof d === 'string' && d) {
    sub = d;
  }
  return { title, sub };
}
async function loadScores(game, ul) {
  if (!ul) return;
  try {
    const d = await mimiApi('/api/games/scores?game=' + encodeURIComponent(game));
    const list = asArrayM(d).slice(0, 5);
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">还没有记录</li>'; return; }
    for (const s of list) {
      const li = document.createElement('li');
      const f = formatScoreLine(game, s);
      li.innerHTML = '<div class="m-title">' + escM(f.title) + '</div>' +
        '<div class="m-date">' + escM(fmtDateM(s.created_at)) + (f.sub ? ' · ' + escM(f.sub) : '') + '</div>';
      ul.appendChild(li);
    }
  } catch (e) {
    ul.innerHTML = '<li class="hint">成绩读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
async function recordScore(game, score, detail) {
  try {
    await mimiApi('/api/games/score', { method: 'POST', body: JSON.stringify({ game, score, detail }) });
    return true;
  } catch (e) {
    mimiToast('成绩没记上：' + (e.message || '后端未连接'));
    return false;
  }
}

/* ---------- 乐园：记忆翻牌 ---------- */
const MEMORY_SYMBOLS = ['🐱', '🌸', '🐟', '🍰', '⭐', '🎀', '🍓', '🌙'];
const memoryGame = { state: 'idle', deck: [], first: null, lock: false, matched: 0, steps: 0, seconds: 0, timer: null };

function memoryStopTimer() {
  if (memoryGame.timer) { clearInterval(memoryGame.timer); memoryGame.timer = null; }
}
function memoryRenderBoard() {
  const board = $m('memoryBoard');
  if (!board) return;
  board.innerHTML = '';
  memoryGame.deck.forEach((sym, idx) => {
    const b = document.createElement('button');
    b.className = 'memory-card';
    b.type = 'button';
    b.textContent = '🐾';
    b.setAttribute('aria-label', '翻牌 ' + (idx + 1));
    b.addEventListener('click', () => memoryFlip(idx, b));
    board.appendChild(b);
  });
}
function memoryUpdateStats() {
  if ($m('memorySteps')) $m('memorySteps').textContent = '步数 ' + memoryGame.steps;
  if ($m('memoryTime')) $m('memoryTime').textContent = '用时 ' + memoryGame.seconds + ' 秒';
}
function memoryStart() {
  memoryStopTimer();
  const deck = [...MEMORY_SYMBOLS, ...MEMORY_SYMBOLS];
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  memoryGame.deck = deck;
  memoryGame.first = null;
  memoryGame.lock = false;
  memoryGame.matched = 0;
  memoryGame.steps = 0;
  memoryGame.seconds = 0;
  memoryGame.state = 'playing';
  memoryRenderBoard();
  memoryUpdateStats();
  if ($m('memoryStatus')) $m('memoryStatus').textContent = '翻牌吧，找到相同的两张';
  memoryGame.timer = setInterval(() => {
    if (memoryGame.state !== 'playing') return;
    memoryGame.seconds += 1;
    memoryUpdateStats();
  }, 1000);
}
function memoryFlip(idx, btn) {
  if (memoryGame.state !== 'playing' || memoryGame.lock) return;
  if (btn.classList.contains('flipped') || btn.classList.contains('matched')) return;
  btn.classList.add('flipped');
  btn.textContent = memoryGame.deck[idx];
  if (memoryGame.first === null) {
    memoryGame.first = { idx, btn };
    return;
  }
  memoryGame.steps += 1;
  memoryUpdateStats();
  const first = memoryGame.first;
  memoryGame.first = null;
  if (memoryGame.deck[first.idx] === memoryGame.deck[idx]) {
    first.btn.classList.add('matched');
    btn.classList.add('matched');
    memoryGame.matched += 1;
    if (memoryGame.matched === MEMORY_SYMBOLS.length) memoryFinish();
  } else {
    memoryGame.lock = true;
    setTimeout(() => {
      first.btn.classList.remove('flipped');
      first.btn.textContent = '🐾';
      btn.classList.remove('flipped');
      btn.textContent = '🐾';
      memoryGame.lock = false;
    }, 700);
  }
}
async function memoryFinish() {
  memoryGame.state = 'done';
  memoryStopTimer();
  const score = Math.max(100, 1600 - memoryGame.steps * 20 - memoryGame.seconds * 5);
  if ($m('memoryStatus')) {
    $m('memoryStatus').textContent = '完成！步数 ' + memoryGame.steps + '，用时 ' + memoryGame.seconds + ' 秒，得分 ' + score;
  }
  mimiToast('翻牌完成，得分 ' + score);
  await recordScore('memory', score, { steps: memoryGame.steps, seconds: memoryGame.seconds });
  loadScores('memory', $m('memoryScores'));
}
function memoryEnd() {
  if (memoryGame.state !== 'playing') return;
  memoryGame.state = 'ended';
  memoryStopTimer();
  const board = $m('memoryBoard');
  if (board) board.querySelectorAll('.memory-card').forEach((b) => { b.disabled = true; });
  if ($m('memoryStatus')) $m('memoryStatus').textContent = '已结束，点「开始」可以再来一局';
}

/* ---------- 乐园：幸运转盘 ---------- */
let wheelSpinning = false;
let wheelRotation = 0;
async function spinWheel(btn) {
  if (wheelSpinning) return;
  wheelSpinning = true;
  if (btn) btn.disabled = true;
  let result = null;
  try {
    result = await mimiApi('/api/games/wheel', { method: 'POST', body: JSON.stringify({}) });
  } catch (e) {
    mimiToast('抽奖失败：' + (e.message || '后端未连接'));
    wheelSpinning = false;
    if (btn) btn.disabled = false;
    return;
  }
  const wheel = $m('wheel');
  wheelRotation += 1800 + Math.floor(Math.random() * 360);
  if (wheel) wheel.style.transform = 'rotate(' + wheelRotation + 'deg)';
  if ($m('wheelResult')) $m('wheelResult').textContent = '转盘转起来了…';
  setTimeout(async () => {
    const prize = result.prize || result.reward || '未知奖品';
    /* 奖品名只取 label/title（formatReward 会把 label 与 hearts 都拼上，造成三重重复） */
    const prizeText = (prize && typeof prize === 'object') ? (prize.label || prize.title || formatReward(prize)) : String(prize);
    /* 后端 hearts 是猫咪爱心总数，不是本次得的；本次所得只取 prize.hearts */
    const hearts = (prize && typeof prize === 'object' && prize.hearts != null) ? prize.hearts : null;
    if ($m('wheelResult')) {
      $m('wheelResult').textContent = '抽中：' + prizeText + (hearts != null ? '（爱心 +' + hearts + '）' : '');
    }
    let toastMsg = '抽中：' + prizeText;
    /* 后端若返回 collected（收入收藏的贴纸/装饰），toast 里补一句，绝不自己编收藏内容 */
    const collected = result && result.collected;
    if (collected != null) {
      const item = Array.isArray(collected)
        ? collected.map((c) => (c && typeof c === 'object' ? (c.item_id || c.id || c.label || '') : String(c))).filter(Boolean).join('、')
        : (collected && typeof collected === 'object' ? (collected.item_id || collected.id || collected.label || '') : String(collected));
      if (item) toastMsg += ' · 已收入收藏：' + item;
    }
    mimiToast(toastMsg);
    await recordScore('wheel', hearts != null ? hearts : 0, { prize });
    loadScores('wheel', $m('wheelScores'));
    wheelSpinning = false;
    if (btn) btn.disabled = false;
  }, 3000);
}

/* ---------- 我的页 ---------- */
function openSettingsSection(name) {
  if (typeof window.openSettings === 'function' && typeof window.showSection === 'function') {
    window.openSettings();
    window.showSection(name);
    return;
  }
  const overlay = $m('settingsOverlay');
  if (overlay) overlay.hidden = false;
  const item = document.querySelector('.menu-item[data-section="' + name + '"]');
  if (item) item.click();
  else mimiToast('打不开这个设置分区');
}
/* 房间主题（/api/room 的 theme）优先于我的页外观选择；没有房间主题时才用 #sceneThemeSelect */
let roomTheme = null;
function applySceneTheme() {
  const sel = $m('sceneThemeSelect');
  const home = $m('page-home');
  if (!home) return;
  const v = roomTheme || (sel ? (sel.value || 'auto') : 'auto');
  home.className = 'page scene-' + (v === 'auto' ? 'home' : v);
}
async function refreshMinePage() {
  loadScores('memory', $m('myGameScores'));
  const box = $m('myDailyRecords');
  if (!box) return;
  try {
    const d = dailyCache || await mimiApi('/api/daily');
    const tasks = asArrayM(d && d.tasks !== undefined ? d.tasks : d);
    const done = tasks.filter((t) => t.done).length;
    const claimed = tasks.filter((t) => t.claimed).length;
    box.innerHTML = '<p>今日任务：' + done + ' / ' + tasks.length + ' 已完成，' + claimed + ' 已领取' +
      (d && d.surprise ? ' · 盲盒：' + (d.surprise.claimed ? '已领（' + escM(formatReward(d.surprise.reward)) + '）' : '未领') : '') +
      (d && d.fortune ? ' · 幸运签：' + (d.fortune.drawn ? '已抽' : '未抽') : '') + '</p>';
  } catch (e) {
    box.innerHTML = '<p class="hint">每日记录读不到：' + escM(e.message || '后端未连接') + '</p>';
  }
}

/* ---------- 乐园：换装拍照（V4.0 第二阶段） ---------- */
const DRESS_ACC_KEYS = ['bow', 'hat', 'scarf', 'dress', 'glasses'];
const DRESS_BG_KEYS = ['bedroom', 'starry', 'garden', 'dessert', 'moon'];
const DRESS_POSE_KEYS = ['sit', 'lie', 'stand'];
/* 拍照 Canvas 用的背景渐变（与 style.css 的 dress-bg-* 对应） */
const DRESS_BG_GRADIENTS = {
  bedroom: ['#ffeef4', '#fff8ef'],
  starry: ['#f3e8ff', '#ffe9f3'],
  garden: ['#e8f7e3', '#ffe9f1'],
  dessert: ['#fff1d6', '#ffe9f1'],
  moon: ['#e6e2ff', '#fff4e6']
};
let dressOutfit = { bow: false, hat: false, scarf: false, dress: false, glasses: false, bg: 'bedroom', pose: 'sit' };
let dressSaving = false;

function normalizeOutfit(o) {
  const out = { bow: false, hat: false, scarf: false, dress: false, glasses: false, bg: 'bedroom', pose: 'sit' };
  if (!o || typeof o !== 'object') return out;
  for (const k of DRESS_ACC_KEYS) if (o[k] === true) out[k] = true;
  if (DRESS_BG_KEYS.includes(o.bg)) out.bg = o.bg;
  if (DRESS_POSE_KEYS.includes(o.pose)) out.pose = o.pose;
  return out;
}
function setDressupStatus(text) {
  const el = $m('dressupStatus');
  if (el) el.textContent = text;
}
function applyOutfit() {
  const preview = $m('dressupPreview');
  if (preview) preview.className = 'dressup-preview dress-bg-' + dressOutfit.bg + ' dress-pose-' + dressOutfit.pose;
  /* 首页猫（#catFigure 里的 <svg>）与换装猫（#dressCatSvg 本身就是 <svg>）共用同一模板、
   * 同一 dressOutfit：五件饰品的显隐必须同时应用到两只 SVG。只改 display，不动脸型/毛色/比例。
   * 时序安全：renderCatFigure 末尾调 applyOutfit（重渲染后 inline display:none 被重应用），
   * loadOutfit 异步返回后也调 applyOutfit；CatState.refresh/set 只动 g-* 表情层与 g-bow，
   * 从不动 .acc-*（见 catstate.js applyLayers），所以状态切换不会把饰品显隐重置。 */
  for (const container of [$m('catFigure'), $m('dressCatSvg')]) {
    if (!container) continue;
    for (const k of DRESS_ACC_KEYS) {
      const g = container.querySelector('.acc-' + k);
      if (g) g.style.display = dressOutfit[k] ? 'block' : 'none';
    }
  }
  document.querySelectorAll('.dress-acc-btn').forEach((b) => {
    const on = !!dressOutfit[b.dataset.acc];
    b.classList.toggle('selected', on);
    b.setAttribute('aria-pressed', String(on));
  });
  document.querySelectorAll('.dress-bg-btn').forEach((b) => {
    const on = b.dataset.bg === dressOutfit.bg;
    b.classList.toggle('selected', on);
    b.setAttribute('aria-pressed', String(on));
  });
  document.querySelectorAll('.dress-pose-btn').forEach((b) => {
    const on = b.dataset.pose === dressOutfit.pose;
    b.classList.toggle('selected', on);
    b.setAttribute('aria-pressed', String(on));
  });
}
async function loadOutfit() {
  try {
    const d = await mimiApi('/api/cat/outfit');
    dressOutfit = normalizeOutfit(d && d.outfit !== undefined ? d.outfit : d);
    applyOutfit();
    setDressupStatus('换装已读取');
  } catch (e) {
    applyOutfit();
    setDressupStatus('换装读不到：' + (e.message || '后端未连接') + '，先用默认搭配');
  }
}
async function saveOutfit() {
  if (dressSaving) return;
  dressSaving = true;
  try {
    await mimiApi('/api/cat/outfit', { method: 'PUT', body: JSON.stringify({ outfit: dressOutfit }) });
    setDressupStatus('换装已保存');
  } catch (e) {
    setDressupStatus('保存失败：' + (e.message || '后端未连接') + '，换装只留在了当前页面');
    mimiToast('换装保存失败：' + (e.message || '后端未连接'));
  } finally {
    dressSaving = false;
  }
}
async function dressupPhoto(btn) {
  const svg = $m('dressCatSvg');
  if (!svg) { mimiToast('拍照失败：找不到换装猫咪'); return; }
  if (btn) btn.disabled = true;
  try {
    const clone = svg.cloneNode(true);
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    clone.setAttribute('width', '720');
    clone.setAttribute('height', '720');
    const svgText = new XMLSerializer().serializeToString(clone);
    const svgBlob = new Blob([svgText], { type: 'image/svg+xml;charset=utf-8' });
    const svgUrl = URL.createObjectURL(svgBlob);
    try {
      const img = await new Promise((resolve, reject) => {
        const im = new Image();
        im.onload = () => resolve(im);
        im.onerror = () => reject(new Error('猫咪图片加载失败'));
        im.src = svgUrl;
      });
      const canvas = document.createElement('canvas');
      canvas.width = 720;
      canvas.height = 720;
      const c = canvas.getContext('2d');
      if (!c) throw new Error('Canvas 不可用');
      const cols = DRESS_BG_GRADIENTS[dressOutfit.bg] || DRESS_BG_GRADIENTS.bedroom;
      const grad = c.createLinearGradient(0, 0, 0, 720);
      grad.addColorStop(0, cols[0]);
      grad.addColorStop(1, cols[1]);
      c.fillStyle = grad;
      c.fillRect(0, 0, 720, 720);
      /* 姿势的 CSS transform 不进 SVG 序列化，这里在 Canvas 里等价还原 */
      c.save();
      c.translate(360, 360);
      if (dressOutfit.pose === 'lie') { c.scale(1.05, 0.82); c.translate(0, 60); }
      else if (dressOutfit.pose === 'stand') { c.scale(0.94, 0.94); c.translate(0, -12); }
      c.translate(-360, -360);
      c.drawImage(img, 0, 0, 720, 720);
      c.restore();
      const pngBlob = await new Promise((resolve, reject) => {
        canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('生成图片失败'))), 'image/png');
      });
      const pngUrl = URL.createObjectURL(pngBlob);
      const a = document.createElement('a');
      a.href = pngUrl;
      a.download = 'mimi-cat.png';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(pngUrl), 5000);
      setDressupStatus('照片已下载：mimi-cat.png');
    } finally {
      URL.revokeObjectURL(svgUrl);
    }
  } catch (e) {
    setDressupStatus('拍照失败：' + (e.message || '未知错误'));
    mimiToast('拍照失败：' + (e.message || '未知错误'));
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ---------- 乐园：房间装扮（V4.0 第二阶段） ---------- */
const ROOM_WALLPAPER_KEYS = ['pink', 'sakura', 'lavender', 'peach', 'starry'];
const ROOM_BED_KEYS = ['pink', 'white', 'lavender'];
const ROOM_PLUSH_KEYS = ['bear', 'bunny', 'cat'];
const ROOM_PAINTING_KEYS = ['none', 'cat', 'flower', 'heart'];
const ROOM_THEME_KEYS = ['home', 'chat', 'memories', 'park', 'mine'];
const ROOM_PLUSH_EMOJI = { bear: '🧸', bunny: '🐰', cat: '🐱' };
const ROOM_PAINTING_EMOJI = { none: '', cat: '🐱', flower: '🌸', heart: '💗' };
let roomState = { wallpaper: 'pink', bed: 'pink', plushies: [], lamp: true, flowers: true, painting: 'none', theme: 'home' };
let roomSaving = false;
let roomSavePending = false;

function normalizeRoom(r) {
  const out = { wallpaper: 'pink', bed: 'pink', plushies: [], lamp: true, flowers: true, painting: 'none', theme: 'home' };
  if (!r || typeof r !== 'object') return out;
  if (ROOM_WALLPAPER_KEYS.includes(r.wallpaper)) out.wallpaper = r.wallpaper;
  if (ROOM_BED_KEYS.includes(r.bed)) out.bed = r.bed;
  if (Array.isArray(r.plushies)) out.plushies = r.plushies.filter((p) => ROOM_PLUSH_KEYS.includes(p));
  else if (typeof r.plushies === 'string') out.plushies = r.plushies.split(',').map((s) => s.trim()).filter((p) => ROOM_PLUSH_KEYS.includes(p));
  if (typeof r.lamp === 'boolean') out.lamp = r.lamp;
  if (typeof r.flowers === 'boolean') out.flowers = r.flowers;
  if (ROOM_PAINTING_KEYS.includes(r.painting)) out.painting = r.painting;
  if (ROOM_THEME_KEYS.includes(r.theme)) out.theme = r.theme;
  return out;
}
function renderRoom() {
  const preview = $m('roomPreview');
  if (preview) {
    preview.className = 'room-preview room-wp-' + roomState.wallpaper;
    const bed = $m('roomBedItem');
    if (bed) bed.dataset.bed = roomState.bed;
    const setShow = (id, on) => { const el = $m(id); if (el) el.style.display = on ? '' : 'none'; };
    setShow('roomPlushBear', roomState.plushies.includes('bear'));
    setShow('roomPlushBunny', roomState.plushies.includes('bunny'));
    setShow('roomPlushCat', roomState.plushies.includes('cat'));
    setShow('roomLampItem', roomState.lamp);
    setShow('roomFlowerItem', roomState.flowers);
    const painting = $m('roomPaintingItem');
    if (painting) {
      painting.style.display = roomState.painting === 'none' ? 'none' : '';
      painting.textContent = '🖼' + (ROOM_PAINTING_EMOJI[roomState.painting] || '');
    }
  }
  document.querySelectorAll('[data-room-wallpaper]').forEach((b) => b.classList.toggle('selected', b.dataset.roomWallpaper === roomState.wallpaper));
  document.querySelectorAll('[data-room-bed]').forEach((b) => b.classList.toggle('selected', b.dataset.roomBed === roomState.bed));
  document.querySelectorAll('[data-room-plush]').forEach((b) => b.classList.toggle('selected', roomState.plushies.includes(b.dataset.roomPlush)));
  document.querySelectorAll('[data-room-painting]').forEach((b) => b.classList.toggle('selected', b.dataset.roomPainting === roomState.painting));
  document.querySelectorAll('[data-room-theme]').forEach((b) => b.classList.toggle('selected', b.dataset.roomTheme === roomState.theme));
  const lampBtn = $m('roomLampBtn');
  if (lampBtn) { lampBtn.classList.toggle('selected', roomState.lamp); lampBtn.textContent = roomState.lamp ? '💡 小灯开' : '💡 小灯关'; }
  const flowerBtn = $m('roomFlowerBtn');
  if (flowerBtn) { flowerBtn.classList.toggle('selected', roomState.flowers); flowerBtn.textContent = roomState.flowers ? '🌸 花朵开' : '🌸 花朵关'; }
}
async function loadRoom() {
  try {
    const d = await mimiApi('/api/room');
    roomState = normalizeRoom(d && d.room ? d.room : d);
    roomTheme = roomState.theme || null;
    renderRoom();
    applySceneTheme();
    if ($m('roomStatus')) $m('roomStatus').textContent = '房间已同步';
  } catch (e) {
    if ($m('roomStatus')) $m('roomStatus').textContent = '房间读不到：' + (e.message || '后端未连接');
  }
}
async function saveRoom() {
  if (roomSaving) { roomSavePending = true; return; }
  roomSaving = true;
  try {
    const d = await mimiApi('/api/room', { method: 'PUT', body: JSON.stringify(roomState) });
    if (d && (d.room || d.ok !== false)) {
      roomState = normalizeRoom(d.room || d);
      roomTheme = roomState.theme || null;
      renderRoom();
      applySceneTheme();
    }
  } catch (e) {
    mimiToast('房间保存失败：' + (e.message || '后端未连接'));
  } finally {
    roomSaving = false;
    /* 连续改动时正在保存的那次会跳过，这里把最新状态补存一次，不丢改动 */
    if (roomSavePending) { roomSavePending = false; saveRoom(); }
  }
}
function roomChange(patch) {
  Object.assign(roomState, patch);
  roomTheme = roomState.theme || null;
  renderRoom();
  applySceneTheme();
  saveRoom();
}

/* ---------- 乐园：小花园（V4.0 第二阶段） ---------- */
const FLOWER_TYPES = {
  daisy: { emoji: '🌼', name: '雏菊' },
  rose: { emoji: '🌹', name: '玫瑰' },
  tulip: { emoji: '🌷', name: '郁金香' },
  sunflower: { emoji: '🌻', name: '向日葵' }
};
const GARDEN_STAGES = { seed: '种子', sprout: '发芽', bud: '花苞', bloom: '开花' };
function gardenSlotId(s, i) {
  return s && (s.id != null ? s.id : s.slot != null ? s.slot : s.index != null ? s.index : i);
}
function renderGarden(slots, pots) {
  const box = $m('gardenSlots');
  if (!box) return;
  box.innerHTML = '';
  /* 兜底：后端未返回槽位（或返回空数组）时，也要留一个明确的种花入口（第 1 槽），
   * 不能只剩一行提示文字——否则空花园永远点不到种花。后端实际返回的是 plots，见 loadGarden。 */
  const empty = !Array.isArray(slots) || !slots.length;
  if (empty) {
    box.innerHTML = '<p class="hint">花园是空的，先种一朵花吧</p>';
  }
  const list = empty ? [{ slot: 0, flower: null, stage: 'empty', progress: 0 }] : slots;
  {
    list.forEach((s, i) => {
      const id = gardenSlotId(s, i);
      const card = document.createElement('div');
      card.className = 'garden-slot';
      const flower = s && s.flower ? (FLOWER_TYPES[s.flower] || { emoji: '🌱', name: s.flower }) : null;
      const stage = s && s.stage ? (GARDEN_STAGES[s.stage] || s.stage) : '';
      const progress = s && s.progress != null ? Math.max(0, Math.min(100, Number(s.progress) || 0)) : 0;
      const head = document.createElement('div');
      head.className = 'garden-slot-head';
      head.innerHTML = '<span class="garden-flower">' + (flower ? escM(flower.emoji) + ' ' + escM(flower.name) : '🪴 空花盆') + '</span>' +
        '<span class="garden-stage">' + (flower ? escM(stage) : '第 ' + (i + 1) + ' 槽') + '</span>';
      card.appendChild(head);
      if (flower) {
        const bar = document.createElement('div');
        bar.className = 'garden-progress';
        bar.innerHTML = '<div class="garden-progress-fill" style="width:' + progress + '%"></div>';
        card.appendChild(bar);
        const pct = document.createElement('div');
        pct.className = 'garden-progress-text';
        pct.textContent = '生长 ' + progress + '%';
        card.appendChild(pct);
      }
      const actions = document.createElement('div');
      actions.className = 'row garden-actions';
      if (!flower) {
        const sel = document.createElement('select');
        sel.setAttribute('aria-label', '选择花种');
        for (const k of Object.keys(FLOWER_TYPES)) {
          const opt = document.createElement('option');
          opt.value = k;
          opt.textContent = FLOWER_TYPES[k].emoji + ' ' + FLOWER_TYPES[k].name;
          sel.appendChild(opt);
        }
        const plantBtn = document.createElement('button');
        plantBtn.className = 'btn primary';
        plantBtn.textContent = '种花';
        plantBtn.addEventListener('click', () => gardenPlant(id, sel.value, plantBtn));
        actions.appendChild(sel);
        actions.appendChild(plantBtn);
      } else if (s.stage === 'bloom') {
        const harvestBtn = document.createElement('button');
        harvestBtn.className = 'btn primary';
        harvestBtn.textContent = '收获 🌸';
        harvestBtn.addEventListener('click', () => gardenHarvest(id, harvestBtn));
        actions.appendChild(harvestBtn);
      } else {
        const watered = s.watered === true || s.needs_water === false;
        const waterBtn = document.createElement('button');
        waterBtn.className = 'btn';
        waterBtn.textContent = watered ? '已浇水，等它长大' : '浇水 💧';
        waterBtn.disabled = !!watered;
        if (!watered) waterBtn.addEventListener('click', () => gardenWater(id, waterBtn));
        actions.appendChild(waterBtn);
      }
      card.appendChild(actions);
      box.appendChild(card);
    });
  }
  const potsBox = $m('gardenPots');
  if (potsBox) {
    potsBox.innerHTML = '';
    if (!Array.isArray(pots) || !pots.length) {
      /* 花盆解锁条件是后端数据，没有就不编数字，只诚实提示 */
      potsBox.innerHTML = '<p class="hint">花盆信息读不到，后端未返回</p>';
    } else {
      for (const p of pots) {
        const el = document.createElement('div');
        const unlocked = p.unlocked === true || p.unlocked === 1;
        el.className = 'garden-pot' + (unlocked ? '' : ' locked');
        el.innerHTML = '<div class="garden-pot-emoji">' + escM(p.emoji || '🪴') + '</div>' +
          '<div class="garden-pot-name">' + escM(p.name || p.id || '花盆') + '</div>' +
          '<div class="garden-pot-state">' + (unlocked ? '已解锁' : '收获 ' + (p.harvests_required != null ? p.harvests_required : '？') + ' 次解锁') + '</div>';
        potsBox.appendChild(el);
      }
    }
  }
}
async function loadGarden() {
  try {
    const d = await mimiApi('/api/garden');
    /* 后端 getGarden() 实际返回 { plots, pots, harvests }，键名是 plots；
     * 之前这里只认 slots/garden/list，空槽永远读不到。plots 优先，旧键名保留兼容。 */
    const slots = Array.isArray(d) ? d : (d && (d.plots || d.slots || d.garden || d.list) ? (d.plots || d.slots || d.garden || d.list) : []);
    const pots = d && Array.isArray(d.pots) ? d.pots : null;
    renderGarden(slots, pots);
  } catch (e) {
    const box = $m('gardenSlots');
    if (box) box.innerHTML = '<p class="hint">花园读不到：' + escM(e.message || '后端未连接') + '</p>';
  }
}
async function gardenPlant(slot, flower, btn) {
  if (btn) btn.disabled = true;
  try {
    await mimiApi('/api/garden/plant', { method: 'POST', body: JSON.stringify({ slot, flower }) });
    mimiToast('已种下' + (FLOWER_TYPES[flower] ? FLOWER_TYPES[flower].name : flower));
    await loadGarden();
  } catch (e) {
    mimiToast('种花失败：' + (e.message || '后端未连接'));
    if (btn) btn.disabled = false;
  }
}
async function gardenWater(slot, btn) {
  if (btn) btn.disabled = true;
  try {
    await mimiApi('/api/garden/water', { method: 'POST', body: JSON.stringify({ slot }) });
    mimiToast('已浇水 💧');
    await loadGarden();
  } catch (e) {
    mimiToast('浇水失败：' + (e.message || '后端未连接'));
    if (btn) btn.disabled = false;
  }
}
async function gardenHarvest(slot, btn) {
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/garden/harvest', { method: 'POST', body: JSON.stringify({ slot }) });
    const reward = r && (r.reward || r.gained);
    mimiToast(reward ? '收获成功：' + formatReward(reward) : '收获成功 🌸');
    await loadGarden();
  } catch (e) {
    mimiToast('收获失败：' + (e.message || '后端未连接'));
    if (btn) btn.disabled = false;
  }
}

/* ---------- 首页：心动事件（V4.0 第二阶段） ---------- */
const EVENT_ANIM_EMOJI = {
  'cat-cuddle': '🐱💗',
  'flower-gift': '🌸💐',
  'pink-rain': '💗🌸💗',
  'mystery-note': '💌✨',
  'gift-box': '🎁',
  'heart-appear': '💗'
};
let currentEvent = null;
let eventCooldownUntil = 0;
let eventCooldownTimer = null;
let eventAutoDone = false;
function eventCooldownLeft() {
  return Math.max(0, Math.ceil((eventCooldownUntil - Date.now()) / 1000));
}
function renderEventCooldown() {
  const btn = $m('eventNextBtn');
  if (!btn) return;
  const left = eventCooldownLeft();
  if (left > 0) {
    btn.disabled = true;
    btn.textContent = '再等 ' + left + ' 秒';
  } else {
    btn.disabled = false;
    btn.textContent = '等一个小心动';
    if (eventCooldownTimer) { clearInterval(eventCooldownTimer); eventCooldownTimer = null; }
  }
}
function startEventCooldown(seconds) {
  eventCooldownUntil = Date.now() + seconds * 1000;
  renderEventCooldown();
  if (eventCooldownTimer) clearInterval(eventCooldownTimer);
  eventCooldownTimer = setInterval(renderEventCooldown, 1000);
}
function showEvent(ev) {
  if (!ev || typeof ev !== 'object') return;
  currentEvent = ev;
  const body = $m('eventBody');
  const anim = $m('eventAnim');
  const title = $m('eventTitle');
  const text = $m('eventText');
  if (!body || !anim || !title || !text) return;
  const animKey = ev.anim || ev.animation || '';
  anim.className = 'event-anim' + (animKey ? ' anim-' + animKey : '');
  anim.textContent = EVENT_ANIM_EMOJI[animKey] || '💗';
  title.textContent = ev.title || '心动时刻';
  text.textContent = ev.text || ev.content || '';
  body.hidden = false;
  const hint = $m('eventHint');
  if (hint) hint.hidden = true;
}
function hideEvent() {
  const body = $m('eventBody');
  if (body) body.hidden = true;
  const hint = $m('eventHint');
  if (hint) hint.hidden = false;
  currentEvent = null;
}
async function fetchNextEvent(opts = {}) {
  const btn = $m('eventNextBtn');
  if (!opts.auto && eventCooldownLeft() > 0) return;
  if (btn) btn.disabled = true;
  try {
    const d = await mimiApi('/api/events/next');
    const ev = d && d.event ? d.event : d;
    if (!ev || typeof ev !== 'object' || (!ev.title && !ev.text && !ev.content)) {
      mimiToast('这次没有等到小心动，稍后再试');
    } else {
      showEvent(ev);
    }
  } catch (e) {
    mimiToast('心动事件读不到：' + (e.message || '后端未连接'));
  } finally {
    startEventCooldown(60);
  }
}
async function favoriteEvent(btn) {
  if (!currentEvent || currentEvent.id == null) { mimiToast('先等一个小心动，再收藏它'); return; }
  if (btn) btn.disabled = true;
  try {
    await mimiApi('/api/events/' + encodeURIComponent(currentEvent.id) + '/favorite', { method: 'POST', body: JSON.stringify({}) });
    mimiToast('已收藏 ♥');
  } catch (e) {
    mimiToast('收藏失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}
function scheduleAutoEvent() {
  if (eventAutoDone) return;
  eventAutoDone = true;
  setTimeout(() => {
    if (Math.random() >= 0.3) return;
    if (currentPage !== 'home') return;
    fetchNextEvent({ auto: true });
  }, 2000);
}

/* ---------- 回忆：神秘信箱（V4.0 第二阶段） ---------- */
let currentLetter = null;
function letterSourceText(l) {
  const source = (l && (l.source || l.from)) || '';
  if (/真实聊天记录/.test(source)) {
    const cat = l.category || '';
    const date = l.date || l.created_at || '';
    return '来自真实聊天记录' + (cat ? ' · ' + cat : '') + (date ? ' · ' + fmtDateM(date) : '');
  }
  if (/原创/.test(source)) return '原创小纸条';
  return source || '神秘信件';
}
function renderLetter(l) {
  if (!l || typeof l !== 'object') return;
  currentLetter = l;
  const body = $m('letterBody');
  const src = $m('letterSource');
  const txt = $m('letterText');
  if (!body || !src || !txt) return;
  src.textContent = letterSourceText(l);
  /* 信件内容一律用后端原文，不改写、不编造 */
  txt.textContent = l.content || l.text || '';
  body.hidden = false;
}
async function drawLetter(btn) {
  if (btn) btn.disabled = true;
  try {
    const d = await mimiApi('/api/letters/draw', { method: 'POST', body: JSON.stringify({}) });
    const letter = d && d.letter ? d.letter : d;
    if (!letter || typeof letter !== 'object' || !(letter.content || letter.text)) {
      mimiToast('信箱是空的，稍后再开');
    } else {
      renderLetter(letter);
    }
    await loadLetters();
  } catch (e) {
    mimiToast('开信箱失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}
async function loadLetters() {
  const ul = $m('letterList');
  if (!ul) return;
  try {
    const d = await mimiApi('/api/letters');
    const list = asArrayM(d).filter((l) => l && l.status !== 'deleted' && !l.deleted);
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">还没有信件</li>'; return; }
    for (const l of list) {
      const li = document.createElement('li');
      const saved = l.saved === true || l.favorite === true || l.is_favorite === true;
      li.innerHTML = '<div class="m-title">' + (saved ? '♥ ' : '') + escM(l.content || l.text || '') + '</div>' +
        '<div class="m-date">' + escM(letterSourceText(l)) + (l.created_at || l.date ? ' · ' + escM(fmtDateM(l.created_at || l.date)) : '') + '</div>';
      li.style.cursor = 'pointer';
      li.addEventListener('click', () => renderLetter(l));
      ul.appendChild(li);
    }
  } catch (e) {
    ul.innerHTML = '<li class="hint">信件读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
async function saveLetter(btn) {
  if (!currentLetter || currentLetter.id == null) { mimiToast('先打开一封信，再收藏它'); return; }
  if (btn) btn.disabled = true;
  try {
    await mimiApi('/api/letters/' + encodeURIComponent(currentLetter.id) + '/save', { method: 'POST', body: JSON.stringify({}) });
    mimiToast('已收藏 ♥');
    await loadLetters();
  } catch (e) {
    mimiToast('收藏失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}
async function deleteLetter(btn) {
  if (!currentLetter || currentLetter.id == null) { mimiToast('先打开一封信，再删它'); return; }
  if (btn) btn.disabled = true;
  try {
    await mimiApi('/api/letters/' + encodeURIComponent(currentLetter.id), { method: 'DELETE' });
    mimiToast('这封信已删除');
    currentLetter = null;
    const body = $m('letterBody');
    if (body) body.hidden = true;
    await loadLetters();
  } catch (e) {
    mimiToast('删除失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ================= V4.0 第三阶段前端 =================
 * 只做前端：回忆加深（手动回忆/照片墙空态/聊天收藏/纪念日/心情日记/每日报告）、
 * 情绪陪伴中心、睡前陪伴模式。只按契约调后端，不自造接口名，不碰人格/DeepSeek 配置。
 * 情绪只存在 JS 变量里，不写进任何持久化人格；发完一次即清除。 */

/* ---------- 日期小工具 ---------- */
function todayStrLocal(d) {
  const t = d || new Date();
  return t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
}
/* daysUntil('2026-12-25', '2026-11-11') === 44；UTC 算整天数，不受本地时区影响 */
function daysUntil(dateStr, todayStr) {
  if (!dateStr) return null;
  const parse = (s) => {
    const p = String(s).slice(0, 10).split('-');
    if (p.length !== 3) return null;
    const t = Date.UTC(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
    return isNaN(t) ? null : t;
  };
  const target = parse(dateStr);
  const today = parse(todayStr || todayStrLocal());
  if (target == null || today == null) return null;
  return Math.round((target - today) / 86400000);
}

/* ---------- 情绪陪伴中心 ---------- */
const EMOTIONS = {
  happy: { label: '今天很开心', mood: '开心', pills: ['今天超开心的！', '跟你分享个好消息', '今天心情超好'] },
  sad: { label: '今天有点难过', mood: '难过', pills: ['今天有点难过', '想跟你说说话', '今天不太开心'] },
  wronged: { label: '今天很委屈', mood: '委屈', pills: ['今天有点委屈', '被欺负了呜呜', '好委屈呀'] },
  irritated: { label: '有点烦躁', mood: '烦躁', pills: ['今天有点烦躁', '心情有点烦', '想发发牢骚'] },
  praise: { label: '想被夸奖', mood: '想被夸', pills: ['快夸夸我', '今天想被夸一下', '我今天超棒的对不对'] },
  clingy: { label: '想撒娇', mood: '想撒娇', pills: ['想你了', '抱抱我嘛', '想撒个娇'] },
  talk: { label: '想找人聊天', mood: '想找人聊天', pills: ['在干嘛呀', '陪我聊聊天', '无聊了找你说说话'] },
  quiet: { label: '想安静待一会儿', mood: '想安静待一会儿', pills: ['想安静待一会儿', '今天不想说话，陪陪我就好', '让我静静'] },
};
let pendingEmotion = null;

function setEmotion(key) {
  const e = EMOTIONS[key];
  if (!e) return;
  pendingEmotion = key;
  /* 情绪入口要自动保存今日心情（用心情日记同一套心情词）：
   * 之前这里没保存，保存是靠初始化里 `.mood-btn` 通绑的 saveMood(b.dataset.mood)，
   * 但情绪按钮只有 data-emotion、没有 data-mood，于是发了空 mood，被后端 400 拒收。 */
  saveMood(e.mood);
  const banner = $m('emotionBanner');
  if (banner) {
    banner.hidden = false;
    if ($m('emotionBannerText')) $m('emotionBannerText').textContent = '已告诉小猪你' + e.label;
  }
  const pills = $m('emotionPills');
  if (pills) {
    pills.hidden = false;
    pills.innerHTML = '';
    for (const p of e.pills) {
      const b = document.createElement('button');
      b.className = 'btn emotion-pill';
      b.type = 'button';
      b.textContent = p;
      b.addEventListener('click', () => sendPill(p));
      pills.appendChild(b);
    }
  }
  showPage('chat');
}
function clearEmotion() {
  pendingEmotion = null;
  const banner = $m('emotionBanner');
  if (banner) banner.hidden = true;
  const pills = $m('emotionPills');
  if (pills) { pills.hidden = true; pills.innerHTML = ''; }
}
/* 药丸只填进输入框再点发送（走 app.js 正常的发送流程），绝不替用户自动发话 */
function sendPill(text) {
  const input = $m('input');
  if (!input) return;
  input.value = text;
  input.dispatchEvent(new Event('input', { bubbles: true }));
  const btn = $m('sendBtn');
  if (btn && !btn.disabled) btn.click();
}
/* app.js 的 sendMessage 不认识 emotion，这里包一层 fetch：只有发往 /chat 的 POST
 * 且本次有情绪待发送时，才在 body 里补一个 emotion 字段；发完一次（无论成功失败）
 * 就清除情绪状态。其他请求原样透传。 */
let emotionFetchWrapped = false;
function wrapFetchForEmotion() {
  if (emotionFetchWrapped) return;
  if (typeof window.fetch !== 'function') return;
  emotionFetchWrapped = true;
  const origFetch = window.fetch.bind(window);
  window.fetch = function (url, opts) {
    opts = opts || {};
    const method = String(opts.method || 'GET').toUpperCase();
    const isChatPost = method === 'POST' && /\/api\/sessions\/[^/]+\/chat/.test(String(url));
    if (isChatPost && pendingEmotion) {
      const emotion = pendingEmotion;
      let body = opts.body;
      try {
        const parsed = typeof body === 'string' ? JSON.parse(body) : (body || {});
        parsed.emotion = emotion;
        body = JSON.stringify(parsed);
      } catch (e) { /* body 不是 JSON 时不注入 */ }
      const p = origFetch(url, Object.assign({}, opts, { body }));
      const done = () => { if (pendingEmotion === emotion) clearEmotion(); };
      if (p && typeof p.then === 'function') p.then(done, done);
      else done();
      return p;
    }
    return origFetch(url, opts);
  };
}
wrapFetchForEmotion();

/* ---------- 聊天收藏（⭐ 按钮挂在消息行上） ---------- */
const favMidSet = new Set();
function currentSessionId() {
  try { return localStorage.getItem('v3_session_id') || ''; } catch (e) { return ''; }
}
function attachFavoriteButtons() {
  const box = $m('messages');
  if (!box) return;
  box.querySelectorAll('.msg-row').forEach((row) => {
    if (row.classList.contains('system')) return;
    if (row.querySelector('.fav-btn')) return;
    const mid = row.dataset.mid || '';
    if (!mid) return;
    const body = row.querySelector('.msg-body');
    if (!body) return;
    const b = document.createElement('button');
    b.className = 'fav-btn';
    b.type = 'button';
    b.dataset.mid = mid;
    b.setAttribute('aria-label', '收藏这条聊天');
    b.textContent = favMidSet.has(String(mid)) ? '⭐' : '☆';
    b.addEventListener('click', (ev) => { ev.stopPropagation(); toggleFavorite(mid, b); });
    body.appendChild(b);
  });
}
async function toggleFavorite(mid, btn) {
  const sid = currentSessionId();
  if (!sid || !mid) { mimiToast('这条消息还没有编号，稍后再试'); return; }
  const want = !favMidSet.has(String(mid));
  if (btn) btn.disabled = true;
  try {
    const r = await mimiApi('/api/sessions/' + encodeURIComponent(sid) + '/messages/' + encodeURIComponent(mid) + '/favorite', { method: 'POST', body: JSON.stringify({ favorite: want }) });
    const fav = r && r.favorite !== undefined ? !!r.favorite : want;
    if (fav) favMidSet.add(String(mid)); else favMidSet.delete(String(mid));
    if (btn) btn.textContent = fav ? '⭐' : '☆';
    mimiToast(fav ? '已收藏 ⭐' : '已取消收藏');
    if (currentPage === 'memories') loadFavoritesList();
  } catch (e) {
    mimiToast('收藏失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}
let favObserver = null;
function watchMessagesForFav() {
  const box = $m('messages');
  if (!box || favObserver || typeof MutationObserver === 'undefined') return;
  favObserver = new MutationObserver(() => attachFavoriteButtons());
  favObserver.observe(box, { childList: true, subtree: true });
  attachFavoriteButtons();
}
async function loadChatFavorites() {
  try {
    const d = await mimiApi('/api/favorites');
    const list = asArrayM(d && d.favorites !== undefined ? d.favorites : d);
    favMidSet.clear();
    for (const f of list) if (f && f.id != null) favMidSet.add(String(f.id));
  } catch (e) { /* 读不到就不标记，收藏按钮仍可用 */ }
  attachFavoriteButtons();
}
async function loadFavoritesList() {
  const ul = $m('favoritesList');
  if (!ul) return;
  try {
    const d = await mimiApi('/api/favorites');
    const list = asArrayM(d && d.favorites !== undefined ? d.favorites : d);
    favMidSet.clear();
    for (const f of list) if (f && f.id != null) favMidSet.add(String(f.id));
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">还没有收藏的聊天</li>'; return; }
    for (const f of list) {
      const li = document.createElement('li');
      li.innerHTML = '<div>' + escM(f.content || '') + '</div>' +
        '<div class="m-date">' + escM(f.role === 'user' || f.role === 'mine' ? '我' : '小猪') + ' · ' + escM(fmtDateM(f.created_at)) + '</div>';
      const b = document.createElement('button');
      b.className = 'btn';
      b.textContent = '取消收藏';
      b.addEventListener('click', async () => {
        if (!f.session_id || f.id == null) { mimiToast('这条收藏没有会话信息，取消不了'); return; }
        b.disabled = true;
        try {
          await mimiApi('/api/sessions/' + encodeURIComponent(f.session_id) + '/messages/' + encodeURIComponent(f.id) + '/favorite', { method: 'POST', body: JSON.stringify({ favorite: false }) });
          favMidSet.delete(String(f.id));
          mimiToast('已取消收藏');
          loadFavoritesList();
        } catch (e) {
          mimiToast('取消失败：' + (e.message || '后端未连接'));
          b.disabled = false;
        }
      });
      li.appendChild(b);
      ul.appendChild(li);
    }
  } catch (e) {
    ul.innerHTML = '<li class="hint">收藏读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}

/* ---------- 手动添加回忆 ---------- */
let editingManualMemId = null;
async function loadManualMemories() {
  const ul = $m('manualMemList');
  if (!ul) return;
  try {
    const d = await mimiApi('/api/manual-memories');
    const list = asArrayM(d && d.memories !== undefined ? d.memories : d);
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">还没有手动回忆，写下第一条吧</li>'; return; }
    for (const m of list) {
      const li = document.createElement('li');
      li.innerHTML = '<div class="m-title">' + escM(m.title || '未命名回忆') + '</div>' +
        '<div>' + escM(m.text || '') + '</div>' +
        '<div class="m-date">' + escM(m.date || '') + (m.created_at ? ' · ' + escM(fmtDateM(m.created_at)) : '') + '</div>';
      const row = document.createElement('div');
      row.className = 'row';
      const edit = document.createElement('button');
      edit.className = 'btn';
      edit.textContent = '编辑';
      edit.addEventListener('click', () => {
        editingManualMemId = m.id;
        if ($m('manualMemTitle')) $m('manualMemTitle').value = m.title || '';
        if ($m('manualMemDate')) $m('manualMemDate').value = (m.date || '').slice(0, 10);
        if ($m('manualMemText')) $m('manualMemText').value = m.text || '';
        if ($m('manualMemSubmitBtn')) $m('manualMemSubmitBtn').textContent = '保存修改';
        if ($m('manualMemCancelBtn')) $m('manualMemCancelBtn').hidden = false;
        if ($m('manualMemStatus')) $m('manualMemStatus').textContent = '正在编辑这条回忆，改完点「保存修改」';
        if ($m('manualMemTitle')) $m('manualMemTitle').focus();
      });
      const del = document.createElement('button');
      del.className = 'btn danger';
      del.textContent = '删除';
      del.addEventListener('click', async () => {
        del.disabled = true;
        try {
          await mimiApi('/api/manual-memories/' + encodeURIComponent(m.id), { method: 'DELETE' });
          mimiToast('已删除这条回忆');
          loadManualMemories();
        } catch (e) {
          mimiToast('删除失败：' + (e.message || '后端未连接'));
          del.disabled = false;
        }
      });
      row.appendChild(edit);
      row.appendChild(del);
      li.appendChild(row);
      ul.appendChild(li);
    }
  } catch (e) {
    ul.innerHTML = '<li class="hint">手动回忆读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
function resetManualMemoryForm() {
  editingManualMemId = null;
  if ($m('manualMemTitle')) $m('manualMemTitle').value = '';
  if ($m('manualMemDate')) $m('manualMemDate').value = '';
  if ($m('manualMemText')) $m('manualMemText').value = '';
  if ($m('manualMemSubmitBtn')) $m('manualMemSubmitBtn').textContent = '保存这条回忆';
  if ($m('manualMemCancelBtn')) $m('manualMemCancelBtn').hidden = true;
  if ($m('manualMemStatus')) $m('manualMemStatus').textContent = '';
}
async function submitManualMemory(btn) {
  const title = ($m('manualMemTitle') ? $m('manualMemTitle').value : '').trim();
  const date = $m('manualMemDate') ? $m('manualMemDate').value : '';
  const text = ($m('manualMemText') ? $m('manualMemText').value : '').trim();
  if (!title) { mimiToast('先写个标题'); return; }
  if (!date) { mimiToast('先选个日期'); return; }
  if (btn) btn.disabled = true;
  try {
    if (editingManualMemId != null) {
      await mimiApi('/api/manual-memories/' + encodeURIComponent(editingManualMemId), { method: 'PUT', body: JSON.stringify({ title, date, text }) });
      mimiToast('回忆已更新');
    } else {
      await mimiApi('/api/manual-memories', { method: 'POST', body: JSON.stringify({ title, date, text }) });
      mimiToast('回忆已保存');
    }
    resetManualMemoryForm();
    loadManualMemories();
  } catch (e) {
    mimiToast('保存失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ---------- 纪念日倒计时 ---------- */
let editingAnnivId = null;
function annivText(a) {
  const days = a && a.days_left != null ? Number(a.days_left) : daysUntil(a && a.date);
  if (days == null || isNaN(days)) return '';
  if (days > 0) return '还有 ' + days + ' 天';
  if (days === 0) return '就是今天 🎉';
  return '已经过去 ' + Math.abs(days) + ' 天';
}
async function loadAnniversaries() {
  const ul = $m('annivList');
  if (!ul) return;
  try {
    const d = await mimiApi('/api/anniversaries');
    const list = asArrayM(d && d.anniversaries !== undefined ? d.anniversaries : d);
    ul.innerHTML = '';
    if (!list.length) { ul.innerHTML = '<li class="hint">还没有纪念日</li>'; return; }
    for (const a of list) {
      const li = document.createElement('li');
      li.innerHTML = '<div class="m-title">' + escM(a.name || '纪念日') + ' · ' + escM(annivText(a)) + '</div>' +
        '<div class="m-date">' + escM(a.date || '') + '</div>';
      const row = document.createElement('div');
      row.className = 'row';
      const edit = document.createElement('button');
      edit.className = 'btn';
      edit.textContent = '编辑';
      edit.addEventListener('click', () => {
        editingAnnivId = a.id;
        if ($m('annivName')) $m('annivName').value = a.name || '';
        if ($m('annivDate')) $m('annivDate').value = (a.date || '').slice(0, 10);
        if ($m('annivSubmitBtn')) $m('annivSubmitBtn').textContent = '保存修改';
        if ($m('annivCancelBtn')) $m('annivCancelBtn').hidden = false;
        if ($m('annivStatus')) $m('annivStatus').textContent = '正在编辑这个纪念日，改完点「保存修改」';
        if ($m('annivName')) $m('annivName').focus();
      });
      const del = document.createElement('button');
      del.className = 'btn danger';
      del.textContent = '删除';
      del.addEventListener('click', async () => {
        del.disabled = true;
        try {
          await mimiApi('/api/anniversaries/' + encodeURIComponent(a.id), { method: 'DELETE' });
          mimiToast('已删除这个纪念日');
          loadAnniversaries();
        } catch (e) {
          mimiToast('删除失败：' + (e.message || '后端未连接'));
          del.disabled = false;
        }
      });
      row.appendChild(edit);
      row.appendChild(del);
      li.appendChild(row);
      ul.appendChild(li);
    }
  } catch (e) {
    ul.innerHTML = '<li class="hint">纪念日读不到：' + escM(e.message || '后端未连接') + '</li>';
  }
}
function resetAnnivForm() {
  editingAnnivId = null;
  if ($m('annivName')) $m('annivName').value = '';
  if ($m('annivDate')) $m('annivDate').value = '';
  if ($m('annivSubmitBtn')) $m('annivSubmitBtn').textContent = '保存纪念日';
  if ($m('annivCancelBtn')) $m('annivCancelBtn').hidden = true;
  if ($m('annivStatus')) $m('annivStatus').textContent = '';
}
async function submitAnniversary(btn) {
  const name = ($m('annivName') ? $m('annivName').value : '').trim();
  const date = $m('annivDate') ? $m('annivDate').value : '';
  if (!name) { mimiToast('先写个纪念日名称'); return; }
  if (!date) { mimiToast('先选个日期'); return; }
  if (btn) btn.disabled = true;
  try {
    if (editingAnnivId != null) {
      await mimiApi('/api/anniversaries/' + encodeURIComponent(editingAnnivId), { method: 'PUT', body: JSON.stringify({ name, date }) });
      mimiToast('纪念日已更新');
    } else {
      await mimiApi('/api/anniversaries', { method: 'POST', body: JSON.stringify({ name, date }) });
      mimiToast('纪念日已保存');
    }
    resetAnnivForm();
    loadAnniversaries();
  } catch (e) {
    mimiToast('保存失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ---------- 心情日记：写心情 + 按日期查 ---------- */
async function submitMoodDiary(btn) {
  const mood = $m('moodDiaryMood') ? $m('moodDiaryMood').value : '';
  const note = ($m('moodDiaryNote') ? $m('moodDiaryNote').value : '').trim();
  if (!mood) { mimiToast('先选今日心情'); return; }
  if (btn) btn.disabled = true;
  try {
    await mimiApi('/api/mood', { method: 'POST', body: JSON.stringify({ mood, note }) });
    if ($m('moodDiaryStatus')) $m('moodDiaryStatus').textContent = '今日心情已保存：' + mood + (note ? ' · ' + note : '');
    if ($m('moodDiaryNote')) $m('moodDiaryNote').value = '';
    renderTodayMood(mood);
    loadMoodRecent();
    mimiToast('今日心情已保存：' + mood);
  } catch (e) {
    mimiToast('保存失败：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}
async function lookupMoodByDate(btn) {
  const date = $m('moodLookupDate') ? $m('moodLookupDate').value : '';
  const out = $m('moodLookupResult');
  if (!date) { if (out) out.textContent = '先选一个日期'; return; }
  if (btn) btn.disabled = true;
  try {
    const d = await mimiApi('/api/mood?date=' + encodeURIComponent(date));
    /* 只认日期对得上的记录：后端若不支持 ?date 而返回了今天的数据，绝不能把它当成那天的心情 */
    const pick = (r) => {
      if (!r || typeof r !== 'object') return null;
      const ds = String(r.date || r.created_at || '').slice(0, 10);
      return ds === date ? r : null;
    };
    let found = pick(d);
    if (!found) {
      const list = asArrayM(d && d.recent !== undefined ? d.recent : d);
      for (const r of list) { found = pick(r); if (found) break; }
    }
    if (out) {
      if (found) {
        const mood = found.mood || found.today || '';
        out.textContent = date + ' 的心情：' + (typeof mood === 'string' ? mood : (mood.mood || '')) + (found.note ? ' · ' + found.note : '');
      } else {
        out.textContent = '这天没有心情记录';
      }
    }
  } catch (e) {
    if (out) out.textContent = '查不到：' + (e.message || '后端未连接');
  } finally {
    if (btn) btn.disabled = false;
  }
}

/* ---------- 每日陪伴报告 ---------- */
function renderReport(d) {
  const box = $m('reportBody');
  if (!box) return;
  if (!d || typeof d !== 'object') { box.innerHTML = '<p class="hint">今天还没有报告</p>'; return; }
  const rows = [];
  const chat = d.chat || {};
  const cu = Number(chat.user) || 0;
  const ca = Number(chat.assistant) || 0;
  rows.push(['💬 聊天', (cu || ca) ? ('用户 ' + cu + ' 条 / 小猪 ' + ca + ' 条') : '今天还没有聊天']);
  const mood = d.mood;
  rows.push(['💭 心情', mood ? escM(mood.mood || '') + (mood.note ? ' · ' + escM(mood.note) : '') : '今天还没有心情记录']);
  const tasks = d.tasks || {};
  const total = Number(tasks.total) || 0;
  const done = Number(tasks.done) || 0;
  const claimed = Number(tasks.claimed) || 0;
  rows.push(['✅ 任务', total ? ('已完成 ' + done + ' / ' + total + '，已领奖 ' + claimed + ' 个') : '今天还没有任务']);
  const surprise = d.surprise || {};
  rows.push(['🎁 盲盒', surprise.claimed ? '已开' : '今天还没有开盲盒']);
  const games = Array.isArray(d.games) ? d.games : [];
  rows.push(['🎡 游戏', games.length
    ? games.map((g) => escM((GAME_NAMES[g.game] || g.game || '游戏') + ' · 得分 ' + (g.score ?? '–') + (g.played_at ? ' · ' + fmtDateM(g.played_at) : ''))).join('<br>')
    : '今天还没有游戏成绩']);
  const cat = d.cat;
  if (!cat) {
    rows.push(['🐱 猫咪', '今天还没有猫咪记录']);
  } else {
    const ht = Number(cat.heartsToday) || 0;
    const it = Number(cat.intimacyToday) || 0;
    rows.push(['🐱 猫咪', '爱心 ' + (cat.hearts ?? '–') + ' · 亲密度 ' + (cat.intimacy ?? '–') +
      ((ht || it) ? '（今日爱心 +' + ht + ' · 亲密度 +' + it + '）' : '（今日还没有变化）')]);
  }
  const garden = d.garden || {};
  const harvested = Array.isArray(garden.harvested) ? garden.harvested : [];
  const growing = Array.isArray(garden.growing) ? garden.growing : [];
  rows.push(['🌷 花园', '收获：' + (harvested.length ? harvested.map((h) => escM(typeof h === 'string' ? h : (h.flower || h.name || ''))).filter(Boolean).join('、') : '今天还没有收获') +
    '<br>生长中：' + (growing.length ? growing.map((g) => escM((FLOWER_TYPES[g.flower] ? FLOWER_TYPES[g.flower].name : (g.flower || '')) + ' · ' + (GARDEN_STAGES[g.stage] || g.stage || '') + ' · 生长 ' + (Number(g.progress) || 0) + '%')).join('、') : '今天没有正在生长的花')]);
  const letters = d.letters || {};
  const drawn = Number(letters.drawn) || 0;
  const saved = Number(letters.saved) || 0;
  rows.push(['💌 信件', (drawn || saved) ? ('抽取 ' + drawn + ' 封 · 收藏 ' + saved + ' 封') : '今天还没有抽信件，也没有收藏信件']);
  box.innerHTML = rows.map(([label, html]) =>
    '<div class="report-row"><div class="report-label">' + label + '</div><div class="report-value">' + html + '</div></div>'
  ).join('');
}
async function loadReport(dateStr) {
  const box = $m('reportBody');
  const input = $m('reportDate');
  const date = dateStr || (input ? input.value : '') || todayStrLocal();
  if (input) input.value = date;
  if (date > todayStrLocal()) {
    if (box) box.innerHTML = '<p class="hint">还没到那天</p>';
    mimiToast('还没到那天');
    return;
  }
  if (box) box.innerHTML = '<p class="hint">正在读取报告…</p>';
  try {
    const d = await mimiApi('/api/report?date=' + encodeURIComponent(date));
    renderReport(d);
  } catch (e) {
    if (box) box.innerHTML = '<p class="hint">报告读不到：' + escM(e.message || '后端未连接') + '</p>';
  }
}
function shiftReportDate(delta) {
  const input = $m('reportDate');
  if (!input) return;
  const cur = input.value || todayStrLocal();
  const p = cur.split('-');
  const t = new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]) + delta);
  loadReport(todayStrLocal(t));
}

/* ---------- 睡前陪伴模式 ---------- */
let bedtimeOpen = false;
function renderBedtimeCat() {
  const fig = $m('bedtimeCatFigure');
  if (!fig) return;
  if (typeof window.buildCatSVG === 'function') {
    fig.innerHTML = '<svg viewBox="0 0 220 200" class="cat-svg" aria-hidden="true">' +
      window.buildCatSVG({ suffix: 'bedtime' }) + '</svg>';
  }
  /* 睡觉态：闭眼、藏起开心眼/嘴/舌头/爱心/毛线球（只改这只猫的层，不动首页猫） */
  const svg = fig.querySelector('.cat-svg');
  if (!svg) return;
  const hide = (sel) => { const el = svg.querySelector(sel); if (el) el.style.display = 'none'; };
  const show = (sel) => { const el = svg.querySelector(sel); if (el) el.style.display = ''; };
  hide('.g-eye-open');
  hide('.g-eye-happy');
  hide('.g-mouth');
  hide('.g-mouth-yawn');
  hide('.g-mouth-sad');
  hide('.g-tongue');
  hide('.cat-hearts');
  hide('.cat-yarn');
  show('.g-eye-closed');
}
function openBedtime() {
  const ov = $m('bedtimeOverlay');
  if (!ov) return;
  renderBedtimeCat();
  ov.hidden = false;
  bedtimeOpen = true;
  /* 暂停首页猫的待机随机动画（与 visibilitychange 的处理一样：挂 .paused） */
  const fig = $m('catFigure');
  if (fig) fig.classList.add('paused');
}
function closeBedtime() {
  const ov = $m('bedtimeOverlay');
  if (ov) ov.hidden = true;
  bedtimeOpen = false;
  stopLullaby();
  const fig = $m('catFigure');
  if (fig) fig.classList.remove('paused');
}
async function fetchBedtimeStory(btn) {
  const box = $m('bedtimeStoryBox');
  const src = $m('bedtimeStorySource');
  const txt = $m('bedtimeStoryText');
  if (!box || !txt) return;
  if (btn) btn.disabled = true;
  try {
    const d = await mimiApi('/api/bedtime/story', { method: 'POST', body: JSON.stringify({}) });
    const story = d && (d.story || d.text || d.content);
    if (!story) {
      mimiToast('今晚没有故事，稍后再试');
      return;
    }
    txt.textContent = story;
    if (src) src.textContent = d.source === 'deepseek' ? '小猪现讲的' : '小故事（AI 讲不了时用的本地故事）';
    box.hidden = false;
  } catch (e) {
    mimiToast('故事没讲成：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}
async function fetchBedtimeLetter(btn) {
  const box = $m('bedtimeLetterBox');
  const src = $m('bedtimeLetterSource');
  const txt = $m('bedtimeLetterText');
  if (!box || !txt) return;
  if (btn) btn.disabled = true;
  try {
    const d = await mimiApi('/api/bedtime/letter');
    const letter = d && (d.letter || d.text || d.content);
    if (!letter) {
      mimiToast('今晚没有信，稍后再试');
      return;
    }
    txt.textContent = letter;
    if (src) src.textContent = d.source === 'generic' ? '一封通用晚安信' : (d.source || '晚安信');
    box.hidden = false;
  } catch (e) {
    mimiToast('信没收到：' + (e.message || '后端未连接'));
  } finally {
    if (btn) btn.disabled = false;
  }
}
/* 摇篮曲：WebAudio 合成的轻柔摇篮音（仿照 catfx.js 的写法：只在用户点击后建
 * AudioContext，单音正弦 + 淡入淡出，循环轻奏；不做语音播放，没有任何“语音”按钮）。
 * 开关状态保存在 localStorage，只恢复开关记忆，绝不自动播放。 */
let lullabyCtx = null;
let lullabyTimer = null;
let lullabyOn = false;
let lullabyStep = 0;
const LULLABY_NOTES = [523.25, 659.25, 783.99, 659.25, 587.33, 523.25, 493.88, 587.33];
const LULLABY_KEY = 'v3_lullaby_on';
function updateLullabyBtn() {
  const b = $m('bedtimeLullabyBtn');
  if (!b) return;
  b.textContent = lullabyOn ? '🎵 摇篮曲 开' : '🎵 摇篮曲 关';
  b.setAttribute('aria-pressed', String(lullabyOn));
}
function lullabyNote(freq) {
  if (!lullabyCtx) return;
  try {
    const t0 = lullabyCtx.currentTime;
    const osc = lullabyCtx.createOscillator();
    const g = lullabyCtx.createGain();
    osc.type = 'sine';
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(0.12, t0 + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.4);
    osc.connect(g);
    g.connect(lullabyCtx.destination);
    osc.start(t0);
    osc.stop(t0 + 1.5);
  } catch (e) { /* 静默失败 */ }
}
function startLullaby() {
  if (window.CatFX && window.CatFX.isMuted && window.CatFX.isMuted()) {
    mimiToast('音效是静音的，先在首页打开音效');
    return false;
  }
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { mimiToast('这台设备放不了摇篮曲'); return false; }
    if (!lullabyCtx) lullabyCtx = new AC();
    if (lullabyCtx.state === 'suspended') {
      const p = lullabyCtx.resume();
      if (p && p.catch) p.catch(() => { /* 静默失败 */ });
    }
    lullabyOn = true;
    lullabyStep = 0;
    try { localStorage.setItem(LULLABY_KEY, '1'); } catch (e) { /* 忽略 */ }
    updateLullabyBtn();
    lullabyNote(LULLABY_NOTES[0]);
    lullabyStep = 1;
    lullabyTimer = setInterval(() => {
      lullabyNote(LULLABY_NOTES[lullabyStep % LULLABY_NOTES.length]);
      lullabyStep++;
    }, 900);
    return true;
  } catch (e) {
    mimiToast('摇篮曲放不出来');
    return false;
  }
}
function stopLullaby() {
  if (lullabyTimer) { clearInterval(lullabyTimer); lullabyTimer = null; }
  lullabyOn = false;
  try { localStorage.setItem(LULLABY_KEY, '0'); } catch (e) { /* 忽略 */ }
  updateLullabyBtn();
  if (lullabyCtx) {
    try {
      if (lullabyCtx.close) {
        const p = lullabyCtx.close();
        if (p && p.catch) p.catch(() => { /* 静默失败 */ });
      }
    } catch (e) { /* 忽略 */ }
    lullabyCtx = null;
  }
}
function toggleLullaby() {
  if (lullabyOn) stopLullaby();
  else startLullaby();
}

Object.assign(window.MimiCat, {
  setEmotion,
  clearEmotion,
  daysUntil,
  annivText,
  loadManualMemories,
  loadAnniversaries,
  loadFavoritesList,
  loadReport,
  openBedtime,
  closeBedtime,
  toggleLullaby,
  get pendingEmotion() { return pendingEmotion; },
});

/* ---------- 初始化 ---------- */
function initMimi() {
  renderCatFigure();
  document.querySelectorAll('.nav-btn').forEach((b) =>
    b.addEventListener('click', () => showPage(b.dataset.page)));
  document.querySelectorAll('[data-nav]').forEach((b) =>
    b.addEventListener('click', () => showPage(b.dataset.nav)));
  document.querySelectorAll('[data-open-section]').forEach((b) =>
    b.addEventListener('click', () => openSettingsSection(b.dataset.openSection)));

  updateClock();
  setInterval(updateClock, 30000);

  document.querySelectorAll('[data-cat-action]').forEach((b) =>
    b.addEventListener('click', () => catInteract(b.dataset.catAction, b)));
  updateSoundToggleBtn();
  const soundBtn = $m('soundToggleBtn');
  if (soundBtn) soundBtn.addEventListener('click', toggleSound);
  /* 今日心情选择器：只绑真正带 data-mood 的按钮。
   * 情绪入口按钮（data-emotion）复用 .mood-btn 样式但没有 data-mood，
   * 以前通绑 .mood-btn 会让点情绪入口时多发一次 saveMood(undefined)，
   * 被后端 400「需要 mood」拒收、弹出「保存失败：需要 mood」。 */
  document.querySelectorAll('.mood-btn[data-mood]').forEach((b) =>
    b.addEventListener('click', () => saveMood(b.dataset.mood, b)));

  const surpriseBtn = $m('surpriseBtn');
  if (surpriseBtn) surpriseBtn.addEventListener('click', () => openSurprise(surpriseBtn));
  const fortuneBtn = $m('fortuneBtn');
  if (fortuneBtn) fortuneBtn.addEventListener('click', () => drawFortune(fortuneBtn));

  const memStart = $m('memoryStartBtn');
  if (memStart) memStart.addEventListener('click', memoryStart);
  const memRestart = $m('memoryRestartBtn');
  if (memRestart) memRestart.addEventListener('click', memoryStart);
  const memEnd = $m('memoryEndBtn');
  if (memEnd) memEnd.addEventListener('click', memoryEnd);
  const wheelBtn = $m('wheelSpinBtn');
  if (wheelBtn) wheelBtn.addEventListener('click', () => spinWheel(wheelBtn));

  /* 房间装扮 */
  document.querySelectorAll('[data-room-wallpaper]').forEach((b) =>
    b.addEventListener('click', () => roomChange({ wallpaper: b.dataset.roomWallpaper })));
  document.querySelectorAll('[data-room-bed]').forEach((b) =>
    b.addEventListener('click', () => roomChange({ bed: b.dataset.roomBed })));
  document.querySelectorAll('[data-room-plush]').forEach((b) =>
    b.addEventListener('click', () => {
      const p = b.dataset.roomPlush;
      const next = roomState.plushies.includes(p)
        ? roomState.plushies.filter((x) => x !== p)
        : roomState.plushies.concat(p);
      roomChange({ plushies: next });
    }));
  const lampBtn = $m('roomLampBtn');
  if (lampBtn) lampBtn.addEventListener('click', () => roomChange({ lamp: !roomState.lamp }));
  const flowerBtn = $m('roomFlowerBtn');
  if (flowerBtn) flowerBtn.addEventListener('click', () => roomChange({ flowers: !roomState.flowers }));
  document.querySelectorAll('[data-room-painting]').forEach((b) =>
    b.addEventListener('click', () => roomChange({ painting: b.dataset.roomPainting })));
  document.querySelectorAll('[data-room-theme]').forEach((b) =>
    b.addEventListener('click', () => roomChange({ theme: b.dataset.roomTheme })));
  renderRoom();
  loadRoom();

  /* 心动事件 */
  const eventNextBtn = $m('eventNextBtn');
  if (eventNextBtn) eventNextBtn.addEventListener('click', () => fetchNextEvent());
  const eventFavBtn = $m('eventFavBtn');
  if (eventFavBtn) eventFavBtn.addEventListener('click', () => favoriteEvent(eventFavBtn));
  const eventCloseBtn = $m('eventCloseBtn');
  if (eventCloseBtn) eventCloseBtn.addEventListener('click', hideEvent);
  scheduleAutoEvent();

  /* 神秘信箱 */
  const letterDrawBtn = $m('letterDrawBtn');
  if (letterDrawBtn) letterDrawBtn.addEventListener('click', () => drawLetter(letterDrawBtn));
  const letterSaveBtn = $m('letterSaveBtn');
  if (letterSaveBtn) letterSaveBtn.addEventListener('click', () => saveLetter(letterSaveBtn));
  const letterDeleteBtn = $m('letterDeleteBtn');
  if (letterDeleteBtn) letterDeleteBtn.addEventListener('click', () => deleteLetter(letterDeleteBtn));

  /* 换装拍照 */
  document.querySelectorAll('.dress-acc-btn').forEach((b) =>
    b.addEventListener('click', () => {
      const k = b.dataset.acc;
      if (!DRESS_ACC_KEYS.includes(k)) return;
      dressOutfit[k] = !dressOutfit[k];
      applyOutfit();
      saveOutfit();
    }));
  document.querySelectorAll('.dress-bg-btn').forEach((b) =>
    b.addEventListener('click', () => {
      if (!DRESS_BG_KEYS.includes(b.dataset.bg)) return;
      dressOutfit.bg = b.dataset.bg;
      applyOutfit();
      saveOutfit();
    }));
  document.querySelectorAll('.dress-pose-btn').forEach((b) =>
    b.addEventListener('click', () => {
      if (!DRESS_POSE_KEYS.includes(b.dataset.pose)) return;
      dressOutfit.pose = b.dataset.pose;
      applyOutfit();
      saveOutfit();
    }));
  const photoBtn = $m('dressupPhotoBtn');
  if (photoBtn) photoBtn.addEventListener('click', () => dressupPhoto(photoBtn));
  loadOutfit();

  const themeSel = $m('sceneThemeSelect');
  if (themeSel) {
    try {
      const saved = localStorage.getItem('v3_scene_theme');
      if (saved) themeSel.value = saved;
    } catch (e) { /* 忽略 */ }
    themeSel.addEventListener('change', () => {
      try { localStorage.setItem('v3_scene_theme', themeSel.value); } catch (e) { /* 忽略 */ }
      applySceneTheme();
      mimiToast('首页场景已切换');
    });
    applySceneTheme();
  }

  /* ---------- V4.0 第三阶段：情绪陪伴 / 回忆加深 / 睡前模式 / 每日报告 ---------- */
  document.querySelectorAll('[data-emotion]').forEach((b) =>
    b.addEventListener('click', () => setEmotion(b.dataset.emotion)));
  const emotionClearBtn = $m('emotionClearBtn');
  if (emotionClearBtn) emotionClearBtn.addEventListener('click', clearEmotion);
  wrapFetchForEmotion();
  watchMessagesForFav();

  const manualMemSubmitBtn = $m('manualMemSubmitBtn');
  if (manualMemSubmitBtn) manualMemSubmitBtn.addEventListener('click', () => submitManualMemory(manualMemSubmitBtn));
  const manualMemCancelBtn = $m('manualMemCancelBtn');
  if (manualMemCancelBtn) manualMemCancelBtn.addEventListener('click', resetManualMemoryForm);
  const annivSubmitBtn = $m('annivSubmitBtn');
  if (annivSubmitBtn) annivSubmitBtn.addEventListener('click', () => submitAnniversary(annivSubmitBtn));
  const annivCancelBtn = $m('annivCancelBtn');
  if (annivCancelBtn) annivCancelBtn.addEventListener('click', resetAnnivForm);
  const moodDiarySubmitBtn = $m('moodDiarySubmitBtn');
  if (moodDiarySubmitBtn) moodDiarySubmitBtn.addEventListener('click', () => submitMoodDiary(moodDiarySubmitBtn));
  const moodLookupBtn = $m('moodLookupBtn');
  if (moodLookupBtn) moodLookupBtn.addEventListener('click', () => lookupMoodByDate(moodLookupBtn));
  const reportQueryBtn = $m('reportQueryBtn');
  if (reportQueryBtn) reportQueryBtn.addEventListener('click', () => loadReport());
  const reportPrevBtn = $m('reportPrevBtn');
  if (reportPrevBtn) reportPrevBtn.addEventListener('click', () => shiftReportDate(-1));
  const reportNextBtn = $m('reportNextBtn');
  if (reportNextBtn) reportNextBtn.addEventListener('click', () => shiftReportDate(1));
  const bedtimeOpenBtn = $m('bedtimeOpenBtn');
  if (bedtimeOpenBtn) bedtimeOpenBtn.addEventListener('click', openBedtime);
  const bedtimeStoryBtn = $m('bedtimeStoryBtn');
  if (bedtimeStoryBtn) bedtimeStoryBtn.addEventListener('click', () => fetchBedtimeStory(bedtimeStoryBtn));
  const bedtimeLetterBtn = $m('bedtimeLetterBtn');
  if (bedtimeLetterBtn) bedtimeLetterBtn.addEventListener('click', () => fetchBedtimeLetter(bedtimeLetterBtn));
  const bedtimeLullabyBtn = $m('bedtimeLullabyBtn');
  if (bedtimeLullabyBtn) bedtimeLullabyBtn.addEventListener('click', toggleLullaby);
  const bedtimeCloseBtn = $m('bedtimeCloseBtn');
  if (bedtimeCloseBtn) bedtimeCloseBtn.addEventListener('click', closeBedtime);
  updateLullabyBtn();

  showPage('home');
}

document.addEventListener('DOMContentLoaded', initMimi);
