'use strict';
/* Mimi Cat · V4.0 第二阶段：猫咪互动音效（WebAudio 合成，零外链音频）。
 * AudioContext 只在用户点击互动后创建/恢复（手机自动播放策略）；
 * 创建失败或被拒时静默失败，不报错、不显示任何“已播放”文案。 */
(function () {
  var STORAGE_KEY = 'v3_sound_muted';
  var ctx = null;
  var master = null;

  function loadMuted() {
    try { return localStorage.getItem(STORAGE_KEY) === '1'; } catch (e) { return false; }
  }
  var muted = loadMuted();

  function ensureCtx() {
    if (muted) return null;
    try {
      if (!ctx) {
        var AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        ctx = new AC();
        master = ctx.createGain();
        master.gain.value = 0.22;
        master.connect(ctx.destination);
      }
      if (ctx.state === 'suspended') {
        var p = ctx.resume();
        if (p && p.catch) p.catch(function () { /* 静默失败 */ });
      }
      return ctx;
    } catch (e) { return null; }
  }

  /* 一段带淡入淡出的正弦/三角音 */
  function tone(freq, delay, dur, type, vol) {
    if (!ctx || !master) return;
    var t0 = ctx.currentTime + delay;
    var osc = ctx.createOscillator();
    var g = ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    g.connect(master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  function noiseBuffer() {
    var len = Math.floor(ctx.sampleRate * 1);
    var buf = ctx.createBuffer(1, len, ctx.sampleRate);
    var data = buf.getChannelData(0);
    for (var i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    return buf;
  }

  /* 一段短噪声（可指定滤波器类型/频率/时长/音量） */
  function noiseBurst(delay, dur, filterType, filterFreq, vol) {
    if (!ctx || !master) return;
    var t0 = ctx.currentTime + delay;
    var src = ctx.createBufferSource();
    src.buffer = noiseBuffer();
    var filter = ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.value = filterFreq;
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(vol, t0 + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(master);
    src.start(t0);
    src.stop(t0 + dur + 0.05);
  }

  /* pet：轻柔呼噜声——55Hz 低频正弦 + LFO 调制振幅，约 1.2 秒 */
  function playPurr() {
    var t0 = ctx.currentTime;
    var osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = 55;
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(0.9, t0 + 0.15);
    g.gain.setValueAtTime(0.9, t0 + 1.0);
    g.gain.linearRampToValueAtTime(0.0001, t0 + 1.2);
    var lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = 25;
    var lfoGain = ctx.createGain();
    lfoGain.gain.value = 0.35;
    lfo.connect(lfoGain);
    lfoGain.connect(g.gain);
    osc.connect(g);
    g.connect(master);
    osc.start(t0);
    lfo.start(t0);
    osc.stop(t0 + 1.25);
    lfo.stop(t0 + 1.25);
  }

  /* feed：两下短促“咬一口”——短 noise burst + 800Hz 短音，间隔 0.25 秒 */
  function playBite() {
    for (var i = 0; i < 2; i++) {
      var d = i * 0.25;
      noiseBurst(d, 0.08, 'bandpass', 800, 0.8);
      tone(800, d, 0.07, 'triangle', 0.35);
    }
  }

  /* sleep：轻鼾/摇篮风铃——柔和正弦琶音 E5→C5→A4，每音 0.5 秒，音量 0.15 */
  function playLullaby() {
    var notes = [659.25, 523.25, 440.0]; /* E5 C5 A4 */
    for (var i = 0; i < notes.length; i++) {
      tone(notes[i], i * 0.5, 0.5, 'sine', 0.15);
    }
  }

  /* play：轻快三音符 C5 E5 G5，每音 0.12 秒 */
  function playPlayful() {
    var notes = [523.25, 659.25, 783.99]; /* C5 E5 G5 */
    for (var i = 0; i < notes.length; i++) {
      tone(notes[i], i * 0.12, 0.12, 'triangle', 0.3);
    }
  }

  /* bath：水花声——带通滤波噪声 0.6 秒 + 两滴水音 */
  function playSplash() {
    noiseBurst(0, 0.6, 'bandpass', 1200, 0.6);
    tone(1200, 0.1, 0.08, 'sine', 0.25);
    tone(900, 0.45, 0.08, 'sine', 0.25);
  }

  var PLAYERS = { pet: playPurr, feed: playBite, sleep: playLullaby, play: playPlayful, bath: playSplash };

  function play(action) {
    if (muted) return false;
    var fn = PLAYERS[action];
    if (!fn) return false;
    try {
      if (!ensureCtx()) return false;
      fn();
      return true;
    } catch (e) { return false; /* 静默失败，不报错 */ }
  }

  function setMuted(bool) {
    muted = !!bool;
    try { localStorage.setItem(STORAGE_KEY, muted ? '1' : '0'); } catch (e) { /* 忽略 */ }
  }

  window.CatFX = {
    play: play,
    setMuted: setMuted,
    isMuted: function () { return muted; },
    ensureCtx: ensureCtx
  };
})();
