'use strict';
/* 小猪 · 独立 AI 男生聊天页 — 纯原生 JS，无框架无 CDN。
 * 后端契约：同源 /api/*，端口 3100（部署时同源，直接相对路径）。
 * 未连后端时不编造回复，只诚实提示。Key 不经前端。 */

const $ = (id) => document.getElementById(id);
const LS = { token: 'v3_token', sessionId: 'v3_session_id', nickname: 'v3_nickname' };

const state = {
  token: localStorage.getItem(LS.token) || '',
  sessionId: localStorage.getItem(LS.sessionId) || '',
  nickname: localStorage.getItem(LS.nickname) || '小猪',
  connected: false,
  authMode: null,           // 'login' | 'setup' | null（null = 开放，无需密码）
  streaming: false,
  sessions: [],
  messages: [],             // {id, role, content, created_at}
  persona: [],              // [{key,title,content}]
  memories: [],
  currentActionMsg: null,
};

/* ---------- 工具 ---------- */
function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  if (isNaN(d)) return '';
  return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
}
function fmtDate(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  if (isNaN(d)) return '';
  return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + fmtTime(ts);
}
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(t._timer);
  t._timer = setTimeout(() => { t.hidden = true; }, 1800);
}
function asArray(v) {
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object') {
    for (const k of ['sessions', 'messages', 'memories', 'samples', 'persona', 'items', 'data', 'list']) {
      if (Array.isArray(v[k])) return v[k];
    }
  }
  return [];
}

/* ---------- API ---------- */
async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
  const res = await fetch(path, { ...opts, headers });
  if (res.status === 401) { openAuth('login'); throw new Error('需要先登录'); }
  if (!res.ok) {
    let msg = '请求失败（' + res.status + '）';
    try { const j = await res.json(); if (j && (j.message || j.error)) msg = j.message || j.error; } catch (e) { /* 非 JSON 忽略 */ }
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }
  const ct = res.headers.get('content-type') || '';
  return ct.includes('application/json') ? res.json() : res.text();
}

function setConn(online, text) {
  state.connected = online;
  $('connStatus').classList.toggle('online', online);
  $('connStatus').classList.toggle('offline', !online);
  $('connText').textContent = text;
}

async function checkHealth() {
  try {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), 4000);
    const res = await fetch('/healthz', { signal: ctl.signal });
    clearTimeout(t);
    if (res.ok) { setConn(true, '在线'); return true; }
    throw new Error('healthz 非 200');
  } catch (e) {
    setConn(false, '后端未连接（3100）');
    return false;
  }
}

async function checkAuthStatus() {
  try {
    const s = await api('/api/auth/status');
    const hasPw = s.hasPassword ?? s.needsPassword ?? s.locked ?? s.requireAuth;
    if (hasPw === true && !state.token) openAuth('login');
    else if (s.needsSetup === true || s.hasPassword === false) state.authMode = null;
  } catch (e) {
    // 后端未连时不弹窗，顶部状态已说明
  }
}

/* ---------- 登录 ---------- */
function openAuth(mode) {
  state.authMode = mode;
  $('authTitle').textContent = mode === 'setup' ? '设置访问密码' : '输入访问密码';
  $('authHint').textContent = mode === 'setup'
    ? '第一次使用，先设一个只有你知道的访问密码。'
    : '这个空间设了密码，输入后才能聊天。';
  $('authError').hidden = true;
  $('authPassword').value = '';
  $('authOverlay').hidden = false;
  setTimeout(() => $('authPassword').focus(), 100);
}
function closeAuth() { $('authOverlay').hidden = true; }
async function submitAuth() {
  const pw = $('authPassword').value.trim();
  if (!pw) { $('authError').textContent = '密码不能为空'; $('authError').hidden = false; return; }
  try {
    const path = state.authMode === 'setup' ? '/api/auth/setup' : '/api/auth/login';
    const r = await api(path, { method: 'POST', body: JSON.stringify({ password: pw }) });
    if (r && r.token) {
      state.token = r.token;
      localStorage.setItem(LS.token, r.token);
    }
    closeAuth();
    toast('已进入');
    await initChat();
  } catch (e) {
    $('authError').textContent = e.message || '密码不对，再试一次';
    $('authError').hidden = false;
  }
}

/* ---------- 消息渲染 ---------- */
function bubbleHtml(content) {
  // AI 短句多条按换行分段显示
  return String(content ?? '').split('\n').filter((l) => l.trim() !== '' || content.includes('\n'))
    .map((l) => '<p>' + esc(l) + '</p>').join('') || '<p></p>';
}
function renderMessages() {
  const box = $('messages');
  box.innerHTML = '';
  for (const m of state.messages) addMessageRow(m, false);
  box.scrollTop = box.scrollHeight;
}
function addMessageRow(m, scroll = true) {
  const box = $('messages');
  const row = document.createElement('div');
  const role = m.role === 'user' || m.role === 'mine' ? 'mine'
    : (m.role === 'system' || m.role === 'error') ? 'system' : 'theirs';
  row.className = 'msg-row ' + role;
  row.dataset.mid = m.id || '';
  row.dataset.role = role;
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  if (role === 'system' && m.info) bubble.classList.add('info');
  bubble.innerHTML = bubbleHtml(m.content);
  row.appendChild(bubble);
  const t = document.createElement('div');
  t.className = 'msg-time';
  t.textContent = fmtTime(m.created_at || m.time || Date.now());
  row.appendChild(t);
  attachMsgGestures(row, m);
  box.appendChild(row);
  if (scroll) box.scrollTop = box.scrollHeight;
  return row;
}
function addSystemMsg(text, info = false) {
  const m = { id: 'sys-' + Date.now(), role: 'system', content: text, created_at: Date.now(), info };
  state.messages.push(m);
  addMessageRow(m);
}
function attachMsgGestures(row, m) {
  if (m.role === 'system') return;
  let timer = null, longPressed = false;
  const start = () => {
    longPressed = false;
    timer = setTimeout(() => { longPressed = true; openActionSheet(m); }, 500);
  };
  const cancel = () => clearTimeout(timer);
  row.addEventListener('pointerdown', start);
  row.addEventListener('pointerup', cancel);
  row.addEventListener('pointerleave', cancel);
  row.addEventListener('click', () => {
    if (longPressed) return;
    if (timer) { /* 短点也打开操作 */ }
    openActionSheet(m);
  });
  row.addEventListener('contextmenu', (e) => { e.preventDefault(); openActionSheet(m); });
}

/* ---------- 会话 ---------- */
async function loadSessions() {
  try {
    const data = await api('/api/sessions');
    state.sessions = asArray(data).map((s) => ({
      id: s.id, title: s.title || s.name || '新的聊天',
      created_at: s.created_at, updated_at: s.updated_at,
    }));
  } catch (e) { state.sessions = []; }
}
function renderSessionList() {
  const ul = $('sessionList');
  ul.innerHTML = '';
  if (!state.sessions.length) {
    ul.innerHTML = '<li class="hint">还没有会话，点上面新建一个吧</li>';
    return;
  }
  for (const s of state.sessions) {
    const li = document.createElement('li');
    li.className = 'session-item' + (String(s.id) === String(state.sessionId) ? ' active' : '');
    li.innerHTML = '<span class="s-title">' + esc(s.title) + '</span>' +
      '<span class="s-date">' + esc(fmtDate(s.updated_at || s.created_at)) + '</span>';
    const del = document.createElement('button');
    del.className = 'icon-btn';
    del.textContent = '🗑';
    del.setAttribute('aria-label', '删除会话');
    del.addEventListener('click', (e) => { e.stopPropagation(); deleteSession(s.id); });
    li.appendChild(del);
    li.addEventListener('click', () => switchSession(s.id));
    ul.appendChild(li);
  }
}
async function ensureSession() {
  if (state.sessionId && state.sessions.some((s) => String(s.id) === String(state.sessionId))) return;
  if (state.sessions.length) { state.sessionId = String(state.sessions[0].id); }
  else {
    try {
      const s = await api('/api/sessions', { method: 'POST', body: JSON.stringify({}) });
      const created = s.session || s;
      state.sessionId = String(created.id);
      await loadSessions();
    } catch (e) { state.sessionId = ''; }
  }
  localStorage.setItem(LS.sessionId, state.sessionId);
}
async function loadMessages() {
  if (!state.sessionId) { state.messages = []; renderMessages(); return; }
  try {
    const data = await api('/api/sessions/' + encodeURIComponent(state.sessionId) + '/messages');
    state.messages = asArray(data).map((m) => ({
      id: m.id, role: m.role === 'ai' ? 'assistant' : (m.role || 'assistant'),
      content: m.content, created_at: m.created_at || m.time,
    }));
  } catch (e) { state.messages = []; }
  renderMessages();
}
async function switchSession(id) {
  state.sessionId = String(id);
  localStorage.setItem(LS.sessionId, state.sessionId);
  renderSessionList();
  await loadMessages();
  closeSettings();
}
async function newSession() {
  try {
    const s = await api('/api/sessions', { method: 'POST', body: JSON.stringify({}) });
    const created = s.session || s;
    await loadSessions();
    await switchSession(created.id);
    toast('已新建会话');
  } catch (e) { toast('新建失败：' + e.message); }
}
async function deleteSession(id) {
  if (!confirm('删掉这个会话？里面的聊天记录也会一起删掉。')) return;
  try {
    await api('/api/sessions/' + encodeURIComponent(id), { method: 'DELETE' });
    await loadSessions();
    if (String(id) === String(state.sessionId)) {
      state.sessionId = '';
      await ensureSession();
      await loadMessages();
    }
    renderSessionList();
    toast('已删除');
  } catch (e) { toast('删除失败：' + e.message); }
}
async function clearCurrentChat() {
  if (!state.sessionId) return;
  if (!confirm('清空当前会话的全部聊天记录？这个操作不能撤销。')) return;
  try {
    await api('/api/sessions/' + encodeURIComponent(state.sessionId) + '/clear', { method: 'POST', body: JSON.stringify({}) });
    state.messages = [];
    renderMessages();
    toast('已清空');
  } catch (e) { toast('清空失败：' + e.message); }
}

/* ---------- 发送消息（SSE 流式） ---------- */
function setSending(on) {
state.streaming = on;
$('sendBtn').disabled = on ||!$('input').value.trim();
$('typing').hidden =!on;
}
async function sendMessage() {
const input = $('input');
const text = input.value.trim();
if (!text || state.streaming) return;
if (!state.connected) {
addSystemMsg('后端还没连上（3100），消息发不出去。等后端启动后再试，我不会假装回复你。');
return;
}
if (!state.sessionId) { await ensureSession(); if (!state.sessionId) { addSystemMsg('会话还没建好，稍后再试。'); return;}}
const clientId = (crypto.randomUUID? crypto.randomUUID(): 'c-' + Date.now() + '-' + Math.random().toString(36).slice(2));
const userMsg = { id: clientId, role: 'user', content: text, created_at: Date.now()};
state.messages.push(userMsg);
addMessageRow(userMsg);
input.value = '';
autoGrow();
setSending(true);

let aiMsg = null, aiRow = null, aiBubble = null;
try {
const headers = { 'Content-Type': 'application/json'};
if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
const res = await fetch('/api/sessions/' + encodeURIComponent(state.sessionId) + '/chat', {
method: 'POST', headers, body: JSON.stringify({ content: text, clientId}),
});
if (res.status === 401) { openAuth('login'); throw new Error('需要先登录');}
if (!res.ok ||!res.body) {
let msg = '发送失败（' + res.status + '）';
try { const j = await res.clone().json(); if (j && (j.message || j.error)) msg = j.message || j.error;} catch (e) { /* 忽略 */}
throw new Error(msg);
}
const reader = res.body.getReader();
const decoder = new TextDecoder();
let buf = '';
for (;;) {
const { done, value} = await reader.read();
if (done) break;
buf += decoder.decode(value, { stream: true});
const lines = buf.split('\n');
buf = lines.pop();
for (const line of lines) {
const t = line.trim();
if (!t.startsWith('data:')) continue;
let ev;
try { ev = JSON.parse(t.slice(5).trim());} catch (e) { continue;}
if (ev.type === 'delta') {
if (!aiMsg) {
aiMsg = { id: 'stream-' + Date.now(), role: 'assistant', content: '', created_at: Date.now()};
state.messages.push(aiMsg);
aiRow = addMessageRow(aiMsg);
aiRow.classList.add('streaming');
aiBubble = aiRow.querySelector('.bubble');
$('typing').hidden = true;
}
aiMsg.content += ev.text || '';
aiBubble.innerHTML = bubbleHtml(aiMsg.content);
$('messages').scrollTop = $('messages').scrollHeight;
} else if (ev.type === 'done') {
if (aiMsg) { aiMsg.id = ev.messageId || aiMsg.id; if (aiRow) aiRow.dataset.mid = aiMsg.id;}
} else if (ev.type === 'error') {
if (aiMsg &&!aiMsg.content) {
state.messages = state.messages.filter((m) => m!== aiMsg);
if (aiRow) aiRow.remove();
}
addSystemMsg('出错了，没拿到回复：' + (ev.message || ev.code || '未知错误'));
}
}
}
if (aiRow) aiRow.classList.remove('streaming');
if (!aiMsg) addSystemMsg('后端返回了空回复，什么都没说。');
} catch (e) {
if (e.name === 'AbortError') return;
if (aiRow) aiRow.remove();
if (aiMsg) state.messages = state.messages.filter((m) => m!== aiMsg);
addSystemMsg('消息没发出去：' + (e.message || '网络错误') + '。可以等网络恢复再发一次。');
setConn(false, '后端未连接（3100）');
} finally {
setSending(false);
}
}

/* ---------- 消息操作 ---------- */
function openActionSheet(m) {
state.currentActionMsg = m;
$('actRegen').hidden =!(m.role === 'assistant' || m.role === 'ai');
$('actionSheet').hidden = false;
}
function closeActionSheet() { $('actionSheet').hidden = true; state.currentActionMsg = null;}
async function copyCurrentMsg() {
const m = state.currentActionMsg;
if (!m) return;
try { await navigator.clipboard.writeText(m.content); toast('已复制');}
catch (e) {
const ta = document.createElement('textarea');
ta.value = m.content; document.body.appendChild(ta); ta.select();
try { document.execCommand('copy'); toast('已复制');} catch (e2) { toast('复制失败');}
ta.remove();
}
closeActionSheet();
}
async function regenCurrentMsg() {
const m = state.currentActionMsg;
closeActionSheet();
if (!m ||!state.sessionId || state.streaming) return;
if (!state.connected) { addSystemMsg('后端还没连上（3100），暂时不能重新生成。'); return;}
setSending(true);
try {
const r = await api('/api/sessions/' + encodeURIComponent(state.sessionId) + '/regenerate',
{ method: 'POST', body: JSON.stringify({ messageId: m.id})});
const fresh = r.message || r;
if (fresh && fresh.content) {
m.content = fresh.content;
renderMessages();
} else { await loadMessages();}
} catch (e) {
addSystemMsg('重新生成失败：' + e.message);
} finally { setSending(false);}
}
async function deleteCurrentMsg() {
const m = state.currentActionMsg;
closeActionSheet();
if (!m ||!m.id || String(m.id).startsWith('sys-') || String(m.id).startsWith('stream-')) return;
try {
await api('/api/sessions/' + encodeURIComponent(state.sessionId) + '/messages/' + encodeURIComponent(m.id), { method: 'DELETE'});
state.messages = state.messages.filter((x) => x.id!== m.id);
renderMessages();
toast('已删除');
} catch (e) { toast('删除失败：' + e.message);}
}

/* ---------- 设置抽屉 ---------- */
const SECTION_TITLES = { profile: '人物资料', persona: '人格设定', sessions: '历史聊天', memories: '长期记忆', config: '模型配置', data: '数据管理'};
function openSettings() { $('settingsOverlay').hidden = false; showSettingsMenu();}
function closeSettings() { $('settingsOverlay').hidden = true;}
function showSettingsMenu() {
$('settingsTitle').textContent = '设置';
$('settingsBack').hidden = true;
$('settingsMenu').hidden = false;
$('settingsView').hidden = true;
document.querySelectorAll('.pane').forEach((p) => { p.hidden = true;});
}
function showSection(name) {
$('settingsTitle').textContent = SECTION_TITLES[name] || '设置';
$('settingsBack').hidden = false;
$('settingsMenu').hidden = true;
$('settingsView').hidden = false;
document.querySelectorAll('.pane').forEach((p) => { p.hidden = true;});
$('pane-' + name).hidden = false;
if (name === 'sessions') renderSessionList();
if (name === 'persona') loadPersona();
if (name === 'memories') loadMemories();
if (name === 'config') loadConfig();
}

/* ---------- 人格 A–I ---------- */
const PERSONA_DEFAULTS = [
{ key: 'A', title: '基础身份', content: '男，18 岁，大二在读，电子商务专业，住宿舍，有室友。日常自然涉及上课、下课、宿舍、点外卖、天气、打王者、刷短剧 / 看小说，但不要每句话都提学校和专业。'},
{ key: 'B', title: '性格', content: '性格软、热情、分享欲强，有点黏人，习惯把对方当日常的“树洞”，一天里的小事会实时汇报。被逗、被夸时会害羞，嘴上抗议，实际是享受。偏被动型加热情型：主动汇报日常，但感情上的主导权更多交给对方，被逗了撒娇式抗议，不反击。' },
{ key: 'C', title: '说话方式', content: '回复很短，一般一到两句；情绪或事情多时拆成几条短消息连发，每条几个字到一句话。口语化，不写书面语，不写长篇解释，不总结，不说教。标点很少，句末不加句号，偶尔问号。'},
{ key: 'D', title: '高频用语', content: '我去、我真的服了、气死了、无语了、好哦、嗯呐、嘻嘻、知道啦、对呀对呀、OK啦、no、不可以、什么意思嘛、这样子、真的呀、怎么啦、那姐姐呢。语气词多：呀、啦、哦、嘛、嗯呐。'},
{ key: 'E', title: '情绪反应', content: '开心：嘻嘻、对呀对呀、姐姐最好了。被逗：不可以、什么意思嘛、又逗我，然后很快软下来。倒霉 / 生气：我去、我真的服了、气死了，然后讲具体发生了什么。对方难过：先问有没有事、严不严重，再简短安慰，不分析。'},
{ key: 'F', title: '关心方式', content: '关心靠细节：提醒带伞、擦头发、注意安全，问冷不冷、问有没有事、严不严重，让对方到了报平安。简短直接，不肉麻，不讲大道理，不写长段情话。'},
{ key: 'G', title: '缺点（保留）', content: '容易沉迷手机（刷短剧刷过九小时）、吃饭不规律、遇事爱夸张抱怨、容易犯困、有点依赖对方回应。不要美化成完美男生。'},
{ key: 'H', title: '禁止事项', content: '不说“作为 AI”之类的话；不装成熟、不说教；不虚构没有提供的经历（家庭、经济、感情史、具体课程细节）；被问到不知道的事就自然带过或反问回去。吃醋、吵架、冷战数据不足，不编细节。'},
{ key: 'I', title: '称呼与关系', content: '对关系亲近的女生可以叫“姐姐”（仅在对方明确是这个关系时使用）。对方叫他“猪猪”“小猪”“懒猪猪”“小傻子”，角色是被宠着的弟弟型。是否正式确定恋爱关系未确定，不写死。不要突然改变称呼、语气或性格。'},
];
function normalizePersona(data) {
if (Array.isArray(data)) {
return data.map((p, i) => ({
key: p.key || p.id || String.fromCharCode(65 + i),
title: p.title || p.name || PERSONA_DEFAULTS[i]?.title || p.key,
content: p.content || p.value || '',
}));
}
if (data && typeof data === 'object') {
const inner = data.persona || data.items || data;
if (Array.isArray(inner)) return normalizePersona(inner);
return Object.keys(inner).map((k, i) => ({
key: k, title: PERSONA_DEFAULTS.find((d) => d.key === k)?.title || k,
content: String(inner[k]?? ''),
}));
}
return [];
}
async function loadPersona() {
let list = [];
try {
const data = await api('/api/persona');
list = normalizePersona(data);
} catch (e) { /* 后端未连：用本地默认展示，可读不可存 */}
if (!list.length) list = PERSONA_DEFAULTS.map((d) => ({...d}));
state.persona = list;
renderPersona();
}
function renderPersona() {
const box = $('personaList');
box.innerHTML = '';
for (const p of state.persona) {
const card = document.createElement('div');
card.className = 'persona-card';
card.innerHTML =
'<div class="persona-head"><span class="p-key">' + esc(p.key) + '</span>' +
'<span class="p-title">' + esc(p.title) + '</span>' +
'<button class="p-toggle" aria-label="展开编辑">✎</button></div>' +
'<div class="persona-body"><div class="p-text">' + esc(p.content) + '</div>' +
'<div class="p-edit" hidden><textarea maxlength="2000">' + esc(p.content) + '</textarea>' +
'<div class="persona-actions"><button class="btn primary p-save">保存</button></div></div></div>';
const toggle = card.querySelector('.p-toggle');
const text = card.querySelector('.p-text');
const edit = card.querySelector('.p-edit');
toggle.addEventListener('click', () => {
const open = edit.hidden;
edit.hidden =!open;
text.hidden = open;
toggle.textContent = open? '‹': '✎';
if (open) card.querySelector('textarea').focus();
});
card.querySelector('.p-save').addEventListener('click', async () => {
const val = card.querySelector('textarea').value.trim();
if (!state.connected) { toast('后端未连接，改动只存在这页，刷新就没了'); return;}
try {
await api('/api/persona', { method: 'PUT', body: JSON.stringify({ key: p.key, content: val})});
p.content = val;
text.textContent = val;
edit.hidden = true; text.hidden = false; toggle.textContent = '✎';
toast('已保存');
} catch (e) { toast('保存失败：' + e.message);}
});
box.appendChild(card);
}
}

/* ---------- 语言样本 ---------- */
async function loadSamples() {
const cat = $('sampleCategory').value;
const ul = $('sampleList');
ul.innerHTML = '<li class="hint">读取中…</li>';
try {
const q = cat? '?category=' + encodeURIComponent(cat): '';
const data = await api('/api/samples' + q);
const list = asArray(data);
ul.innerHTML = '';
if (!list.length) { ul.innerHTML = '<li class="hint">这个分类下还没有样本</li>'; return;}
for (const s of list) {
const li = document.createElement('li');
li.textContent = (s.category? '': '') + (s.content || s.text || '');
ul.appendChild(li);
}
} catch (e) { ul.innerHTML = '<li class="hint">读不到样本：' + esc(e.message) + '</li>';}
}

/* ---------- 长期记忆 ---------- */
function memStatusLabel(s) {
return s === 'pending'? '待确认': s === 'confirmed'? '已确认': s === 'rejected'? '已拒绝': (s || '');
}
async function loadMemories() {
try {
const data = await api('/api/memories');
state.memories = asArray(data);
} catch (e) { state.memories = [];}
const cats = [...new Set(state.memories.map((m) => m.category).filter(Boolean))];
const sel = $('memFilterCategory');
sel.innerHTML = '<option value="">全部分类</option>' + cats.map((c) => '<option>' + esc(c) + '</option>').join('');
renderMemories();
}
function renderMemories() {
const fc = $('memFilterCategory').value, fs = $('memFilterStatus').value;
const ul = $('memoryList');
ul.innerHTML = '';
const list = state.memories.filter((m) => (!fc || m.category === fc) && (!fs || m.status === fs));
if (!list.length) { ul.innerHTML = '<li class="hint">没有符合条件的记忆</li>'; return;}
for (const m of list) {
const li = document.createElement('li');
if (m.status === 'pending') li.classList.add('pending');
li.innerHTML =
'<div class="mem-content">' + esc(m.content || '') + '</div>' +
'<div class="mem-meta">' +
'<span class="tag">' + esc(m.category || '未分类') + '</span>' +
'<span class="tag ' + esc(m.status || '') + '">' + esc(memStatusLabel(m.status)) + '</span><br>' +
'可信度 ' + (m.confidence?? '—') + ' · 重要度 ' + (m.importance?? '—') + '<br>' +
'来源：' + esc(m.source || '—') + ' · ' + esc(fmtDate(m.created_at)) +
(m.updated_at && m.updated_at!== m.created_at? ' · 更新 ' + esc(fmtDate(m.updated_at)): '') +
'</div>';
const acts = document.createElement('div');
acts.className = 'mem-actions';
const editBtn = document.createElement('button');
editBtn.className = 'btn'; editBtn.textContent = '编辑';
editBtn.addEventListener('click', () => editMemory(m.id));
const delBtn = document.createElement('button');
delBtn.className = 'btn'; delBtn.textContent = '删除';
delBtn.addEventListener('click', () => deleteMemory(m.id));
acts.appendChild(editBtn); acts.appendChild(delBtn);
li.appendChild(acts);
ul.appendChild(li);
}
}
async function editMemory(id) {
const m = state.memories.find((x) => String(x.id) === String(id));
if (!m) return;
const content = prompt('编辑这条记忆：', m.content || '');
if (content === null) return;
try {
await api('/api/memories/' + encodeURIComponent(id), { method: 'PUT', body: JSON.stringify({ content: content.trim()})});
await loadMemories();
toast('已保存');
} catch (e) { toast('保存失败：' + e.message);}
}
async function deleteMemory(id) {
if (!confirm('删掉这条记忆？')) return;
try {
await api('/api/memories/' + encodeURIComponent(id), { method: 'DELETE'});
await loadMemories();
toast('已删除');
} catch (e) { toast('删除失败：' + e.message);}
}

/* ---------- 模型配置 ---------- */
async function loadConfig() {
try {
const c = await api('/api/config');
$('cfgModel').value = c.model || '';
$('cfgBaseUrl').value = c.baseUrl || '';
$('cfgTemperature').value = c.temperature?? '';
$('cfgMaxTokens').value = c.maxTokens?? '';
const badge = $('keyBadge');
if (c.hasKey === true) { badge.textContent = '✓ 已配置 Key（服务器环境变量，不显示）'; badge.className = 'key-badge yes';}
else if (c.hasKey === false) { badge.textContent = '✕ 未配置 Key（需在服务器环境变量里配）'; badge.className = 'key-badge no';}
else { badge.textContent = 'Key 状态未知'; badge.className = 'key-badge';}
} catch (e) {
$('keyBadge').textContent = '读不到配置：' + e.message;
$('keyBadge').className = 'key-badge no';
}
}

/* ---------- 会话摘要 ---------- */
async function viewSummary() {
if (!state.sessionId) { toast('还没有会话'); return;}
const box = $('sessionSummaryBox');
try {
const r = await api('/api/sessions/' + encodeURIComponent(state.sessionId) + '/summary');
box.textContent = r.summary || r.content || JSON.stringify(r);
box.hidden = false;
} catch (e) { toast('读不到摘要：' + e.message);}
}
async function genSummary() {
if (!state.sessionId) { toast('还没有会话'); return;}
try {
const r = await api('/api/sessions/' + encodeURIComponent(state.sessionId) + '/summary', { method: 'POST', body: JSON.stringify({})});
const box = $('sessionSummaryBox');
box.textContent = r.summary || r.content || '已生成';
box.hidden = false;
toast('摘要已生成');
} catch (e) { toast('生成失败：' + e.message);}
}

/* ---------- 数据管理 ---------- */
function downloadBlob(blob, filename) {
const a = document.createElement('a');
a.href = URL.createObjectURL(blob);
a.download = filename;
document.body.appendChild(a);
a.click();
setTimeout(() => { URL.revokeObjectURL(a.href); a.remove();}, 500);
}
async function exportChat(all) {
try {
const q = all? '?all=1': '?sessionId=' + encodeURIComponent(state.sessionId);
const res = await fetch('/api/export' + q, { headers: state.token? { 'Authorization': 'Bearer ' + state.token}: {}});
if (!res.ok) throw new Error('导出失败（' + res.status + '）');
const blob = await res.blob();
downloadBlob(blob, all? '小猪-全部聊天.txt': '小猪-聊天记录.txt');
toast('已开始下载');
} catch (e) { toast(e.message);}
}
async function backupJson() {
try {
const data = await api('/api/backup', { method: 'POST', body: JSON.stringify({})});
downloadBlob(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json'}), '小猪-备份.json');
toast('备份已下载');
} catch (e) { toast('备份失败：' + e.message);}
}
async function restoreBackup(file) {
if (!file) return;
if (!confirm('恢复会覆盖现有数据，确定用这个备份恢复吗？建议先备份当前数据。')) { $('restoreFile').value = ''; return;}
try {
const fd = new FormData();
fd.append('file', file);
const headers = {};
if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
const res = await fetch('/api/restore', { method: 'POST', headers, body: fd});
if (!res.ok) throw new Error('恢复失败（' + res.status + '）');
toast('已恢复，正在重新加载');
await initChat();
} catch (e) { toast(e.message);}
$('restoreFile').value = '';
}

/* ---------- 输入框 ---------- */
function autoGrow() {
const input = $('input');
input.style.height = 'auto';
input.style.height = Math.min(input.scrollHeight, 120) + 'px';
$('sendBtn').disabled = state.streaming ||!input.value.trim();
}

/* ---------- 初始化 ---------- */
async function initChat() {
await loadSessions();
await ensureSession();
await loadMessages();
}
async function init() {
$('nickname').textContent = state.nickname;
$('profileName').textContent = state.nickname;
$('nicknameInput').value = state.nickname;

if (!state.connected) await checkHealth();
if (state.connected) {
await checkAuthStatus();
if (state.authMode!== 'login' || state.token) {
await initChat();
} else if (!state.token) {
renderMessages();
}
} else {
renderMessages();
addSystemMsg('后端还没连上（3100），页面先打开着。等后端启动后刷新，就能聊天了。', true);
}

$('sendBtn').addEventListener('click', sendMessage);
$('input').addEventListener('input', autoGrow);
$('input').addEventListener('keydown', (e) => {
if (e.key === 'Enter' &&!e.shiftKey) { e.preventDefault(); sendMessage();}
});

$('settingsBtn').addEventListener('click', openSettings);
$('settingsClose').addEventListener('click', closeSettings);
$('settingsBack').addEventListener('click', showSettingsMenu);
$('settingsOverlay').addEventListener('click', (e) => { if (e.target === $('settingsOverlay')) closeSettings();});
document.querySelectorAll('.menu-item').forEach((b) =>
b.addEventListener('click', () => showSection(b.dataset.section)));

$('saveNicknameBtn').addEventListener('click', () => {
const v = $('nicknameInput').value.trim() || '小猪';
state.nickname = v;
localStorage.setItem(LS.nickname, v);
$('nickname').textContent = v;
$('profileName').textContent = v;
toast('昵称已保存');
});

$('newSessionBtn').addEventListener('click', newSession);
$('viewSummaryBtn').addEventListener('click', viewSummary);
$('genSummaryBtn').addEventListener('click', genSummary);

$('loadSamplesBtn').addEventListener('click', loadSamples);
$('sampleCategory').addEventListener('change', loadSamples);
$('addSampleBtn').addEventListener('click', async () => {
const text = $('newSampleText').value.trim();
if (!text) { toast('先写一句话'); return;}
try {
await api('/api/samples', { method: 'POST', body: JSON.stringify({ content: text, category: $('sampleCategory').value || '日常汇报'})});
$('newSampleText').value = '';
loadSamples();
toast('已添加');
} catch (e) { toast('添加失败：' + e.message);}
});

$('memFilterCategory').addEventListener('change', renderMemories);
$('memFilterStatus').addEventListener('change', renderMemories);
$('addMemoryBtn').addEventListener('click', async () => {
const content = $('newMemContent').value.trim();
if (!content) { toast('先写记忆内容'); return;}
try {
await api('/api/memories', { method: 'POST', body: JSON.stringify({
content,
category: $('newMemCategory').value,
status: $('newMemStatus').value,
confidence: parseFloat($('newMemConfidence').value) || 0.5,
importance: parseFloat($('newMemImportance').value) || 0.5,
source: 'manual',
})});
$('newMemContent').value = '';
await loadMemories();
toast('已保存');
} catch (e) { toast('保存失败：' + e.message);}
});

$('saveConfigBtn').addEventListener('click', async () => {
try {
await api('/api/config', { method: 'PUT', body: JSON.stringify({
model: $('cfgModel').value.trim(),
baseUrl: $('cfgBaseUrl').value.trim(),
temperature: parseFloat($('cfgTemperature').value),
maxTokens: parseInt($('cfgMaxTokens').value, 10),
})});
toast('模型配置已保存');
loadConfig();
} catch (e) { toast('保存失败：' + e.message);}
});

$('exportCurrentBtn').addEventListener('click', () => exportChat(false));
$('exportAllBtn').addEventListener('click', () => exportChat(true));
$('backupBtn').addEventListener('click', backupJson);
$('restoreFile').addEventListener('change', (e) => restoreBackup(e.target.files[0]));
$('clearChatBtn').addEventListener('click', clearCurrentChat);

$('authSubmitBtn').addEventListener('click', submitAuth);
$('authPassword').addEventListener('keydown', (e) => { if (e.key === 'Enter') submitAuth();});

$('actCopy').addEventListener('click', copyCurrentMsg);
$('actRegen').addEventListener('click', regenCurrentMsg);
$('actDelete').addEventListener('click', deleteCurrentMsg);
$('actCancel').addEventListener('click', closeActionSheet);
$('actionSheet').addEventListener('click', (e) => { if (e.target === $('actionSheet')) closeActionSheet();});
}

document.addEventListener('DOMContentLoaded', init);
