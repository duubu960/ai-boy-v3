'use strict';
/* Mimi Cat · V4.0 第二阶段：猫咪形象重构（状态机 + 统一 SVG 模板 + 分区点击）。
 * 只做小猫形象与动画状态机：不碰 server.js、src/、db/、聊天逻辑、人格、DeepSeek，不部署。
 * 免费现有技术：分层 SVG + CSS Keyframes + JS，无外链素材、无位图、无付费服务。
 * 暴露 window.CatState = { set, get, toIdle, refresh } 与 window.buildCatSVG(opts)。
 *
 * 分层说明（与 public/style.css 的状态规则、public/mimi.js 的映射对应）：
 * - is-*（is-pet/is-eating/is-sleeping/is-playing/is-bath）只动整个 .cat-svg 的 transform，
 *   是某次按钮互动的瞬时动画；st-* 只动眼睛/耳朵/嘴/爪子等内部层，是表情/状态层，
 *   两者作用在不同元素上，不打架。
 * - 眼睛/嘴的显隐由 CatState.set() 直接在对应 <g> 层上改 style.display（jsdom 可断言），
 *   不依赖 CSS 级联；碗/Z 的显隐沿用已有的 opacity 规则（.st-eat/.st-sleep 挂 opacity:1）。
 */
(function () {
  var STATES = ['idle', 'happy', 'shy', 'sad', 'sleepy', 'curious', 'eat', 'play', 'sleep'];
  var INTERACTION_CLASSES = ['is-pet', 'is-eating', 'is-sleeping', 'is-playing', 'is-bath'];
  /* 动作完成后自动回 idle 的时长；sleep/sleepy 持久，保持到下一次互动 */
  var AUTO_RETURN_MS = { happy: 2000, shy: 2000, curious: 2000, eat: 2000, play: 2000 };
  var IDLE_BEHAVIORS = ['idle-tilt', 'idle-ear', 'idle-stretch', 'idle-tail'];

  var current = 'idle';
  var autoTimer = null;
  var idleTimer = null;

  function fig() { return document.getElementById('catFigure'); }
  function svgEl() {
    var f = fig();
    return f ? f.querySelector('.cat-svg') : null;
  }
  function layer(cls) {
    var s = svgEl();
    return s ? s.querySelector('.' + cls) : null;
  }
  function show(el, on) { if (el) el.style.display = on ? '' : 'none'; }

  /* 各状态下眼睛/嘴/舌头/爱心/蝴蝶结/毛线球的显隐（JS 直接改 display，测试可断言）。 */
  function applyLayers(state) {
    var eye = 'g-eye-open';
    if (state === 'happy') eye = 'g-eye-happy';
    else if (state === 'shy' || state === 'sleepy' || state === 'sleep') eye = 'g-eye-closed';
    show(layer('g-eye-open'), eye === 'g-eye-open');
    show(layer('g-eye-happy'), eye === 'g-eye-happy');
    show(layer('g-eye-closed'), eye === 'g-eye-closed');
    show(layer('g-mouth'), state !== 'sleepy' && state !== 'sad');
    show(layer('g-mouth-yawn'), state === 'sleepy');
    show(layer('g-mouth-sad'), state === 'sad');
    show(layer('g-tongue'), state === 'eat');
    show(layer('cat-hearts'), state === 'happy' || state === 'shy');
    show(layer('g-bow'), state === 'happy' || state === 'shy');
    show(layer('cat-yarn'), state === 'play');
  }

  function stopIdleTimer() {
    if (idleTimer !== null) { clearTimeout(idleTimer); idleTimer = null; }
  }
  function scheduleIdle() {
    stopIdleTimer();
    if (current !== 'idle') return;
    idleTimer = setTimeout(function () {
      idleTimer = null;
      pokeIdle();
      scheduleIdle();
    }, 4000 + Math.random() * 4000);
  }
  /* 待机随机行为：每次只播一个（歪头/抖耳/伸懒腰/摆尾四选一），互动或非 idle 时不触发。
   * 供测试用的钩子：返回是否真的播了一个行为。 */
  function pokeIdle() {
    var f = fig();
    if (!f || current !== 'idle') return false;
    if (document.hidden || document.visibilityState === 'hidden') return false;
    if (f.classList.contains('paused')) return false;
    for (var i = 0; i < IDLE_BEHAVIORS.length; i++) {
      if (f.classList.contains(IDLE_BEHAVIORS[i])) return false;
    }
    var pick = IDLE_BEHAVIORS[Math.floor(Math.random() * IDLE_BEHAVIORS.length)];
    f.classList.add(pick);
    setTimeout(function () { if (f) f.classList.remove(pick); }, 2000);
    return true;
  }

  function set(state, opts) {
    opts = opts || {};
    if (STATES.indexOf(state) === -1) return false;
    var f = fig();
    if (!f) return false;
    if (autoTimer !== null) { clearTimeout(autoTimer); autoTimer = null; }
    for (var i = 0; i < STATES.length; i++) f.classList.remove('st-' + STATES[i]);
    /* 直接 set() 会清掉互动 class 的残留；按钮互动经 catInteract 调 set 时传
     * keepInteraction:true，保留刚挂上的 is-* 瞬时动画。 */
    if (!opts.keepInteraction) {
      for (var j = 0; j < INTERACTION_CLASSES.length; j++) f.classList.remove(INTERACTION_CLASSES[j]);
    }
    current = state;
    f.classList.add('st-' + state);
    f.dataset.state = state;
    applyLayers(state);
    stopIdleTimer();
    if (state === 'idle') {
      scheduleIdle();
    } else {
      var dur = opts.duration != null ? opts.duration : (AUTO_RETURN_MS[state] || 0);
      if (dur > 0) {
        autoTimer = setTimeout(function () {
          if (current === state) set('idle');
        }, dur);
      }
    }
    return true;
  }

  function refresh() {
    var f = fig();
    if (!f) return;
    if (!f.classList.contains('st-' + current)) f.classList.add('st-' + current);
    f.dataset.state = current;
    applyLayers(current);
  }

  /* ---------- 分区点击（只做本地动画 + 音效，不发后端） ---------- */
  function spawnHeart(f) {
    if (!f) return;
    var heart = document.createElement('span');
    heart.className = 'float-heart';
    heart.textContent = '💗';
    heart.setAttribute('aria-hidden', 'true');
    f.appendChild(heart);
    setTimeout(function () { heart.remove(); }, 1000);
  }
  function playFx(action) {
    try { if (window.CatFX) window.CatFX.play(action); } catch (e) { /* 静默失败 */ }
  }
  function transient(f, cls, ms) {
    if (!f) return;
    f.classList.add(cls);
    setTimeout(function () { if (f) f.classList.remove(cls); }, ms);
  }
  function onFigureClick(e) {
    var f = fig();
    if (!f) return;
    var zoneEl = (e.target && e.target.closest) ? e.target.closest('[data-zone]') : null;
    var zone = zoneEl ? zoneEl.getAttribute('data-zone') : 'head';
    /* sleep/sleepy 是持久态，任何一次点击都算下一次互动，先唤醒回 idle 再播分区反馈 */
    if (current === 'sleep' || current === 'sleepy') set('idle');
    if (zone === 'head') {
      playFx('pet');
      spawnHeart(f);
      set('happy');
    } else if (zone === 'body') {
      playFx('pet');
      transient(f, 'zone-wiggle', 800);
      set('happy', { duration: 800 });
    } else if (zone === 'tail') {
      playFx('play');
      transient(f, 'zone-tail', 1000);
    } else if (zone === 'paw-l' || zone === 'paw-r') {
      playFx('play');
      transient(f, 'zone-' + zone, 800);
    } else {
      playFx('pet');
      spawnHeart(f);
      set('happy');
    }
  }

  /* ---------- 页面隐藏时暂停 ---------- */
  function onVisibility() {
    var f = fig();
    var hidden = document.hidden || document.visibilityState === 'hidden';
    if (hidden) {
      if (f) f.classList.add('paused');
      stopIdleTimer();
    } else {
      if (f) f.classList.remove('paused');
      if (current === 'idle') scheduleIdle();
    }
  }

  /* ---------- 统一猫 SVG 模板 ----------
   * 返回 SVG 内部 markup（不含 <svg> 外壳），首页 #catFigure 与换装 #dressCatSvg 共用。
   * withAccessories=true 时才含 acc-bow/acc-hat/acc-scarf/acc-dress/acc-glasses 五组换装件；
   * 脸部（.g-head）与身体（.g-body）的 markup 与饰品无关，同一 suffix 下两次渲染完全一致。
   * gradient defs 的 id 带 suffix：两只猫共存时 id 不冲突，拍照序列化带上 <defs> 也不串渐变。
   * 换装件全部用 SVG 属性写 fill/stroke，不依赖外部 CSS，拍照进 Canvas 才不会丢样式。 */
  function buildCatSVG(opts) {
    opts = opts || {};
    var s = opts.suffix || 'home';
    var withAcc = !!opts.withAccessories;
    var acc = '';
    if (withAcc) {
      acc =
        '<g class="acc acc-bow" style="display:none">' +
          '<path d="M68 40 L44 28 L46 52 Z" fill="#ec6f9b" stroke="#d6336c" stroke-width="2" stroke-linejoin="round"/>' +
          '<path d="M68 40 L92 28 L90 52 Z" fill="#ec6f9b" stroke="#d6336c" stroke-width="2" stroke-linejoin="round"/>' +
          '<circle cx="68" cy="40" r="6" fill="#d6336c"/>' +
        '</g>' +
        '<g class="acc acc-hat" style="display:none">' +
          '<path d="M66 44 Q110 2 154 44 L146 48 Q110 18 74 48 Z" fill="#c9b8f0" stroke="#8a7bd6" stroke-width="2" stroke-linejoin="round"/>' +
          '<circle cx="110" cy="10" r="7" fill="#fff7ef" stroke="#c9b8f0" stroke-width="2"/>' +
        '</g>' +
        '<g class="acc acc-scarf" style="display:none">' +
          '<rect x="76" y="116" width="68" height="15" rx="7.5" fill="#ff8fab" stroke="#ec6f9b" stroke-width="2"/>' +
          '<rect x="120" y="128" width="17" height="28" rx="8" fill="#ec6f9b" stroke="#d6336c" stroke-width="2"/>' +
        '</g>' +
        '<g class="acc acc-dress" style="display:none">' +
          '<path d="M56 148 Q110 126 164 148 L170 178 Q110 194 50 178 Z" fill="#ffd6e6" stroke="#ec6f9b" stroke-width="2" stroke-linejoin="round"/>' +
          '<circle cx="110" cy="162" r="5" fill="#ec6f9b"/>' +
        '</g>' +
        '<g class="acc acc-glasses" style="display:none" fill="none" stroke="#4a3440" stroke-width="3" stroke-linecap="round">' +
          '<circle cx="90" cy="78" r="14"/><circle cx="130" cy="78" r="14"/>' +
          '<path d="M104 78 h12"/><path d="M76 78 L64 74"/><path d="M144 78 L156 74"/>' +
        '</g>';
    }
    return '' +
    '<defs>' +
      '<radialGradient id="catFur-' + s + '" cx="50%" cy="36%" r="78%">' +
        '<stop offset="0%" stop-color="#fffdf8"/><stop offset="55%" stop-color="#fff7ef"/>' +
        '<stop offset="100%" stop-color="#ffe9f1"/>' +
      '</radialGradient>' +
      '<radialGradient id="catBelly-' + s + '" cx="50%" cy="40%" r="75%">' +
        '<stop offset="0%" stop-color="#ffffff"/><stop offset="100%" stop-color="#ffe3ec"/>' +
      '</radialGradient>' +
      '<linearGradient id="catTail-' + s + '" x1="0%" y1="100%" x2="100%" y2="0%">' +
        '<stop offset="0%" stop-color="#ffc2d6"/><stop offset="100%" stop-color="#f9a8c0"/>' +
      '</linearGradient>' +
      '<radialGradient id="catEar-' + s + '" cx="50%" cy="60%" r="70%">' +
        '<stop offset="0%" stop-color="#ff8fab"/><stop offset="100%" stop-color="#f97ba6"/>' +
      '</radialGradient>' +
    '</defs>' +
    '<ellipse cx="110" cy="186" rx="78" ry="10" fill="#f3c6d4" opacity=".55"/>' +
    /* 毛线球（play 态才显示，猫去追它） */
    '<g class="cat-yarn" style="display:none">' +
      '<circle cx="188" cy="168" r="13" fill="#f9a8c0" stroke="#ec6f9b" stroke-width="2"/>' +
      '<path d="M176 164 Q188 158 200 164 M176 172 Q188 166 200 172 M178 178 Q188 173 198 178" fill="none" stroke="#ec6f9b" stroke-width="1.6" stroke-linecap="round"/>' +
      '<path d="M180 176 Q160 168 148 172" fill="none" stroke="#ec6f9b" stroke-width="1.6" stroke-linecap="round"/>' +
    '</g>' +
    '<g class="g-cat-all">' +
      /* 尾巴：加粗渐变 + 毛簇尖 */
      '<g class="g-tail" data-zone="tail">' +
        '<path class="cat-tail" d="M168 158 Q204 150 196 108 Q192 92 180 96" fill="none" stroke="url(#catTail-' + s + ')" stroke-width="18" stroke-linecap="round"/>' +
        '<path d="M180 96 l-8 -6 l2 10 l-8 -4" fill="none" stroke="#f9a8c0" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>' +
      '</g>' +
      /* 身体 */
      '<g class="g-body" data-zone="body">' +
        '<ellipse cx="110" cy="158" rx="66" ry="36" fill="url(#catFur-' + s + ')"/>' +
        '<ellipse cx="110" cy="164" rx="40" ry="22" fill="url(#catBelly-' + s + ')"/>' +
        '<path d="M52 150 l-8 4 l8 4 M168 150 l8 4 l-8 4" fill="none" stroke="#f3d9e2" stroke-width="2" stroke-linecap="round"/>' +
      '</g>' +
      /* 爪子（独立层，可单独抬起） */
      '<g class="g-paw-l" data-zone="paw-l"><ellipse cx="76" cy="184" rx="17" ry="9" fill="url(#catFur-' + s + ')"/><ellipse cx="76" cy="186" rx="9" ry="4.5" fill="#ffd6e6" opacity=".8"/></g>' +
      '<g class="g-paw-r" data-zone="paw-r"><ellipse cx="144" cy="184" rx="17" ry="9" fill="url(#catFur-' + s + ')"/><ellipse cx="144" cy="186" rx="9" ry="4.5" fill="#ffd6e6" opacity=".8"/></g>' +
      /* 头：耳朵/眼睛/鼻子/嘴/腮红都在这一层里，歪头时整体动 */
      '<g class="g-head" data-zone="head">' +
        '<g class="g-ear-l"><path d="M72 78 L58 28 L100 52 Z" fill="#ffb3c1"/><path d="M80 66 L72 40 L94 54 Z" fill="url(#catEar-' + s + ')"/><path d="M58 28 l-4 -8 l8 6" fill="none" stroke="#ffb3c1" stroke-width="3" stroke-linecap="round"/></g>' +
        '<g class="g-ear-r"><path d="M148 78 L162 28 L120 52 Z" fill="#ffb3c1"/><path d="M140 66 L148 40 L126 54 Z" fill="url(#catEar-' + s + ')"/><path d="M162 28 l4 -8 l-8 6" fill="none" stroke="#ffb3c1" stroke-width="3" stroke-linecap="round"/></g>' +
        '<circle cx="110" cy="80" r="50" fill="url(#catFur-' + s + ')"/>' +
        '<path d="M62 102 l-6 10 l8 -4 M158 102 l6 10 l-8 -4" fill="#fff7ef" stroke="#ffe9f1" stroke-width="1"/>' +
        '<g class="g-eye-open">' +
          '<ellipse class="cat-eye" cx="90" cy="78" rx="6.5" ry="9" fill="#5b4a52"/>' +
          '<ellipse class="cat-eye" cx="130" cy="78" rx="6.5" ry="9" fill="#5b4a52"/>' +
          '<circle cx="92" cy="75" r="2" fill="#fff"/><circle cx="132" cy="75" r="2" fill="#fff"/>' +
          '<path d="M84 68 Q90 64 96 68 M124 68 Q130 64 136 68" fill="none" stroke="#5b4a52" stroke-width="2" stroke-linecap="round"/>' +
        '</g>' +
        '<g class="g-eye-happy" style="display:none" stroke="#5b4a52" stroke-width="3" fill="none" stroke-linecap="round">' +
          '<path d="M83 80 Q90 70 97 80"/><path d="M123 80 Q130 70 137 80"/>' +
        '</g>' +
        '<g class="g-eye-closed" stroke="#5b4a52" stroke-width="3" fill="none" stroke-linecap="round">' +
          '<path d="M83 78 Q90 84 97 78"/><path d="M123 78 Q130 84 137 78"/>' +
        '</g>' +
        '<g class="g-nose"><path d="M105 94 h10 l-5 7 z" fill="#e87a90"/><circle cx="108" cy="95" r="1.2" fill="#fff" opacity=".8"/></g>' +
        '<path class="cat-mouth g-mouth" d="M110 101 Q110 110 101 110 M110 101 Q110 110 119 110" fill="none" stroke="#c98a94" stroke-width="2.5" stroke-linecap="round"/>' +
        '<ellipse class="g-mouth-yawn" style="display:none" cx="110" cy="107" rx="7" ry="9" fill="#b3556e"/>' +
        '<path class="g-mouth-sad" style="display:none" d="M101 111 Q110 104 119 111" fill="none" stroke="#c98a94" stroke-width="2.5" stroke-linecap="round"/>' +
        '<ellipse class="g-tongue" style="display:none" cx="110" cy="113" rx="5" ry="7" fill="#ff9eb5"/>' +
        '<g class="g-blush"><circle class="cat-blush" cx="74" cy="94" r="8" fill="#ffb3c1" opacity=".7"/><circle class="cat-blush" cx="146" cy="94" r="8" fill="#ffb3c1" opacity=".7"/></g>' +
        '<g stroke="#e8b7c4" stroke-width="2" stroke-linecap="round">' +
          '<path d="M52 84 L70 88"/><path d="M52 96 L70 94"/><path d="M168 84 L150 88"/><path d="M168 96 L150 94"/>' +
        '</g>' +
        /* 蝴蝶结层（happy/shy 态才戴上，换装 acc-bow 是另一组饰品，不冲突） */
        '<g class="g-bow" style="display:none">' +
          '<path d="M150 44 L134 34 L136 54 Z" fill="#ec6f9b" stroke="#d6336c" stroke-width="1.6" stroke-linejoin="round"/>' +
          '<path d="M150 44 L166 34 L164 54 Z" fill="#ec6f9b" stroke="#d6336c" stroke-width="1.6" stroke-linejoin="round"/>' +
          '<circle cx="150" cy="44" r="4" fill="#d6336c"/>' +
        '</g>' +
      '</g>' +
      /* 饭碗（eat 态 / is-eating 时出现） */
      '<g class="cat-bowl g-bowl">' +
        '<path d="M82 148 h56 l-8 18 a8 8 0 0 1-8 6 h-24 a8 8 0 0 1-8-6 z" fill="#c9b8f0"/>' +
        '<path d="M92 140 q6-8 12 0 q6-8 12 0" fill="none" stroke="#8a7bd6" stroke-width="3" stroke-linecap="round"/>' +
      '</g>' +
      /* 飘起的小爱心（happy/shy 态） */
      '<g class="cat-hearts" style="display:none">' +
        '<path d="M52 44 c-4 -6 -14 -2 -12 5 c1 5 8 8 12 11 c4 -3 11 -6 12 -11 c2 -7 -8 -11 -12 -5z" fill="#ec6f9b"/>' +
        '<path d="M168 34 c-3 -5 -11 -2 -10 4 c1 4 7 6 10 9 c3 -3 9 -5 10 -9 c1 -6 -7 -9 -10 -4z" fill="#f78fb8"/>' +
      '</g>' +
      '<g class="g-zzz">' +
        '<text class="cat-zzz" x="162" y="40" font-size="22" fill="#8a7bd6" font-weight="700">Z</text>' +
        '<text class="cat-zzz z2" x="176" y="22" font-size="16" fill="#8a7bd6" font-weight="700">z</text>' +
      '</g>' +
    '</g>' +
    acc;
  }

  window.CatState = {
    set: set,
    get: function () { return current; },
    toIdle: function () { return set('idle'); },
    refresh: refresh,
    /* 以下划线方法只供测试用：_pokeIdle 触发一次待机行为并返回是否播出；
     * _idleActive 报告待机随机定时器是否在跑。 */
    _pokeIdle: pokeIdle,
    _idleActive: function () { return idleTimer !== null; }
  };
  window.buildCatSVG = buildCatSVG;

  var f0 = fig();
  if (f0) {
    f0.addEventListener('click', onFigureClick);
    document.addEventListener('visibilitychange', onVisibility);
    set('idle');
  } else if (typeof document !== 'undefined' && document.addEventListener) {
    document.addEventListener('DOMContentLoaded', function () {
      var f = fig();
      if (f) f.addEventListener('click', onFigureClick);
      document.addEventListener('visibilitychange', onVisibility);
      set('idle');
    });
  }
})();
