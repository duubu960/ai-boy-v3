// tests: seed.js —— 人格 A–I 九类完整、报告结论已融入、关系未写成已确定、样本分类齐全
import test from 'node:test';
import assert from 'node:assert/strict';
import { PERSONA_SECTIONS, LANGUAGE_SAMPLES } from '../src/seed.js';

test('persona 共 9 节，key 为 A–I', () => {
  assert.equal(PERSONA_SECTIONS.length, 9);
  assert.deepEqual(PERSONA_SECTIONS.map((s) => s.key), ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']);
});

test('每节都有标题和非空内容', () => {
  for (const s of PERSONA_SECTIONS) {
    assert.ok(s.title.length > 0);
    assert.ok(s.content.length > 50, `${s.key} 内容过短`);
  }
});

test('报告结论融入：树洞/被动型加热情型/反差', () => {
  const all = PERSONA_SECTIONS.map((s) => s.content).join('\n');
  assert.ok(all.includes('树洞'));
  assert.ok(all.includes('被动型加热情型'));
  assert.ok(all.includes('被哄两句马上软下来'));
  assert.ok(all.includes('表情包带过'));
  assert.ok(all.includes('猪猪不气啦'));
});

test('关系未写成已确定恋爱关系', () => {
  const g = PERSONA_SECTIONS.find((s) => s.key === 'G').content;
  assert.ok(g.includes('是否正式确定恋爱关系未确定'));
  assert.ok(!g.includes('女朋友') || g.includes('未确定'));
  const all = PERSONA_SECTIONS.map((s) => s.content).join('\n');
  assert.ok(all.includes('不要写成已确定的恋爱关系'));
});

test('无法确定的不外推：I 节明确列出', () => {
  const i = PERSONA_SECTIONS.find((s) => s.key === 'I').content;
  assert.ok(i.includes('无法确定'));
  assert.ok(i.includes('对陌生人'));
  assert.ok(i.includes('错别字'));
});

test('语言样本覆盖 7 类有原话的情境', () => {
  const cats = new Set(LANGUAGE_SAMPLES.map((s) => s.category));
  for (const c of ['日常聊天', '主动开启话题', '表达不满', '生气', '表达关心', '面对对方撒娇', '开玩笑']) {
    assert.ok(cats.has(c), `缺 ${c}`);
  }
});

test('吃醋/难过/委屈/结束话题/调侃无样本（不编造）', () => {
  const cats = new Set(LANGUAGE_SAMPLES.map((s) => s.category));
  for (const c of ['吃醋', '难过', '委屈', '结束话题', '调侃']) {
    assert.ok(!cats.has(c), `${c} 不应有编造样本`);
  }
});

test('样本都有来源标注', () => {
  assert.ok(LANGUAGE_SAMPLES.length > 40);
  for (const s of LANGUAGE_SAMPLES) {
    assert.ok(s.content.length > 0);
    assert.ok(s.context);
  }
});
