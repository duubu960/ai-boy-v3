// 02-seed-persona.test.js — 人格与样本库种子数据（src/seed.js 纯导出，不碰数据库）
// 对应 20 项中的：4 人格遵循（九类齐全、高频词、缺点）、6 保留语言习惯（五类原话、短句风格）、19 人格配置稳定（种子只补空库，不覆盖已有——见 05-http）。
import test from 'node:test';
import assert from 'node:assert/strict';
import { PERSONA_SECTIONS, LANGUAGE_SAMPLES } from '../src/seed.js';

test('item-4：固定人格 A–I 九类齐全，标题与内容非空', () => {
  assert.equal(PERSONA_SECTIONS.length, 9);
  assert.deepEqual(PERSONA_SECTIONS.map((s) => s.key), ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']);
  for (const s of PERSONA_SECTIONS) {
    assert.ok(s.title && s.title.length > 0, `${s.key} 标题为空`);
    assert.ok(s.content && s.content.length > 20, `${s.key} 内容过短`);
  }
});

test('item-4：系统提示词含高频词与缺点（不美化成完美男生）', () => {
  const all = PERSONA_SECTIONS.map((s) => s.content).join('\n');
  const highFreq = ['我去', '我真的服了', '气死了', '无语了', '好哦', '嗯呐', '嘻嘻', '知道啦', '对呀对呀', 'OK啦', '不可以', '什么意思嘛', '这样子', '真的呀', '怎么啦', '那姐姐呢'];
  for (const w of highFreq) assert.ok(all.includes(w), `人格全文缺少高频词：${w}`);
  const flaws = ['刷手机上头', '吃饭不规律', '容易犯困', '依赖对方回应'];
  for (const w of flaws) assert.ok(all.includes(w), `人格全文缺少缺点表述：${w}`);
  assert.ok(all.includes('不要美化成完美男生'), '应明确写出"不要美化成完美男生"');
});

test('item-4：红线与未知项写进人格（不编造经历、关系未确定）', () => {
  const all = PERSONA_SECTIONS.map((s) => s.content).join('\n');
  assert.ok(all.includes('不要虚构'), '应写明不要虚构未提供的经历');
  assert.ok(all.includes('吃醋、吵架、冷战'), 'E 类应写明吃醋吵架冷战数据不足');
  assert.ok(all.includes('不要编造细节') || all.includes('不要编'), '应写明不编造');
  assert.ok(all.includes('是否正式确定恋爱关系未确定'), 'G/I 类应写明与姐姐是否正式恋爱关系未确定');
  assert.ok(all.includes('不要说"作为AI"') || all.includes('作为AI'), 'I 类红线应含"不要说作为AI"');
});

test('item-6：样本库五类有原话（日常/吐槽/关心/撒娇/追问的映射类）', () => {
  const byCat = new Map();
  for (const s of LANGUAGE_SAMPLES) {
    if (!byCat.has(s.category)) byCat.set(s.category, []);
    byCat.get(s.category).push(s.content);
  }
  const expectedPresent = {
    '日常聊天': ['下课啦', '冷死了', '我室友健身回来给我弄醒了'],
    '主动开启话题': ['那姐姐呢', '在干嘛姐姐'],
    '表达不满': ['哎呀，我真的服了，这阿姨总是耳朵不好使'],
    '生气': ['我去，我的伞被人偷了', '气死了'],
    '表达关心': ['好哦姐姐，到啦和我讲', '严不严重？'],
    '面对对方撒娇': ['不可以', '什么意思嘛', '又逗我'],
    '开玩笑': ['姐姐最好了', '嘻嘻'],
  };
  for (const [cat, quotes] of Object.entries(expectedPresent)) {
    assert.ok(byCat.has(cat), `样本库缺少分类：${cat}`);
    for (const q of quotes) assert.ok(byCat.get(cat).includes(q), `分类 ${cat} 缺少原话：${q}`);
  }
});

test('item-6：样本库五类留空、不编造（吃醋/难过/委屈/结束话题/调侃无样本）', () => {
  const cats = new Set(LANGUAGE_SAMPLES.map((s) => s.category));
  for (const empty of ['吃醋', '难过', '委屈', '结束话题', '调侃']) {
    assert.ok(!cats.has(empty), `无原话分类 ${empty} 不应出现在样本库中（不得编造填充）`);
  }
});

test('item-6：样本保持短句风格、无 AI 腔、无长篇', () => {
  for (const s of LANGUAGE_SAMPLES) {
    assert.ok(s.content.length <= 40, `样本过长、已不像短句原话：${s.content}`);
    assert.doesNotMatch(s.content, /作为AI|很高兴为您服务|您好/, `样本含 AI 腔：${s.content}`);
    // 注意：种子导出本身不带 source 字段，入库时 seedIfEmpty 统一写 '微信截图转录'（见 05-http 的 API 检查）。
  }
});
