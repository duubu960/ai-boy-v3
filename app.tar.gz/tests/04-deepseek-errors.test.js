// 04-deepseek-errors.test.js — DeepSeek 错误映射（src/deepseek.js，模块级）
// 对应 20 项中的：2 无 Key 诚实报错 NO_API_KEY、16 API 断开正确报错（401/402/超时映射）。
// 方法：本地 stub 只返回错误 HTTP 状态（401/402/500/延迟超时），绝不伪造成功回复；
// Key 只用测试假值 'test-dummy-key'（非真实 Key），且只在测试进程环境变量里。
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { chatCompletionStream, ERROR_CODES, makeDeepSeekError, estimateTokens } from '../src/deepseek.js';
import { startErrorStub, stopStub } from './helpers.js';

let stub401, stub402, stub500, stubSlow;

before(async () => {
  stub401 = await startErrorStub((req, res) => { res.writeHead(401, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: { message: 'Incorrect API key provided' } })); });
  stub402 = await startErrorStub((req, res) => { res.writeHead(402, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: { message: 'Insufficient Balance' } })); });
  stub500 = await startErrorStub((req, res) => { res.writeHead(500, { 'Content-Type': 'application/json' }); res.end('Internal Server Error'); });
  stubSlow = await startErrorStub((req, res) => { setTimeout(() => { res.writeHead(200, { 'Content-Type': 'text/event-stream' }); res.end('data: [DONE]\n\n'); }, 1500); });
});

after(async () => {
  for (const s of [stub401, stub402, stub500, stubSlow]) if (s) await stopStub(s.server);
});

const baseArgs = (baseUrl, extra = {}) => ({
  systemPrompt: '你是测试人格。',
  messages: [{ role: 'user', content: '你好' }],
  config: { baseUrl, timeoutMs: 8000, ...extra },
});

test('item-2：无 Key 时抛出 NO_API_KEY（不发请求、不返回假回复）', async () => {
  const prev = process.env.DEEPSEEK_API_KEY;
  delete process.env.DEEPSEEK_API_KEY;
  try {
    await assert.rejects(
      () => chatCompletionStream(baseArgs('http://127.0.0.1:1')),
      (e) => { assert.equal(e.code, 'NO_API_KEY'); assert.match(e.message, /未配置/); return true; }
    );
  } finally {
    if (prev === undefined) delete process.env.DEEPSEEK_API_KEY;
    else process.env.DEEPSEEK_API_KEY = prev;
  }
});

test('item-16：上游 401 映射为 DEEPSEEK_401', async () => {
  process.env.DEEPSEEK_API_KEY = 'test-dummy-key';
  await assert.rejects(
    () => chatCompletionStream(baseArgs(stub401.base)),
    (e) => { assert.equal(e.code, 'DEEPSEEK_401'); assert.match(e.message, /401/); return true; }
  );
});

test('item-16：上游 402 映射为 DEEPSEEK_402（余额不足）', async () => {
  process.env.DEEPSEEK_API_KEY = 'test-dummy-key';
  await assert.rejects(
    () => chatCompletionStream(baseArgs(stub402.base)),
    (e) => { assert.equal(e.code, 'DEEPSEEK_402'); assert.match(e.message, /402/); return true; }
  );
});

test('item-16：上游 500 映射为 DEEPSEEK_ERROR（不伪装成成功）', async () => {
  process.env.DEEPSEEK_API_KEY = 'test-dummy-key';
  await assert.rejects(
    () => chatCompletionStream(baseArgs(stub500.base)),
    (e) => { assert.equal(e.code, 'DEEPSEEK_ERROR'); assert.match(e.message, /500/); return true; }
  );
});

test('item-16：超时映射为 DEEPSEEK_TIMEOUT', async () => {
  process.env.DEEPSEEK_API_KEY = 'test-dummy-key';
  await assert.rejects(
    () => chatCompletionStream(baseArgs(stubSlow.base, { timeoutMs: 300 })),
    (e) => { assert.equal(e.code, 'DEEPSEEK_TIMEOUT'); return true; }
  );
});

test('item-16：错误码表与 makeDeepSeekError 一致', () => {
  for (const code of ['NO_API_KEY', 'DEEPSEEK_401', 'DEEPSEEK_402', 'DEEPSEEK_TIMEOUT', 'DEEPSEEK_ERROR']) {
    assert.ok(ERROR_CODES[code], `ERROR_CODES 缺少 ${code}`);
    assert.equal(makeDeepSeekError(code).code, code);
  }
  assert.ok(estimateTokens('你好世界') >= 1, 'token 估算应为正数');
});
