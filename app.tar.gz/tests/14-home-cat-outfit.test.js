// 14-home-cat-outfit.test.js — Bug #3 回归：首页猫不显示换装
// 根因：renderCatFigure 里首页猫用 buildCatSVG({ suffix: 'home' })（不含 acc-* 五组饰品层），
// 且 applyOutfit 只对 #dressCatSvg 应用显隐，所以乐园换装正常、首页猫永远没饰品。
// 修复：首页猫也用 withAccessories:true 渲染；applyOutfit 同时应用到 #catFigure 与 #dressCatSvg。
// 静态检查 + jsdom（mock fetch 返回契约数据，不跑服务、不碰后端与数据库、不碰线上 Neon）。
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { JSDOM } from 'jsdom';
import { APP_ROOT } from './helpers.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ACC_KEYS = ['bow', 'hat', 'scarf', 'dress', 'glasses'];

/* ================= 静态 ================= */

test('HOME-OUTFIT 静态：mimi.js 首页猫用 withAccessories 渲染，applyOutfit 同时覆盖两只猫', () => {
  const mimi = read('public/mimi.js');
  assert.ok(
    mimi.includes("buildCatSVG({ withAccessories: true, suffix: 'home' })"),
    'renderCatFigure 里首页猫须用 buildCatSVG({ withAccessories: true, suffix: \'home\' }) 渲染',
  );
  assert.ok(
    mimi.includes("buildCatSVG({ withAccessories: true, suffix: 'dress' })"),
    '换装猫须继续用 buildCatSVG({ withAccessories: true, suffix: \'dress\' }) 渲染',
  );
  // applyOutfit 必须同时查 #catFigure 与 #dressCatSvg 的 .acc-* 层
  const apply = mimi.slice(mimi.indexOf('function applyOutfit()'), mimi.indexOf('async function loadOutfit()'));
  assert.ok(apply.includes("$m('catFigure')"), 'applyOutfit 须对 #catFigure 应用饰品显隐');
  assert.ok(apply.includes("$m('dressCatSvg')"), 'applyOutfit 须继续对 #dressCatSvg 应用饰品显隐');
  assert.ok(apply.includes("'.acc-' + k") || apply.includes("`.acc-${k}`"), 'applyOutfit 须按 DRESS_ACC_KEYS 逐件开关 .acc-* 层');
  execFileSync('node', ['--check', path.join(APP_ROOT, 'public/mimi.js')], { stdio: 'pipe' });
});

test('HOME-OUTFIT 静态：catstate.js 状态机不动 .acc-* 层（g-bow 与 acc-bow 是两组饰品）', () => {
  const cs = read('public/catstate.js');
  // applyLayers 只动表情层：眼睛/嘴/舌头/爱心/g-bow/毛线球，不得出现 acc-
  const applyLayers = cs.slice(cs.indexOf('function applyLayers'), cs.indexOf('function stopIdleTimer'));
  assert.doesNotMatch(applyLayers, /acc-/, '状态机 applyLayers 不得碰 .acc-* 换装饰品层');
  assert.ok(applyLayers.includes("show(layer('g-bow')"), '状态机只动自己的 g-bow 层（happy/shy 态蝴蝶结）');
  assert.ok(cs.includes("/* 蝴蝶结层（happy/shy 态才戴上，换装 acc-bow 是另一组饰品，不冲突） */"),
    '模板注释须说明 g-bow 与换装 acc-bow 不冲突');
});

/* ================= jsdom ================= */

function resp(status, body, isJson = true) {
  return {
    ok: status >= 200 && status < 300, status,
    headers: { get: (n) => (n.toLowerCase() === 'content-type' ? (isJson ? 'application/json' : 'text/html') : null) },
    json: async () => body,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    body: null,
    clone: function () { return this; },
  };
}

const CAT_STATE = { id: 1, state: 'happy', mood: 'happy', intimacy: 0, hearts: 0, level: 1, stage: '初次见面', lastInteractAt: null, lastActions: {}, updatedAt: '2026-11-11T10:00:00Z' };
const DEFAULT_ROOM = { wallpaper: 'pink', bed: 'pink', plushies: ['bear'], lamp: true, flowers: true, painting: 'none', theme: 'home' };
const DEFAULT_GARDEN_SLOTS = [
  { id: 0, flower: 'rose', stage: 'bloom', progress: 100, watered: true },
  { id: 1, flower: null, stage: null, progress: 0 },
  { id: 2, flower: 'daisy', stage: 'sprout', progress: 35, watered: false },
];

/* 换装后端用有状态 mock：GET 返回已存搭配，PUT 存下来（模拟真实后端，便于测重渲染时序）。 */
function mockFetchFactory() {
  const calls = [];
  let storedOutfit = { bow: true, hat: false, scarf: false, dress: false, glasses: true, bg: 'bedroom', pose: 'sit' };
  const fetch = async (url, opts = {}) => {
    const method = (opts.method || 'GET').toUpperCase();
    const [p, q] = String(url).split('?');
    calls.push(method + ' ' + p);
    const body = opts.body ? JSON.parse(opts.body) : {};
    if (p === '/api/cat' && method === 'GET') return resp(200, { cat: { ...CAT_STATE } });
    if (p === '/api/cat/interact' && method === 'POST') {
      return resp(200, { cat: { ...CAT_STATE, hearts: 2 }, gained: { hearts: 2, intimacy: 1 } });
    }
    if (p === '/api/cat/outfit' && method === 'GET') return resp(200, { outfit: { ...storedOutfit } });
    if (p === '/api/cat/outfit' && method === 'PUT') {
      storedOutfit = { ...storedOutfit, ...(body.outfit || {}) };
      return resp(200, { ok: true });
    }
    if (p === '/api/mood' && method === 'GET') return resp(200, { today: null, recent: [] });
    if (p === '/api/daily' && method === 'GET') return resp(200, { tasks: [], surprise: { claimed: false }, fortune: { drawn: false } });
    if (p === '/api/memories' && method === 'GET') return resp(200, []);
    if (p === '/api/sessions' && method === 'GET') return resp(200, []);
    if (p === '/api/room' && method === 'GET') return resp(200, { room: { ...DEFAULT_ROOM } });
    if (p === '/api/room' && method === 'PUT') return resp(200, { room: { ...DEFAULT_ROOM, ...body } });
    if (p === '/api/garden' && method === 'GET') return resp(200, {
      slots: DEFAULT_GARDEN_SLOTS.map((s) => ({ ...s })),
      pots: [
        { id: 'clay', name: '陶土花盆', emoji: '🪴', unlocked: true, harvests_required: 0 },
        { id: 'pink', name: '粉色花盆', emoji: '🌸', unlocked: false, harvests_required: 3 },
        { id: 'gold', name: '金色花盆', emoji: '🏆', unlocked: false, harvests_required: 10 },
      ],
    });
    if (p === '/api/garden/plant' && method === 'POST') return resp(200, { ok: true, slot: body.slot, flower: body.flower });
    if (p === '/api/garden/water' && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/garden/harvest' && method === 'POST') return resp(200, { ok: true, reward: { hearts: 2 } });
    if (p === '/api/events/next' && method === 'GET') return resp(200, { event: { id: 'ev-1', title: '午后的一阵风', text: '风把一片花瓣吹到了你的窗台上', anim: 'pink-rain' } });
    if (/^\/api\/events\/[^/]+\/favorite$/.test(p) && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/letters/draw' && method === 'POST') return resp(200, { letter: { id: 'l-1', content: '冷死了，记得穿厚一点', source: '来自真实聊天记录', category: '关心对方', date: '2026-11-11T10:00:00Z' } });
    if (p === '/api/letters' && method === 'GET') return resp(200, { letters: [{ id: 'l-1', content: '冷死了，记得穿厚一点', source: '来自真实聊天记录', category: '关心对方', saved: true, created_at: '2026-11-11T10:00:00Z' }] });
    if (/^\/api\/letters\/[^/]+\/save$/.test(p) && method === 'POST') return resp(200, { ok: true });
    if (/^\/api\/letters\/[^/]+$/.test(p) && method === 'DELETE') return resp(200, { ok: true });
    if (p === '/api/games/scores' && method === 'GET') {
      const game = new URLSearchParams(q || '').get('game');
      if (game === 'memory') return resp(200, { scores: [{ score: 1200, detail: '{"steps":5,"seconds":10}', created_at: '2026-11-11T10:00:00Z' }] });
      if (game === 'wheel') return resp(200, { scores: [{ score: 10, detail: '{"prize":{"label":"爱心+10","hearts":10}}', created_at: '2026-11-11T10:00:00Z' }] });
      return resp(200, { scores: [] });
    }
    if (p === '/api/games/wheel' && method === 'POST') return resp(200, { prize: { id: 'heart10', label: '爱心+10', hearts: 10 }, collected: { item_id: 'sticker-heart' }, cat: { ...CAT_STATE }, hearts: 12 });
    if (p === '/api/games/score' && method === 'POST') return resp(201, { id: 1, game: body.game, score: body.score });
    return resp(404, { error: 'not_found' });
  };
  return { fetch, calls, getStoredOutfit: () => ({ ...storedOutfit }) };
}

async function makeDom() {
  const html = read('public/index.html');
  const dom = new JSDOM(html, { url: 'http://127.0.0.1:3199/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  class FakeGain { constructor() { this.gain = { value: 0 }; } connect() {} }
  class FakeOsc { constructor() { this.frequency = { value: 0 }; this.type = 'sine'; } connect() {} start() {} stop() {} }
  class FakeAudioContext {
    constructor() { this.currentTime = 0; this.state = 'running'; this.destination = {}; }
    createOscillator() { return new FakeOsc(); }
    createGain() { return new FakeGain(); }
    resume() { return Promise.resolve(); }
  }
  window.AudioContext = FakeAudioContext;
  window.webkitAudioContext = FakeAudioContext;
  const { fetch, calls, getStoredOutfit } = mockFetchFactory();
  window.fetch = fetch;
  window.eval(read('public/catfx.js'));
  window.eval(read('public/catstate.js'));
  window.eval(read('public/mimi.js'));
  await sleep(250);
  return { dom, window, calls, getStoredOutfit };
}

const homeAcc = (window, key) => window.document.querySelector('#catFigure .acc-' + key);
const dressAcc = (window, key) => window.document.querySelector('#dressCatSvg .acc-' + key);
const accVisible = (el) => !!el && el.style.display === 'block';
const accHidden = (el) => !!el && el.style.display === 'none';

test('HOME-OUTFIT 首屏：首页猫 SVG 含全部五组饰品层，loadOutfit 异步返回后与换装猫显隐一致', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  // mock 预置搭配：bow 开、glasses 开，其余关；init 时 loadOutfit 已异步取回并应用
  for (const k of ACC_KEYS) {
    assert.ok(homeAcc(window, k), `首页猫 SVG 应含 .acc-${k} 层`);
    assert.ok(dressAcc(window, k), `换装猫 SVG 应含 .acc-${k} 层`);
  }
  assert.ok(accVisible(homeAcc(window, 'bow')), '首页猫 acc-bow 应显示（后端搭配 bow:true）');
  assert.ok(accVisible(dressAcc(window, 'bow')), '换装猫 acc-bow 应显示');
  assert.ok(accVisible(homeAcc(window, 'glasses')), '首页猫 acc-glasses 应显示（后端搭配 glasses:true）');
  assert.ok(accVisible(dressAcc(window, 'glasses')), '换装猫 acc-glasses 应显示');
  for (const k of ['hat', 'scarf', 'dress']) {
    assert.ok(accHidden(homeAcc(window, k)), `首页猫 acc-${k} 应隐藏（后端搭配为关）`);
    assert.ok(accHidden(dressAcc(window, k)), `换装猫 acc-${k} 应隐藏`);
  }
  // 脸部 markup 与饰品无关：带饰品与不带饰品渲染的 .g-head 完全一致
  const parse = (markup) => {
    const holder = window.document.createElement('div');
    holder.innerHTML = '<svg viewBox="0 0 220 200">' + markup + '</svg>';
    return holder.querySelector('svg');
  };
  const withAcc = parse(window.buildCatSVG({ withAccessories: true, suffix: 'home' }));
  const withoutAcc = parse(window.buildCatSVG({ suffix: 'home' }));
  assert.strictEqual(
    withAcc.querySelector('.g-head').outerHTML,
    withoutAcc.querySelector('.g-head').outerHTML,
    '只改饰品组时脸部 .g-head markup 应完全一致',
  );
  assert.strictEqual(
    withAcc.querySelector('.g-body').outerHTML,
    withoutAcc.querySelector('.g-body').outerHTML,
    '只改饰品组时身体 .g-body markup 应完全一致',
  );
});

test('HOME-OUTFIT 换装点击：点蝴蝶结/帽子按钮后，首页猫与换装猫的饰品同时切换', async (t) => {
  const { dom, window, getStoredOutfit } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(150);
  const hatBtn = window.document.querySelector('.dress-acc-btn[data-acc="hat"]');
  const bowBtn = window.document.querySelector('.dress-acc-btn[data-acc="bow"]');
  assert.ok(hatBtn && bowBtn, '缺少换装按钮 [data-acc="hat"] / [data-acc="bow"]');

  hatBtn.click();
  /* saveOutfit 有 dressSaving 串行 guard：两次点击之间要等上一次 PUT 落袋，否则第二次会被跳过 */
  await sleep(100);
  assert.ok(accVisible(homeAcc(window, 'hat')), '点帽子后首页猫 acc-hat 应显示');
  assert.ok(accVisible(dressAcc(window, 'hat')), '点帽子后换装猫 acc-hat 应显示');
  assert.ok(accVisible(homeAcc(window, 'bow')), '点帽子不应影响首页猫 acc-bow（仍显示）');

  bowBtn.click();
  await sleep(100);
  assert.ok(accHidden(homeAcc(window, 'bow')), '点蝴蝶结关掉后首页猫 acc-bow 应隐藏');
  assert.ok(accHidden(dressAcc(window, 'bow')), '点蝴蝶结关掉后换装猫 acc-bow 应隐藏');
  assert.ok(accVisible(homeAcc(window, 'hat')), '关蝴蝶结不应影响首页猫 acc-hat（仍显示）');
  assert.strictEqual(getStoredOutfit().hat, true, '点击后 PUT 应把帽子存到后端');
  assert.strictEqual(getStoredOutfit().bow, false, '点击后 PUT 应把蝴蝶结关掉存到后端');
});

test('HOME-OUTFIT 重渲染：renderCatFigure 重跑（刷新/重进）后，已保存的饰品仍显示在首页猫上', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  // 首屏 mock 搭配 bow:true；模拟一次重渲染：再触发 DOMContentLoaded → initMimi 重跑
  // renderCatFigure（innerHTML 全换、饰品回到 display:none）+ loadOutfit（GET 取回已存搭配）
  window.document.dispatchEvent(new window.Event('DOMContentLoaded'));
  await sleep(250);
  assert.ok(homeAcc(window, 'bow'), '重渲染后首页猫仍应有 acc-bow 层');
  assert.ok(accVisible(homeAcc(window, 'bow')), '重渲染 + loadOutfit 返回后首页猫 acc-bow 应仍显示');
  assert.ok(accVisible(dressAcc(window, 'bow')), '重渲染后换装猫 acc-bow 应仍显示');
  assert.ok(accVisible(homeAcc(window, 'glasses')), '重渲染后首页猫 acc-glasses 应仍显示');
  assert.ok(accHidden(homeAcc(window, 'hat')), '重渲染后首页猫 acc-hat 应仍隐藏');
});

test('HOME-OUTFIT 状态机：切 happy 再自动回 idle，首页饰品显隐不变（g-bow 与 acc-bow 互不干扰）', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const fig = window.document.getElementById('catFigure');
  const gBow = () => fig.querySelector('.g-bow');
  assert.ok(accVisible(homeAcc(window, 'bow')), '切状态前首页猫 acc-bow 应显示');

  window.CatState.set('happy');
  assert.ok(gBow() && gBow().style.display !== 'none', 'happy 态时状态机自己的 g-bow 应可见');
  assert.ok(accVisible(homeAcc(window, 'bow')), 'happy 态时换装 acc-bow 应仍显示');
  assert.ok(accVisible(dressAcc(window, 'bow')), 'happy 态时换装猫 acc-bow 应仍显示');
  assert.notStrictEqual(
    gBow().outerHTML,
    homeAcc(window, 'bow').outerHTML,
    'g-bow 与 acc-bow 应是两个不同的元素',
  );

  await sleep(2300); // happy 2 秒后自动回 idle
  assert.strictEqual(window.CatState.get(), 'idle', 'happy 2 秒后应自动回 idle');
  assert.ok(gBow() && gBow().style.display === 'none', '回 idle 后 g-bow 应隐藏');
  assert.ok(accVisible(homeAcc(window, 'bow')), '回 idle 后换装 acc-bow 应仍显示（状态切换不得重置饰品）');

  window.CatState.set('sleepy');
  assert.ok(accVisible(homeAcc(window, 'bow')), '切 sleepy 后换装 acc-bow 应仍显示');
  window.CatState.refresh();
  assert.ok(accVisible(homeAcc(window, 'bow')), 'CatState.refresh() 后换装 acc-bow 应仍显示');
  window.CatState.set('idle');
  assert.ok(accVisible(homeAcc(window, 'bow')), '回 idle 后换装 acc-bow 应仍显示');
});
