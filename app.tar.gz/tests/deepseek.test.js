// tests: deepseek.js —— 无 Key 诚实报错、token 估算、错误码映射（不调真实 API）
import test from 'node:test';
import assert from 'node:assert/strict';
import { chatCompletionStream, estimateTokens, makeDeepSeekError } from '../src/deepseek.js';

test('无 DEEPSEEK_API_KEY 时抛 NO_API_KEY（不编假回复）', async () => {
  const saved = process.env.DEEPSEEK_API_KEY;
  delete process.env.DEEPSEEK_API_KEY;
  try {
    await assert.rejects(
      chatCompletionStream({ systemPrompt: 'x', messages: [{ role: 'user', content: '你好' }] }),
      (e) => e.code === 'NO_API_KEY'
    );
  } finally {
    if (saved !== undefined) process.env.DEEPSEEK_API_KEY = saved;
  }
});

test('estimateTokens 按字符/4 估算', () => {
  assert.equal(estimateTokens(''), 0);
  assert.equal(estimateTokens('abcd'), 1);
  assert.equal(estimateTokens('abcdefgh'), 2);
  assert.equal(estimateTokens('你好世界你好世界'), 2);
});

test('makeDeepSeekError 带 code', () => {
  const e = makeDeepSeekError('DEEPSEEK_401');
  assert.equal(e.code, 'DEEPSEEK_401');
  assert.ok(String(e.message).includes('401'));
});
