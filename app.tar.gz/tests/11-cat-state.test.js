// 11-cat-state.test.js — V4.0 第二阶段猫咪形象重构（状态机 + 统一 SVG 模板 + 分区点击）
// 静态检查 + jsdom（mock fetch 返回契约数据，不跑服务、不碰后端与数据库）。
// 说明：jsdom 环境没有 AudioContext，测试里先挂最小桩，只验证调用路径，不验证真出声。
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { JSDOM } from 'jsdom';
import { APP_ROOT } from './helpers.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ================= 静态 ================= */

test('CAT 结构：index.html 按 catfx → catstate → mimi 顺序引用脚本', () => {
  const html = read('public/index.html');
  const iFx = html.indexOf('<script src="catfx.js">');
  const iState = html.indexOf('<script src="catstate.js">');
  const iMimi = html.indexOf('<script src="mimi.js">');
  assert.ok(iFx >= 0 && iState > iFx && iMimi > iState, '须按 catfx.js → catstate.js → mimi.js 顺序引用');
  assert.ok(html.includes('id="catFigure"'), '缺少 #catFigure');
  assert.ok(html.includes('id="dressCatSvg"'), '缺少 #dressCatSvg');
});

test('CAT 语法：mimi.js、catfx.js、catstate.js 均能 node --check 通过', () => {
  for (const f of ['public/mimi.js', 'public/catfx.js', 'public/catstate.js']) {
    execFileSync('node', ['--check', path.join(APP_ROOT, f)], { stdio: 'pipe' });
  }
});

test('CAT 无外链：catstate.js 无 http://、无 https://cdn、无外链脚本/样式/图片', () => {
  const src = read('public/catstate.js').replace(/http:\/\/www\.w3\.org\/2000\/svg/g, '');
  assert.doesNotMatch(src, /http:\/\//, 'catstate.js 不得含 http:// 外链');
  assert.doesNotMatch(src, /https:\/\/cdn/i, 'catstate.js 不得含 https://cdn');
  assert.doesNotMatch(src, /<script[^>]+src="https?:\/\//i, 'catstate.js 不得引用外部脚本');
  assert.doesNotMatch(src, /<img[^>]+src="http/i, 'catstate.js 不得有外链 <img>');
});

test('CAT 视觉：style.css 含 st-* 状态规则、待机/分区动画与 paused 收敛规则', () => {
  const css = read('public/style.css');
  for (const cls of ['.st-idle', '.st-happy', '.st-shy', '.st-sad', '.st-sleepy', '.st-curious', '.st-eat', '.st-play', '.st-sleep']) {
    assert.ok(css.includes(cls), `style.css 缺少 ${cls}`);
  }
  for (const kf of ['catBreathe', 'catHeadTilt', 'catEarTwitch', 'catStretch', 'catTailSlow', 'catHappyHop',
    'catTailFast', 'catHeartFloat', 'catShyTilt', 'catPawLift', 'catYawn', 'catDroop', 'catCurious', 'catLook',
    'catEatHead', 'catTongue', 'catPlayChase', 'catYarnMove', 'catWiggle']) {
    assert.ok(css.includes('@keyframes ' + kf), `style.css 缺少 @keyframes ${kf}`);
  }
  assert.ok(css.includes('.cat-figure.paused'), 'style.css 缺少 .paused 暂停规则');
  assert.doesNotMatch(css, /\.paused \* \{/, '暂停规则不得用全局 * 选择器，须收敛在 #catFigure 之下');
  assert.match(css, /\.cat-eye \{[^}]*animation: catBlink 5s infinite/, '眨眼应放慢到 5 秒周期');
});

test('CAT 契约：catstate.js 暴露 CatState 与 buildCatSVG；mimi.js 接入状态机与模板', () => {
  const cs = read('public/catstate.js');
  assert.ok(cs.includes('window.CatState'), 'catstate.js 须暴露 window.CatState');
  assert.ok(cs.includes('window.buildCatSVG'), 'catstate.js 须暴露 window.buildCatSVG');
  for (const s of ['idle', 'happy', 'shy', 'sad', 'sleepy', 'curious', 'eat', 'play', 'sleep']) {
    assert.ok(cs.includes("'" + s + "'"), '状态机须含状态 ' + s);
  }
  for (const layer of ['g-ear-l', 'g-ear-r', 'g-eye-open', 'g-eye-happy', 'g-eye-closed', 'g-nose', 'g-mouth', 'g-blush', 'g-body', 'g-tail', 'g-paw-l', 'g-paw-r', 'g-bow']) {
    assert.ok(cs.includes(layer), 'SVG 模板须有独立层 ' + layer);
  }
  assert.ok(cs.includes('data-zone'), 'SVG 模板须给部位加 data-zone');
  assert.ok(cs.includes('visibilitychange'), '须监听 visibilitychange 暂停待机');
  const mimi = read('public/mimi.js');
  assert.ok(mimi.includes('CatState.set'), 'mimi.js 须在互动里调 CatState.set');
  assert.ok(mimi.includes('buildCatSVG'), 'mimi.js 须用 buildCatSVG 渲染两只猫');
  assert.ok(mimi.includes('catBaseState'), 'mimi.js 须有后端心情 → 基础状态的映射');
});

/* ================= jsdom ================= */

function resp(status, body, isJson = true) {
  return {
    ok: status >= 200 && status < 300, status,
    headers: { get: (n) => (n.toLowerCase() === 'content-type' ? (isJson ? 'application/json' : 'text/html') : null) },
    json: async () => body,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    body: null,
    clone: function () { return this; },
  };
}

const CAT_STATE = { id: 1, state: 'happy', mood: 'happy', intimacy: 0, hearts: 0, level: 1, stage: '初次见面', lastInteractAt: null, lastActions: {}, updatedAt: '2026-11-11T10:00:00Z' };
const DEFAULT_ROOM = { wallpaper: 'pink', bed: 'pink', plushies: ['bear'], lamp: true, flowers: true, painting: 'none', theme: 'home' };
const DEFAULT_GARDEN_SLOTS = [
  { id: 0, flower: 'rose', stage: 'bloom', progress: 100, watered: true },
  { id: 1, flower: null, stage: null, progress: 0 },
  { id: 2, flower: 'daisy', stage: 'sprout', progress: 35, watered: false },
];

function mockFetchFactory(overrides = {}) {
  const calls = [];
  const fetch = async (url, opts = {}) => {
    const method = (opts.method || 'GET').toUpperCase();
    const [p, q] = String(url).split('?');
    calls.push(method + ' ' + p);
    const body = opts.body ? JSON.parse(opts.body) : {};
    const route = method + ' ' + p;
    if (overrides[route]) return overrides[route](body, q);
    if (p === '/api/cat' && method === 'GET') return resp(200, { cat: { ...CAT_STATE } });
    if (p === '/api/cat/interact' && method === 'POST') {
      return resp(200, { cat: { ...CAT_STATE, hearts: 2 }, gained: { hearts: 2, intimacy: 1 } });
    }
    if (p === '/api/cat/outfit' && method === 'GET') return resp(200, { outfit: { bow: false, hat: false, scarf: false, dress: false, glasses: false, bg: 'bedroom', pose: 'sit' } });
    if (p === '/api/cat/outfit' && method === 'PUT') return resp(200, { ok: true });
    if (p === '/api/mood' && method === 'GET') return resp(200, { today: null, recent: [] });
    if (p === '/api/daily' && method === 'GET') return resp(200, { tasks: [], surprise: { claimed: false }, fortune: { drawn: false } });
    if (p === '/api/memories' && method === 'GET') return resp(200, []);
    if (p === '/api/sessions' && method === 'GET') return resp(200, []);
    if (p === '/api/room' && method === 'GET') return resp(200, { room: { ...DEFAULT_ROOM } });
    if (p === '/api/room' && method === 'PUT') return resp(200, { room: { ...DEFAULT_ROOM, ...body } });
    if (p === '/api/garden' && method === 'GET') return resp(200, {
      slots: DEFAULT_GARDEN_SLOTS.map((s) => ({ ...s })),
      pots: [
        { id: 'clay', name: '陶土花盆', emoji: '🪴', unlocked: true, harvests_required: 0 },
        { id: 'pink', name: '粉色花盆', emoji: '🌸', unlocked: false, harvests_required: 3 },
        { id: 'gold', name: '金色花盆', emoji: '🏆', unlocked: false, harvests_required: 10 },
      ],
    });
    if (p === '/api/garden/plant' && method === 'POST') return resp(200, { ok: true, slot: body.slot, flower: body.flower });
    if (p === '/api/garden/water' && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/garden/harvest' && method === 'POST') return resp(200, { ok: true, reward: { hearts: 2 } });
    if (p === '/api/events/next' && method === 'GET') return resp(200, { event: { id: 'ev-1', title: '午后的一阵风', text: '风把一片花瓣吹到了你的窗台上', anim: 'pink-rain' } });
    if (/^\/api\/events\/[^/]+\/favorite$/.test(p) && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/letters/draw' && method === 'POST') return resp(200, { letter: { id: 'l-1', content: '冷死了，记得穿厚一点', source: '来自真实聊天记录', category: '关心对方', date: '2026-11-11T10:00:00Z' } });
    if (p === '/api/letters' && method === 'GET') return resp(200, { letters: [{ id: 'l-1', content: '冷死了，记得穿厚一点', source: '来自真实聊天记录', category: '关心对方', saved: true, created_at: '2026-11-11T10:00:00Z' }] });
    if (/^\/api\/letters\/[^/]+\/save$/.test(p) && method === 'POST') return resp(200, { ok: true });
    if (/^\/api\/letters\/[^/]+$/.test(p) && method === 'DELETE') return resp(200, { ok: true });
    if (p === '/api/games/scores' && method === 'GET') {
      const game = new URLSearchParams(q || '').get('game');
      if (game === 'memory') return resp(200, { scores: [{ score: 1200, detail: '{"steps":5,"seconds":10}', created_at: '2026-11-11T10:00:00Z' }] });
      if (game === 'wheel') return resp(200, { scores: [{ score: 10, detail: '{"prize":{"label":"爱心+10","hearts":10}}', created_at: '2026-11-11T10:00:00Z' }] });
      return resp(200, { scores: [] });
    }
    if (p === '/api/games/wheel' && method === 'POST') return resp(200, { prize: { id: 'heart10', label: '爱心+10', hearts: 10 }, collected: { item_id: 'sticker-heart' }, cat: { ...CAT_STATE }, hearts: 12 });
    if (p === '/api/games/score' && method === 'POST') return resp(201, { id: 1, game: body.game, score: body.score });
    return resp(404, { error: 'not_found' });
  };
  return { fetch, calls };
}

async function makeDom(overrides = {}) {
  const html = read('public/index.html');
  const dom = new JSDOM(html, { url: 'http://127.0.0.1:3199/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  // AudioContext 最小桩：只验证调用路径，不验证真出声
  class FakeGain { constructor() { this.gain = { value: 0 }; } connect() {} }
  class FakeOsc { constructor() { this.frequency = { value: 0 }; this.type = 'sine'; } connect() {} start() {} stop() {} }
  class FakeAudioContext {
    constructor() { this.currentTime = 0; this.state = 'running'; this.destination = {}; }
    createOscillator() { return new FakeOsc(); }
    createGain() { return new FakeGain(); }
    resume() { return Promise.resolve(); }
  }
  window.AudioContext = FakeAudioContext;
  window.webkitAudioContext = FakeAudioContext;
  const { fetch, calls } = mockFetchFactory(overrides);
  window.fetch = fetch;
  window.eval(read('public/catfx.js'));
  window.eval(read('public/catstate.js'));
  window.eval(read('public/mimi.js'));
  await sleep(150);
  return { dom, window, calls };
}

function stClasses(fig) {
  return Array.from(fig.classList).filter((c) => c.startsWith('st-'));
}
function clickEl(window, el) {
  el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true }));
}

test('CAT 状态机：连续 set happy→sleepy→idle，同一时间只有一个 st-* class', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const fig = window.document.getElementById('catFigure');
  assert.ok(window.CatState, '须暴露 window.CatState');
  assert.ok(window.buildCatSVG, '须暴露 window.buildCatSVG');
  /* 首屏 loadCat 已按 mock 心情（happy）联动过一次，初始未必是 idle，先显式回 idle 再测 */
  window.CatState.set('idle');
  assert.strictEqual(window.CatState.get(), 'idle');
  window.CatState.set('happy');
  assert.deepStrictEqual(stClasses(fig), ['st-happy'], 'set happy 后应只有一个 st-happy');
  window.CatState.set('sleepy');
  assert.deepStrictEqual(stClasses(fig), ['st-sleepy'], 'set sleepy 后应只有一个 st-sleepy');
  assert.strictEqual(window.CatState.get(), 'sleepy');
  window.CatState.set('idle');
  assert.deepStrictEqual(stClasses(fig), ['st-idle'], 'set idle 后应只有一个 st-idle');
  assert.strictEqual(fig.dataset.state, 'idle', 'data-state 应同步为 idle');
  assert.strictEqual(window.CatState.set('not-a-state'), false, '非法状态应返回 false 且不切换');
  assert.deepStrictEqual(stClasses(fig), ['st-idle'], '非法 set 后仍应是 st-idle');
});

test('CAT 状态机：各状态的内部层显隐真实挂上', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const fig = window.document.getElementById('catFigure');
  const layer = (cls) => fig.querySelector('.' + cls);
  const visible = (cls) => { const el = layer(cls); return !!el && el.style.display !== 'none'; };

  window.CatState.set('happy');
  assert.ok(visible('g-eye-happy'), 'happy 时开心眼 g-eye-happy 应可见');
  assert.ok(!visible('g-eye-open'), 'happy 时睁眼 g-eye-open 应隐藏');
  assert.ok(visible('cat-hearts'), 'happy 时小爱心应可见');
  assert.ok(visible('g-bow'), 'happy 时蝴蝶结层应可见');

  window.CatState.set('shy');
  assert.ok(visible('g-eye-closed'), 'shy 时眯眼 g-eye-closed 应可见');
  assert.ok(visible('cat-hearts'), 'shy 时小爱心应可见');

  window.CatState.set('sleepy');
  assert.ok(visible('g-mouth-yawn'), 'sleepy 时哈欠嘴 g-mouth-yawn 应可见');
  assert.ok(!visible('g-mouth'), 'sleepy 时普通嘴应隐藏');

  window.CatState.set('sad');
  assert.ok(visible('g-mouth-sad'), 'sad 时委屈嘴 g-mouth-sad 应可见');
  assert.ok(!visible('g-mouth'), 'sad 时普通嘴应隐藏');

  window.CatState.set('eat');
  assert.ok(visible('g-tongue'), 'eat 时舌头 g-tongue 应可见');

  window.CatState.set('play');
  assert.ok(visible('cat-yarn'), 'play 时毛线球 cat-yarn 应可见');

  window.CatState.set('sleep');
  assert.ok(visible('g-eye-closed'), 'sleep 时闭眼 g-eye-closed 应可见');
  assert.ok(!visible('g-eye-open'), 'sleep 时睁眼应隐藏');

  window.CatState.set('curious');
  assert.ok(visible('g-eye-open'), 'curious 时睁眼应可见');
  assert.ok(fig.classList.contains('st-curious'), 'curious 时应挂 st-curious');
});

test('CAT 状态机：happy 2 秒后自动回 idle，sleep 保持不自动回', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const fig = window.document.getElementById('catFigure');
  window.CatState.set('happy');
  await sleep(2300);
  assert.deepStrictEqual(stClasses(fig), ['st-idle'], 'happy 2 秒后应自动回 idle');
  window.CatState.set('sleep');
  await sleep(2300);
  assert.deepStrictEqual(stClasses(fig), ['st-sleep'], 'sleep 是持久态，2.3 秒后仍应是 st-sleep');
  window.CatState.toIdle();
  assert.deepStrictEqual(stClasses(fig), ['st-idle'], 'toIdle 应回到 idle');
});

test('CAT 点击分区：点头/身/尾巴/爪子各有反馈，且不发 /api/cat/interact', async (t) => {
  const { dom, window, calls } = await makeDom();
  t.after(() => dom.window.close());
  const fig = window.document.getElementById('catFigure');
  const fxCalls = [];
  const origPlay = window.CatFX.play;
  window.CatFX.play = (action) => { fxCalls.push(action); return origPlay(action); };
  const interactBefore = calls.filter((c) => c === 'POST /api/cat/interact').length;

  clickEl(window, fig.querySelector('.g-head'));
  assert.ok(fig.classList.contains('st-happy'), '点头部应切到 happy');
  assert.ok(fxCalls.includes('pet'), '点头部应调 CatFX.play("pet")');
  assert.ok(fig.querySelector('.float-heart'), '点头部应飘一颗爱心');

  clickEl(window, fig.querySelector('.g-body'));
  assert.ok(fig.classList.contains('zone-wiggle'), '点身体应挂 zone-wiggle 瞬时 class');
  assert.ok(fig.classList.contains('st-happy'), '点身体后应短暂 happy');

  clickEl(window, fig.querySelector('.g-tail'));
  assert.ok(fig.classList.contains('zone-tail'), '点尾巴应挂 zone-tail 快摆 class');

  clickEl(window, fig.querySelector('.g-paw-l'));
  assert.ok(fig.classList.contains('zone-paw-l'), '点左爪应挂 zone-paw-l 抬爪 class');
  clickEl(window, fig.querySelector('.g-paw-r'));
  assert.ok(fig.classList.contains('zone-paw-r'), '点右爪应挂 zone-paw-r 抬爪 class');

  const interactAfter = calls.filter((c) => c === 'POST /api/cat/interact').length;
  assert.strictEqual(interactAfter, interactBefore, '分区点击只做本地动画+音效，不得发 /api/cat/interact');
});

test('CAT 换装共用：同一模板渲染两次，只改饰品组时脸部 group markup 完全一致', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const parse = (markup) => {
    const holder = window.document.createElement('div');
    holder.innerHTML = '<svg viewBox="0 0 220 200">' + markup + '</svg>';
    return holder.querySelector('svg');
  };
  const a = parse(window.buildCatSVG({ withAccessories: false, suffix: 't' }));
  const b = parse(window.buildCatSVG({ withAccessories: true, suffix: 't' }));
  assert.strictEqual(a.querySelector('.g-head').outerHTML, b.querySelector('.g-head').outerHTML, '只改饰品组时脸部 .g-head markup 应完全一致');
  assert.strictEqual(a.querySelector('.g-body').outerHTML, b.querySelector('.g-body').outerHTML, '只改饰品组时身体 .g-body markup 应完全一致');
  assert.ok(!a.querySelector('.acc-bow'), '无饰品渲染不应含 acc-bow');
  assert.ok(b.querySelector('.acc-bow'), '有饰品渲染应含 acc-bow');
  assert.ok(b.querySelector('.acc-hat') && b.querySelector('.acc-scarf') && b.querySelector('.acc-dress') && b.querySelector('.acc-glasses'), '有饰品渲染应含全部 5 组换装件');
  // defs id 带 suffix：两只猫共存不串渐变
  const home = parse(window.buildCatSVG({ suffix: 'home' }));
  const dress = parse(window.buildCatSVG({ withAccessories: true, suffix: 'dress' }));
  assert.ok(home.querySelector('#catFur-home') && !home.querySelector('#catFur-dress'), '首页猫 defs 应为 catFur-home');
  assert.ok(dress.querySelector('#catFur-dress') && !dress.querySelector('#catFur-home'), '换装猫 defs 应为 catFur-dress');
  assert.ok(dress.querySelector('defs'), '换装猫 SVG 应带 <defs>，拍照序列化才不会丢渐变');
});

test('CAT 换装：模板渲染后换装按钮仍能切换饰品显隐（GET/PUT 契约不变）', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(150);
  const btn = window.document.querySelector('.dress-acc-btn[data-acc="bow"]');
  assert.ok(btn, '缺少换装按钮 [data-acc="bow"]');
  btn.click();
  assert.strictEqual(btn.getAttribute('aria-pressed'), 'true', '点一次后蝴蝶结应为选中');
  const acc = window.document.querySelector('#dressCatSvg .acc-bow');
  assert.ok(acc && acc.style.display === 'block', '蝴蝶结 SVG 配件应显示');
});

test('CAT 隐藏暂停：visibilitychange 隐藏后挂 paused、待机定时器停、随机行为不再触发', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const fig = window.document.getElementById('catFigure');
  window.CatState.set('idle');
  assert.strictEqual(window.CatState._idleActive(), true, 'idle 时待机随机定时器应在跑');
  assert.strictEqual(window.CatState._pokeIdle(), true, '可见时 _pokeIdle 应播出一个待机行为');
  assert.ok(['idle-tilt', 'idle-ear', 'idle-stretch', 'idle-tail'].some((c) => fig.classList.contains(c)), '应挂上一个 idle-* 待机 class');
  // 隐藏
  Object.defineProperty(window.document, 'visibilityState', { value: 'hidden', configurable: true });
  window.document.dispatchEvent(new window.Event('visibilitychange'));
  assert.ok(fig.classList.contains('paused'), '隐藏后 #catFigure 应挂 paused class');
  assert.strictEqual(window.CatState._idleActive(), false, '隐藏后待机定时器应停掉');
  assert.strictEqual(window.CatState._pokeIdle(), false, '隐藏时随机待机行为不应再触发');
  // 恢复可见
  Object.defineProperty(window.document, 'visibilityState', { value: 'visible', configurable: true });
  window.document.dispatchEvent(new window.Event('visibilitychange'));
  assert.ok(!fig.classList.contains('paused'), '恢复可见后 paused class 应摘掉');
  assert.strictEqual(window.CatState._idleActive(), true, '恢复可见后待机定时器应重新跑起来');
});

test('CAT 后端联动：renderCat 按心情给基础状态，只在 idle 时切换', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const fig = window.document.getElementById('catFigure');
  window.CatState.set('idle');
  window.MimiCat.renderCat({ mood: 'sleepy', state: 'sleepy', hearts: 1, intimacy: 1, level: 1, stage: '' });
  assert.ok(fig.classList.contains('st-sleepy'), 'idle 时 renderCat(困倦) 应切到 st-sleepy');
  window.CatState.set('happy');
  window.MimiCat.renderCat({ mood: 'sleepy', state: 'sleepy', hearts: 1, intimacy: 1, level: 1, stage: '' });
  assert.ok(fig.classList.contains('st-happy'), '正在 happy 互动时 renderCat 不应打断');
  window.CatState.set('idle');
  window.MimiCat.renderCat({ mood: 'hungry', state: 'hungry', hearts: 1, intimacy: 1, level: 1, stage: '' });
  assert.ok(fig.classList.contains('st-sad'), 'idle 时 renderCat(饥饿) 应切到 st-sad');
});

test('CAT 按钮互动：摸头后 is-pet 与 st-happy 共存（瞬时动画 + 状态层不打架）', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const fig = window.document.getElementById('catFigure');
  const petBtn = window.document.querySelector('[data-cat-action="pet"]');
  assert.ok(petBtn, '缺少摸头按钮');
  petBtn.click();
  assert.ok(fig.classList.contains('is-pet'), '摸头后 #catFigure 应挂 is-pet class');
  assert.ok(fig.classList.contains('st-happy'), '摸头后 #catFigure 应同时挂 st-happy');
});
