// 01-drift.test.js — 漂移防护（src/drift.js 纯逻辑）
// 对应 20 项中的：5 不同情绪回复（检测）、7 无普通 AI 腔、20 长时间聊天不明显漂移（检测+重载路径）。
import test from 'node:test';
import assert from 'node:assert/strict';
import { checkDrift, recordDrift, getDriftCount, driftReinforcement } from '../src/drift.js';

test('item-7：客服腔 / AI 腔命中 drift（"作为AI / 很高兴为您服务 / 您好"）', () => {
  const cases = [
    '您好，请问有什么可以帮助您？',
    '作为AI，我很高兴为您服务',
    '我是AI助手，很荣幸为您解答',
    '请问您需要什么帮助呢',
  ];
  for (const text of cases) {
    const r = checkDrift(text);
    assert.equal(r.drift, true, `应命中 drift：${text}，实际 reasons=${JSON.stringify(r.reasons)}`);
    assert.ok(r.reasons.length > 0);
  }
});

test('item-5：超长说教命中 drift（>200 字且含说教措辞）', () => {
  const text = '你应该先冷静下来，首先你要明白这件事的来龙去脉，其次你需要认真思考一下自己的问题，总之建议你以后遇到类似的事情要多沟通多理解，只有这样才能真正解决问题，而不是一味地抱怨和逃避，综上所述你要学会成熟地处理关系。'.repeat(2);
  assert.ok(text.length > 200);
  const r = checkDrift(text);
  assert.equal(r.drift, true, `超长说教应命中，reasons=${JSON.stringify(r.reasons)}`);
  // 短句即使含"应该"也不算说教（<200 字）
  assert.equal(checkDrift('你应该带伞哦').drift, false);
});

test('item-5：过度热情 / 套路甜话命中 drift', () => {
  for (const text of ['我永远陪着你！！', '我最爱你！！', '我会一直陪着你的！！']) {
    assert.equal(checkDrift(text).drift, true, `应命中：${text}`);
  }
});

test('item-5：虚构共同经历命中 drift（历史中无记录时）', () => {
  const r = checkDrift('我们上次一起去爬山了，可好玩了', []);
  assert.equal(r.drift, true, `无历史记录时"我们上次一起…"应命中，reasons=${JSON.stringify(r.reasons)}`);
  // 历史中有对应记录时不命中
  const r2 = checkDrift('我们上次一起去爬山了，可好玩了', ['昨天我们去爬山了']);
  assert.equal(r2.drift, false, `历史中有记录时不应命中，reasons=${JSON.stringify(r2.reasons)}`);
});

test('item-5/7：符合人格的正常回复不命中 drift', () => {
  const ok = [
    '好哦姐姐 到啦和我讲',
    '我去 我的伞被人偷了',
    '我真的服了',
    '嘻嘻 知道啦',
    '那冷不冷 不要感冒了',
    '啊 那你没事吧',
    '严不严重',
    '不可以这样子',
    '什么意思嘛 又逗我',
    '我刚刚下去接了杯水',
    '那姐姐呢',
  ];
  for (const text of ok) {
    const r = checkDrift(text);
    assert.equal(r.drift, false, `人格内回复不应命中：${text}，reasons=${JSON.stringify(r.reasons)}`);
  }
});

test('item-20：多轮人格内对话不漂移；漂移后计数 + 人格重载路径存在', () => {
  const sessionId = `drift-test-${Date.now()}`;
  assert.equal(getDriftCount(sessionId), 0);
  assert.equal(driftReinforcement(sessionId), '', '无漂移时不注入重载文本');
  // 模拟 10 轮人格内回复：全部不命中
  const rounds = [
    '下课啦', '冷死了', '还下雨了', '我去 我的伞被人偷了', '我真的服了',
    '好哦姐姐 到啦和我讲', '嘻嘻', '不可以这样子', '那冷不冷', '在干嘛姐姐',
  ];
  for (const text of rounds) assert.equal(checkDrift(text).drift, false, `第轮回不应漂移：${text}`);
  assert.equal(getDriftCount(sessionId), 0, '多轮后漂移计数仍为 0');
  // 混入一条客服腔：计数 +1，重载文本出现
  const bad = checkDrift('您好，很高兴为您服务');
  assert.equal(bad.drift, true);
  recordDrift(sessionId, bad);
  assert.equal(getDriftCount(sessionId), 1);
  const reinforcement = driftReinforcement(sessionId);
  assert.ok(reinforcement.length > 0, '漂移后应返回人格重载文本');
  assert.match(reinforcement, /短句/, '重载文本应要求回到短句人格');
});
