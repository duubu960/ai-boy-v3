// 15-phase3-backend.test.js — V4.0 第三阶段后端（手动回忆 / 收藏 / 纪念日 /
// 情绪上下文 / 睡前故事·晚安信 / 每日报告 / 花园进度百分比）
// 真实 server.js 子进程 + 本地 SQLite（data/app.db），不连线上 Neon。
// 清理：manual_memories / anniversaries / garden_plots 是本阶段新建、无真实用户数据，
// before/after 直接清掉；cat_state、今日 daily_records、今日 mood_entries 按快照恢复；
// game_scores / letters / heart_ledger 只删本次新建的行 id；测试会话与消息按 id 删；
// model_config.baseUrl 按快照恢复（情绪/睡前 DeepSeek 成功路径需临时指向本地 stub）。
// 注意：DeepSeek 成功分支一律用本地 stub 只返回一条固定 SSE delta，绝不伪造“真人”回复；
// Key 只用测试假值 'test-dummy-key'。
import test, { before, after} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync} from 'node:sqlite';
import {
APP_ROOT, freePort, startAppServer, stopServer,
startErrorStub, stopStub, postChatSSE, api,
} from './helpers.js';
import { todayStr, shanghaiDayRange} from '../src/cat.js';
import { flowerStage} from '../src/phase2.js';
import {
EMOTION_LABELS, emotionContextText,
BEDTIME_STORIES, GOODNIGHT_NOTES, localBedtimeStory, goodnightLetter,
} from '../src/phase3.js';

let noKey = null; // 无 Key 服务（大部分 HTTP 测试）
let keyed = null; // 有测试假 Key + 本地 stub 的服务（情绪/睡前 DeepSeek 路径）
let stubOk = null; // 成功 stub：固定返回一条 SSE delta，并记录请求体
let stub401 = null;
let db = null;
let catSnapshot = null;
let todayDailyKinds = new Set();
let moodTodaySnapshot = null;
let gameScoreMaxId = 0;
let lettersMaxId = 0;
let ledgerMaxId = 0;
let originalBaseUrl = 'https://api.deepseek.com';
const createdSessions = [];
const today = todayStr();
const EMPTY_DATE = '2030-06-15'; // 无任何数据的假日期（07 用 2031、09 用 2032，均不冲突）

const capturedBodies = []; // 成功 stub 收到的 DeepSeek 请求体（按序）

function openDb() {
return new DatabaseSync(path.join(APP_ROOT, 'data', 'app.db'));
}

function addDays(dateStr, n) {
const d = new Date(`${dateStr}T00:00:00+08:00`);
return todayStr(new Date(d.getTime() + n * 24 * 60 * 60 * 1000));
}

function hoursAgo(h) {
return new Date(Date.now() - h * 3600 * 1000).toISOString();
}

async function newSession(base, title) {
const r = await api(base, 'POST', '/api/sessions', { title: title || 'phase3测试会话'});
assert.equal(r.status, 201, `建会话应 201，实际 ${r.status}：${r.text}`);
createdSessions.push(r.json.id);
return r.json.id;
}

/** 直接向库里插一条消息（created_at=当前，落在今天窗口内），返回 id。 */
function insertMessage(sessionId, role, content) {
const info = db.prepare(
'INSERT INTO messages (session_id, role, content, client_id, meta, created_at) VALUES (?,?,?, NULL, NULL,?)'
).run(sessionId, role, content, new Date().toISOString());
return Number(info.lastInsertRowid);
}

before(async () => {
noKey = await startAppServer({ port: await freePort(), apiKey: null});
const cfg = await api(noKey.base, 'GET', '/api/config');
originalBaseUrl = cfg.json.baseUrl;
db = openDb();
catSnapshot = db.prepare('SELECT * FROM cat_state WHERE id = 1').get() || null;
todayDailyKinds = new Set(db.prepare('SELECT kind FROM daily_records WHERE date =?').all(today).map((r) => r.kind));
moodTodaySnapshot = db.prepare('SELECT * FROM mood_entries WHERE date =?').get(today) || null;
gameScoreMaxId = db.prepare('SELECT MAX(id) AS id FROM game_scores').get()?.id || 0;
lettersMaxId = db.prepare('SELECT MAX(id) AS id FROM letters').get()?.id || 0;
ledgerMaxId = db.prepare('SELECT MAX(id) AS id FROM heart_ledger').get()?.id || 0;
// 自愈式预清理：本阶段新表无真实用户数据，直接清掉以往失败运行的残留
for (const t of ['manual_memories', 'anniversaries', 'garden_plots']) {
db.prepare(`DELETE FROM ${t}`).run();
}
});

after(async () => {
try {
if (keyed) {
await api(keyed.base, 'PUT', '/api/config', { baseUrl: originalBaseUrl});
}
} catch { /* 恢复失败不影响报告主体 */}
if (noKey) await stopServer(noKey.child);
if (keyed) await stopServer(keyed.child);
if (stubOk) await stopStub(stubOk.server);
if (stub401) await stopStub(stub401.server);
try {
if (!db) db = openDb();
for (const t of ['manual_memories', 'anniversaries', 'garden_plots']) {
db.prepare(`DELETE FROM ${t}`).run();
}
db.prepare('DELETE FROM game_scores WHERE id >?').run(gameScoreMaxId);
db.prepare('DELETE FROM letters WHERE id >?').run(lettersMaxId);
db.prepare('DELETE FROM heart_ledger WHERE id >?').run(ledgerMaxId);
// 恢复今日 daily_records：只删本次新增的 kind（已存在的 kind 行未被改写）
const kinds = [...todayDailyKinds];
if (kinds.length > 0) {
const ph = kinds.map(() => '?').join(',');
db.prepare(`DELETE FROM daily_records WHERE date =? AND kind NOT IN (${ph})`).run(today,...kinds);
} else {
db.prepare('DELETE FROM daily_records WHERE date =?').run(today);
}
if (moodTodaySnapshot) {
db.prepare('UPDATE mood_entries SET mood =?, note =?, updated_at =? WHERE date =?').run(
moodTodaySnapshot.mood, moodTodaySnapshot.note, moodTodaySnapshot.updated_at, today
);
} else {
db.prepare('DELETE FROM mood_entries WHERE date =?').run(today);
}
if (catSnapshot) {
db.prepare('UPDATE cat_state SET state =?, mood =?, intimacy =?, hearts =?, last_interact_at =?, last_actions =?, updated_at =? WHERE id = 1').run(
catSnapshot.state, catSnapshot.mood, catSnapshot.intimacy, catSnapshot.hearts,
catSnapshot.last_interact_at, catSnapshot.last_actions, catSnapshot.updated_at
);
} else {
db.prepare('DELETE FROM cat_state WHERE id = 1').run();
}
for (const sid of createdSessions) {
db.prepare('DELETE FROM messages WHERE session_id =?').run(sid);
db.prepare('DELETE FROM sessions WHERE id =?').run(sid);
}
} catch (e) {
console.error('[15-cleanup] 清理失败：', e.message);
} finally {
try { db?.close();} catch { /* ignore */}
}
});

// ---------- 静态：新表 / 新列 / 备份表 ----------

test('phase3-静态：SQLite 与 PG schema 均含 manual_memories/anniversaries 与 messages.favorite，且无 DROP/DELETE', () => {
for (const f of ['db/schema.sqlite.sql', 'db/schema.pg.sql']) {
const sql = fs.readFileSync(path.join(APP_ROOT, f), 'utf8');
assert.match(sql, /CREATE TABLE IF NOT EXISTS manual_memories\b/, `${f} 缺少表 manual_memories`);
assert.match(sql, /manual_memories[\s\S]*?title TEXT NOT NULL/, `${f} manual_memories 应有 title`);
assert.match(sql, /manual_memories[\s\S]*?date TEXT NOT NULL/, `${f} manual_memories 应有 date`);
assert.match(sql, /CREATE TABLE IF NOT EXISTS anniversaries\b/, `${f} 缺少表 anniversaries`);
assert.match(sql, /anniversaries[\s\S]*?name TEXT NOT NULL/, `${f} anniversaries 应有 name`);
assert.match(sql, /messages[\s\S]*?favorite INTEGER NOT NULL DEFAULT 0/, `${f} messages 应有 favorite 列（默认 0）`);
assert.doesNotMatch(sql, /DROP TABLE|DELETE FROM/i, `${f} 迁移只许新增，不应有 DROP/DELETE`);
}
const serverSrc = fs.readFileSync(path.join(APP_ROOT, 'server.js'), 'utf8');
assert.ok(serverSrc.includes("'manual_memories'"), 'BACKUP_TABLES 应含 manual_memories');
assert.ok(serverSrc.includes("'anniversaries'"), 'BACKUP_TABLES 应含 anniversaries');
const dbSrc = fs.readFileSync(path.join(APP_ROOT, 'src/db.js'), 'utf8');
assert.match(dbSrc, /ensureMessagesFavoriteColumn/, 'db.js 应有 messages.favorite 启动迁移');
assert.match(dbSrc, /ADD COLUMN IF NOT EXISTS favorite/, 'PG 迁移应用 IF NOT EXISTS 加 favorite 列');
});

// ---------- 纯函数：花园百分比 / 睡前池 / 情绪映射 ----------

test('phase3-纯函数：flowerStage progress 是 0–100 整数百分比（不再是 0–1 小数）', () => {
const now = new Date('2026-11-11T12:00:00Z');
const ago = (h) => new Date(now.getTime() - h * 3600 * 1000).toISOString();
assert.deepEqual(flowerStage('rose', null, now), { stage: 'seed', progress: 0, ready: false});
assert.deepEqual(flowerStage('rose', ago(1), now), { stage: 'sprout', progress: 17, ready: false});
assert.deepEqual(flowerStage('rose', ago(3), now), { stage: 'bud', progress: 50, ready: false});
assert.deepEqual(flowerStage('rose', ago(5), now), { stage: 'bud', progress: 83, ready: false});
assert.deepEqual(flowerStage('rose', ago(6), now), { stage: 'bloom', progress: 100, ready: true});
assert.deepEqual(flowerStage('daisy', ago(2), now), { stage: 'bloom', progress: 100, ready: true});
});

test('phase3-纯函数：睡前故事 4 篇均为原创、80–150 字；晚安信 6 条，同日确定', () => {
assert.equal(BEDTIME_STORIES.length, 4, '本地睡前故事应为 4 篇');
for (const s of BEDTIME_STORIES) {
assert.ok(s.length >= 80 && s.length <= 150, `故事应 80–150 字，实际 ${s.length} 字：${s.slice(0, 20)}…`);
}
assert.equal(GOODNIGHT_NOTES.length, 6, '晚安小纸条应为 6 条');
for (const n of GOODNIGHT_NOTES) assert.ok(n.length > 0 && n.length < 60, '小纸条应为一两句');
assert.deepEqual(localBedtimeStory('2030-06-15'), localBedtimeStory('2030-06-15'), '同一天本地故事应稳定');
assert.notEqual(
localBedtimeStory('2030-06-15').story, localBedtimeStory('2030-06-16').story,
'不同天故事应轮换（4 篇按日期种子挑）'
);
assert.equal(goodnightLetter('2030-06-15').letter, goodnightLetter('2030-06-15').letter, '同一天晚安信应稳定');
assert.equal(goodnightLetter('2030-06-15').source, 'generic');
});

test('phase3-纯函数：情绪 8 取值映射与上下文文本，非法取值抛 bad_request', () => {
assert.deepEqual(Object.keys(EMOTION_LABELS), ['happy', 'sad', 'wronged', 'irritated', 'praise', 'clingy', 'talk', 'quiet']);
assert.equal(emotionContextText('happy'), '');
assert.equal(emotionContextText('sad'), '');
assert.equal(emotionContextText('wronged'), '');
assert.equal(emotionContextText('irritated'), '');
assert.equal(emotionContextText('praise'), '');
assert.equal(emotionContextText('clingy'), '');
assert.equal(emotionContextText('talk'), '');
assert.equal(emotionContextText('quiet'), '');
assert.throws(() => emotionContextText('angry'), (e) => e.code === 'bad_request');
});

// ---------- HTTP：手动回忆 ----------

test('phase3-手动回忆：增删改查 + 校验（空标题/空文本/非法日期 400）', async () => {
const empty = await api(noKey.base, 'GET', '/api/manual-memories');
assert.deepEqual(empty.json, { memories: []}, '初始手动回忆应为空');

const c1 = await api(noKey.base, 'POST', '/api/manual-memories', { title: '第一次见面', date: '2026-11-01', text: '在学校门口第一次见面'});
assert.equal(c1.status, 201, `建回忆应 201：${c1.text}`);
const id1 = c1.json.id;
assert.equal(c1.json.title, '第一次见面');
const c2 = await api(noKey.base, 'POST', '/api/manual-memories', { title: '一起看电影', date: '2026-11-10', text: '看了部很好看的电影'});
assert.equal(c2.status, 201);
const id2 = c2.json.id;

// 校验：空标题、空文本、非法日期、不存在的日期都应 400
for (const bad of [
{ title: '', date: '2026-11-01', text: 'x'},
{ title: 'x', date: '2026-11-01', text: ''},
{ title: 'x', date: '2026-13-01', text: 'y'},
{ title: 'x', date: '2026-02-30', text: 'y'},
{ title: 'x', date: '11-01', text: 'y'},
{ date: '2026-11-01', text: 'y'},
]) {
const r = await api(noKey.base, 'POST', '/api/manual-memories', bad);
assert.equal(r.status, 400, `非法回忆 ${JSON.stringify(bad)} 应 400，实际 ${r.status}：${r.text}`);
}

// 列表按 date 倒序（11-10 在前）
const list = await api(noKey.base, 'GET', '/api/manual-memories');
assert.deepEqual(list.json.memories.map((m) => m.date), ['2026-11-10', '2026-11-01']);

// 改：改标题与日期；非法改 400；不存在的 id 改 404
const put = await api(noKey.base, 'PUT', `/api/manual-memories/${id1}`, { title: '第一次见面（改）', date: '2026-11-02'});
assert.equal(put.status, 200);
assert.equal(put.json.title, '第一次见面（改）');
assert.equal(put.json.date, '2026-11-02');
assert.equal(put.json.text, '在学校门口第一次见面', 'PUT 未传 text 时应保留原值');
assert.equal((await api(noKey.base, 'PUT', `/api/manual-memories/${id1}`, { date: '2026-02-30'})).status, 400);
assert.equal((await api(noKey.base, 'PUT', '/api/manual-memories/999999999', { title: 'x'})).status, 404);

// 删
const del = await api(noKey.base, 'DELETE', `/api/manual-memories/${id1}`);
assert.equal(del.status, 200);
assert.deepEqual(del.json, { ok: true});
const del2 = await api(noKey.base, 'DELETE', `/api/manual-memories/${id2}`);
assert.equal(del2.status, 200);
assert.deepEqual((await api(noKey.base, 'GET', '/api/manual-memories')).json, { memories: []});
});

// ---------- HTTP：收藏 ----------

test('phase3-收藏：开/关 + 404 + 列表（只认本会话的消息）', async () => {
const sid = await newSession(noKey.base, '收藏测试');
const mid = insertMessage(sid, 'assistant', 'phase3收藏测试消息');
const otherSid = await newSession(noKey.base, '收藏测试-他会话');
const otherMid = insertMessage(otherSid, 'user', '他会话的消息');

// 非法 favorite 值 400
assert.equal((await api(noKey.base, 'POST', `/api/sessions/${sid}/messages/${mid}/favorite`, { favorite: 'yes'})).status, 400);
assert.equal((await api(noKey.base, 'POST', `/api/sessions/${sid}/messages/${mid}/favorite`, {})).status, 400);
// 不存在 / 不属于该会话的消息 404
assert.equal((await api(noKey.base, 'POST', `/api/sessions/${sid}/messages/999999999/favorite`, { favorite: true})).status, 404);
assert.equal((await api(noKey.base, 'POST', `/api/sessions/${sid}/messages/${otherMid}/favorite`, { favorite: true})).status, 404);

const on = await api(noKey.base, 'POST', `/api/sessions/${sid}/messages/${mid}/favorite`, { favorite: true});
assert.equal(on.status, 200, `收藏应 200：${on.text}`);
assert.deepEqual(on.json, { ok: true, favorite: true});
const list = await api(noKey.base, 'GET', '/api/favorites');
assert.equal(list.status, 200);
const row = list.json.favorites.find((f) => f.id === mid);
assert.ok(row, '收藏后列表应含该消息');
assert.deepEqual(
{ id: row.id, session_id: row.session_id, role: row.role, content: row.content},
{ id: mid, session_id: sid, role: 'assistant', content: 'phase3收藏测试消息'}
);
assert.ok(row.created_at, '收藏项应含 created_at');

const off = await api(noKey.base, 'POST', `/api/sessions/${sid}/messages/${mid}/favorite`, { favorite: false});
assert.deepEqual(off.json, { ok: true, favorite: false});
const list2 = await api(noKey.base, 'GET', '/api/favorites');
assert.ok(!list2.json.favorites.some((f) => f.id === mid), '取消收藏后列表不应再含它');
});

// ---------- HTTP：纪念日 ----------

test('phase3-纪念日：增删改查 + days_left（当天 0、过去负数、未来正数）+ 校验', async () => {
const list0 = await api(noKey.base, 'GET', '/api/anniversaries');
assert.deepEqual(list0.json, { anniversaries: []}, '初始纪念日应为空');

const cToday = await api(noKey.base, 'POST', '/api/anniversaries', { name: '今天', date: today});
assert.equal(cToday.status, 201, `建纪念日应 201：${cToday.text}`);
assert.equal(cToday.json.days_left, 0, '纪念日当天 days_left 应为 0');
const cPast = await api(noKey.base, 'POST', '/api/anniversaries', { name: '五天前', date: addDays(today, -5)});
assert.equal(cPast.status, 201);
assert.equal(cPast.json.days_left, -5, '过去 5 天的纪念日 days_left 应为 -5');
const cFuture = await api(noKey.base, 'POST', '/api/anniversaries', { name: '十天后', date: addDays(today, 10)});
assert.equal(cFuture.status, 201);
assert.equal(cFuture.json.days_left, 10, '未来 10 天的纪念日 days_left 应为 10');

for (const bad of [
{ name: '', date: today},
{ name: 'x', date: '2026-02-30'},
{ name: 'x', date: '2026-13-01'},
{ date: today},
]) {
const r = await api(noKey.base, 'POST', '/api/anniversaries', bad);
assert.equal(r.status, 400, `非法纪念日 ${JSON.stringify(bad)} 应 400，实际 ${r.status}`);
}

const list = await api(noKey.base, 'GET', '/api/anniversaries');
assert.equal(list.json.anniversaries.length, 3);
assert.ok(list.json.anniversaries.every((a) => Number.isInteger(a.days_left)), '每条都应含整数 days_left');

const put = await api(noKey.base, 'PUT', `/api/anniversaries/${cPast.json.id}`, { name: '五天前（改）'});
assert.equal(put.status, 200);
assert.equal(put.json.name, '五天前（改）');
assert.equal(put.json.days_left, -5, '改名不应改 days_left');
assert.equal((await api(noKey.base, 'PUT', `/api/anniversaries/${cPast.json.id}`, { date: '2026-02-30'})).status, 400);
assert.equal((await api(noKey.base, 'PUT', '/api/anniversaries/999999999', { name: 'x'})).status, 404);

for (const id of [cToday.json.id, cPast.json.id, cFuture.json.id]) {
const d = await api(noKey.base, 'DELETE', `/api/anniversaries/${id}`);
assert.equal(d.status, 200);
assert.deepEqual(d.json, { ok: true});
}
assert.deepEqual((await api(noKey.base, 'GET', '/api/anniversaries')).json, { anniversaries: []});
});

// ---------- HTTP：每日报告（空库） ----------

test('phase3-报告空库：无数据日期全 0/null/[]；非法日期 400；默认今天', async () => {
const r = await api(noKey.base, 'GET', `/api/report?date=${EMPTY_DATE}`);
assert.equal(r.status, 200, `空报告应 200：${r.text}`);
assert.deepEqual(r.json, {
date: EMPTY_DATE,
chat: { user: 0, assistant: 0},
mood: null,
tasks: { total: 5, done: 0, claimed: 0},
surprise: { claimed: false},
games: [],
cat: { hearts: r.json.cat.hearts, intimacy: r.json.cat.intimacy, heartsToday: 0, intimacyToday: null},
garden: { harvested: [], growing: []},
letters: { drawn: 0, saved: 0},
}, '空日期的报告应诚实为 0/null/[]（cat 当前值除外，intimacyToday 恒为 null）');
assert.ok(Number.isInteger(r.json.cat.hearts) && r.json.cat.hearts >= 0, 'cat.hearts 应为非负整数');
assert.ok(Number.isInteger(r.json.cat.intimacy) && r.json.cat.intimacy >= 0, 'cat.intimacy 应为非负整数');
assert.equal(r.json.cat.intimacyToday, null, '亲密度变化无记账，intimacyToday 应为 null');

assert.equal((await api(noKey.base, 'GET', '/api/report?date=2026-13-01')).status, 400);
assert.equal((await api(noKey.base, 'GET', '/api/report?date=not-a-date')).status, 400);
assert.equal((await api(noKey.base, 'GET', '/api/report?date=2026-02-30')).status, 400);
const def = await api(noKey.base, 'GET', '/api/report');
assert.equal(def.status, 200);
assert.equal(def.json.date, today, '不传 date 时默认今天（Asia/Shanghai）');
});

// ---------- HTTP：花园进度百分比 ----------

test('phase3-花园进度：getGarden/plant/water 返回的 progress 都是 0–100 整数', async () => {
const g0 = await api(noKey.base, 'GET', '/api/garden');
assert.equal(g0.status, 200);
assert.ok(g0.json.plots.every((p) => p.progress === 0), '空花园 progress 应为 0');

const plant = await api(noKey.base, 'POST', '/api/garden/plant', { slot: 0, flower: 'daisy'});
assert.equal(plant.status, 200);
assert.equal(plant.json.progress, 0, '未浇水种下时 progress 应为 0');
const w = await api(noKey.base, 'POST', '/api/garden/water', { slot: 0});
assert.equal(w.status, 200);
// 浇水瞬间 progress 仍为 0（整数）；注入 3 小时前（雏菊 2h）→ 100
assert.ok(Number.isInteger(w.json.progress) && w.json.progress >= 0 && w.json.progress <= 100, 'water 返回的 progress 应为 0–100 整数');
db.prepare('UPDATE garden_plots SET watered_at =? WHERE slot = 0 AND harvested_at IS NULL').run(hoursAgo(3));
const g1 = await api(noKey.base, 'GET', '/api/garden');
assert.equal(g1.json.plots[0].stage, 'bloom');
assert.equal(g1.json.plots[0].progress, 100, '长满后 progress 应为 100（不是 1）');

// 玫瑰 3h/6h → 50；郁金香 2h/12h → 17
await api(noKey.base, 'POST', '/api/garden/plant', { slot: 1, flower: 'rose'});
await api(noKey.base, 'POST', '/api/garden/plant', { slot: 2, flower: 'tulip'});
await api(noKey.base, 'POST', '/api/garden/water', { slot: 1});
await api(noKey.base, 'POST', '/api/garden/water', { slot: 2});
db.prepare('UPDATE garden_plots SET watered_at =? WHERE slot = 1 AND harvested_at IS NULL').run(hoursAgo(3));
db.prepare('UPDATE garden_plots SET watered_at =? WHERE slot = 2 AND harvested_at IS NULL').run(hoursAgo(2));
const g2 = await api(noKey.base, 'GET', '/api/garden');
assert.equal(g2.json.plots[1].progress, 50, '玫瑰 3h/6h progress 应为 50（不是 0.5）');
assert.equal(g2.json.plots[2].progress, 17, '郁金香 2h/12h progress 应为 17（不是 0.1667）');
// 收獲全部，留干净花园给报告测试（after 也会再清）
db.prepare('UPDATE garden_plots SET watered_at =? WHERE harvested_at IS NULL').run(hoursAgo(30));
for (const slot of [0, 1, 2]) {
const h = await api(noKey.base, 'POST', '/api/garden/harvest', { slot});
assert.equal(h.status, 200, `收获槽 ${slot} 应 200：${h.text}`);
}
});

// ---------- HTTP：每日报告（有数据） ----------

test('phase3-报告有数据：各项数字只读真实记录（基线前后对比 + 交叉核对）', async () => {
const base = (await api(noKey.base, 'GET', '/api/report')).json;
assert.equal(base.date, today);

// 心情
const mood = await api(noKey.base, 'POST', '/api/mood', { mood: '开心', note: 'phase3测试'});
assert.equal(mood.status, 200, `记心情应 200：${mood.text}`);
// 游戏分
const gs = await api(noKey.base, 'POST', '/api/games/score', { game: 'phase3-test', score: 42});
assert.equal(gs.status, 201, `记游戏分应 201：${gs.text}`);
// 聊天：直接落库 2 条 user + 1 条 assistant（今天窗口内）
const sid = await newSession(noKey.base, '报告测试');
insertMessage(sid, 'user', '报告测试用户消息一');
insertMessage(sid, 'user', '报告测试用户消息二');
insertMessage(sid, 'assistant', '报告测试AI回复');
// 猫咪互动：pet（任务 pet 完成 + 爱心记账）
const inter = await api(noKey.base, 'POST', '/api/cat/interact', { action: 'pet'});
assert.equal(inter.status, 200, `互动应 200：${inter.text}`);
// 任务：领 pet 奖励（07/09 已清理今日任务行，应能领到；409 则说明已被领，口径不变）
const claim = await api(noKey.base, 'POST', '/api/daily/tasks/pet/claim', {});
assert.ok([200, 409].includes(claim.status), `领任务应 200 或 409：${claim.text}`);
// 惊喜：未领则领
const daily = await api(noKey.base, 'GET', '/api/daily');
if (!daily.json.surprise.claimed) {
const s = await api(noKey.base, 'POST', '/api/daily/surprise', {});
assert.equal(s.status, 200, `领惊喜应 200：${s.text}`);
}
// 花园：清掉本文件花园测试的残留，种雏菊→浇水→注 3h 前→收获（当天 harvested+1），再种一朵玫瑰 seed（growing）
db.prepare('DELETE FROM garden_plots').run();
await api(noKey.base, 'POST', '/api/garden/plant', { slot: 0, flower: 'daisy'});
await api(noKey.base, 'POST', '/api/garden/water', { slot: 0});
db.prepare('UPDATE garden_plots SET watered_at =? WHERE slot = 0 AND harvested_at IS NULL').run(hoursAgo(3));
const hv = await api(noKey.base, 'POST', '/api/garden/harvest', { slot: 0});
assert.equal(hv.status, 200, `收获应 200：${hv.text}`);
await api(noKey.base, 'POST', '/api/garden/plant', { slot: 1, flower: 'rose'});
// 信件：画一封并收藏
const beforeLetters = { drawn: base.letters.drawn, saved: base.letters.saved};
const drawn = await api(noKey.base, 'POST', '/api/letters/draw', {});
assert.equal(drawn.status, 201, `抽信应 201：${drawn.text}`);
const saved = await api(noKey.base, 'POST', `/api/letters/${drawn.json.id}/save`, {});
assert.equal(saved.status, 200, `收藏信应 200：${saved.text}`);

const r = (await api(noKey.base, 'GET', '/api/report')).json;
assert.equal(r.date, today);
assert.deepEqual(r.chat, { user: base.chat.user + 2, assistant: base.chat.assistant + 1}, '聊天数应为基线 + 本次落库的 3 条');
assert.deepEqual(r.mood, { mood: '开心', note: 'phase3测试'});
assert.deepEqual(r.tasks, {
total: 5,
done: 5, // pet/chat/surprise/game/mood 今日全部完成
claimed: claim.status === 200? base.tasks.claimed + 1: base.tasks.claimed,
}, '任务 done 应 5 个全完成；claimed 按本次领取结果算');
assert.deepEqual(r.surprise, { claimed: true});
const mine = r.games.find((g) => g.game === 'phase3-test');
assert.ok(mine, 'games 应含本次记的 phase3-test');
assert.equal(mine.score, 42);
// 猫：与 /api/cat 当前值一致；heartsToday 与 ledger 当天求和交叉核对
const catNow = (await api(noKey.base, 'GET', '/api/cat')).json;
assert.equal(r.cat.hearts, catNow.hearts);
assert.equal(r.cat.intimacy, catNow.intimacy);
const [s, e] = shanghaiDayRange(today);
const ledger = (await api(noKey.base, 'GET', '/api/cat/ledger?limit=200')).json;
const expectedHeartsToday = ledger
.filter((x) => x.created_at >= s && x.created_at < e)
.reduce((sum, x) => sum + x.delta, 0);
assert.equal(r.cat.heartsToday, expectedHeartsToday, 'heartsToday 应等于 heart_ledger 当天 delta 求和');
assert.equal(r.cat.intimacyToday, null, '亲密度变化无记账，intimacyToday 应为 null');
// 花园：growing 只有刚种的玫瑰 seed；harvested 只有刚收的雏菊
assert.equal(r.garden.growing.length, 1, 'growing 应只有刚种的玫瑰');
assert.deepEqual(r.garden.growing[0], { flower: 'rose', stage: 'seed', progress: 0});
assert.equal(r.garden.harvested.length, 1, 'harvested 应只有刚收的雏菊');
assert.equal(r.garden.harvested[0].flower, 'daisy');
assert.ok(r.garden.harvested[0].harvested_at >= s && r.garden.harvested[0].harvested_at < e, 'harvested_at 应落在今天');
// 信件：drawn/saved 各 +1（当天创建且当天收藏）
assert.deepEqual(r.letters, { drawn: beforeLetters.drawn + 1, saved: beforeLetters.saved + 1});
});

// ---------- HTTP：睡前（无 Key 走本地） ----------

test('phase3-睡前无Key：故事走本地库（source local、80–150 字、同日稳定）；晚安信同日稳定', async () => {
const cfg = await api(noKey.base, 'GET', '/api/config');
assert.equal(cfg.json.hasKey, false, '无 Key 服务 hasKey 应为 false');
const s1 = await api(noKey.base, 'POST', '/api/bedtime/story', {});
assert.equal(s1.status, 200, `睡前故事应 200：${s1.text}`);
assert.equal(s1.json.source, 'local', '无 Key 时故事 source 应为 local');
assert.ok(typeof s1.json.story === 'string' && s1.json.story.length >= 80 && s1.json.story.length <= 150,
`本地故事应 80–150 字，实际 ${s1.json.story?.length} 字`);
const s2 = await api(noKey.base, 'POST', '/api/bedtime/story', {});
assert.equal(s2.json.story, s1.json.story, '同一天本地故事应稳定（按日期轮换）');
assert.equal(s2.json.source, 'local');

const l1 = await api(noKey.base, 'GET', '/api/bedtime/letter');
assert.equal(l1.status, 200);
assert.equal(l1.json.source, 'generic');
assert.ok(typeof l1.json.letter === 'string' && l1.json.letter.length > 0, '晚安信应有文本');
const l2 = await api(noKey.base, 'GET', '/api/bedtime/letter');
assert.equal(l2.json.letter, l1.json.letter, '同一天晚安信应稳定');
});

// ---------- HTTP：情绪上下文（无 Key） ----------

test('phase3-情绪无Key：带 emotion 也诚实报 NO_API_KEY、不建消息；非法 emotion 400', async () => {
const sid = await newSession(noKey.base, '情绪无Key测试');
const { events} = await postChatSSE(noKey.base, sid, { content: '你好', clientId: `emo-nokey-${Date.now()}`, emotion: 'happy'});
const err = events.find((e) => e.type === 'error');
assert.ok(err, `应收到 SSE error 事件，实际：${JSON.stringify(events)}`);
assert.equal(err.code, 'NO_API_KEY');
assert.ok(!events.some((e) => e.type === 'delta'), '无 Key 时绝不返回假回复 delta');
const msgs = await api(noKey.base, 'GET', `/api/sessions/${sid}/messages`);
assert.equal(msgs.json.length, 0, '无 Key 报错时不应落库任何消息（情绪上下文也不应落库）');

const bad = await api(noKey.base, 'POST', `/api/sessions/${sid}/chat`, { content: '你好', emotion: 'angry'});
assert.equal(bad.status, 400, `非法 emotion 应 400，实际 ${bad.status}：${bad.text}`);
const msgs2 = await api(noKey.base, 'GET', `/api/sessions/${sid}/messages`);
assert.equal(msgs2.json.length, 0, '非法 emotion 被拒时也不应落库');
});

// ---------- 有 Key + 本地 stub：情绪三铁律 / 睡前 DeepSeek ----------

test('启动有 Key 服务（测试假 Key + 成功/401 stub），并记录原始 baseUrl', async () => {
stubOk = await startErrorStub((req, res) => {
let body = '';
req.on('data', (c) => { body += c.toString();});
req.on('end', () => {
try { capturedBodies.push(JSON.parse(body));} catch { /* 忽略 */}
res.writeHead(200, { 'Content-Type': 'text/event-stream'});
res.end('data: {"choices":[{"delta":{"content":"嗯呐 你好呀"}}]}\n\ndata: [DONE]\n\n');
});
});
stub401 = await startErrorStub((req, res) => {
res.writeHead(401, { 'Content-Type': 'application/json'});
res.end(JSON.stringify({ error: { message: 'Incorrect API key provided'}}));
});
await stopServer(noKey.child);
noKey = null;
keyed = await startAppServer({ port: await freePort(), apiKey: 'test-dummy-key'});
const cfg = await api(keyed.base, 'GET', '/api/config');
assert.equal(cfg.json.hasKey, true);
assert.equal(cfg.json.baseUrl, originalBaseUrl, '启动时 baseUrl 应仍为原始值');
});

test('phase3-情绪三铁律：system prompt 带/不带 emotion 完全一致；上下文只追加给模型、不落库', async () => {
const put = await api(keyed.base, 'PUT', '/api/config', { baseUrl: stubOk.base});
assert.equal(put.status, 200);
capturedBodies.length = 0;

// 不带 emotion 的聊天
const s1 = await newSession(keyed.base, '情绪对照-无');
const r1 = await postChatSSE(keyed.base, s1, { content: '你好', clientId: `emo-a-${Date.now()}`});
assert.ok(r1.events.some((e) => e.type === 'done'), `无 emotion 聊天应收到 done，实际：${JSON.stringify(r1.events)}`);
assert.ok(!r1.events.some((e) => e.type === 'error'), '成功 stub 不应返回 error');
// 带 emotion 的聊天（同一句话，便于 system prompt 逐字对比）
const s2 = await newSession(keyed.base, '情绪对照-有');
const r2 = await postChatSSE(keyed.base, s2, { content: '你好', clientId: `emo-b-${Date.now()}`, emotion: 'happy'});
assert.ok(r2.events.some((e) => e.type === 'done'), `带 emotion 聊天应收到 done，实际：${JSON.stringify(r2.events)}`);

assert.equal(capturedBodies.length, 2, `DeepSeek 应正好被调 2 次，实际 ${capturedBodies.length}`);
const [plain, withEmo] = capturedBodies;
// 铁律①：system prompt 完全一致（buildSystemPrompt 未被 emotion 影响）
assert.equal(plain.messages[0].role, 'system');
assert.equal(withEmo.messages[0].role, 'system');
assert.equal(withEmo.messages[0].content, plain.messages[0].content, '带 emotion 与不带时 system prompt 应逐字一致');
assert.ok(withEmo.messages[0].content.includes('18岁'), 'system prompt 应含人格 A–I 原文');
// 铁律②：上下文消息只追加给模型，且只有 ONE 条、内容逐字一致
assert.equal(plain.messages.length, 2, '不带 emotion 时只发 [system, user]');
assert.deepEqual(plain.messages[1], { role: 'user', content: '你好'});
assert.equal(withEmo.messages.length, 3, '带 emotion 时只多 ONE 条上下文消息');
assert.deepEqual(withEmo.messages[1], { role: 'user', content: '你好'});
assert.deepEqual(withEmo.messages[2], { role: 'user', content: ''});
// 铁律③：库里不新增上下文消息（每会话只有 user + assistant 两条，且无“当前情绪”字样）
for (const [sid, label] of [[s1, '无 emotion'], [s2, '带 emotion']]) {
const msgs = await api(keyed.base, 'GET', `/api/sessions/${sid}/messages`);
assert.equal(msgs.json.length, 2, `${label}会话库里应正好 2 条消息，实际 ${msgs.json.length}：${JSON.stringify(msgs.json.map((m) => m.content))}`);
assert.deepEqual(msgs.json.map((m) => m.role), ['user', 'assistant']);
assert.ok(msgs.json.every((m) =>!m.content.includes('当前情绪')), `${label}会话库里绝不能出现情绪上下文消息`);
assert.equal(msgs.json[1].content, '嗯呐 你好呀', 'AI 回复应为 stub 返回的固定内容');
}
});

test('phase3-睡前 DeepSeek：成功时 source deepseek；401 失败回 local（不伪装）', async () => {
// 成功 stub（已在上一个测试指向 stubOk）
const before = capturedBodies.length;
const ok = await api(keyed.base, 'POST', '/api/bedtime/story', {});
assert.equal(ok.status, 200, `睡前故事应 200：${ok.text}`);
assert.equal(ok.json.source, 'deepseek', '上游成功时 source 应为 deepseek');
assert.equal(ok.json.story, '嗯呐 你好呀', '故事应为 stub 返回的固定内容');
const storyReq = capturedBodies[capturedBodies.length - 1];
assert.ok(storyReq.messages[0].content.includes('睡前小故事'), '睡前故事的 system prompt 应含睡前要求');
assert.ok(storyReq.messages[0].content.includes('18岁'), '睡前故事的 system prompt 应含人格原文');
assert.equal(capturedBodies.length, before + 1, '睡前故事应调一次 DeepSeek');

// 401 失败 → 回 local，不报错、不伪装
const put = await api(keyed.base, 'PUT', '/api/config', { baseUrl: stub401.base});
assert.equal(put.status, 200);
const bad = await api(keyed.base, 'POST', '/api/bedtime/story', {});
assert.equal(bad.status, 200);
assert.equal(bad.json.source, 'local', '上游 401 时 source 应回落为 local');
assert.ok(bad.json.story.length >= 80 && bad.json.story.length <= 150, '回落的本地故事仍应 80–150 字');
assert.equal(bad.json.story, localBedtimeStory().story, '回落故事应与当日本地轮换一致');
});

test('恢复 model_config.baseUrl 为原始值', async () => {
const put = await api(keyed.base, 'PUT', '/api/config', { baseUrl: originalBaseUrl});
assert.equal(put.status, 200);
const cfg = await api(keyed.base, 'GET', '/api/config');
assert.equal(cfg.json.baseUrl, originalBaseUrl, '测试结束应把 baseUrl 恢复为原始值');
});
