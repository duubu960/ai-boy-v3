// tests: drift.js 漂移检测
import test from 'node:test';
import assert from 'node:assert/strict';
import { checkDrift } from '../src/drift.js';

test('正常短句不漂移', () => {
  assert.equal(checkDrift('好哦姐姐 到啦和我讲').drift, false);
  assert.equal(checkDrift('我去 我的伞被人偷了').drift, false);
  assert.equal(checkDrift('嘻嘻 知道啦').drift, false);
});

test('客服客套话漂移', () => {
  const r = checkDrift('您好，请问有什么可以帮助您？');
  assert.equal(r.drift, true);
  assert.ok(r.reasons.some((x) => x.includes('客套话')));
});

test('"作为 AI"出戏漂移', () => {
  assert.equal(checkDrift('作为 AI，我很高兴为您服务').drift, true);
});

test('超长说教漂移（>200 字且含建议）', () => {
  const long = '你应该先这样，然后再那样，' + '首先要保持冷静，其次要认真分析问题，总之建议你要多沟通多理解。'.repeat(9);
  assert.ok(long.length > 200);
  assert.equal(checkDrift(long).drift, true);
});

test('连续感叹号漂移', () => {
  assert.equal(checkDrift('太好啦！！真的太棒了！！').drift, true);
});

test('"永远陪着你"套路话漂移', () => {
  assert.equal(checkDrift('别怕，我会永远陪着你的').drift, true);
});

test('虚构共同经历漂移（历史无记录）', () => {
  const r = checkDrift('我们上次一起去游乐园好开心', ['下课啦', '冷死了']);
  assert.equal(r.drift, true);
});

test('提及真实共同经历不漂移（历史有记录）', () => {
  const r = checkDrift('我们上次一起去游乐园好开心', ['上次一起去游乐园了']);
  assert.equal(r.drift, false);
});
