// 03-memory.test.js — 自动记忆（src/memory.js + SQLite）
// 对应 20 项中的：8 自动记忆正常、9 记忆去重、10 冲突处理、
// 11 手动改记忆生效（自动提取不覆盖 manual）、12 删除后停止调用、13 新建会话读相关旧记忆。
// 注意：本文件在测试进程内直接用 src/db.js（与 server 子进程不同时运行，见 package.json 的 --test-concurrency=1）。
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { initDb, query, run, closeDb } from '../src/db.js';
import { extractCandidates, saveCandidates, retrieveRelevant } from '../src/memory.js';

const DISH = '麻辣烫';
const NOODLE = '拉面';

before(async () => {
  await initDb();
  // 清掉历次残留的测试记忆，避免跨轮干扰
  await run(`DELETE FROM memories WHERE content LIKE '%${DISH}%' OR content LIKE '%${NOODLE}%' OR content LIKE '%香菇鸡丁%' OR content LIKE 'TESTMEM%'`);
});

after(async () => {
  await run(`DELETE FROM memories WHERE content LIKE '%${DISH}%' OR content LIKE '%${NOODLE}%' OR content LIKE '%香菇鸡丁%' OR content LIKE 'TESTMEM%'`);
  await closeDb();
});

function userMsg(content) {
  return { role: 'user', content };
}

test('item-8：约定 / 偏好被提取（分类与重要性分段正确）', () => {
  const c = extractCandidates([
    userMsg('明天下午三点一起去图书馆'),
    userMsg('我喜欢吃香菇鸡丁'),
  ]);
  assert.equal(c.length, 2);
  const byCat = Object.fromEntries(c.map((x) => [x.category, x]));
  assert.equal(byCat['约定'].content, '明天下午三点一起去图书馆');
  assert.ok(byCat['约定'].importance >= 70 && byCat['约定'].importance <= 90, '约定重要性应在 70–90');
  assert.equal(byCat['偏好'].content, '我喜欢吃香菇鸡丁');
  assert.ok(byCat['偏好'].importance >= 70 && byCat['偏好'].importance <= 90, '偏好重要性应在 70–90');
});

test('item-8：普通闲聊不被保存（下课啦 / 接了杯水 / 打完了 / 冷死了）', () => {
  const c = extractCandidates([
    userMsg('下课啦'),
    userMsg('我刚刚下去接了杯水'),
    userMsg('打完了'),
    userMsg('冷死了'),
    userMsg('嗯呐'),
  ]);
  assert.equal(c.length, 0, `闲聊应零候选，实际：${JSON.stringify(c)}`);
});

test('item-8：「我朋友叫我打王者」不被保存（闲聊子串匹配）', () => {
  // CHITCHAT_ANY 为非锚定子串匹配（打王者/接了杯水/下课啦…），"我朋友叫我打王者"即使以"我朋友"开头，
  // 也先被闲聊规则拦截，不会误判为人物关系记忆。已验证通过。
  const c = extractCandidates([userMsg('我朋友叫我打王者，所以我要打一会')]);
  assert.equal(c.length, 0, `闲聊应零候选，实际：${JSON.stringify(c)}`);
});

test('item-9：同一内容两次只存一条（第二次只更新 updated_at）', async () => {
  const cand = { content: `TESTMEM我喜欢吃香菇鸡丁`, category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' };
  const s1 = await saveCandidates([cand]);
  assert.equal(s1.saved, 1, `第一次应保存 1 条：${JSON.stringify(s1)}`);
  const s2 = await saveCandidates([cand]);
  assert.equal(s2.saved, 0, `第二次不应新增：${JSON.stringify(s2)}`);
  assert.equal(s2.updated, 1, `第二次应只更新：${JSON.stringify(s2)}`);
  const rows = await query('SELECT * FROM memories WHERE content = ?', [cand.content]);
  assert.equal(rows.length, 1, '同一内容在库里只能有一条');
});

test('item-10（已知问题）：矛盾记忆——旧的变 conflict、新的变 pending', async () => {
  // 根因（实测）："我喜欢吃麻辣烫"与"我不喜欢吃麻辣烫"的 Jaccard 相似度为 0.75（> 0.7），
  // saveCandidates 的去重检查先于冲突检查触发，新记忆被当成重复（updated）而不是矛盾，
  // 冲突分支对短句正负翻转基本不可达。本用例按规格断言，当前实现会失败——已作为 bug 报给总协调（见 TEST-REPORT）。
  // 建议修复：冲突检查先于去重检查，或去重时排除正负相反的对子。
  const oldC = { content: `我喜欢吃${DISH}`, category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' };
  const newC = { content: `我不喜欢吃${DISH}`, category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' };
  await saveCandidates([oldC]);
  const s = await saveCandidates([newC]);
  assert.equal(s.conflict, 1, `应标记 1 次冲突：${JSON.stringify(s)}`);
  assert.equal(s.pending, 1, `新记忆应为 pending：${JSON.stringify(s)}`);
  const oldRow = await query('SELECT * FROM memories WHERE content = ?', [oldC.content]);
  const newRow = await query('SELECT * FROM memories WHERE content = ?', [newC.content]);
  assert.equal(oldRow[0].status, 'conflict', '旧记忆状态应为 conflict');
  assert.equal(newRow[0].status, 'pending', '新记忆状态应为 pending');
});

test('item-11：手动记忆永不被自动提取覆盖', async () => {
  const manual = `TESTMEM手动我喜欢吃${NOODLE}`;
  await run(
    "INSERT INTO memories (content, category, created_at, updated_at, source, confidence, importance, status) VALUES (?, '偏好', datetime('now'), datetime('now'), 'manual', 1, 70, 'active')",
    [manual]
  );
  // 自动提取一个与之矛盾的候选
  await saveCandidates([{ content: `TESTMEM手动我不喜欢吃${NOODLE}`, category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' }]);
  const rows = await query('SELECT * FROM memories WHERE content = ?', [manual]);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].status, 'active', '手动记忆状态不应被自动提取改动');
  assert.equal(rows[0].source, 'manual');
  assert.equal(rows[0].confidence, 1);
});

test('item-10（已知问题）：冲突检测过于宽泛——不同对象也判矛盾', async () => {
  // 规格要求：同一话题正负相反才算矛盾。
  // 但 saveCandidates 只看"双字关键词有交集 + 一正一负"：'我喜欢打羽毛球'与'我不喜欢吃拉面'
  // 只因共享"喜欢"就被判矛盾，前者会被打成 pending（见 item-12/13 的失败根因）。
  // 本用例按规格断言，当前实现会失败——已作为 bug 报给总协调（见 TEST-REPORT）。
  await saveCandidates([{ content: `TESTMEM冲突对照我不喜欢吃${NOODLE}`, category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' }]);
  const s = await saveCandidates([{ content: 'TESTMEM冲突对照我喜欢打羽毛球', category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' }]);
  assert.equal(s.conflict, 0, `不同对象不应判冲突，实际：${JSON.stringify(s)}`);
  const rows = await query('SELECT * FROM memories WHERE content = ?', ['TESTMEM冲突对照我喜欢打羽毛球']);
  assert.equal(rows[0]?.status, 'active', '不同对象的正负表述不应被打成 pending');
});

test('item-12/13：删除后 retrieve 不再返回；新建会话按关键词命中相关旧记忆', async () => {
  // 用"约定"类记忆做检索目标，避免与偏好类测试行互相触发冲突检测（见上一条已知问题）。
  const content = `TESTMEM检索明天下午三点去打羽毛球`;
  await saveCandidates([{ content, category: '约定', confidence: 0.7, importance: 85, source: 'auto', status: 'active' }]);
  const hit = await retrieveRelevant('session-new-1', '打羽毛球', 5);
  assert.ok(hit.memories.some((m) => m.content === content), `新建会话应按关键词命中该记忆，实际：${JSON.stringify(hit.memories.map((m) => m.content))}`);
  // 删除后停止调用
  await run('DELETE FROM memories WHERE content = ?', [content]);
  const afterDel = await retrieveRelevant('session-new-2', '打羽毛球', 5);
  assert.ok(!afterDel.memories.some((m) => m.content === content), '删除后 retrieve 不应再返回它');
});

test('item-13：retrieve 限量加载（limit 生效，各最多 N 条）', async () => {
  await saveCandidates([
    { content: 'TESTMEM限量我喜欢吃苹果', category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' },
    { content: 'TESTMEM限量我喜欢吃香蕉', category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' },
    { content: 'TESTMEM限量我喜欢吃橙子', category: '偏好', confidence: 0.7, importance: 80, source: 'auto', status: 'active' },
  ]);
  const r = await retrieveRelevant('session-limit', '喜欢吃', 2);
  assert.ok(r.memories.length <= 2, `memories 应不超过 limit=2，实际 ${r.memories.length}`);
  assert.ok(r.samples.length <= 2, `samples 应不超过 limit=2，实际 ${r.samples.length}`);
});
