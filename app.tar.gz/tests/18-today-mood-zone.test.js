// 18-today-mood-zone.test.js — 首页「💭 今日心情」区刷新后不丢心情回归测试
// 根因：GET /api/mood 返回最近 7 天的记录数组（按日期升序），不是 {today} 对象；
// 旧 loadMood 把整个数组直接传给 renderTodayMood，数组上取不到 mood，
// 于是每次回首页（showPage('home') → refreshHome → loadMood）和整页刷新，
// 心情区都被刷回「今天还没有选心情，点一个告诉小猪吧」，按钮高亮也被清掉，
// 哪怕心情早已保存成功（心情日记/每日报告/今日任务三处都对）。
// 修法（public/mimi.js）：loadMood 改走 pickTodayMood(d)，
// 只挑出 date 等于今天本地日期的那一行；当天没有记录时返回 null，仍显示原提示。
// 本文件两部分：A. jsdom 前端（mock fetch 按真实数组形状喂数据）；B. 真实 server 后端（数组形状）。
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { JSDOM } from 'jsdom';
import { APP_ROOT, freePort, startAppServer, stopServer, api, sleep } from './helpers.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');

/* jsdom 里 todayStrLocal() 用宿主机本地日期算“今天”——与下面同一算法。 */
function localToday() {
  const t = new Date();
  return t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
}
function shiftDate(iso, days) {
  const [y, m, d] = iso.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d + days));
  return t.getUTCFullYear() + '-' + String(t.getUTCMonth() + 1).padStart(2, '0') + '-' + String(t.getUTCDate()).padStart(2, '0');
}
const TODAY = localToday();
const YESTERDAY = shiftDate(TODAY, -1);

function resp(status, body, isJson = true) {
  return {
    ok: status >= 200 && status < 300, status,
    headers: { get: (n) => (n.toLowerCase() === 'content-type' ? (isJson ? 'application/json' : 'text/html') : null) },
    json: async () => body,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    body: null,
    clone: function () { return this; },
  };
}

const CAT_STATE = { id: 1, state: 'happy', mood: 'happy', intimacy: 0, hearts: 0, level: 1, stage: '初次见面', lastInteractAt: null, lastActions: {}, updatedAt: '2026-11-11T10:00:00Z' };
const DEFAULT_ROOM = { wallpaper: 'pink', bed: 'pink', plushies: ['bear'], lamp: true, flowers: true, painting: 'none', theme: 'home' };

/* ---------- A. jsdom 前端 ---------- */

function mockFetchFactory(seedRows = []) {
  const bodies = [];
  /* 按真实后端形状：GET /api/mood 返回记录数组（按日期升序）。 */
  const store = { moodRows: seedRows.map((r) => ({ ...r })) };
  const fetch = async (url, opts = {}) => {
    const method = (opts.method || 'GET').toUpperCase();
    const [p] = String(url).split('?');
    let body = {};
    try { body = opts.body ? JSON.parse(opts.body) : {}; } catch { body = {}; }
    bodies.push({ method, url: String(url), body });
    if (p === '/api/cat' && method === 'GET') return resp(200, { cat: { ...CAT_STATE } });
    if (p === '/api/cat/interact' && method === 'POST') return resp(200, { cat: { ...CAT_STATE, hearts: 2 }, gained: { hearts: 2, intimacy: 1 } });
    if (p === '/api/cat/outfit' && method === 'GET') return resp(200, { outfit: { bow: false, hat: false, scarf: false, dress: false, glasses: false, bg: 'bedroom', pose: 'sit' } });
    if (p === '/api/cat/outfit' && method === 'PUT') return resp(200, { ok: true });
    if (p === '/api/mood' && method === 'GET') return resp(200, [...store.moodRows].sort((a, b) => (a.date < b.date ? -1 : 1)));
    if (p === '/api/mood' && method === 'POST') {
      if (!body.mood || typeof body.mood !== 'string') {
        return resp(400, { error: 'bad_request', message: '需要 mood' });
      }
      const date = body.date || TODAY;
      const i = store.moodRows.findIndex((r) => r.date === date);
      const row = { id: i >= 0 ? store.moodRows[i].id : store.moodRows.length + 1, date, mood: body.mood, note: body.note || '', created_at: date + 'T10:00:00Z', updated_at: date + 'T10:00:00Z' };
      if (i >= 0) store.moodRows[i] = row; else store.moodRows.push(row);
      return resp(200, row);
    }
    if (p === '/api/daily' && method === 'GET') return resp(200, { tasks: [], surprise: { claimed: false }, fortune: { drawn: false } });
    if (p === '/api/memories' && method === 'GET') return resp(200, []);
    if (p === '/api/sessions' && method === 'GET') return resp(200, []);
    if (p === '/api/room' && method === 'GET') return resp(200, { room: { ...DEFAULT_ROOM } });
    if (p === '/api/room' && method === 'PUT') return resp(200, { room: { ...DEFAULT_ROOM, ...body } });
    if (p === '/api/garden' && method === 'GET') return resp(200, { plots: [], pots: [] });
    if (p === '/api/events/next' && method === 'GET') return resp(200, { event: null });
    if (p === '/api/letters' && method === 'GET') return resp(200, { letters: [] });
    if (p === '/api/games/scores' && method === 'GET') return resp(200, { scores: [] });
    if (p === '/api/manual-memories' && method === 'GET') return resp(200, { memories: [] });
    if (p === '/api/favorites' && method === 'GET') return resp(200, { favorites: [] });
    if (p === '/api/anniversaries' && method === 'GET') return resp(200, { anniversaries: [] });
    if (p === '/api/bedtime/story' && method === 'POST') return resp(200, { story: '从前有一只小猫……', source: 'local' });
    if (p === '/api/bedtime/letter' && method === 'GET') return resp(200, { letter: '晚安呀。', source: 'generic' });
    if (p === '/api/report' && method === 'GET') {
      const row = store.moodRows.find((r) => r.date === TODAY);
      return resp(200, {
        date: TODAY, chat: { user: 0, assistant: 0 },
        mood: row ? { mood: row.mood, note: row.note } : null,
        tasks: { total: 0, done: 0, claimed: 0 }, surprise: { claimed: false },
        games: [], cat: null, garden: { harvested: [], growing: [] }, letters: { drawn: 0, saved: 0 },
      });
    }
    if (/^\/api\/sessions\/[^/]+\/chat$/.test(p) && method === 'POST') return resp(200, { ok: true });
    return resp(404, { error: 'not_found' });
  };
  return { fetch, bodies, store };
}

async function makeDom(seedRows = []) {
  const html = read('public/index.html');
  const dom = new JSDOM(html, { url: 'http://127.0.0.1:3199/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  class FakeGain {
    constructor() { this.gain = { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} }; }
    connect() {}
  }
  class FakeOsc {
    constructor() { this.frequency = { value: 0 }; this.type = 'sine'; }
    connect() {} start() {} stop() {}
  }
  class FakeAudioContext {
    constructor() { this.currentTime = 0; this.state = 'running'; this.destination = {}; }
    createOscillator() { return new FakeOsc(); }
    createGain() { return new FakeGain(); }
    resume() { return Promise.resolve(); }
    close() { return Promise.resolve(); }
  }
  window.AudioContext = FakeAudioContext;
  window.webkitAudioContext = FakeAudioContext;
  const { fetch, bodies, store } = mockFetchFactory(seedRows);
  window.fetch = fetch;
  window.eval(read('public/catfx.js'));
  window.eval(read('public/mimi.js'));
  await sleep(200);
  return { dom, window, bodies, store };
}

function moodText(window) {
  return window.document.getElementById('todayMoodText').textContent;
}
function selectedMoods(window) {
  return [...window.document.querySelectorAll('#moodPicker .mood-btn.selected')].map((b) => b.dataset.mood);
}

test('刷新场景：打开页面时今天已有心情记录，心情区应显示已保存的心情并高亮对应按钮', async (t) => {
  const { dom, window } = await makeDom([{ id: 1, date: TODAY, mood: '难过', note: '', created_at: TODAY + 'T10:00:00Z' }]);
  t.after(() => dom.window.close());
  await sleep(150);
  assert.match(moodText(window), /今日心情：难过 · 已保存/, `刷新后心情区应显示“今日心情：难过 · 已保存”，实际：${moodText(window)}`);
  assert.deepEqual(selectedMoods(window), ['难过'], `应只有“难过”按钮高亮，实际：${JSON.stringify(selectedMoods(window))}`);
});

test('无记录场景：今天没有心情、只有昨天的记录，心情区仍显示原提示、无按钮高亮', async (t) => {
  const { dom, window } = await makeDom([{ id: 1, date: YESTERDAY, mood: '开心', note: '', created_at: YESTERDAY + 'T10:00:00Z' }]);
  t.after(() => dom.window.close());
  await sleep(150);
  assert.strictEqual(moodText(window), '今天还没有选心情，点一个告诉小猪吧', `今天无记录时心情区应显示原提示，实际：${moodText(window)}`);
  assert.deepEqual(selectedMoods(window), [], `今天无记录时不应有按钮高亮，实际：${JSON.stringify(selectedMoods(window))}`);
});

test('情绪入口：点“今天有点难过”保存后，再回首页，心情区仍显示难过并高亮', async (t) => {
  const { dom, window } = await makeDom([]);
  t.after(() => dom.window.close());
  assert.strictEqual(moodText(window), '今天还没有选心情，点一个告诉小猪吧', '开始时应显示原提示');
  window.document.querySelector('[data-emotion="sad"]').click();
  await sleep(150);
  assert.match(moodText(window), /难过/, `点情绪入口后心情区应显示难过，实际：${moodText(window)}`);
  assert.deepEqual(selectedMoods(window), ['难过'], `点情绪入口后应高亮“难过”，实际：${JSON.stringify(selectedMoods(window))}`);
  // 模拟从聊天页切回首页：refreshHome → loadMood 重新拉取（这就是旧 bug 的触发路径）
  window.MimiCat.showPage('home');
  await sleep(200);
  assert.match(moodText(window), /今日心情：难过 · 已保存/, `回首页后心情区仍应显示已保存的难过，实际：${moodText(window)}`);
  assert.deepEqual(selectedMoods(window), ['难过'], `回首页后仍应只有“难过”高亮，实际：${JSON.stringify(selectedMoods(window))}`);
});

test('手动路径：心情选择器点“开心”、心情日记保存“委屈”，回首页后心情区都正确更新', async (t) => {
  const { dom, window } = await makeDom([]);
  t.after(() => dom.window.close());
  window.document.querySelector('#moodPicker [data-mood="开心"]').click();
  await sleep(150);
  assert.match(moodText(window), /今日心情：开心 · 已保存/, `点心情选择器后应显示开心，实际：${moodText(window)}`);
  assert.deepEqual(selectedMoods(window), ['开心']);
  window.MimiCat.showPage('home');
  await sleep(200);
  assert.match(moodText(window), /开心/, `回首页后仍应显示开心，实际：${moodText(window)}`);
  // 心情日记表单保存“委屈”（以最后一次为准）
  window.document.getElementById('moodDiaryMood').value = '委屈';
  window.document.getElementById('moodDiarySubmitBtn').click();
  await sleep(150);
  assert.match(moodText(window), /今日心情：委屈 · 已保存/, `日记保存后心情区应显示委屈，实际：${moodText(window)}`);
  assert.deepEqual(selectedMoods(window), ['委屈'], `日记保存后应高亮“委屈”，实际：${JSON.stringify(selectedMoods(window))}`);
  window.MimiCat.showPage('home');
  await sleep(200);
  assert.match(moodText(window), /委屈/, `日记保存后回首页仍应显示委屈，实际：${moodText(window)}`);
  assert.deepEqual(selectedMoods(window), ['委屈']);
});

test('情绪入口无对应按钮的心情：点“想找人聊天”后文字应显示心情，无按钮高亮也不报错', async (t) => {
  const { dom, window } = await makeDom([]);
  t.after(() => dom.window.close());
  window.document.querySelector('[data-emotion="talk"]').click();
  await sleep(150);
  assert.match(moodText(window), /想找人聊天/, `点“想找人聊天”后心情区文字应显示该心情，实际：${moodText(window)}`);
  assert.deepEqual(selectedMoods(window), [], '“想找人聊天”没有心情选择器按钮，不应有高亮');
  window.MimiCat.showPage('home');
  await sleep(200);
  assert.match(moodText(window), /想找人聊天/, `回首页后仍应显示“想找人聊天”，实际：${moodText(window)}`);
});

test('静态：loadMood 不得再把 GET /api/mood 的原始返回直接传给 renderTodayMood', () => {
  const mimi = read('public/mimi.js');
  assert.doesNotMatch(mimi, /renderTodayMood\(d && d\.today !== undefined \? d\.today : d\)/,
    'loadMood 不得再用旧写法把原始返回直接传给 renderTodayMood');
  assert.match(mimi, /function pickTodayMood/, '应有 pickTodayMood 专门从记录数组里挑今天的行');
  assert.match(mimi, /renderTodayMood\(pickTodayMood\(d\)\)/, 'loadMood 应调用 pickTodayMood(d) 再渲染');
  assert.match(mimi, /r\.date.*=== today|=== todayStrLocal\(\)/, '挑行应按 date 等于今天本地日期');
});

/* ---------- B. 后端（真实 server 子进程 + 本地 SQLite，仅用 2033 年假日期） ---------- */

const D1 = '2033-03-22';
const D2 = '2033-03-23';
let server = null;
let db = null;

function openDb() {
  return new DatabaseSync(path.join(APP_ROOT, 'data', 'app.db'));
}

before(async () => {
  server = await startAppServer({ port: await freePort(), apiKey: null });
  db = openDb();
  db.prepare("DELETE FROM mood_entries WHERE date LIKE '2033-%'").run();
});

after(async () => {
  if (server) await stopServer(server.child);
  try {
    if (!db) db = openDb();
    db.prepare("DELETE FROM mood_entries WHERE date LIKE '2033-%'").run();
  } catch (e) {
    console.error('[18-cleanup] 清理失败：', e.message);
  } finally {
    try { db?.close(); } catch { /* ignore */ }
  }
});

test('后端：GET /api/mood 返回记录数组，含日期与心情——前端必须按 date 挑今天的行', async () => {
  const a = await api(server.base, 'POST', '/api/mood', { date: D1, mood: '难过', note: '' });
  assert.strictEqual(a.status, 200, `保存应 200，实际 ${a.status}：${a.text}`);
  const b = await api(server.base, 'POST', '/api/mood', { date: D2, mood: '开心', note: '' });
  assert.strictEqual(b.status, 200, `保存应 200，实际 ${b.status}：${b.text}`);
  const g = await api(server.base, 'GET', '/api/mood');
  assert.strictEqual(g.status, 200);
  assert.ok(Array.isArray(g.json), `GET /api/mood 应返回数组，实际 ${JSON.stringify(g.json)}`);
  const r1 = g.json.find((r) => r.date === D1);
  const r2 = g.json.find((r) => r.date === D2);
  assert.ok(r1, `数组里应有 ${D1} 的记录，实际 ${JSON.stringify(g.json)}`);
  assert.ok(r2, `数组里应有 ${D2} 的记录，实际 ${JSON.stringify(g.json)}`);
  assert.strictEqual(r1.mood, '难过', `日期 ${D1} 的心情应为难过，实际 ${JSON.stringify(r1)}`);
  assert.strictEqual(r2.mood, '开心', `日期 ${D2} 的心情应为开心，实际 ${JSON.stringify(r2)}`);
  // 旧前端写法：把整个数组传给 renderTodayMood 时，数组上取不到 mood ——
  // 这里只确认契约：数组本身没有 .mood/.today 字段。
  assert.strictEqual(g.json.mood, undefined, '数组本身不应有 .mood 字段（旧写法就是在这里取空）');
  assert.strictEqual(g.json.today, undefined, '数组本身不应有 .today 字段（旧写法就是在这里取空）');
});
