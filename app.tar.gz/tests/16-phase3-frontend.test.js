// 16-phase3-frontend.test.js — V4.0 第三阶段前端（不跑服务、不碰后端与数据库）。
// jsdom + mock fetch（按契约形状喂数据）：
// - 回忆页：手动回忆增删改、照片墙空态、聊天收藏、纪念日倒计时、心情日记、每日报告
// - 情绪陪伴中心：8 个情绪各有不同药丸，点后 body 带 emotion，发完清除
// - 睡前模式：覆盖层开/关、故事 source 标注、摇篮曲开关
// - 花园进度 50 显示“生长 50%”
// 说明：jsdom 环境没有 AudioContext，测试里先挂最小桩，只验证调用路径与开关状态，不验证真出声。
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { JSDOM } from 'jsdom';
import { APP_ROOT } from './helpers.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function resp(status, body, isJson = true) {
  return {
    ok: status >= 200 && status < 300, status,
    headers: { get: (n) => (n.toLowerCase() === 'content-type' ? (isJson ? 'application/json' : 'text/html') : null) },
    json: async () => body,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    body: null,
    clone: function () { return this; },
  };
}

/* 固定“今天”：2026-11-11。纪念日 days_left 按与这天之差算。 */
function daysBetween(a, b) {
  const p = (s) => { const [y, m, d] = s.split('-').map(Number); return Date.UTC(y, m - 1, d); };
  return Math.round((p(a) - p(b)) / 86400000);
}

const CAT_STATE = { id: 1, state: 'happy', mood: 'happy', intimacy: 0, hearts: 0, level: 1, stage: '初次见面', lastInteractAt: null, lastActions: {}, updatedAt: '2026-11-11T10:00:00Z' };
const DEFAULT_ROOM = { wallpaper: 'pink', bed: 'pink', plushies: ['bear'], lamp: true, flowers: true, painting: 'none', theme: 'home' };

function mockFetchFactory(overrides = {}) {
  const calls = [];
  const bodies = [];
  const store = {
    manualMems: [],
    annivs: [],
    favorites: [
      { id: 'm1', session_id: 's1', role: 'assistant', content: '嗯呐 你好呀', created_at: '2026-11-11T09:00:00Z' },
    ],
    storySource: overrides.storySource || 'deepseek',
    reportVariant: overrides.reportVariant || 'empty',
    favPosts: [],
    chatPosts: [],
  };
  let memSeq = 1;
  let annivSeq = 1;
  const fetch = async (url, opts = {}) => {
    const method = (opts.method || 'GET').toUpperCase();
    const [p, q] = String(url).split('?');
    calls.push(method + ' ' + String(url));
    let body = {};
    try { body = opts.body ? JSON.parse(opts.body) : {}; } catch { body = {}; }
    bodies.push({ method, url: String(url), body });
    const route = method + ' ' + p;
    if (overrides[route]) return overrides[route](body, q, store);
    if (p === '/api/cat' && method === 'GET') return resp(200, { cat: { ...CAT_STATE } });
    if (p === '/api/cat/interact' && method === 'POST') return resp(200, { cat: { ...CAT_STATE, hearts: 2 }, gained: { hearts: 2, intimacy: 1 } });
    if (p === '/api/cat/outfit' && method === 'GET') return resp(200, { outfit: { bow: false, hat: false, scarf: false, dress: false, glasses: false, bg: 'bedroom', pose: 'sit' } });
    if (p === '/api/cat/outfit' && method === 'PUT') return resp(200, { ok: true });
    if (p === '/api/mood' && method === 'GET') {
      const date = new URLSearchParams(q || '').get('date');
      const recent = [
        { mood: '开心', note: '今天天气很好', date: '2026-11-11', created_at: '2026-11-11T08:00:00Z' },
        { mood: '难过', note: '', date: '2026-11-10', created_at: '2026-11-10T20:00:00Z' },
      ];
      if (date) return resp(200, { today: null, recent: recent.filter((r) => r.date === date) });
      return resp(200, { today: '开心', recent });
    }
    if (p === '/api/mood' && method === 'POST') return resp(200, { ok: true, mood: body.mood, note: body.note });
    if (p === '/api/daily' && method === 'GET') return resp(200, { tasks: [], surprise: { claimed: false }, fortune: { drawn: false } });
    if (p === '/api/memories' && method === 'GET') return resp(200, []);
    if (p === '/api/sessions' && method === 'GET') return resp(200, []);
    if (p === '/api/room' && method === 'GET') return resp(200, { room: { ...DEFAULT_ROOM } });
    if (p === '/api/room' && method === 'PUT') return resp(200, { room: { ...DEFAULT_ROOM, ...body } });
    if (p === '/api/garden' && method === 'GET') return resp(200, {
      plots: [
        { id: 0, flower: 'rose', stage: 'bloom', progress: 100, watered: true },
        { id: 1, flower: null, stage: null, progress: 0 },
        { id: 2, flower: 'daisy', stage: 'sprout', progress: 50, watered: false },
      ],
      pots: [{ id: 'clay', name: '陶土花盆', emoji: '🪴', unlocked: true, harvests_required: 0 }],
    });
    if (p === '/api/garden/plant' && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/garden/water' && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/garden/harvest' && method === 'POST') return resp(200, { ok: true, reward: { hearts: 2 } });
    if (p === '/api/events/next' && method === 'GET') return resp(200, { event: { id: 'ev-1', title: '午后的一阵风', text: '风把一片花瓣吹到了你的窗台上', anim: 'pink-rain' } });
    if (/^\/api\/events\/[^/]+\/favorite$/.test(p) && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/letters/draw' && method === 'POST') return resp(200, { letter: { id: 'l-1', content: '冷死了，记得穿厚一点', source: '来自真实聊天记录', category: '关心对方', date: '2026-11-11T10:00:00Z' } });
    if (p === '/api/letters' && method === 'GET') return resp(200, { letters: [] });
    if (p === '/api/games/scores' && method === 'GET') return resp(200, { scores: [] });
    if (p === '/api/games/wheel' && method === 'POST') return resp(200, { prize: { id: 'heart10', label: '爱心+10', hearts: 10 }, cat: { ...CAT_STATE } });
    if (p === '/api/games/score' && method === 'POST') return resp(201, { id: 1, game: body.game, score: body.score });
    /* --- 第三阶段契约 --- */
    if (p === '/api/manual-memories' && method === 'GET') return resp(200, { memories: store.manualMems.slice().sort((a, b) => (b.date < a.date ? -1 : 1)) });
    if (p === '/api/manual-memories' && method === 'POST') {
      const m = { id: 'mm' + (memSeq++), title: body.title, date: body.date, text: body.text, created_at: '2026-11-11T10:00:00Z' };
      store.manualMems.push(m);
      return resp(201, { memory: m });
    }
    if (/^\/api\/manual-memories\/[^/]+$/.test(p) && method === 'PUT') {
      const id = p.split('/').pop();
      const m = store.manualMems.find((x) => x.id === id);
      if (m) Object.assign(m, { title: body.title, date: body.date, text: body.text });
      return resp(200, { ok: true, memory: m || null });
    }
    if (/^\/api\/manual-memories\/[^/]+$/.test(p) && method === 'DELETE') {
      const id = p.split('/').pop();
      store.manualMems = store.manualMems.filter((x) => x.id !== id);
      return resp(200, { ok: true });
    }
    if (p === '/api/favorites' && method === 'GET') return resp(200, { favorites: store.favorites.slice() });
    if (/^\/api\/sessions\/[^/]+\/messages\/[^/]+\/favorite$/.test(p) && method === 'POST') {
      const mid = p.split('/')[5];
      store.favPosts.push({ mid, favorite: body.favorite });
      if (body.favorite === false) store.favorites = store.favorites.filter((f) => String(f.id) !== String(mid));
      return resp(200, { ok: true, favorite: body.favorite });
    }
    if (p === '/api/anniversaries' && method === 'GET') {
      return resp(200, { anniversaries: store.annivs.map((a) => ({ ...a, days_left: daysBetween(a.date, '2026-11-11') })) });
    }
    if (p === '/api/anniversaries' && method === 'POST') {
      const a = { id: 'an' + (annivSeq++), name: body.name, date: body.date, created_at: '2026-11-11T10:00:00Z' };
      store.annivs.push(a);
      return resp(201, { anniversary: a });
    }
    if (/^\/api\/anniversaries\/[^/]+$/.test(p) && method === 'PUT') {
      const id = p.split('/').pop();
      const a = store.annivs.find((x) => x.id === id);
      if (a) Object.assign(a, { name: body.name, date: body.date });
      return resp(200, { ok: true, anniversary: a || null });
    }
    if (/^\/api\/anniversaries\/[^/]+$/.test(p) && method === 'DELETE') {
      const id = p.split('/').pop();
      store.annivs = store.annivs.filter((x) => x.id !== id);
      return resp(200, { ok: true });
    }
    if (p === '/api/bedtime/story' && method === 'POST') {
      if (store.storySource === 'local') return resp(200, { story: '从前有一只小猫，它每天晚上都会数星星睡觉。', source: 'local' });
      return resp(200, { story: '今天月亮很圆，小猪现讲给你听：从前……', source: 'deepseek' });
    }
    if (p === '/api/bedtime/letter' && method === 'GET') return resp(200, { letter: '晚安呀，今天也辛苦啦，好好睡一觉。', source: 'generic' });
    if (p === '/api/report' && method === 'GET') {
      const date = new URLSearchParams(q || '').get('date') || '2026-11-11';
      if (store.reportVariant === 'full') {
        return resp(200, {
          date, chat: { user: 3, assistant: 4 }, mood: { mood: '开心', note: '天气很好' },
          tasks: { total: 5, done: 3, claimed: 2 }, surprise: { claimed: true },
          games: [{ game: 'wheel', score: 10, played_at: date + 'T10:00:00Z' }],
          cat: { hearts: 12, intimacy: 8, heartsToday: 2, intimacyToday: 1 },
          garden: { harvested: ['玫瑰'], growing: [{ flower: 'daisy', stage: 'sprout', progress: 50 }] },
          letters: { drawn: 1, saved: 1 },
        });
      }
      return resp(200, {
        date, chat: { user: 0, assistant: 0 }, mood: null,
        tasks: { total: 0, done: 0, claimed: 0 }, surprise: { claimed: false },
        games: [], cat: null, garden: { harvested: [], growing: [] }, letters: { drawn: 0, saved: 0 },
      });
    }
    if (/^\/api\/sessions\/[^/]+\/chat$/.test(p) && method === 'POST') {
      store.chatPosts.push(body);
      return resp(200, { ok: true });
    }
    return resp(404, { error: 'not_found' });
  };
  return { fetch, calls, bodies, store };
}

async function makeDom(overrides = {}) {
  const html = read('public/index.html');
  const dom = new JSDOM(html, { url: 'http://127.0.0.1:3199/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  class FakeGain {
    constructor() { this.gain = { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} }; }
    connect() {}
  }
  class FakeOsc {
    constructor() { this.frequency = { value: 0 }; this.type = 'sine'; }
    connect() {} start() {} stop() {}
  }
  class FakeAudioContext {
    constructor() { this.currentTime = 0; this.state = 'running'; this.destination = {}; }
    createOscillator() { return new FakeOsc(); }
    createGain() { return new FakeGain(); }
    resume() { return Promise.resolve(); }
    close() { return Promise.resolve(); }
  }
  window.AudioContext = FakeAudioContext;
  window.webkitAudioContext = FakeAudioContext;
  const { fetch, calls, bodies, store } = mockFetchFactory(overrides);
  window.fetch = fetch;
  window.eval(read('public/catfx.js'));
  window.eval(read('public/mimi.js'));
  await sleep(150);
  return { dom, window, calls, bodies, store };
}
function toastText(window) {
  const t = window.document.getElementById('toast');
  return t ? t.textContent : '';
}
function setInput(window, id, value) {
  const el = window.document.getElementById(id);
  el.value = value;
  return el;
}

/* ================= 静态 ================= */

test('P3 结构：回忆页含手动回忆/照片墙/收藏/纪念日/心情日记/报告卡片，首页含情绪陪伴卡与睡前入口，聊天页含情绪横幅与药丸区，睡前覆盖层齐全', () => {
  const html = read('public/index.html');
  for (const id of ['emotionCard', 'emotionPicker', 'bedtimeOpenBtn', 'emotionBanner', 'emotionBannerText',
    'emotionClearBtn', 'emotionPills', 'manualMemCard', 'manualMemTitle', 'manualMemDate', 'manualMemText',
    'manualMemSubmitBtn', 'manualMemList', 'photoWallCard', 'favoritesCard', 'favoritesList',
    'annivCard', 'annivName', 'annivDate', 'annivSubmitBtn', 'annivList',
    'moodDiaryCard', 'moodDiaryMood', 'moodDiaryNote', 'moodDiarySubmitBtn', 'moodLookupDate', 'moodLookupBtn',
    'moodLookupResult', 'reportCard', 'reportDate', 'reportPrevBtn', 'reportNextBtn', 'reportQueryBtn',
    'reportBody', 'bedtimeOverlay', 'bedtimeCatFigure', 'bedtimeStoryBtn', 'bedtimeLetterBtn',
    'bedtimeLullabyBtn', 'bedtimeCloseBtn', 'bedtimeStoryText', 'bedtimeLetterText']) {
    assert.match(html, new RegExp(`id="${id}"`), `缺少第三阶段元素 #${id}`);
  }
  for (const e of ['happy', 'sad', 'wronged', 'irritated', 'praise', 'clingy', 'talk', 'quiet']) {
    assert.match(html, new RegExp(`data-emotion="${e}"`), `情绪陪伴卡缺少 data-emotion="${e}"`);
  }
  // 旧提示已删：回忆页不再说纪念日是“第三阶段先不放”，我的页不再说睡前报告先不放
  assert.doesNotMatch(html, /纪念日倒计时是第三阶段功能，这里先不放入口/, '回忆页仍留着“第三阶段先不放”的提示，应已删掉');
  assert.doesNotMatch(html, /睡前报告是第三阶段功能/, '我的页仍说睡前报告是第三阶段功能，应已改掉');
  // 照片墙诚实空态：没有假图、占位图、猫图，也不新加上传功能
  assert.match(html, /还没有照片。照片墙只展示你上传过的照片，现在还没有上传过/, '照片墙须老实写空态');
  assert.doesNotMatch(html, /photoWallCard[\s\S]{0,400}type="file"/, '照片墙不得新加上传功能');
  const mimi = read('public/mimi.js');
  for (const path of ['/api/manual-memories', '/api/favorites', '/api/anniversaries', '/api/bedtime/story',
    '/api/bedtime/letter', '/api/report?date=', '/messages/', '/favorite']) {
    assert.ok(mimi.includes(path), 'mimi.js 须按契约调用 ' + path);
  }
  // 睡前覆盖层不是新页面：没有新增底部导航按钮（仍为 5 个）
  const navBtns = html.match(/class="nav-btn[^"]*" data-page="(home|chat|memories|park|mine)"/g) || [];
  assert.strictEqual(navBtns.length, 5, '不得新增底部导航，仍应为 5 个，实际 ' + navBtns.length);
  assert.doesNotMatch(html, /语音/, '页面不得出现任何“语音”按钮或文案');
});

test('P3 语法：mimi.js 与 style.css 均能 node --check / 正常读取', () => {
  execFileSync('node', ['--check', path.join(APP_ROOT, 'public/mimi.js')], { stdio: 'pipe' });
  const css = read('public/style.css');
  assert.match(css, /\.bedtime-overlay\b/, 'style.css 缺少 .bedtime-overlay');
  assert.match(css, /\.emotion-banner\b/, 'style.css 缺少 .emotion-banner');
  assert.match(css, /\.emotion-pill\b/, 'style.css 缺少 .emotion-pill');
  assert.match(css, /\.fav-btn\b/, 'style.css 缺少 .fav-btn');
  assert.match(css, /\.report-row\b/, 'style.css 缺少 .report-row');
  assert.match(css, /@keyframes bedtimeBreathe/, 'style.css 须定义呼吸光晕动画 bedtimeBreathe');
  assert.match(css, /@keyframes bedtimeTwinkle/, 'style.css 须定义星星闪烁动画 bedtimeTwinkle');
  assert.match(css, /linear-gradient\(180deg, #14102b/, '睡前覆盖层须为深色星空渐变');
});

test('P3 无横向溢出（静态审计）：无 100vw，容器 max-width 720px 不变', () => {
  for (const f of ['public/index.html', 'public/mimi.js', 'public/style.css']) {
    assert.doesNotMatch(read(f), /100vw/, `${f} 不得用 100vw`);
  }
  assert.match(read('public/style.css'), /#app\s*\{[^}]*max-width:\s*720px/, '#app 容器 max-width 须保持 720px');
});

/* ================= jsdom ================= */

test('P3 手动回忆：空态→提交调 POST→列表渲染→编辑回填调 PUT→删除调 DELETE 回空态', async (t) => {
  const { dom, window, calls } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('memories');
  await sleep(250);
  const list = window.document.getElementById('manualMemList');
  assert.ok(list.textContent.includes('还没有手动回忆，写下第一条吧'), '空态应写“还没有手动回忆，写下第一条吧”：' + list.textContent.slice(0, 60));
  setInput(window, 'manualMemTitle', '第一次一起看日落');
  setInput(window, 'manualMemDate', '2026-11-01');
  setInput(window, 'manualMemText', '那天晚霞特别好看');
  window.document.getElementById('manualMemSubmitBtn').click();
  await sleep(250);
  assert.ok(calls.some((c) => c === 'POST /api/manual-memories'), '提交应调 POST /api/manual-memories');
  assert.ok(list.textContent.includes('第一次一起看日落'), '列表应渲染新回忆标题');
  assert.ok(list.textContent.includes('那天晚霞特别好看'), '列表应渲染新回忆正文');
  assert.ok(list.textContent.includes('2026-11-01'), '列表应渲染日期');
  // 编辑：点开回填表单，改标题后提交调 PUT
  const editBtn = Array.from(list.querySelectorAll('button')).find((b) => b.textContent === '编辑');
  assert.ok(editBtn, '每条回忆应有“编辑”按钮');
  editBtn.click();
  assert.strictEqual(window.document.getElementById('manualMemTitle').value, '第一次一起看日落', '编辑应把标题回填进表单');
  assert.strictEqual(window.document.getElementById('manualMemDate').value, '2026-11-01', '编辑应把日期回填进表单');
  setInput(window, 'manualMemTitle', '第一次一起看日落呀');
  window.document.getElementById('manualMemSubmitBtn').click();
  await sleep(250);
  assert.ok(calls.some((c) => /^PUT \/api\/manual-memories\//.test(c)), '编辑提交应调 PUT /api/manual-memories/:id');
  assert.ok(list.textContent.includes('第一次一起看日落呀'), '列表应显示改后的标题');
  // 删除
  const delBtn = Array.from(list.querySelectorAll('button')).find((b) => b.textContent === '删除');
  assert.ok(delBtn, '每条回忆应有“删除”按钮');
  delBtn.click();
  await sleep(250);
  assert.ok(calls.some((c) => /^DELETE \/api\/manual-memories\//.test(c)), '删除应调 DELETE /api/manual-memories/:id');
  assert.ok(list.textContent.includes('还没有手动回忆，写下第一条吧'), '删完应回到空态');
});

test('P3 纪念日：daysUntil 固定日期算对 44 天，提交后列表显示“还有 44 天”', async (t) => {
  const { dom, window, calls } = await makeDom();
  t.after(() => dom.window.close());
  const daysUntil = window.MimiCat.daysUntil;
  assert.strictEqual(daysUntil('2026-12-25', '2026-11-11'), 44, '2026-11-11 到 2026-12-25 应为 44 天');
  assert.strictEqual(daysUntil('2026-11-11', '2026-11-11'), 0, '同一天应为 0 天');
  assert.strictEqual(daysUntil('2026-11-10', '2026-11-11'), -1, '过去一天应为 -1 天');
  assert.strictEqual(window.MimiCat.annivText({ days_left: 0 }), '就是今天 🎉', 'days_left 0 应显示“就是今天 🎉”');
  assert.strictEqual(window.MimiCat.annivText({ days_left: -3 }), '已经过去 3 天', 'days_left -3 应显示“已经过去 3 天”');
  assert.strictEqual(window.MimiCat.annivText({ days_left: 44 }), '还有 44 天', 'days_left 44 应显示“还有 44 天”');
  window.MimiCat.showPage('memories');
  await sleep(250);
  const list = window.document.getElementById('annivList');
  assert.ok(list.textContent.includes('还没有纪念日'), '空态应写“还没有纪念日”');
  setInput(window, 'annivName', '圣诞节');
  setInput(window, 'annivDate', '2026-12-25');
  window.document.getElementById('annivSubmitBtn').click();
  await sleep(250);
  assert.ok(calls.some((c) => c === 'POST /api/anniversaries'), '提交应调 POST /api/anniversaries');
  assert.ok(list.textContent.includes('圣诞节'), '列表应显示纪念日名称');
  assert.ok(list.textContent.includes('还有 44 天'), '2026-12-25 在 2026-11-11 应显示“还有 44 天”：' + list.textContent.slice(0, 80));
  const delBtn = Array.from(list.querySelectorAll('button')).find((b) => b.textContent === '删除');
  delBtn.click();
  await sleep(250);
  assert.ok(calls.some((c) => /^DELETE \/api\/anniversaries\//.test(c)), '删除应调 DELETE /api/anniversaries/:id');
  assert.ok(list.textContent.includes('还没有纪念日'), '删完应回到空态');
});

test('P3 聊天收藏：列表读 /api/favorites 可取消；消息行旁有 ⭐ 按钮，点后调 favorite 并变实心', async (t) => {
  const { dom, window, calls, store } = await makeDom();
  t.after(() => dom.window.close());
  window.localStorage.setItem('v3_session_id', 's1');
  window.MimiCat.showPage('memories');
  await sleep(250);
  const favList = window.document.getElementById('favoritesList');
  assert.ok(favList.textContent.includes('嗯呐 你好呀'), '收藏列表应显示收藏内容');
  const cancelBtn = Array.from(favList.querySelectorAll('button')).find((b) => b.textContent === '取消收藏');
  assert.ok(cancelBtn, '收藏列表每条应有“取消收藏”按钮');
  cancelBtn.click();
  await sleep(250);
  assert.ok(store.favPosts.some((f) => f.mid === 'm1' && f.favorite === false), '取消收藏应调 favorite {favorite:false}');
  await sleep(100);
  assert.ok(favList.textContent.includes('还没有收藏的聊天'), '取消后应回到空态“还没有收藏的聊天”');
  // 聊天页消息行旁的 ⭐ 按钮（MutationObserver 挂）
  window.MimiCat.showPage('chat');
  await sleep(150);
  const box = window.document.getElementById('messages');
  const row = window.document.createElement('div');
  row.className = 'msg-row theirs';
  row.dataset.mid = 'm2';
  row.innerHTML = '<div class="msg-avatar">🐷</div><div class="msg-body"><div class="bubble"><p>你好呀</p></div><div class="msg-time">10:00</div></div>';
  box.appendChild(row);
  await sleep(150);
  const favBtn = row.querySelector('.fav-btn');
  assert.ok(favBtn, '消息行旁应有收藏按钮');
  assert.strictEqual(favBtn.textContent, '☆', '未收藏时应为空心 ☆');
  favBtn.click();
  await sleep(250);
  assert.ok(store.favPosts.some((f) => f.mid === 'm2' && f.favorite === true), '点 ☆ 应调 favorite {favorite:true}');
  assert.strictEqual(favBtn.textContent, '⭐', '收藏后按钮应变实心 ⭐');
  assert.ok(calls.some((c) => c === 'POST /api/sessions/s1/messages/m2/favorite'), '应按契约调 POST /api/sessions/:id/messages/:mid/favorite');
  favBtn.click();
  await sleep(250);
  assert.strictEqual(favBtn.textContent, '☆', '再点一次应取消收藏变回 ☆');
});

test('P3 情绪陪伴：8 个情绪各有 2–3 条互不相同的药丸；点药丸后 body 带 emotion，发完横幅与药丸消失', async (t) => {
  const { dom, window, store } = await makeDom();
  t.after(() => dom.window.close());
  // 模拟 app.js 的 autoGrow（输入有字就启用发送）与 sendMessage（发往后端）
  const input = window.document.getElementById('input');
  const sendBtn = window.document.getElementById('sendBtn');
  input.addEventListener('input', () => { sendBtn.disabled = !input.value.trim(); });
  sendBtn.addEventListener('click', async () => {
    await window.fetch('/api/sessions/s1/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: input.value, clientId: 'c1' }),
    });
  });
  const allPills = [];
  const keys = ['happy', 'sad', 'wronged', 'irritated', 'praise', 'clingy', 'talk', 'quiet'];
  const labels = { happy: '今天很开心', sad: '今天有点难过', wronged: '今天很委屈', irritated: '有点烦躁', praise: '想被夸奖', clingy: '想撒娇', talk: '想找人聊天', quiet: '想安静待一会儿' };
  const banner = window.document.getElementById('emotionBanner');
  const pills = window.document.getElementById('emotionPills');
  for (const key of keys) {
    window.document.querySelector(`[data-emotion="${key}"]`).click();
    await sleep(100);
    assert.strictEqual(banner.hidden, false, key + ' 情绪横幅应显示');
    assert.ok(window.document.getElementById('emotionBannerText').textContent.includes('已告诉小猪你' + labels[key]),
      key + ' 横幅文案应为“已告诉小猪你' + labels[key] + '”');
    assert.strictEqual(window.document.getElementById('page-chat').hidden, false, '点情绪后应切换到聊天页');
    const pillBtns = Array.from(pills.querySelectorAll('.emotion-pill'));
    assert.ok(pillBtns.length >= 2 && pillBtns.length <= 3, key + ' 应有 2–3 条药丸，实际 ' + pillBtns.length);
    const texts = pillBtns.map((b) => b.textContent);
    assert.strictEqual(new Set(texts).size, texts.length, key + ' 的药丸之间不得重复');
    allPills.push(...texts);
    // 清除后再测下一个情绪
    window.document.getElementById('emotionClearBtn').click();
    assert.strictEqual(banner.hidden, true, '点清除后横幅应消失');
    assert.strictEqual(pills.hidden, true, '点清除后药丸应消失');
  }
  assert.strictEqual(new Set(allPills).size, allPills.length, '8 个情绪的药丸全部互不相同，实际 ' + allPills.length + ' 条、去重后 ' + new Set(allPills).size + ' 条');
  // 难过情绪：点第一条药丸，输入框被填上，发送的 body 带 emotion:'sad'，发完状态清除
  window.document.querySelector('[data-emotion="sad"]').click();
  await sleep(100);
  const firstPill = pills.querySelector('.emotion-pill');
  const pillText = firstPill.textContent;
  firstPill.click();
  await sleep(250);
  assert.strictEqual(input.value, pillText, '点药丸应把药丸文本填进输入框，作为用户自己的话');
  assert.strictEqual(store.chatPosts.length, 1, '点药丸应触发一次发送');
  assert.strictEqual(store.chatPosts[0].content, pillText, '发送内容应为药丸文本');
  assert.strictEqual(store.chatPosts[0].emotion, 'sad', '发送的 body 须带 emotion:"sad"，实际 ' + JSON.stringify(store.chatPosts[0]));
  assert.strictEqual(window.MimiCat.pendingEmotion, null, '发完一次后情绪状态应已清除');
  assert.strictEqual(banner.hidden, true, '发完后横幅应消失');
  assert.strictEqual(pills.hidden, true, '发完后药丸应消失');
});

test('P3 心情日记：写心情调 POST /api/mood 且带 note；按日期查得到就显示，查不到写“这天没有心情记录”', async (t) => {
  const { dom, window, bodies } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('memories');
  await sleep(250);
  // 最近 7 天列表仍在
  assert.ok(window.document.getElementById('moodRecentList').textContent.includes('开心'), '最近 7 天心情列表应保留');
  setInput(window, 'moodDiaryMood', '委屈');
  setInput(window, 'moodDiaryNote', '被阿姨点错餐了');
  window.document.getElementById('moodDiarySubmitBtn').click();
  await sleep(250);
  const moodPost = bodies.find((b) => b.method === 'POST' && b.url === '/api/mood');
  assert.ok(moodPost, '写心情应调 POST /api/mood');
  assert.strictEqual(moodPost.body.mood, '委屈', '应按现有字段发 mood');
  assert.strictEqual(moodPost.body.note, '被阿姨点错餐了', '备注应随 note 一起发');
  // 查 2026-11-10（mock 里有“难过”）
  setInput(window, 'moodLookupDate', '2026-11-10');
  window.document.getElementById('moodLookupBtn').click();
  await sleep(250);
  const out = window.document.getElementById('moodLookupResult');
  assert.ok(out.textContent.includes('难过'), '查到 2026-11-10 应显示那天的心情“难过”：' + out.textContent);
  // 查 2026-11-05（没有记录）
  setInput(window, 'moodLookupDate', '2026-11-05');
  window.document.getElementById('moodLookupBtn').click();
  await sleep(250);
  assert.strictEqual(out.textContent, '这天没有心情记录', '没有记录的那天应写“这天没有心情记录”，实际：' + out.textContent);
});

test('P3 睡前模式：打开覆盖层并暂停首页猫动画；故事按 source 标注；信件显示；摇篮曲开关可切且保存；关闭恢复', async (t) => {
  const { dom, window, calls } = await makeDom();
  t.after(() => dom.window.close());
  window.document.getElementById('bedtimeOpenBtn').click();
  await sleep(100);
  const ov = window.document.getElementById('bedtimeOverlay');
  assert.strictEqual(ov.hidden, false, '点入口后睡前覆盖层应打开');
  assert.ok(window.document.getElementById('catFigure').classList.contains('paused'), '覆盖层打开时首页猫应挂 .paused（待机随机动画暂停）');
  window.document.getElementById('bedtimeStoryBtn').click();
  await sleep(250);
  assert.ok(calls.some((c) => c === 'POST /api/bedtime/story'), '睡前故事应调 POST /api/bedtime/story');
  const storyBox = window.document.getElementById('bedtimeStoryBox');
  assert.strictEqual(storyBox.hidden, false, '故事应显示在层内');
  assert.ok(window.document.getElementById('bedtimeStoryText').textContent.length > 0, '故事正文应显示');
  assert.strictEqual(window.document.getElementById('bedtimeStorySource').textContent, '小猪现讲的', 'deepseek 来源应标注“小猪现讲的”');
  window.document.getElementById('bedtimeLetterBtn').click();
  await sleep(250);
  assert.ok(calls.some((c) => c === 'GET /api/bedtime/letter'), '晚安信件应调 GET /api/bedtime/letter');
  assert.strictEqual(window.document.getElementById('bedtimeLetterBox').hidden, false, '信件应显示在层内');
  assert.ok(window.document.getElementById('bedtimeLetterText').textContent.includes('晚安'), '信件正文应显示');
  // 摇篮曲：只在点击后建 AudioContext；开关切两次，状态保存进 localStorage
  const lullBtn = window.document.getElementById('bedtimeLullabyBtn');
  assert.ok(lullBtn.textContent.includes('摇篮曲 关'), '初始摇篮曲应为关：' + lullBtn.textContent);
  lullBtn.click();
  await sleep(100);
  assert.ok(lullBtn.textContent.includes('摇篮曲 开'), '点一次应变为开');
  assert.strictEqual(window.localStorage.getItem('v3_lullaby_on'), '1', '开的状态应保存进 localStorage');
  lullBtn.click();
  await sleep(100);
  assert.ok(lullBtn.textContent.includes('摇篮曲 关'), '再点一次应变回关');
  assert.strictEqual(window.localStorage.getItem('v3_lullaby_on'), '0', '关的状态应保存进 localStorage');
  window.document.getElementById('bedtimeCloseBtn').click();
  await sleep(100);
  assert.strictEqual(ov.hidden, true, '点“结束睡前模式”后覆盖层应关闭');
  assert.ok(!window.document.getElementById('catFigure').classList.contains('paused'), '关闭后首页猫应恢复待机动画（去掉 .paused）');
});

test('P3 睡前故事 local 来源标注为本地故事', async (t) => {
  const { dom, window } = await makeDom({ storySource: 'local' });
  t.after(() => dom.window.close());
  window.document.getElementById('bedtimeOpenBtn').click();
  await sleep(100);
  window.document.getElementById('bedtimeStoryBtn').click();
  await sleep(250);
  assert.strictEqual(window.document.getElementById('bedtimeStorySource').textContent,
    '小故事（AI 讲不了时用的本地故事）', 'local 来源应标注本地故事');
});

test('P3 每日报告：空数据时各项都写“今天还没有…”；未来日期提示“还没到那天”且不查后端；有数据时数字与花园进度正常显示', async (t) => {
  const { dom, window, calls } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('memories');
  await sleep(300);
  const body = window.document.getElementById('reportBody');
  const text = body.textContent;
  assert.ok(text.includes('今天还没有聊天'), '空报告应写“今天还没有聊天”：' + text.slice(0, 120));
  assert.ok(text.includes('今天还没有心情记录'), '空报告应写“今天还没有心情记录”');
  assert.ok(text.includes('今天还没有任务'), '空报告应写“今天还没有任务”');
  assert.ok(text.includes('今天还没有开盲盒'), '空报告应写“今天还没有开盲盒”');
  assert.ok(text.includes('今天还没有游戏成绩'), '空报告应写“今天还没有游戏成绩”');
  assert.ok(text.includes('今天还没有抽信件'), '空报告应写“今天还没有抽信件”');
  assert.ok(text.includes('今天还没有收获'), '空报告应写“今天还没有收获”');
  assert.doesNotMatch(text, /\[object Object\]/, '报告不得含 [object Object]');
  // 未来日期
  const callsBefore = calls.length;
  setInput(window, 'reportDate', '2026-12-25');
  window.document.getElementById('reportQueryBtn').click();
  await sleep(200);
  assert.ok(body.textContent.includes('还没到那天'), '未来日期应提示“还没到那天”');
  assert.strictEqual(calls.length, callsBefore, '未来日期不得再查后端');
  // 前一天/后一天按钮会改日期并发一次查询
  const prevBtn = window.document.getElementById('reportPrevBtn');
  prevBtn.click();
  await sleep(250);
  assert.strictEqual(window.document.getElementById('reportDate').value, '2026-12-24', '前一天按钮应把日期减一天');
  const nextBtn = window.document.getElementById('reportNextBtn');
  nextBtn.click();
  await sleep(250);
  assert.strictEqual(window.document.getElementById('reportDate').value, '2026-12-25', '后一天按钮应把日期加一天');
});

test('P3 每日报告有数据：聊天条数、任务、猫咪、信件数字与花园生长 50% 正常显示', async (t) => {
  const { dom, window } = await makeDom({ reportVariant: 'full' });
  t.after(() => dom.window.close());
  window.MimiCat.showPage('memories');
  await sleep(300);
  const text = window.document.getElementById('reportBody').textContent;
  assert.ok(text.includes('用户 3 条 / 小猪 4 条'), '应显示聊天条数：' + text.slice(0, 200));
  assert.ok(text.includes('已完成 3 / 5'), '应显示任务完成 3/5');
  assert.ok(text.includes('爱心 12'), '应显示猫咪爱心 12');
  assert.ok(text.includes('抽取 1 封'), '应显示信件抽取 1 封');
  assert.ok(text.includes('生长 50%'), '花园生长中雏菊应显示“生长 50%”');
  assert.ok(text.includes('已开'), '盲盒已开应显示“已开”');
  assert.doesNotMatch(text, /\[object Object\]/, '报告不得含 [object Object]');
});

test('P3 花园进度：progress 50 显示“生长 50%”，不是 0.5%', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(250);
  const slots = window.document.querySelectorAll('#gardenSlots .garden-slot');
  assert.ok(slots.length >= 3, '应有 3 个花园槽位');
  const sprout = Array.from(slots).find((s) => s.textContent.includes('发芽'));
  assert.ok(sprout, '应有雏菊槽位');
  assert.ok(sprout.textContent.includes('生长 50%'), 'progress 50 应显示“生长 50%”：' + sprout.textContent.slice(0, 60));
  assert.ok(!sprout.textContent.includes('0.5%'), '不得把 50 当成 0.5 显示成 0.5%');
  // 源码里不得再有 ×100 或 /100 的进度换算残留
  const mimi = read('public/mimi.js');
  assert.doesNotMatch(mimi, /progress\s*\*\s*100/, '花园渲染不得再有 progress × 100');
  assert.doesNotMatch(mimi, /progress\s*\/\s*100/, '花园渲染不得再有 progress / 100');
});

test('P3 整页无 [object Object]：回忆页全部真实数据渲染后不含对象占位', async (t) => {
  const { dom, window } = await makeDom({ reportVariant: 'full' });
  t.after(() => dom.window.close());
  window.MimiCat.showPage('memories');
  await sleep(300);
  window.MimiCat.showPage('home');
  await sleep(200);
  const text = window.document.body.textContent;
  assert.doesNotMatch(text, /\[object Object\]/, '整页不得出现 [object Object]');
});
