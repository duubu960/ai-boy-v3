// 05-http.test.js — HTTP 层端到端（真实 server.js 子进程 + SQLite）
// 对应 20 项中的：1 首次打开、2 无 Key 诚实报错、3 多条消息不丢不串（数据层）、
// 4 人格遵循（API）、6 样本库（API）、11 手动改记忆、12 删除记忆、
// 14 重启后记录保留、15 重新打开恢复、16 API 断开报错（HTTP）、17 手机端显示、
// 18 会话不污染、19 人格配置稳定。
// 注意：
// - DeepSeek 上游一律用本地 stub 只返回 401（不伪造成功回复）；Key 只用测试假值 'test-dummy-key'。
// - 真实 Key 下的成功对话、多轮真实回复不属于自动测试，见 tests/06-manual-cases.md。
// - 本文件与 03-memory.test.js 共用 data/app.db，需串行跑（package.json：--test-concurrency=1）。
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  APP_ROOT, freePort, startAppServer, stopServer,
  startErrorStub, stopStub, postChatSSE, api,
} from './helpers.js';

let stub401 = null;
let noKey = null;   // 无 Key 服务（测 NO_API_KEY）
let keyed = null;   // 有测试假 Key + 401 stub 的服务
let originalBaseUrl = 'https://api.deepseek.com';
const createdSessions = [];
const createdMemories = [];

before(async () => {
  stub401 = await startErrorStub((req, res) => {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: { message: 'Incorrect API key provided' } }));
  });
  noKey = await startAppServer({ port: await freePort(), apiKey: null });
});

after(async () => {
  try {
    if (keyed) {
      await api(keyed.base, 'PUT', '/api/config', { baseUrl: originalBaseUrl });
      for (const id of createdMemories) await api(keyed.base, 'DELETE', `/api/memories/${id}`);
      for (const id of createdSessions) await api(keyed.base, 'DELETE', `/api/sessions/${id}`);
    }
  } catch { /* 清理失败不影响报告主体 */ }
  if (noKey) await stopServer(noKey.child);
  if (keyed) await stopServer(keyed.child);
  if (stub401) await stopStub(stub401.server);
});

async function newSession(base, title) {
  const r = await api(base, 'POST', '/api/sessions', { title: title || '测试会话' });
  assert.equal(r.status, 201, `建会话应 201，实际 ${r.status}：${r.text}`);
  createdSessions.push(r.json.id);
  return r.json.id;
}

// ---------- 无 Key 服务 ----------

test('item-1：首次打开网页 GET / 返回 200，含聊天骨架', async () => {
  const res = await fetch(`${noKey.base}/`, { signal: AbortSignal.timeout(10000) });
  assert.equal(res.status, 200);
  assert.match(res.headers.get('content-type') || '', /text\/html/);
  const html = await res.text();
  for (const frag of ['id="messages"', 'id="input"', 'id="sendBtn"', 'id="settingsBtn"', 'viewport']) {
    assert.ok(html.includes(frag), `首页缺少聊天骨架片段：${frag}`);
  }
});

test('item-17：手机端显示——viewport、设置六项、安全区、触摸滚动、流式布局', async () => {
  const html = fs.readFileSync(path.join(APP_ROOT, 'public/index.html'), 'utf8');
  const css = fs.readFileSync(path.join(APP_ROOT, 'public/style.css'), 'utf8');
  assert.match(html, /<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">/, '缺少移动端 viewport meta');
  const menuItems = [...html.matchAll(/data-section="([^"]+)"/g)].map((m) => m[1]);
  assert.deepEqual(
    menuItems,
    ['profile', 'persona', 'sessions', 'memories', 'config', 'data'],
    `设置应正好六项（人物资料/人格设定/历史聊天/长期记忆/模型配置/数据管理），实际：${JSON.stringify(menuItems)}`
  );
  assert.ok(html.includes('id="input"'), '应有消息输入框');
  assert.ok(html.includes('maxlength="2000"'), '输入框应有限长');
  assert.match(css, /env\(safe-area-inset-bottom/, 'CSS 应处理底部安全区（刘海屏/手势条）');
  assert.match(css, /-webkit-overflow-scrolling:\s*touch/, 'CSS 应有触摸滚动优化');
  assert.match(css, /max-width:\s*720px/, '聊天区应为流式窄栏布局（手机端居中）');
  // 如实记录：style.css 只有 2 条 @media（均为深色模式；第二条是第三阶段睡前深色样式），没有 max-width 断点——移动端靠流式布局而非断点适配。
  const mediaCount = (css.match(/@media/g) || []).length;
  assert.equal(mediaCount, 2, '当前只有深色模式 2 条 @media（见 TEST-REPORT 备注）');
  assert.equal((css.match(/@media[^{]*max-width/g) || []).length, 0, '不得出现 max-width 断点');
});

test('item-2/16：无 Key 时 POST 聊天走 SSE 诚实报错 NO_API_KEY，不建消息、不返回假回复', async () => {
  const cfg = await api(noKey.base, 'GET', '/api/config');
  assert.equal(cfg.status, 200);
  assert.equal(cfg.json.hasKey, false, '无 Key 服务的 /api/config.hasKey 应为 false');
  assert.ok(!('DEEPSEEK_API_KEY' in cfg.json) && !JSON.stringify(cfg.json).includes('sk-'), '配置接口绝不返回 Key 值');
  const sid = await newSession(noKey.base, '无Key测试');
  const { status, contentType, events } = await postChatSSE(noKey.base, sid, { content: '你好', clientId: `nokey-${Date.now()}` });
  assert.equal(status, 200);
  assert.match(contentType || '', /text\/event-stream/);
  const err = events.find((e) => e.type === 'error');
  assert.ok(err, `应收到 SSE error 事件，实际：${JSON.stringify(events)}`);
  assert.equal(err.code, 'NO_API_KEY');
  assert.ok(!events.some((e) => e.type === 'delta'), '无 Key 时绝不返回假回复 delta');
  const msgs = await api(noKey.base, 'GET', `/api/sessions/${sid}/messages`);
  assert.equal(msgs.json.length, 0, '无 Key 报错时不应落库任何消息');
});

// ---------- 有测试假 Key + 401 stub 的服务 ----------

test('启动有 Key 服务（测试假 Key + 401 stub），并记录原始 baseUrl', async () => {
  await stopServer(noKey.child);
  noKey = null;
  keyed = await startAppServer({ port: await freePort(), apiKey: 'test-dummy-key' });
  const cfg = await api(keyed.base, 'GET', '/api/config');
  assert.equal(cfg.json.hasKey, true);
  assert.equal(cfg.json.model, 'deepseek-flash', '默认模型应为 deepseek-flash（deepseek-chat 已于 2026-07-24 退役）');
  originalBaseUrl = cfg.json.baseUrl;
  const put = await api(keyed.base, 'PUT', '/api/config', { baseUrl: stub401.base });
  assert.equal(put.status, 200);
  assert.equal(put.json.baseUrl, stub401.base);
});

test('item-16：上游 401 时 HTTP 层返回 DEEPSEEK_401，用户消息已保存、无假 AI 回复', async () => {
  const sid = await newSession(keyed.base, '401测试');
  const { events } = await postChatSSE(keyed.base, sid, { content: '你好', clientId: `c401-${Date.now()}` });
  const err = events.find((e) => e.type === 'error');
  assert.ok(err, `应收到 SSE error 事件，实际：${JSON.stringify(events)}`);
  assert.equal(err.code, 'DEEPSEEK_401');
  assert.ok(!events.some((e) => e.type === 'delta'), '401 时绝不返回假回复 delta');
  const msgs = await api(keyed.base, 'GET', `/api/sessions/${sid}/messages`);
  assert.equal(msgs.json.length, 1, '用户消息应在调用上游前落库');
  assert.equal(msgs.json[0].role, 'user');
  assert.equal(msgs.json[0].content, '你好');
});

test('item-3：连续多条消息不丢不串（用户消息按序落库；同 clientId 去重）', async () => {
  const sid = await newSession(keyed.base, '多条测试');
  const texts = ['第一条：下课啦', '第二条：冷死了', '第三条：还下雨了'];
  const ids = texts.map((_, i) => `multi-${Date.now()}-${i}`);
  for (let i = 0; i < texts.length; i++) {
    await postChatSSE(keyed.base, sid, { content: texts[i], clientId: ids[i] });
  }
  // 同一 clientId 重复提交：不建第二条（必须用完全相同的 clientId）
  await postChatSSE(keyed.base, sid, { content: texts[0], clientId: ids[0] });
  const msgs = await api(keyed.base, 'GET', `/api/sessions/${sid}/messages`);
  const contents = msgs.json.map((m) => m.content);
  assert.deepEqual(contents, texts, `三条消息应按序保留且不串不丢，实际：${JSON.stringify(contents)}`);
  assert.ok(msgs.json.every((m) => m.role === 'user'), '上游 401 时不应有假 AI 回复落库');
});

test('item-18：会话不污染（A 会话消息不在 B 会话出现）', async () => {
  const a = await newSession(keyed.base, '会话A');
  const b = await newSession(keyed.base, '会话B');
  await postChatSSE(keyed.base, a, { content: 'A的专属消息', clientId: `a-${Date.now()}` });
  await postChatSSE(keyed.base, b, { content: 'B的专属消息', clientId: `b-${Date.now()}` });
  const ma = await api(keyed.base, 'GET', `/api/sessions/${a}/messages`);
  const mb = await api(keyed.base, 'GET', `/api/sessions/${b}/messages`);
  assert.deepEqual(ma.json.map((m) => m.content), ['A的专属消息']);
  assert.deepEqual(mb.json.map((m) => m.content), ['B的专属消息']);
});

test('item-4/6：人格九类与样本库通过 API 可读', async () => {
  const p = await api(keyed.base, 'GET', '/api/persona');
  assert.equal(p.status, 200);
  assert.deepEqual(p.json.sections.map((s) => s.key), ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']);
  const all = p.json.sections.map((s) => s.content).join('\n');
  for (const w of ['我去', '我真的服了', '气死了', '无语了', '知道啦', '那姐姐呢']) {
    assert.ok(all.includes(w), `人格 API 缺少高频词：${w}`);
  }
  const s = await api(keyed.base, 'GET', '/api/samples');
  assert.equal(s.status, 200);
  assert.ok(s.json.length > 0, '样本库不应为空');
  assert.ok(s.json.every((x) => x.source === '微信截图转录'), '种子样本来源应标注为微信截图转录');
  const cats = [...new Set(s.json.map((x) => x.category))];
  for (const c of ['日常聊天', '主动开启话题', '表达不满', '生气', '表达关心', '面对对方撒娇', '开玩笑']) {
    assert.ok(cats.includes(c), `样本 API 缺少分类：${c}`);
  }
  const empty = await api(keyed.base, 'GET', '/api/samples?category=吃醋');
  assert.deepEqual(empty.json, [], '无原话分类"吃醋"应返回空数组（不编造）');
});

test('item-11/12：手动改记忆生效（PUT 后 GET 一致）；删除后停止调用', async () => {
  const created = await api(keyed.base, 'POST', '/api/memories', {
    content: 'TESTHTTP手动记忆：喜欢吃苹果', category: '偏好', source: 'manual', confidence: 1, importance: 70,
  });
  assert.equal(created.status, 201);
  const id = created.json.id;
  createdMemories.push(id);
  const put = await api(keyed.base, 'PUT', `/api/memories/${id}`, { content: 'TESTHTTP手动记忆：喜欢吃香蕉', importance: 80 });
  assert.equal(put.status, 200);
  const list = await api(keyed.base, 'GET', '/api/memories');
  const row = list.json.find((m) => m.id === id);
  assert.ok(row, 'PUT 后 GET 应能找到该记忆');
  assert.equal(row.content, 'TESTHTTP手动记忆：喜欢吃香蕉', 'PUT 后 GET 内容应一致');
  assert.equal(row.importance, 80);
  assert.equal(row.source, 'manual', '手动记忆来源不应被改掉');
  const del = await api(keyed.base, 'DELETE', `/api/memories/${id}`);
  assert.equal(del.status, 200);
  const list2 = await api(keyed.base, 'GET', '/api/memories');
  assert.ok(!list2.json.some((m) => m.id === id), '删除后 GET 不应再返回它');
  createdMemories.splice(createdMemories.indexOf(id), 1);
});

test('item-19：人格配置稳定——PUT 改动在重启后不变，改回后亦然', async () => {
  const before = await api(keyed.base, 'GET', '/api/persona');
  const origC = before.json.sections.find((s) => s.key === 'C').content;
  const put = await api(keyed.base, 'PUT', '/api/persona', { key: 'C', content: 'TESTPERSONA临时内容：只回短句。' });
  assert.equal(put.status, 200);
  const afterPut = await api(keyed.base, 'GET', '/api/persona');
  assert.equal(afterPut.json.sections.find((s) => s.key === 'C').content, 'TESTPERSONA临时内容：只回短句。');
  // 重启服务（同一端口、同一 data/app.db）
  const port = Number(new URL(keyed.base).port);
  await stopServer(keyed.child);
  keyed = await startAppServer({ port, apiKey: 'test-dummy-key' });
  // 注意：重启后 baseUrl 仍为 stub（存在 model_config 中），属于预期内
  const afterRestart = await api(keyed.base, 'GET', '/api/persona');
  assert.equal(afterRestart.json.sections.find((s) => s.key === 'C').content, 'TESTPERSONA临时内容：只回短句。', 'PUT 以外无人改人格，重启后应保持改动');
  // 改回原值
  await api(keyed.base, 'PUT', '/api/persona', { key: 'C', content: origC });
  const restored = await api(keyed.base, 'GET', '/api/persona');
  assert.equal(restored.json.sections.find((s) => s.key === 'C').content, origC, '改回后应与原始内容一致');
});

test('item-14/15：重启后记录保留——会话列表与消息与重启前一致', async () => {
  const sid = await newSession(keyed.base, '重启保留测试');
  await postChatSSE(keyed.base, sid, { content: '重启前的一条消息', clientId: `re-${Date.now()}` });
  const sessionsBefore = await api(keyed.base, 'GET', '/api/sessions');
  const msgsBefore = await api(keyed.base, 'GET', `/api/sessions/${sid}/messages`);
  assert.ok(msgsBefore.json.some((m) => m.content === '重启前的一条消息'));
  const port = Number(new URL(keyed.base).port);
  await stopServer(keyed.child);
  keyed = await startAppServer({ port, apiKey: 'test-dummy-key' });
  const sessionsAfter = await api(keyed.base, 'GET', '/api/sessions');
  const msgsAfter = await api(keyed.base, 'GET', `/api/sessions/${sid}/messages`);
  assert.deepEqual(
    sessionsAfter.json.map((s) => s.id).sort(),
    sessionsBefore.json.map((s) => s.id).sort(),
    '重启后会话列表应一致'
  );
  assert.deepEqual(msgsAfter.json, msgsBefore.json, '重启后同一会话的消息应逐条一致');
});
