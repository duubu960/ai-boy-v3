// 13-garden-empty.test.js — V4.0 第二阶段花园 bug #2 回归（空花园没有种花/浇水入口）
// 根因：后端 getGarden() 返回 { plots, pots, harvests }，键名是 plots；
// 前端 loadGarden 只认 d.slots/d.garden/d.list，从不读 d.plots，空槽被当成 []，
// renderGarden 空分支又只写一行提示文字、没有任何按钮，于是线上空花园永远看不到入口。
// 修法：loadGarden 归一化加上 d.plots（保留旧键名兼容）；renderGarden 空数组时也渲染
// 一个明确的种花入口（第 1 槽，选花种 +「种花」按钮，调 POST /api/garden/plant）。
// 纯 jsdom + mock fetch（mock 返回真实后端形状），不跑服务、不碰数据库。
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { JSDOM } from 'jsdom';
import { APP_ROOT } from './helpers.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const POTS = [
  { id: 'clay', name: '陶土花盆', emoji: '🪴', unlocked: true },
  { id: 'pink', name: '粉色花盆', emoji: '🌸', unlocked: false },
  { id: 'gold', name: '金色花盆', emoji: '🏆', unlocked: false },
];

// 真实后端形状的空槽（getGarden 返回的 plots 元素）
function emptySlots() {
  return [0, 1, 2].map((slot) => ({
    slot, flower: null, flower_name: null, planted_at: null, watered_at: null,
    stage: 'empty', progress: 0, ready: false,
  }));
}

function resp(status, body) {
  const isJson = typeof body !== 'string';
  return {
    ok: status >= 200 && status < 300, status,
    headers: { get: (n) => (n.toLowerCase() === 'content-type' ? (isJson ? 'application/json' : 'text/html') : null) },
    json: async () => body,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    body: null,
    clone: function () { return this; },
  };
}

/**
 * 带状态的花园 mock：GET 返回真实后端形状 { plots, pots, harvests }；
 * plant/water/harvest 改写 state；harvest 未长好时返回 400（与后端 not_ready 一致）。
 * getGardenOverride 可整体替换 GET /api/garden 的返回（用于空数组 / 旧键名用例）。
 */
function makeGardenMock({ getGardenOverride } = {}) {
  const state = { plots: emptySlots(), pots: POTS.map((p) => ({ ...p })), harvests: 0 };
  const calls = [];
  const fetch = async (url, opts = {}) => {
    const method = (opts.method || 'GET').toUpperCase();
    const [p] = String(url).split('?');
    const body = opts.body ? JSON.parse(opts.body) : {};
    calls.push({ method, path: p, body });
    if (p === '/api/garden' && method === 'GET') {
      if (getGardenOverride) return resp(200, getGardenOverride(state));
      return resp(200, { plots: state.plots.map((s) => ({ ...s })), pots: state.pots, harvests: state.harvests });
    }
    if (p === '/api/garden/plant' && method === 'POST') {
      const s = state.plots[body.slot];
      if (!s || s.flower) return resp(409, { error: 'conflict', message: '槽位已有花' });
      const names = { daisy: '雏菊', rose: '玫瑰', tulip: '郁金香', sunflower: '向日葵' };
      state.plots[body.slot] = {
        slot: body.slot, flower: body.flower, flower_name: names[body.flower] || body.flower,
        planted_at: new Date().toISOString(), watered_at: null, stage: 'seed', progress: 0, ready: false,
      };
      return resp(200, { ok: true, slot: body.slot, flower: body.flower });
    }
    if (p === '/api/garden/water' && method === 'POST') {
      const s = state.plots[body.slot];
      if (!s || !s.flower) return resp(404, { error: 'not_found', message: '槽位没有花' });
      s.watered_at = new Date().toISOString();
      s.stage = 'sprout';
      s.progress = 5;
      return resp(200, { ok: true });
    }
    if (p === '/api/garden/harvest' && method === 'POST') {
      const s = state.plots[body.slot];
      if (!s || !s.flower) return resp(404, { error: 'not_found', message: '槽位没有花' });
      if (s.stage !== 'bloom') return resp(400, { error: 'not_ready', message: '花还没长好' });
      state.plots[body.slot] = {
        slot: body.slot, flower: null, flower_name: null, planted_at: null, watered_at: null,
        stage: 'empty', progress: 0, ready: false,
      };
      state.harvests += 1;
      return resp(200, { ok: true, reward: { hearts: 2 } });
    }
    // 其余首屏接口给最小默认值，避免 initMimi 卡住
    if (p === '/api/cat' && method === 'GET') return resp(200, { cat: { id: 1, state: 'happy', mood: 'happy', intimacy: 0, hearts: 0, level: 1, stage: '初次见面', lastInteractAt: null, lastActions: {}, updatedAt: '2026-11-11T10:00:00Z' } });
    if (p === '/api/daily' && method === 'GET') return resp(200, { tasks: [], surprise: { claimed: false }, fortune: { drawn: false } });
    if (p === '/api/mood' && method === 'GET') return resp(200, { today: null, recent: [] });
    if (p === '/api/cat/outfit' && method === 'GET') return resp(200, { outfit: { bow: false, hat: false, scarf: false, dress: false, glasses: false, bg: 'bedroom', pose: 'sit' } });
    if (p === '/api/room' && method === 'GET') return resp(200, { room: { wallpaper: 'pink', bed: 'pink', plushies: [], lamp: false, flowers: false, painting: 'none', theme: 'home' } });
    if (p === '/api/memories' && method === 'GET') return resp(200, []);
    if (p === '/api/sessions' && method === 'GET') return resp(200, []);
    if (p === '/api/games/scores' && method === 'GET') return resp(200, { scores: [] });
    return resp(404, { error: 'not_found' });
  };
  return { fetch, calls, state };
}

async function makeDom(mockOpts) {
  const html = read('public/index.html');
  const dom = new JSDOM(html, { url: 'http://127.0.0.1:3199/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  class FakeGain { constructor() { this.gain = { value: 0 }; } connect() {} }
  class FakeOsc { constructor() { this.frequency = { value: 0 }; this.type = 'sine'; } connect() {} start() {} stop() {} }
  class FakeAudioContext {
    constructor() { this.currentTime = 0; this.state = 'running'; this.destination = {}; }
    createOscillator() { return new FakeOsc(); }
    createGain() { return new FakeGain(); }
    resume() { return Promise.resolve(); }
  }
  window.AudioContext = FakeAudioContext;
  window.webkitAudioContext = FakeAudioContext;
  const mock = makeGardenMock(mockOpts);
  window.fetch = mock.fetch;
  window.eval(read('public/catfx.js'));
  window.eval(read('public/mimi.js'));
  await sleep(150);
  return { dom, window, mock };
}

function toastText(window) {
  const t = window.document.getElementById('toast');
  return t ? t.textContent : '';
}

function gardenSlots(window) {
  return window.document.querySelectorAll('#gardenSlots .garden-slot');
}

function slotButton(window, slotIndex, label) {
  const slots = gardenSlots(window);
  assert.ok(slots[slotIndex], `缺少第 ${slotIndex + 1} 个花园槽位`);
  const btn = Array.from(slots[slotIndex].querySelectorAll('button')).find((b) => b.textContent.includes(label));
  assert.ok(btn, `第 ${slotIndex + 1} 槽应有「${label}」按钮，实际：` + slots[slotIndex].textContent.slice(0, 60));
  return btn;
}

test('G2-1 后端返回 plots 时前端归一化能读到 3 个空槽，每槽都有选花种 + 种花按钮', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(200);
  const slots = gardenSlots(window);
  assert.strictEqual(slots.length, 3, '应渲染 3 个花园槽位，实际 ' + slots.length);
  for (let i = 0; i < 3; i++) {
    const sel = slots[i].querySelector('select[aria-label="选择花种"]');
    assert.ok(sel, `第 ${i + 1} 槽应有选花种下拉`);
    assert.strictEqual(sel.options.length, 4, `第 ${i + 1} 槽下拉应有 4 种花`);
    assert.ok(slots[i].textContent.includes('种花'), `第 ${i + 1} 槽应有「种花」按钮`);
  }
});

test('G2-2 旧键名 slots 仍兼容：返回 { slots } 时也能渲染 3 个槽', async (t) => {
  const { dom, window } = await makeDom({
    getGardenOverride: (state) => ({ slots: state.plots.map((s) => ({ ...s })), pots: state.pots }),
  });
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(200);
  assert.strictEqual(gardenSlots(window).length, 3, '旧键名 slots 应仍渲染 3 个槽');
});

test('G2-3 renderGarden 空数组时仍渲染种花入口（第 1 槽），不只剩提示文字', async (t) => {
  const { dom, window } = await makeDom({
    getGardenOverride: () => ({ plots: [], pots: [] }),
  });
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(200);
  const box = window.document.getElementById('gardenSlots');
  assert.ok(box.textContent.includes('花园是空的'), '提示文字应保留');
  const slots = gardenSlots(window);
  assert.strictEqual(slots.length, 1, '空花园兜底应渲染 1 个种花入口槽位，实际 ' + slots.length);
  assert.ok(slots[0].querySelector('select[aria-label="选择花种"]'), '兜底入口应有选花种下拉');
  const btn = slotButton(window, 0, '种花');
  assert.ok(btn, '兜底入口应有「种花」按钮');
});

test('G2-4 jsdom 里点种花能调 POST /api/garden/plant，随后出现浇水按钮', async (t) => {
  const { dom, window, mock } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(200);
  slotButton(window, 0, '种花').click();
  await sleep(200);
  const plantCall = mock.calls.find((c) => c.method === 'POST' && c.path === '/api/garden/plant');
  assert.ok(plantCall, '点种花应调 POST /api/garden/plant，实际调用：' + JSON.stringify(mock.calls.map((c) => c.method + ' ' + c.path)));
  assert.strictEqual(plantCall.body.slot, 0, '种花应种到第 1 槽（slot 0）');
  assert.strictEqual(plantCall.body.flower, 'daisy', '默认应种下拉第一种花（雏菊 daisy）');
  assert.ok(toastText(window).includes('已种下'), '种花后 toast 应提示已种下，实际：' + toastText(window));
  const slots = gardenSlots(window);
  assert.strictEqual(slots.length, 3, '种花后仍应有 3 个槽位');
  assert.ok(slots[0].textContent.includes('雏菊'), '第 1 槽种花后应显示雏菊');
  slotButton(window, 0, '浇水');
});

test('G2-5 种→浇→收获全程走通（收获用 mock 把 stage 推到 bloom，模拟 growMs 走完）', async (t) => {
  const { dom, window, mock } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(200);
  // 种
  slotButton(window, 0, '种花').click();
  await sleep(200);
  assert.ok(mock.calls.some((c) => c.method === 'POST' && c.path === '/api/garden/plant'), '应调 plant');
  // 浇
  slotButton(window, 0, '浇水').click();
  await sleep(200);
  const waterCall = mock.calls.find((c) => c.method === 'POST' && c.path === '/api/garden/water');
  assert.ok(waterCall, '点浇水应调 POST /api/garden/water');
  assert.strictEqual(waterCall.body.slot, 0);
  assert.ok(toastText(window).includes('已浇水'), '浇水后 toast 应提示已浇水，实际：' + toastText(window));
  // 模拟时间走完：后端 flowerStage 会按真实时间算出 bloom，这里直接把 mock 状态推到开花
  mock.state.plots[0].stage = 'bloom';
  mock.state.plots[0].progress = 100;
  mock.state.plots[0].ready = true;
  window.MimiCat.showPage('park');
  await sleep(200);
  // 收获
  const harvestBtn = slotButton(window, 0, '收获');
  assert.ok(gardenSlots(window)[0].textContent.includes('开花'), '开花后第 1 槽应显示“开花”');
  harvestBtn.click();
  await sleep(200);
  const harvestCall = mock.calls.find((c) => c.method === 'POST' && c.path === '/api/garden/harvest');
  assert.ok(harvestCall, '点收获应调 POST /api/garden/harvest');
  assert.strictEqual(harvestCall.body.slot, 0);
  assert.ok(toastText(window).includes('爱心 +2'), '收获后 toast 应显示奖励“爱心 +2”，实际：' + toastText(window));
  // 收获后槽位回到空花盆，可再种
  assert.ok(gardenSlots(window)[0].textContent.includes('种花'), '收获后第 1 槽应回到可种花状态');
});
