// tests/helpers.js — 测试公共工具（HTTP 层，不改产品代码）
// 说明：测试用临时端口启动真实 server.js（SQLite 本地 data/app.db）；
// DeepSeek 一律用本地 stub 只返回错误状态（401/402/超时），绝不伪造成功回复。
import { spawn } from 'node:child_process';
import http from 'node:http';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export function freePort() {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.listen(0, '127.0.0.1', () => {
      const port = s.address().port;
      s.close(() => resolve(port));
    });
  });
}

export function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function waitForHealth(base, timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    try {
      const r = await fetch(`${base}/healthz`, { signal: AbortSignal.timeout(2000) });
      if (r.ok) return true;
    } catch { /* 未就绪，继续等 */ }
    if (Date.now() > deadline) throw new Error(`服务 ${base} 在 ${timeoutMs}ms 内未就绪`);
    await sleep(300);
  }
}

/**
 * 启动真实 server.js 子进程。
 * @param {object} opts { port, apiKey } — apiKey 省略/传 null 表示无 Key（测 NO_API_KEY）。
 */
export async function startAppServer({ port, apiKey } = {}) {
  const env = { ...process.env, PORT: String(port), DATABASE_URL: '' };
  if (apiKey === undefined || apiKey === null) delete env.DEEPSEEK_API_KEY;
  else env.DEEPSEEK_API_KEY = apiKey;
  const child = spawn('node', ['server.js'], { cwd: APP_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] });
  let stderr = '';
  child.stderr.on('data', (d) => { stderr += d.toString(); });
  const base = `http://127.0.0.1:${port}`;
  try {
    await waitForHealth(base);
  } catch (e) {
    try { child.kill('SIGKILL'); } catch { /* ignore */ }
    throw new Error(`${e.message}\nserver stderr: ${stderr.slice(0, 2000)}`);
  }
  return { child, base, stderr: () => stderr };
}

export async function stopServer(child) {
  if (!child || child.exitCode !== null) return;
  child.kill('SIGTERM');
  const exited = await Promise.race([
    new Promise((r) => child.once('exit', () => r(true))),
    sleep(5000).then(() => false),
  ]);
  if (!exited) child.kill('SIGKILL');
}

/** 启动一个只返回错误状态的本地 DeepSeek stub（用于 401/402/超时映射，不返回假回复）。 */
export function startErrorStub(handler) {
  return new Promise((resolve) => {
    const server = http.createServer(handler);
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, base: `http://127.0.0.1:${server.address().port}` });
    });
  });
}

export function stopStub(server) {
  return new Promise((resolve) => server.close(() => resolve()));
}

/** POST 聊天（SSE），收集全部事件后返回。 */
export async function postChatSSE(base, sessionId, body) {
  const res = await fetch(`${base}/api/sessions/${sessionId}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(30000),
  });
  const text = await res.text();
  const events = [];
  for (const chunk of text.split('\n\n')) {
    const line = chunk.trim();
    if (!line.startsWith('data:')) continue;
    try { events.push(JSON.parse(line.slice(5).trim())); } catch { /* ignore */ }
  }
  return { status: res.status, contentType: res.headers.get('content-type'), events };
}

export async function api(base, method, p, body) {
  const res = await fetch(`${base}${p}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(15000),
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* 非 JSON */ }
  return { status: res.status, json, text };
}
