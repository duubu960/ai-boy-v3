// 07-phase1-backend.test.js — V4.0 第一阶段后端（猫咪小屋 / 每日 / 小游戏 / 心情）
// 真实 server.js 子进程 + 本地 SQLite（data/app.db），不连线上 Neon。
// 确定性：领取类断言一律用明确的假日期（2031-03-xx）走 HTTP，不依赖“今天”是否已被领过；
// 任务完成条件逐项用真实记录判定：pet=daily_records interact 行、chat=messages user 行、
// surprise=daily_records surprise 行、game=game_scores 行、mood=mood_entries 行。
// 清理：after 里停服务后直连 SQLite，只删本次测试产生的数据——
// fake 日期（2031-%）全删、今日 daily_records 只删快照外新增的 kind、game_scores 只删测试中
// 新建的行 id、messages 只删测试种子 session、cat_state 按快照恢复（此前无行则删行）。
// 绝不碰 sessions/messages/memories/persona_config/language_samples 的真实行
// （除测试自己建、随后删掉的会话与种子消息行外）。
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { APP_ROOT, freePort, startAppServer, stopServer, api, sleep } from './helpers.js';
import {
  todayStr, mulberry32, seededPick, SURPRISE_POOL, FORTUNES, WHEEL_PRIZES,
  TASKS, STAGES, stageFor, levelFor, deriveState, interactGains,
} from '../src/cat.js';

let server = null;
let db = null;
let catSnapshot = null; // 测试前 cat_state id=1 的行（或 null）
let todayKinds = new Set(); // 测试前今日 daily_records 的 kind 集合
let createdGameScoreIds = [];
const seedSessionId = `phase1-test-session-${Date.now()}`;
const today = todayStr();

const D_SURPRISE_1 = '2031-03-10';
const D_SURPRISE_2 = '2031-03-11';
const D_FORTUNE = '2031-03-12';
const D_DAILY = '2031-03-13';
const D_TASKS = '2031-03-14';
const D_MOOD = '2031-03-15';

function openDb() {
  return new DatabaseSync(path.join(APP_ROOT, 'data', 'app.db'));
}

before(async () => {
  server = await startAppServer({ port: await freePort(), apiKey: null });
  db = openDb();
  // 快照（用于 after 精确清理）
  catSnapshot = db.prepare('SELECT * FROM cat_state WHERE id = 1').get() || null;
  todayKinds = new Set(db.prepare('SELECT kind FROM daily_records WHERE date = ?').all(today).map((r) => r.kind));
  // 自愈式预清理：删掉以往失败运行可能留下的 fake 日期测试行
  db.prepare("DELETE FROM daily_records WHERE date LIKE '2031-%'").run();
  db.prepare("DELETE FROM mood_entries WHERE date LIKE '2031-%'").run();
  db.prepare("DELETE FROM game_scores WHERE game IN ('phase1-test-game', 'phase1-test-seed')").run();
  db.prepare('DELETE FROM messages WHERE session_id = ?').run(seedSessionId);
});

after(async () => {
  if (server) await stopServer(server.child);
  try {
    if (!db) db = openDb();
    db.prepare("DELETE FROM daily_records WHERE date LIKE '2031-%'").run();
    const kinds = [...todayKinds];
    if (kinds.length === 0) {
      db.prepare('DELETE FROM daily_records WHERE date = ?').run(today);
    } else {
      const ph = kinds.map(() => '?').join(', ');
      db.prepare(`DELETE FROM daily_records WHERE date = ? AND kind NOT IN (${ph})`).run(today, ...kinds);
    }
    if (createdGameScoreIds.length > 0) {
      const ph = createdGameScoreIds.map(() => '?').join(', ');
      db.prepare(`DELETE FROM game_scores WHERE id IN (${ph})`).run(...createdGameScoreIds);
    }
    db.prepare("DELETE FROM mood_entries WHERE date LIKE '2031-%'").run();
    db.prepare('DELETE FROM messages WHERE session_id = ?').run(seedSessionId);
    if (catSnapshot) {
      db.prepare('UPDATE cat_state SET state = ?, mood = ?, intimacy = ?, hearts = ?, last_interact_at = ?, last_actions = ?, updated_at = ? WHERE id = 1').run(
        catSnapshot.state, catSnapshot.mood, catSnapshot.intimacy, catSnapshot.hearts,
        catSnapshot.last_interact_at, catSnapshot.last_actions, catSnapshot.updated_at
      );
    } else {
      db.prepare('DELETE FROM cat_state WHERE id = 1').run();
    }
    // 清理自查：fake 日期行应已清零（只读断言失败不掩盖主结果，用 console 报错）
    const left = db.prepare("SELECT COUNT(*) AS n FROM daily_records WHERE date LIKE '2031-%'").get();
    if (left.n !== 0) console.error(`[07-cleanup] daily_records 仍有 ${left.n} 行 fake 日期未清理`);
  } catch (e) {
    console.error('[07-cleanup] 清理失败：', e.message);
  } finally {
    try { db?.close(); } catch { /* ignore */ }
  }
});

async function getCat() {
  const r = await api(server.base, 'GET', '/api/cat');
  assert.equal(r.status, 200, `GET /api/cat 应 200，实际 ${r.status}：${r.text}`);
  return r.json;
}

// ---------- 静态：新表存在 ----------

test('phase1-静态：SQLite 与 PG schema 均含 4 张新表及关键列', () => {
  for (const f of ['db/schema.sqlite.sql', 'db/schema.pg.sql']) {
    const sql = fs.readFileSync(path.join(APP_ROOT, f), 'utf8');
    for (const t of ['cat_state', 'daily_records', 'game_scores', 'mood_entries']) {
      assert.match(sql, new RegExp(`CREATE TABLE IF NOT EXISTS ${t}\\b`), `${f} 缺少表 ${t}`);
    }
    assert.match(sql, /PRIMARY KEY\s*\(\s*date\s*,\s*kind\s*\)/, `${f} daily_records 应为 (date, kind) 复合主键`);
    assert.match(sql, /mood_entries[\s\S]*?date TEXT NOT NULL UNIQUE/, `${f} mood_entries.date 应 UNIQUE`);
  }
  assert.doesNotMatch(
    fs.readFileSync(path.join(APP_ROOT, 'db/schema.sqlite.sql'), 'utf8'),
    /DROP TABLE|DELETE FROM/i,
    '迁移只许新增，schema 里不应有 DROP/DELETE'
  );
});

// ---------- 纯函数：日期 / 随机 / 等级 / 阶段 / 状态派生 ----------

test('phase1-纯函数：todayStr 按 Asia/Shanghai 算真实日期', () => {
  assert.equal(todayStr(new Date('2026-11-11T15:00:00Z')), '2026-11-11'); // 23:00 上海，同一天
  assert.equal(todayStr(new Date('2026-11-11T17:00:00Z')), '2026-11-12'); // 01:00 上海，已是次日
  assert.equal(todayStr(new Date('2026-11-11T16:00:00Z')), '2026-11-12'); // 00:00 上海
  assert.match(todayStr(), /^\d{4}-\d{2}-\d{2}$/);
  assert.equal(todayStr(), todayStr(new Date()));
});

test('phase1-纯函数：mulberry32/seededPick 同种子同结果，内容常量齐全', () => {
  const a = mulberry32(42), b = mulberry32(42);
  assert.equal(a(), b(), '同种子随机序列应一致');
  assert.equal(seededPick(SURPRISE_POOL, 'surprise:2031-03-10'), seededPick(SURPRISE_POOL, 'surprise:2031-03-10'));
  assert.equal(SURPRISE_POOL.length, 6, '惊喜池应为 6 种');
  assert.deepEqual(SURPRISE_POOL.map((x) => x.kind), ['note', 'card', 'heart', 'sticker', 'quote', 'task']);
  assert.equal(FORTUNES.length, 8, '幸运签应为 8 条');
  assert.equal(WHEEL_PRIZES.length, 8, '转盘应为 8 格');
  assert.deepEqual(WHEEL_PRIZES.map((x) => x.label), ['爱心+5', '爱心+10', '贴纸·星星', '贴纸·蝴蝶结', '小纸条', '幸运语录', '爱心+2', '爱心+1']);
  assert.equal(TASKS.length, 5, '任务应为 5 个');
  assert.deepEqual(TASKS.map((x) => x.id), ['pet', 'chat', 'surprise', 'game', 'mood']);
  assert.deepEqual(TASKS.map((x) => x.reward.hearts), [3, 3, 3, 3, 2], '任务奖励 hearts 应为 3/3/3/3/2');
  assert.deepEqual(STAGES.map((x) => x.name), ['初次见面', '熟悉阶段', '亲密阶段', '最好的伙伴']);
  assert.deepEqual(interactGains.pet, { hearts: 2, intimacy: 3, state: '开心' });
  assert.deepEqual(interactGains.feed, { hearts: 3, intimacy: 3, state: '满足' });
  assert.deepEqual(interactGains.sleep, { hearts: 1, intimacy: 2, state: '困倦' });
  assert.deepEqual(interactGains.play, { hearts: 3, intimacy: 4, state: '兴奋' });
});

test('phase1-纯函数：levelFor 与 stageFor 阈值', () => {
  assert.equal(levelFor(0), 1);
  assert.equal(levelFor(39), 1);
  assert.equal(levelFor(40), 2);
  assert.equal(levelFor(80), 3);
  assert.equal(levelFor(399), 10);
  assert.equal(levelFor(100000), 10, '等级上限 10');
  assert.equal(stageFor(0), '初次见面');
  assert.equal(stageFor(29), '初次见面');
  assert.equal(stageFor(30), '熟悉阶段');
  assert.equal(stageFor(79), '熟悉阶段');
  assert.equal(stageFor(80), '亲密阶段');
  assert.equal(stageFor(149), '亲密阶段');
  assert.equal(stageFor(150), '最好的伙伴');
  assert.equal(stageFor(9999), '最好的伙伴');
});

test('phase1-纯函数：deriveState 派生顺序——互动优先、空闲饥饿、夜间困倦、否则好奇', () => {
  const day = new Date('2026-11-11T15:00:00+08:00'); // 上海 15:00
  const night = new Date('2026-11-11T23:30:00+08:00'); // 上海 23:30
  const early = new Date('2026-11-12T03:00:00+08:00'); // 上海 03:00
  const morning = new Date('2026-11-11T10:00:00+08:00'); // 上海 10:00
  const isoAgo = (base, ms) => new Date(base.getTime() - ms).toISOString();
  // 互动 5 分钟前 → 互动后状态优先
  assert.equal(deriveState({ state: '满足', last_interact_at: isoAgo(day, 5 * 60 * 1000) }, day), '满足');
  // 空闲 7 小时（白天）→ 饥饿
  assert.equal(deriveState({ state: '开心', last_interact_at: isoAgo(day, 7 * 3600 * 1000) }, day), '饥饿');
  // 空闲 7 小时（夜间）→ 饥饿优先于困倦
  assert.equal(deriveState({ state: '开心', last_interact_at: isoAgo(night, 7 * 3600 * 1000) }, night), '饥饿');
  // 空闲 3 小时（白天，介于 30 分钟与 6 小时之间）→ 好奇
  assert.equal(deriveState({ state: '开心', last_interact_at: isoAgo(morning, 3 * 3600 * 1000) }, morning), '好奇');
  // 无互动记录：夜间 → 困倦，白天 → 好奇
  assert.equal(deriveState({ state: '开心', last_interact_at: null }, night), '困倦');
  assert.equal(deriveState({ state: '开心', last_interact_at: null }, early), '困倦');
  assert.equal(deriveState({ state: '开心', last_interact_at: null }, morning), '好奇');
  assert.equal(deriveState({ state: '开心', last_interact_at: null }, day), '好奇');
});

// ---------- HTTP：猫咪 ----------

test('phase1-猫咪：GET /api/cat 返回完整状态，等级/阶段与亲密度一致', async () => {
  const cat = await getCat();
  for (const k of ['id', 'state', 'mood', 'intimacy', 'hearts', 'level', 'stage', 'last_interact_at', 'last_actions']) {
    assert.ok(k in cat, `GET /api/cat 缺少字段 ${k}`);
  }
  assert.ok(['开心', '满足', '困倦', '兴奋', '好奇', '饥饿'].includes(cat.state), `未知状态：${cat.state}`);
  assert.equal(cat.level, levelFor(cat.intimacy), 'level 应与 levelFor(亲密度) 一致');
  assert.equal(cat.stage, stageFor(cat.intimacy), 'stage 应与 stageFor(亲密度) 一致');
});

test('phase1-猫咪：互动奖励按动作给，同一动作 10 秒内重复不重复给', async () => {
  const before = await getCat();
  const pet = await api(server.base, 'POST', '/api/cat/interact', { action: 'pet' });
  assert.equal(pet.status, 200, `pet 应 200：${pet.text}`);
  assert.deepEqual(pet.json.gained, { hearts: 2, intimacy: 3 });
  assert.equal(pet.json.rewarded, true);
  assert.equal(pet.json.cat.state, '开心');
  const petAgain = await api(server.base, 'POST', '/api/cat/interact', { action: 'pet' });
  assert.equal(petAgain.status, 200);
  assert.deepEqual(petAgain.json.gained, { hearts: 0, intimacy: 0 }, '10 秒内重复 pet 不应再给奖励');
  assert.equal(petAgain.json.rewarded, false);
  const feed = await api(server.base, 'POST', '/api/cat/interact', { action: 'feed' });
  assert.deepEqual(feed.json.gained, { hearts: 3, intimacy: 3 }, '不同动作不受同一动作冷却影响');
  const play = await api(server.base, 'POST', '/api/cat/interact', { action: 'play' });
  assert.deepEqual(play.json.gained, { hearts: 3, intimacy: 4 });
  const sleep = await api(server.base, 'POST', '/api/cat/interact', { action: 'sleep' });
  assert.deepEqual(sleep.json.gained, { hearts: 1, intimacy: 2 });
  const after = await getCat();
  assert.equal(after.hearts, before.hearts + 2 + 3 + 3 + 1, '四次发奖爱心应累计');
  assert.equal(after.intimacy, before.intimacy + 3 + 3 + 4 + 2, '四次发奖亲密度应累计');
  const bad = await api(server.base, 'POST', '/api/cat/interact', { action: 'fly' });
  assert.equal(bad.status, 400, '未知动作应 400');
  assert.equal(bad.json.error, 'bad_request');
  const empty = await api(server.base, 'POST', '/api/cat/interact', {});
  assert.equal(empty.status, 400, '无 action 应 400');
});

// ---------- HTTP：每日总览 ----------

test('phase1-每日：GET /api/daily 全新日期形状完整、五项任务皆未完成未领', async () => {
  const r = await api(server.base, 'GET', `/api/daily?date=${D_DAILY}`);
  assert.equal(r.status, 200);
  assert.equal(r.json.date, D_DAILY);
  assert.deepEqual(r.json.surprise, { claimed: false, reward: null });
  assert.deepEqual(r.json.fortune, { drawn: false, text: null });
  assert.equal(r.json.tasks.length, 5);
  assert.deepEqual(r.json.tasks.map((t) => t.id), ['pet', 'chat', 'surprise', 'game', 'mood']);
  for (const t of r.json.tasks) {
    assert.equal(t.done, false, `全新日期任务 ${t.id} 应未完成`);
    assert.equal(t.claimed, false, `全新日期任务 ${t.id} 应未领取`);
  }
  const todayR = await api(server.base, 'GET', '/api/daily');
  assert.equal(todayR.json.date, today, '不传 date 时默认今天');
});

// ---------- HTTP：惊喜 ----------

test('phase1-惊喜：同日只能领一次，换日可再领，奖励与日期种子一致', async () => {
  const first = await api(server.base, 'POST', '/api/daily/surprise', { date: D_SURPRISE_1 });
  assert.equal(first.status, 200, `首次领惊喜应 200：${first.text}`);
  assert.equal(first.json.claimed, true);
  assert.equal(first.json.date, D_SURPRISE_1);
  assert.deepEqual(first.json.reward, seededPick(SURPRISE_POOL, `surprise:${D_SURPRISE_1}`), '奖励应由日期种子确定');
  const again = await api(server.base, 'POST', '/api/daily/surprise', { date: D_SURPRISE_1 });
  assert.equal(again.status, 409, '同日再领应 409');
  assert.equal(again.json.error, 'already_claimed');
  const daily = await api(server.base, 'GET', `/api/daily?date=${D_SURPRISE_1}`);
  assert.equal(daily.json.surprise.claimed, true);
  assert.deepEqual(daily.json.surprise.reward, first.json.reward, '总览里的惊喜奖励应与领取时一致');
  const nextDay = await api(server.base, 'POST', '/api/daily/surprise', { date: D_SURPRISE_2 });
  assert.equal(nextDay.status, 200, '换日应可再领');
});

// ---------- HTTP：幸运签 ----------

test('phase1-幸运签：同日同签，换日重抽', async () => {
  const a = await api(server.base, 'POST', '/api/daily/fortune', { date: D_FORTUNE });
  assert.equal(a.status, 200);
  assert.equal(a.json.drawn, true);
  assert.ok(FORTUNES.includes(a.json.text), `签文应在 8 条内：${a.json.text}`);
  const b = await api(server.base, 'POST', '/api/daily/fortune', { date: D_FORTUNE });
  assert.equal(b.status, 200);
  assert.equal(b.json.text, a.json.text, '同日重抽应为同一签');
  const daily = await api(server.base, 'GET', `/api/daily?date=${D_FORTUNE}`);
  assert.equal(daily.json.fortune.drawn, true);
  assert.equal(daily.json.fortune.text, a.json.text);
  const other = await api(server.base, 'POST', '/api/daily/fortune', { date: D_DAILY });
  assert.equal(other.status, 200);
  assert.ok(FORTUNES.includes(other.json.text));
});

// ---------- HTTP：任务（逐项用真实记录判定） ----------

test('phase1-任务：未完成先领一律 400 not_ready；真实记录齐全后逐项可领，重复领 409', async () => {
  const d = D_TASKS;
  for (const id of ['pet', 'chat', 'surprise', 'game', 'mood']) {
    const r = await api(server.base, 'POST', `/api/daily/tasks/${id}/claim`, { date: d });
    assert.equal(r.status, 400, `任务 ${id} 未完成时领奖应 400，实际 ${r.status}`);
    assert.equal(r.json.error, 'not_ready');
  }
  const unknown = await api(server.base, 'POST', '/api/daily/tasks/nope/claim', { date: d });
  assert.equal(unknown.status, 400);
  assert.equal(unknown.json.error, 'bad_request');

  // 造真实记录：pet=daily_records interact 行；chat=messages user 行（上海窗口内）；
  // game=game_scores 行；mood 走 HTTP；surprise 走 HTTP。
  const now = new Date().toISOString();
  db.prepare("INSERT INTO daily_records (date, kind, payload, created_at) VALUES (?, 'interact:pet', '{}', ?)").run(d, now);
  db.prepare('INSERT INTO messages (session_id, role, content, client_id, meta, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    seedSessionId, 'user', 'phase1 测试消息', null, null, `${d}T04:00:00.000Z` // 12:00 上海，落在 D_TASKS 窗口内
  );
  db.prepare("INSERT INTO game_scores (game, score, detail, played_at) VALUES ('phase1-test-seed', 10, NULL, ?)").run(`${d}T04:00:00.000Z`);
  createdGameScoreIds.push(db.prepare('SELECT MAX(id) AS id FROM game_scores').get().id);
  const moodRes = await api(server.base, 'POST', '/api/mood', { date: d, mood: '开心', note: '任务测试' });
  assert.equal(moodRes.status, 200, `写心情应 200：${moodRes.text}`);
  const surpriseRes = await api(server.base, 'POST', '/api/daily/surprise', { date: d });
  assert.equal(surpriseRes.status, 200, `领惊喜应 200：${surpriseRes.text}`);

  const daily = await api(server.base, 'GET', `/api/daily?date=${d}`);
  const doneMap = Object.fromEntries(daily.json.tasks.map((t) => [t.id, t.done]));
  assert.deepEqual(doneMap, { pet: true, chat: true, surprise: true, game: true, mood: true }, '五项任务有真实记录后应全部 done');

  const expectedRewards = { pet: 3, chat: 3, surprise: 3, game: 3, mood: 2 };
  for (const id of ['pet', 'chat', 'surprise', 'game', 'mood']) {
    const before = await getCat();
    const claim = await api(server.base, 'POST', `/api/daily/tasks/${id}/claim`, { date: d });
    assert.equal(claim.status, 200, `任务 ${id} 完成后领奖应 200：${claim.text}`);
    assert.equal(claim.json.claimed, true);
    assert.deepEqual(claim.json.reward, { hearts: expectedRewards[id] });
    const after = await getCat();
    assert.equal(after.hearts, before.hearts + expectedRewards[id], `任务 ${id} 领奖后爱心应 +${expectedRewards[id]}`);
    const again = await api(server.base, 'POST', `/api/daily/tasks/${id}/claim`, { date: d });
    assert.equal(again.status, 409, `任务 ${id} 重复领应 409`);
    assert.equal(again.json.error, 'already_claimed');
  }
  const dailyAfter = await api(server.base, 'GET', `/api/daily?date=${d}`);
  assert.ok(dailyAfter.json.tasks.every((t) => t.claimed), '五项任务领完后总览应全部 claimed');
});

// ---------- HTTP：游戏分数 ----------

test('phase1-游戏分数：POST 201 落库，GET 按 game 过滤，非法分 400', async () => {
  const post = await api(server.base, 'POST', '/api/games/score', { game: 'phase1-test-game', score: 42, detail: 'test-detail' });
  assert.equal(post.status, 201, `记分应 201：${post.text}`);
  assert.equal(post.json.game, 'phase1-test-game');
  assert.equal(post.json.score, 42);
  assert.equal(post.json.detail, 'test-detail');
  assert.ok(post.json.played_at);
  createdGameScoreIds.push(post.json.id);
  const list = await api(server.base, 'GET', '/api/games/scores?game=phase1-test-game');
  assert.equal(list.status, 200);
  assert.ok(list.json.some((r) => r.id === post.json.id && r.score === 42), 'GET 应能查到刚记的分数');
  const badScore = await api(server.base, 'POST', '/api/games/score', { game: 'phase1-test-game', score: -1 });
  assert.equal(badScore.status, 400);
  const noGame = await api(server.base, 'POST', '/api/games/score', { score: 1 });
  assert.equal(noGame.status, 400);
});

// ---------- HTTP：心情 ----------

test('phase1-心情：同日 upsert 只留一行，GET /api/mood 返回最近记录', async () => {
  const a = await api(server.base, 'POST', '/api/mood', { date: D_MOOD, mood: '开心', note: 'a' });
  assert.equal(a.status, 200, `写心情应 200：${a.text}`);
  assert.equal(a.json.date, D_MOOD);
  assert.equal(a.json.mood, '开心');
  const b = await api(server.base, 'POST', '/api/mood', { date: D_MOOD, mood: '有点累', note: 'b' });
  assert.equal(b.status, 200);
  assert.equal(b.json.id, a.json.id, '同日再写应 upsert 同一行');
  assert.equal(b.json.mood, '有点累');
  assert.equal(b.json.note, 'b');
  const list = await api(server.base, 'GET', '/api/mood');
  assert.equal(list.status, 200);
  assert.ok(Array.isArray(list.json));
  const rows = list.json.filter((r) => r.date === D_MOOD);
  assert.equal(rows.length, 1, '同日心情应只有一行');
  assert.equal(rows[0].mood, '有点累');
  const bad = await api(server.base, 'POST', '/api/mood', { date: D_MOOD });
  assert.equal(bad.status, 400, '无 mood 应 400');
});

// ---------- HTTP：转盘 ----------

test('phase1-转盘：首次成功、立即再转 429 冷却、3 秒后可再转，且分数落库', async () => {
  const before = await api(server.base, 'GET', '/api/games/scores?game=wheel');
  assert.equal(before.status, 200);
  const beforeCount = before.json.length;
  const first = await api(server.base, 'POST', '/api/games/wheel', {});
  assert.equal(first.status, 200, `首次转盘应 200：${first.text}`);
  assert.ok(WHEEL_PRIZES.some((p) => p.label === first.json.prize.label), `奖品应在 8 格内：${JSON.stringify(first.json.prize)}`);
  const fast = await api(server.base, 'POST', '/api/games/wheel', {});
  assert.equal(fast.status, 429, '冷却内再转应 429');
  assert.equal(fast.json.error, 'cooldown');
  await sleep(3100);
  const second = await api(server.base, 'POST', '/api/games/wheel', {});
  assert.equal(second.status, 200, '冷却 3 秒后应可再转');
  const after = await api(server.base, 'GET', '/api/games/scores?game=wheel');
  assert.equal(after.json.length, beforeCount + 2, '两次成功转动应落库 2 条 wheel 分数');
  const newIds = after.json.slice(0, 2).map((r) => r.id);
  createdGameScoreIds.push(...newIds);
});
