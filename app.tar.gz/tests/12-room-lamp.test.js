// tests/12-room-lamp.test.js — 房间 lamp 字段回归（bug #1：房间保存失败）
// 根因：前端 public/mimi.js 一直用 lamp，后端 src/phase2.js 只认 lights，
// PUT /api/room 带 lamp 直接 400，刷新后恢复原样。修法：后端以 lamp 为规范字段，
// 旧 lights 输入/旧存量都映射为 lamp，GET 永远不再返回 lights。
// 只测本 bug；不跑全量，避免与并行工人争 SQLite 文件。
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { validateRoom, DEFAULT_ROOM, getRoom, setRoom } from '../src/phase2.js';
import { initDb, get, run, closeDb } from '../src/db.js';
import { startAppServer, stopServer, freePort } from './helpers.js';

const FULL = { wallpaper: 'starry', bed: 'white', plushies: ['bear', 'cat'], lamp: true, flowers: true, painting: 'heart', theme: 'park' };

async function api(base, method, path, body) {
  const r = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* 非 JSON */ }
  return { status: r.status, json, text };
}

test('room-lamp：validateRoom 接受 lamp，旧 lights 归一化为 lamp，非法值 400', () => {
  assert.deepEqual(DEFAULT_ROOM, { wallpaper: 'pink', bed: 'pink', plushies: [], lamp: false, flowers: false, painting: 'none', theme: 'home' });
  assert.ok(!('lights' in DEFAULT_ROOM), 'DEFAULT_ROOM 不应再含 lights');
  assert.deepEqual(validateRoom({}), {});
  assert.deepEqual(validateRoom({ ...FULL }), FULL);
  assert.deepEqual(validateRoom({ lamp: false }), { lamp: false });
  // 旧字段 lights：布尔值映射为 lamp，不再原样透传
  assert.deepEqual(validateRoom({ lights: true }), { lamp: true });
  assert.deepEqual(validateRoom({ lights: false }), { lamp: false });
  // 两者同传以 lamp 为准
  assert.deepEqual(validateRoom({ lamp: false, lights: true }), { lamp: false });
  assert.deepEqual(validateRoom({ lights: true, lamp: false }), { lamp: false });
  for (const bad of [{ lamp: 'yes' }, { lamp: 1 }, { lamp: null }, { lights: 'yes' }, { lights: 0 }, { unknown: 1 }]) {
    assert.throws(() => validateRoom(bad), (e) => e.code === 'bad_request', `room ${JSON.stringify(bad)} 应抛 bad_request`);
  }
});

test('room-lamp：已存旧 lights 数据读出时映射为 lamp，不丢值', async () => {
  await initDb();
  const orig = await get('SELECT room FROM room_state WHERE id = 1');
  try {
    // 直接写一条旧格式行（lights:true，无 lamp），模拟线上旧存量
    const legacy = { wallpaper: 'sakura', bed: 'white', plushies: ['bunny'], lights: true, flowers: false, painting: 'cat', theme: 'park' };
    await run(
      'INSERT INTO room_state (id, room, updated_at) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET room = EXCLUDED.room, updated_at = EXCLUDED.updated_at',
      [JSON.stringify(legacy), new Date().toISOString()]
    );
    const room = await getRoom();
    assert.equal(room.lamp, true, '旧 lights:true 应读成 lamp:true');
    assert.ok(!('lights' in room), 'getRoom 返回里不应再有 lights');
    assert.deepEqual(room, { wallpaper: 'sakura', bed: 'white', plushies: ['bunny'], lamp: true, flowers: false, painting: 'cat', theme: 'park' });
    // setRoom 只改 lamp 后，旧 lights 不应再出现在存储里
    const after = await setRoom({ lamp: false });
    assert.equal(after.lamp, false);
    assert.ok(!('lights' in after));
    const row = await get('SELECT room FROM room_state WHERE id = 1');
    assert.ok(!('lights' in JSON.parse(row.room)), '落库 JSON 里不应再有 lights');
  } finally {
    if (orig?.room) {
      await run('UPDATE room_state SET room = ? WHERE id = 1', [orig.room]);
    } else {
      await run('DELETE FROM room_state WHERE id = 1');
    }
    await closeDb();
  }
});

test('room-lamp：HTTP 全字段 PUT 200、GET 一致，只发 lamp 成功，非法 lamp 400', async () => {
  const { child, base } = await startAppServer({ port: await freePort() });
  try {
    const before = await api(base, 'GET', '/api/room');
    assert.equal(before.status, 200);
    const origRoom = before.json;

    // 全字段 PUT（含 lamp:true）必须 200，且返回与发的一致
    const put = await api(base, 'PUT', '/api/room', FULL);
    assert.equal(put.status, 200, `全字段 PUT 应 200：${put.text}`);
    assert.deepEqual(put.json, FULL);
    assert.ok(!('lights' in put.json), 'PUT 返回里不应有 lights');
    const read = await api(base, 'GET', '/api/room');
    assert.deepEqual(read.json, FULL, 'GET 应读回刚保存的 room');

    // 只发 lamp 字段成功，其余字段保持
    const patch = await api(base, 'PUT', '/api/room', { lamp: false });
    assert.equal(patch.status, 200, `只发 lamp 应 200：${patch.text}`);
    assert.equal(patch.json.lamp, false);
    assert.equal(patch.json.wallpaper, 'starry', '其余字段应保持');
    const read2 = await api(base, 'GET', '/api/room');
    assert.equal(read2.json.lamp, false);

    // 旧字段 lights 经 HTTP 也接受并归一化为 lamp
    const legacyPut = await api(base, 'PUT', '/api/room', { lights: true });
    assert.equal(legacyPut.status, 200, `lights 别名 PUT 应 200：${legacyPut.text}`);
    assert.equal(legacyPut.json.lamp, true);
    assert.ok(!('lights' in legacyPut.json));

    // 非法 lamp 值 400
    for (const bad of [{ lamp: 'yes' }, { lamp: 1 }, { lights: 'yes' }, { lamp: null }, { unknown: 1 }]) {
      const r = await api(base, 'PUT', '/api/room', bad);
      assert.equal(r.status, 400, `room ${JSON.stringify(bad)} 应 400，实际 ${r.status}`);
      assert.equal(r.json.error, 'bad_request');
    }

    // 恢复原房间，避免影响他人测试
    const restore = await api(base, 'PUT', '/api/room', origRoom);
    assert.equal(restore.status, 200, `恢复原房间应 200：${restore.text}`);
  } finally {
    await stopServer(child);
  }
});
