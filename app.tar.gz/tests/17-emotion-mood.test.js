// 17-emotion-mood.test.js — 情绪入口自动保存心情回归测试
// 根因：首页 8 个情绪入口按钮复用 .mood-btn 样式却没有 data-mood，
// 初始化里 `document.querySelectorAll('.mood-btn')` 通绑 saveMood(b.dataset.mood)，
// 点情绪入口时多发一次 saveMood(undefined) → POST /api/mood 空 body，
// 后端 400「需要 mood」，弹出「保存失败：需要 mood」，且心情日记里一直没有记录。
// 修法（public/mimi.js）：① 选择器收紧为 .mood-btn[data-mood]；
// ② EMOTIONS 每项加 mood 字段（心情日记同一套心情词）；
// ③ setEmotion 里显式 saveMood(e.mood)；④ saveMood 空值直接返回，不再误发请求。
// 本文件两部分：A. jsdom 前端（mock fetch，带心情存储）；B. 真实 server 子进程后端。
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { JSDOM } from 'jsdom';
import { APP_ROOT, freePort, startAppServer, stopServer, api, sleep } from './helpers.js';
import { todayStr } from '../src/cat.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');

function resp(status, body, isJson = true) {
  return {
    ok: status >= 200 && status < 300, status,
    headers: { get: (n) => (n.toLowerCase() === 'content-type' ? (isJson ? 'application/json' : 'text/html') : null) },
    json: async () => body,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    body: null,
    clone: function () { return this; },
  };
}

const CAT_STATE = { id: 1, state: 'happy', mood: 'happy', intimacy: 0, hearts: 0, level: 1, stage: '初次见面', lastInteractAt: null, lastActions: {}, updatedAt: '2026-11-11T10:00:00Z' };
const DEFAULT_ROOM = { wallpaper: 'pink', bed: 'pink', plushies: ['bear'], lamp: true, flowers: true, painting: 'none', theme: 'home' };

/* ---------- A. jsdom 前端 ---------- */

function mockFetchFactory() {
  const calls = [];
  const bodies = [];
  const store = {
    mood: null, moodNote: '', moodPosts: [],
    manualMems: [], annivs: [],
    favorites: [],
    chatPosts: [],
  };
  const fetch = async (url, opts = {}) => {
    const method = (opts.method || 'GET').toUpperCase();
    const [p, q] = String(url).split('?');
    calls.push(method + ' ' + String(url));
    let body = {};
    try { body = opts.body ? JSON.parse(opts.body) : {}; } catch { body = {}; }
    bodies.push({ method, url: String(url), body });
    const route = method + ' ' + p;
    if (p === '/api/cat' && method === 'GET') return resp(200, { cat: { ...CAT_STATE } });
    if (p === '/api/cat/interact' && method === 'POST') return resp(200, { cat: { ...CAT_STATE, hearts: 2 }, gained: { hearts: 2, intimacy: 1 } });
    if (p === '/api/cat/outfit' && method === 'GET') return resp(200, { outfit: { bow: false, hat: false, scarf: false, dress: false, glasses: false, bg: 'bedroom', pose: 'sit' } });
    if (p === '/api/cat/outfit' && method === 'PUT') return resp(200, { ok: true });
    if (p === '/api/mood' && method === 'GET') {
      const date = new URLSearchParams(q || '').get('date');
      const row = store.mood ? { mood: store.mood, note: store.moodNote, date: '2026-11-11', created_at: '2026-11-11T10:00:00Z' } : null;
      if (date) return resp(200, { today: date === '2026-11-11' ? row : null, recent: row && date === '2026-11-11' ? [row] : [] });
      return resp(200, { today: store.mood, recent: row ? [row] : [] });
    }
    if (p === '/api/mood' && method === 'POST') {
      // 模拟真实后端契约：mood 为空 → 400「需要 mood」
      if (!body.mood || typeof body.mood !== 'string') {
        return resp(400, { error: 'bad_request', message: '需要 mood' });
      }
      store.mood = body.mood;
      store.moodNote = body.note || '';
      store.moodPosts.push({ mood: body.mood, note: body.note || '' });
      return resp(200, { ok: true, mood: body.mood, note: body.note || '' });
    }
    if (p === '/api/daily' && method === 'GET') return resp(200, { tasks: [], surprise: { claimed: false }, fortune: { drawn: false } });
    if (p === '/api/memories' && method === 'GET') return resp(200, []);
    if (p === '/api/sessions' && method === 'GET') return resp(200, []);
    if (p === '/api/room' && method === 'GET') return resp(200, { room: { ...DEFAULT_ROOM } });
    if (p === '/api/room' && method === 'PUT') return resp(200, { room: { ...DEFAULT_ROOM, ...body } });
    if (p === '/api/garden' && method === 'GET') return resp(200, { plots: [], pots: [] });
    if (p === '/api/events/next' && method === 'GET') return resp(200, { event: null });
    if (p === '/api/letters' && method === 'GET') return resp(200, { letters: [] });
    if (p === '/api/games/scores' && method === 'GET') return resp(200, { scores: [] });
    if (p === '/api/manual-memories' && method === 'GET') return resp(200, { memories: [] });
    if (p === '/api/favorites' && method === 'GET') return resp(200, { favorites: [] });
    if (p === '/api/anniversaries' && method === 'GET') return resp(200, { anniversaries: [] });
    if (p === '/api/bedtime/story' && method === 'POST') return resp(200, { story: '从前有一只小猫……', source: 'local' });
    if (p === '/api/bedtime/letter' && method === 'GET') return resp(200, { letter: '晚安呀。', source: 'generic' });
    if (p === '/api/report' && method === 'GET') {
      const date = new URLSearchParams(q || '').get('date') || '2026-11-11';
      return resp(200, {
        date, chat: { user: 0, assistant: 0 },
        mood: store.mood ? { mood: store.mood, note: store.moodNote } : null,
        tasks: { total: 0, done: 0, claimed: 0 }, surprise: { claimed: false },
        games: [], cat: null, garden: { harvested: [], growing: [] }, letters: { drawn: 0, saved: 0 },
      });
    }
    if (/^\/api\/sessions\/[^/]+\/chat$/.test(p) && method === 'POST') {
      store.chatPosts.push(body);
      return resp(200, { ok: true });
    }
    void route;
    return resp(404, { error: 'not_found' });
  };
  return { fetch, calls, bodies, store };
}

async function makeDom() {
  const html = read('public/index.html');
  const dom = new JSDOM(html, { url: 'http://127.0.0.1:3199/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  class FakeGain {
    constructor() { this.gain = { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} }; }
    connect() {}
  }
  class FakeOsc {
    constructor() { this.frequency = { value: 0 }; this.type = 'sine'; }
    connect() {} start() {} stop() {}
  }
  class FakeAudioContext {
    constructor() { this.currentTime = 0; this.state = 'running'; this.destination = {}; }
    createOscillator() { return new FakeOsc(); }
    createGain() { return new FakeGain(); }
    resume() { return Promise.resolve(); }
    close() { return Promise.resolve(); }
  }
  window.AudioContext = FakeAudioContext;
  window.webkitAudioContext = FakeAudioContext;
  const { fetch, calls, bodies, store } = mockFetchFactory();
  window.fetch = fetch;
  window.eval(read('public/catfx.js'));
  window.eval(read('public/mimi.js'));
  await sleep(150);
  return { dom, window, calls, bodies, store };
}

function toastText(window) {
  const t = window.document.getElementById('toast');
  return t ? t.textContent : '';
}
function moodPosts(bodies) {
  return bodies.filter((b) => b.method === 'POST' && b.url === '/api/mood');
}

/* 情绪入口 8 个 key → 应自动保存的心情词（心情日记同一套词） */
const EXPECTED_MOOD = {
  happy: '开心', sad: '难过', wronged: '委屈', irritated: '烦躁',
  praise: '想被夸', clingy: '想撒娇', talk: '想找人聊天', quiet: '想安静待一会儿',
};

test('情绪入口：点“今天有点难过”只发一次带 mood 的保存，不弹“保存失败”，今日心情变成难过', async (t) => {
  const { dom, window, bodies, store } = await makeDom();
  t.after(() => dom.window.close());
  window.document.querySelector('[data-emotion="sad"]').click();
  await sleep(150);
  const posts = moodPosts(bodies);
  assert.strictEqual(posts.length, 1, `点一次情绪入口应只发 1 次 POST /api/mood，实际 ${posts.length} 次：${JSON.stringify(posts)}`);
  assert.strictEqual(posts[0].body.mood, '难过', `保存的心情应为“难过”，实际 ${JSON.stringify(posts[0].body)}`);
  assert.strictEqual(store.mood, '难过', 'mock 存储里今日心情应为难过');
  assert.doesNotMatch(toastText(window), /保存失败/, `不应弹出保存失败，实际 toast：${toastText(window)}`);
  assert.match(toastText(window), /今日心情已保存：难过/, `应提示今日心情已保存，实际 toast：${toastText(window)}`);
  assert.match(window.document.getElementById('todayMoodText').textContent, /难过/, '今日心情区应显示难过');
  assert.strictEqual(window.document.getElementById('emotionBanner').hidden, false, '进聊天后情绪横幅应显示');
});

test('情绪入口：8 个入口各自动保存一个非空心情词，且不发空 mood 请求', async (t) => {
  const { dom, window, bodies } = await makeDom();
  t.after(() => dom.window.close());
  for (const key of Object.keys(EXPECTED_MOOD)) {
    const before = moodPosts(bodies).length;
    window.document.querySelector(`[data-emotion="${key}"]`).click();
    await sleep(120);
    const posts = moodPosts(bodies);
    assert.strictEqual(posts.length, before + 1, `点 ${key} 应新增 1 次心情保存，实际新增 ${posts.length - before} 次`);
    assert.strictEqual(posts[posts.length - 1].body.mood, EXPECTED_MOOD[key],
      `点 ${key} 应保存“${EXPECTED_MOOD[key]}”，实际 ${JSON.stringify(posts[posts.length - 1].body)}`);
    assert.doesNotMatch(toastText(window), /保存失败/, `点 ${key} 不应弹出保存失败`);
    window.document.getElementById('emotionClearBtn').click();
    await sleep(30);
  }
  for (const p of moodPosts(bodies)) {
    assert.ok(p.body.mood && typeof p.body.mood === 'string', `心情保存 body 里 mood 不能为空，实际 ${JSON.stringify(p)}`);
  }
});

test('情绪入口：同一天重复点不同情绪，以最后一次为准（不再多条打架）', async (t) => {
  const { dom, window, bodies, store } = await makeDom();
  t.after(() => dom.window.close());
  window.document.querySelector('[data-emotion="sad"]').click();
  await sleep(120);
  window.document.querySelector('[data-emotion="happy"]').click();
  await sleep(120);
  const posts = moodPosts(bodies);
  assert.strictEqual(posts.length, 2, `点两次应有 2 次保存，实际 ${posts.length} 次`);
  assert.strictEqual(posts[1].body.mood, '开心', '第二次保存应为开心');
  assert.strictEqual(store.mood, '开心', '最终今日心情应为最后一次的开心');
  assert.match(window.document.getElementById('todayMoodText').textContent, /开心/, '今日心情区应更新为开心');
});

test('心情选择器仍正常：点今日心情“开心”只保存一次；心情日记手动保存仍正常', async (t) => {
  const { dom, window, bodies } = await makeDom();
  t.after(() => dom.window.close());
  window.document.querySelector('#moodPicker [data-mood="开心"]').click();
  await sleep(120);
  let posts = moodPosts(bodies);
  assert.strictEqual(posts.length, 1, `点心情选择器应只发 1 次保存，实际 ${posts.length} 次`);
  assert.strictEqual(posts[0].body.mood, '开心');
  // 心情日记表单手动保存：选“委屈”+备注
  const sel = window.document.getElementById('moodDiaryMood');
  sel.value = '委屈';
  window.document.getElementById('moodDiaryNote').value = '手动备注';
  window.document.getElementById('moodDiarySubmitBtn').click();
  await sleep(120);
  posts = moodPosts(bodies);
  assert.strictEqual(posts.length, 2, `日记手动保存后应共 2 次保存，实际 ${posts.length} 次`);
  assert.deepEqual(posts[1].body, { mood: '委屈', note: '手动备注' }, '日记手动保存应带心情与备注');
  assert.match(window.document.getElementById('moodDiaryStatus').textContent, /今日心情已保存：委屈/, '日记状态应显示已保存');
  assert.doesNotMatch(toastText(window), /保存失败/, '手动保存不应弹出保存失败');
});

test('每日报告：情绪入口保存心情后，报告里心情随之更新', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.document.querySelector('[data-emotion="sad"]').click();
  await sleep(120);
  const dateEl = window.document.getElementById('reportDate');
  dateEl.value = '2026-11-11';
  window.document.getElementById('reportQueryBtn').click();
  await sleep(120);
  const text = window.document.getElementById('reportBody').textContent;
  assert.match(text, /难过/, `报告里心情应显示难过，实际：${text}`);
  assert.doesNotMatch(text, /今天还没有心情记录/, '报告不应再说今天没有心情记录');
});

test('静态：心情选择器绑定只认带 data-mood 的按钮；setEmotion 显式保存心情', () => {
  const mimi = read('public/mimi.js');
  assert.match(mimi, /\.mood-btn\[data-mood\]/, '心情选择器绑定须收紧为 .mood-btn[data-mood]');
  assert.doesNotMatch(mimi, /querySelectorAll\('\.mood-btn'\)\.forEach\(\(b\) =>\s*b\.addEventListener\('click', \(\) => saveMood\(b\.dataset\.mood, b\)\)\);/,
    '不得再有通绑 .mood-btn → saveMood(b.dataset.mood) 的旧写法');
  assert.match(mimi, /saveMood\(e\.mood\)/, 'setEmotion 须显式调用 saveMood(e.mood)');
  for (const key of Object.keys(EXPECTED_MOOD)) {
    assert.match(mimi, new RegExp(`${key}: \\{ label: '[^']+', mood: '${EXPECTED_MOOD[key]}'`),
      `EMOTIONS.${key} 须有 mood: '${EXPECTED_MOOD[key]}'`);
  }
});

/* ---------- B. 后端（真实 server 子进程 + 本地 SQLite） ---------- */

const D1 = '2033-03-20';
const D2 = '2033-03-21';
let server = null;
let db = null;
const today = todayStr();
let moodTodaySnapshot = null;

function openDb() {
  return new DatabaseSync(path.join(APP_ROOT, 'data', 'app.db'));
}

before(async () => {
  server = await startAppServer({ port: await freePort(), apiKey: null });
  db = openDb();
  moodTodaySnapshot = db.prepare('SELECT * FROM mood_entries WHERE date = ?').get(today) || null;
  db.prepare("DELETE FROM mood_entries WHERE date LIKE '2033-%'").run();
});

after(async () => {
  if (server) await stopServer(server.child);
  try {
    if (!db) db = openDb();
    db.prepare("DELETE FROM mood_entries WHERE date LIKE '2033-%'").run();
    if (moodTodaySnapshot) {
      db.prepare('UPDATE mood_entries SET mood = ?, note = ?, updated_at = ? WHERE date = ?').run(
        moodTodaySnapshot.mood, moodTodaySnapshot.note, moodTodaySnapshot.updated_at, today);
    } else {
      db.prepare('DELETE FROM mood_entries WHERE date = ?').run(today);
    }
  } catch (e) {
    console.error('[17-cleanup] 清理失败：', e.message);
  } finally {
    try { db?.close(); } catch { /* ignore */ }
  }
});

test('后端：POST /api/mood 空 body 应 400「需要 mood」（前端绝不能再发空心情）', async () => {
  const r = await api(server.base, 'POST', '/api/mood', {});
  assert.strictEqual(r.status, 400, `空心情应 400，实际 ${r.status}：${r.text}`);
  assert.match(r.text, /需要 mood/, '400 错误信息应为“需要 mood”');
});

test('后端：同日重复保存心情，以最后一次为准、只留一行', async () => {
  const a = await api(server.base, 'POST', '/api/mood', { date: D1, mood: '难过', note: '' });
  assert.strictEqual(a.status, 200, `第一次保存应 200，实际 ${a.status}：${a.text}`);
  const b = await api(server.base, 'POST', '/api/mood', { date: D1, mood: '开心', note: '后来好了' });
  assert.strictEqual(b.status, 200, `第二次保存应 200，实际 ${b.status}：${b.text}`);
  assert.strictEqual(b.json.id, a.json.id, '同日再写应 upsert 同一行');
  // GET /api/mood 返回最近记录数组（不支持 ?date），按日期过滤
  const g = await api(server.base, 'GET', '/api/mood');
  assert.strictEqual(g.status, 200);
  assert.ok(Array.isArray(g.json), `GET /api/mood 应返回数组，实际 ${JSON.stringify(g.json)}`);
  const rows = g.json.filter((r) => r.date === D1);
  assert.strictEqual(rows.length, 1, `同日心情应只留一行，实际 ${rows.length} 行`);
  assert.strictEqual(rows[0].mood, '开心', `同日最后一次保存应胜出，实际 ${JSON.stringify(rows[0])}`);
  assert.strictEqual(rows[0].note, '后来好了');
  const n = db.prepare('SELECT COUNT(*) AS n FROM mood_entries WHERE date = ?').get(D1).n;
  assert.strictEqual(n, 1, `同日心情应只留一行，实际 ${n} 行`);
});

test('后端：心情日记形状保存后按日期能查到（手动保存路径）', async () => {
  const r = await api(server.base, 'POST', '/api/mood', { date: D2, mood: '委屈', note: '手动备注' });
  assert.strictEqual(r.status, 200, `保存应 200，实际 ${r.status}：${r.text}`);
  const g = await api(server.base, 'GET', '/api/mood');
  assert.strictEqual(g.status, 200);
  assert.ok(Array.isArray(g.json), `GET /api/mood 应返回数组，实际 ${JSON.stringify(g.json)}`);
  const rows = g.json.filter((x) => x.date === D2);
  assert.strictEqual(rows.length, 1, `日期 ${D2} 应有一行心情，实际 ${rows.length} 行`);
  assert.strictEqual(rows[0].mood, '委屈');
  assert.strictEqual(rows[0].note, '手动备注');
});
