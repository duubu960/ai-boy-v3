// 00-static.test.js — 静态卫生检查（不跑服务）：
// - .env.example 只有空占位，不含真 Key；.gitignore 遮住 .env / data / *.db
// - render.yaml：healthCheck /healthz，两个关键 env 均为 sync:false
// - schema：8 张表齐全
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { APP_ROOT } from './helpers.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');

test('item-16/配置卫生：.env.example 只有空占位，不写真 Key', () => {
  const env = read('.env.example');
  assert.match(env, /DEEPSEEK_API_KEY=\s*$/m, '.env.example 里的 DEEPSEEK_API_KEY 必须是空占位');
  assert.doesNotMatch(env, /DEEPSEEK_API_KEY=\S+/m, '.env.example 不得含任何 Key 值');
  assert.match(env, /DATABASE_URL=/, '应有 DATABASE_URL 占位');
});

test('配置卫生：.gitignore 遮住 .env / data / *.db', () => {
  const gi = read('.gitignore');
  for (const pat of ['.env', 'data/', '*.db']) {
    assert.ok(gi.split('\n').some((l) => l.trim() === pat), `.gitignore 缺少 ${pat}`);
  }
});

test('部署卫生：render.yaml 用 Render+Neon 免费路线，关键 env 均为 sync:false', () => {
  const yaml = read('render.yaml');
  assert.match(yaml, /healthCheckPath:\s*\/healthz/, 'healthCheck 必须是 /healthz');
  assert.match(yaml, /key:\s*NODE_VERSION\s*\n\s*value:\s*['"]?22['"]?/, 'NODE_VERSION 须为 22');
  assert.match(yaml, /key:\s*DEEPSEEK_API_KEY[\s\S]*?sync:\s*false/, 'DEEPSEEK_API_KEY 必须是 sync:false');
  assert.match(yaml, /key:\s*DATABASE_URL[\s\S]*?sync:\s*false/, 'DATABASE_URL 必须是 sync:false');
  assert.match(yaml, /buildCommand:\s*tar -xzf app\.tar\.gz && npm install/, '构建命令应为 tarball 流程：tar -xzf app.tar.gz && npm install（与可爱的乖乖已验证的部署方式一致，仓库只放 render.yaml + app.tar.gz）');
  assert.match(yaml, /startCommand:\s*npm start/, '启动命令应为 npm start');
  assert.doesNotMatch(yaml, /sk-[A-Za-z0-9]/, 'render.yaml 不得含任何真实 Key');
  assert.doesNotMatch(yaml, /postgres(ql)?:\/\/\S+@/, 'render.yaml 不得含真实连接串');
});

test('数据库卫生：SQLite 与 PG schema 均为 8 张表', () => {
  const expected = ['users', 'sessions', 'messages', 'persona_config', 'memories', 'language_samples', 'summaries', 'model_config'];
  for (const f of ['db/schema.sqlite.sql', 'db/schema.pg.sql']) {
    const sql = read(f);
    for (const t of expected) {
      assert.match(sql, new RegExp(`CREATE TABLE IF NOT EXISTS ${t}\\b`), `${f} 缺少表 ${t}`);
    }
  }
});
