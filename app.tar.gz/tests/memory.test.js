// tests: memory.js 规则式提取 / 去重相似度 / 关键词检索打分（纯逻辑，不碰数据库）
import test from 'node:test';
import assert from 'node:assert/strict';
import { extractCandidates, jaccard, normalizeText, keywords } from '../src/memory.js';

test('普通闲聊不产生记忆候选', () => {
  const c = extractCandidates([
    { role: 'user', content: '下课啦' },
    { role: 'user', content: '我刚刚下去接了杯水' },
    { role: 'user', content: '我朋友叫我打王者，所以我要打一会' },
  ]);
  assert.equal(c.length, 0);
});

test('约定信号：明天一起去 -> 约定 70-90', () => {
  const c = extractCandidates([{ role: 'user', content: '明天我们一起去吃火锅吧' }]);
  assert.equal(c.length, 1);
  assert.equal(c[0].category, '约定');
  assert.ok(c[0].importance >= 70 && c[0].importance <= 90);
});

test('偏好信号：喜欢 -> 偏好', () => {
  const c = extractCandidates([{ role: 'user', content: '我喜欢吃香菇鸡丁' }]);
  assert.equal(c.length, 1);
  assert.equal(c[0].category, '偏好');
});

test('人物关系信号：室友/姐姐 -> 人物关系', () => {
  const c = extractCandidates([{ role: 'user', content: '我室友健身回来给我弄醒了' }]);
  assert.equal(c.length, 1);
  assert.equal(c[0].category, '人物关系');
});

test('经历信号：摔手机 -> 经历', () => {
  const c = extractCandidates([{ role: 'user', content: '刚才手机摔了，屏幕裂了' }]);
  assert.equal(c.length, 1);
  assert.equal(c[0].category, '经历');
});

test('只有 assistant 消息不产生候选', () => {
  const c = extractCandidates([{ role: 'assistant', content: '明天一起去吃火锅吧' }]);
  assert.equal(c.length, 0);
});

test('Jaccard：相同文本为 1，完全不同接近 0', () => {
  assert.equal(jaccard('我喜欢吃香菇鸡丁', '我喜欢吃香菇鸡丁'), 1);
  assert.ok(jaccard('我喜欢吃香菇鸡丁', '今天天气很好') < 0.3);
});

test('normalizeText 去标点空格', () => {
  assert.equal(normalizeText('我去， 我的伞被人偷了！'), '我去我的伞被人偷了');
});

test('keywords 含单字和双字 gram', () => {
  const k = keywords('明天一起去');
  assert.ok(k.has('明'));
  assert.ok(k.has('明天'));
});
