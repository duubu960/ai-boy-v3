// 09-phase2-backend.test.js — V4.0 第二阶段后端（爱心记账 / 收藏 / 换装 / 房间 / 花园 / 心动事件 / 神秘信箱）
// 真实 server.js 子进程 + 本地 SQLite（data/app.db），不连线上 Neon。
// 清理：phase2 新表（heart_ledger/collection/garden_plots/letters/event_log）是本阶段新建、
// 未上线、无真实用户数据，before/after 直接全清；dress_state/room_state 按快照恢复；
// cat_state 与今日 daily_records 按快照恢复（今日 daily_records 全行快照后重插）；
// game_scores 只删本次新建的行 id；假日期（2032-%）全删；测试种子记忆随后删掉。
// 注意：memories 表 CHECK 约束只允许 status ∈ active/pending/conflict，
// ‘confirmed’ 写不进 status；“已确认”改用独立标记列 memories.confirmed（db.js 启动时幂等新增，
// 只新增列），POST 的 status:'confirmed' 与 PUT {confirmed:1} 都会写这一列，信箱 ai 分支只读它。
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { APP_ROOT, freePort, startAppServer, stopServer, api, sleep } from './helpers.js';
import { todayStr, seededPick, SURPRISE_POOL } from '../src/cat.js';
import {
  FLOWERS, flowerStage, EVENTS, LETTER_POOL, validateOutfit, validateRoom,
  DEFAULT_OUTFIT, DEFAULT_ROOM,
} from '../src/phase2.js';

let server = null;
let db = null;
let catSnapshot = null; // 测试前 cat_state id=1 的行（或 null）
let todayDailySnapshot = []; // 测试前今日 daily_records 全行
let gameScoreMaxId = 0;
let dressSnapshot = null;
let roomSnapshot = null;
let seedMemoryId = null;
const today = todayStr();

const D_TASK = '2032-04-14';

// 挑一个 2032-04 里惊喜奖励带爱心的假日期（seededPick 是确定性的）
function surpriseDateWithHearts() {
  for (let d = 10; d <= 30; d++) {
    const date = `2032-04-${String(d).padStart(2, '0')}`;
    if (seededPick(SURPRISE_POOL, `surprise:${date}`).hearts > 0) return date;
  }
  return null;
}
const D_SURPRISE = surpriseDateWithHearts();

function openDb() {
  return new DatabaseSync(path.join(APP_ROOT, 'data', 'app.db'));
}

function hoursAgo(h) {
  return new Date(Date.now() - h * 3600 * 1000).toISOString();
}

before(async () => {
  server = await startAppServer({ port: await freePort(), apiKey: null });
  db = openDb();
  // 快照（用于 after 精确清理）
  catSnapshot = db.prepare('SELECT * FROM cat_state WHERE id = 1').get() || null;
  todayDailySnapshot = db.prepare('SELECT * FROM daily_records WHERE date = ?').all(today);
  gameScoreMaxId = db.prepare('SELECT MAX(id) AS id FROM game_scores').get()?.id || 0;
  dressSnapshot = db.prepare('SELECT * FROM dress_state WHERE id = 1').get() || null;
  roomSnapshot = db.prepare('SELECT * FROM room_state WHERE id = 1').get() || null;
  // 自愈式预清理：phase2 新表无真实用户数据，直接清掉以往失败运行的残留
  for (const t of ['heart_ledger', 'collection', 'garden_plots', 'letters', 'event_log']) {
    db.prepare(`DELETE FROM ${t}`).run();
  }
  db.prepare('DELETE FROM dress_state WHERE id = 1').run();
  db.prepare('DELETE FROM room_state WHERE id = 1').run();
  db.prepare("DELETE FROM daily_records WHERE date LIKE '2032-%'").run();
  // 洗澡任务测试需要“今天只做过 bath”的干净起点，先清掉今日的互动行（after 按快照恢复）
  db.prepare("DELETE FROM daily_records WHERE date = ? AND kind LIKE 'interact:%'").run(today);
  db.prepare("DELETE FROM mood_entries WHERE date LIKE '2032-%'").run();
});

after(async () => {
  if (server) await stopServer(server.child);
  try {
    if (!db) db = openDb();
    for (const t of ['heart_ledger', 'collection', 'garden_plots', 'letters', 'event_log']) {
      db.prepare(`DELETE FROM ${t}`).run();
    }
    db.prepare("DELETE FROM daily_records WHERE date LIKE '2032-%'").run();
    // 恢复今日 daily_records 快照（先清今日全行，再重插快照行）
    db.prepare('DELETE FROM daily_records WHERE date = ?').run(today);
    for (const r of todayDailySnapshot) {
      db.prepare('INSERT INTO daily_records (date, kind, payload, created_at) VALUES (?, ?, ?, ?)').run(r.date, r.kind, r.payload, r.created_at);
    }
    db.prepare('DELETE FROM game_scores WHERE id > ?').run(gameScoreMaxId);
    if (seedMemoryId) db.prepare('DELETE FROM memories WHERE id = ?').run(seedMemoryId);
    if (dressSnapshot) {
      db.prepare('INSERT INTO dress_state (id, outfit, updated_at) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET outfit = EXCLUDED.outfit, updated_at = EXCLUDED.updated_at').run(dressSnapshot.outfit, dressSnapshot.updated_at);
    } else {
      db.prepare('DELETE FROM dress_state WHERE id = 1').run();
    }
    if (roomSnapshot) {
      db.prepare('INSERT INTO room_state (id, room, updated_at) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET room = EXCLUDED.room, updated_at = EXCLUDED.updated_at').run(roomSnapshot.room, roomSnapshot.updated_at);
    } else {
      db.prepare('DELETE FROM room_state WHERE id = 1').run();
    }
    if (catSnapshot) {
      db.prepare('UPDATE cat_state SET state = ?, mood = ?, intimacy = ?, hearts = ?, last_interact_at = ?, last_actions = ?, updated_at = ? WHERE id = 1').run(
        catSnapshot.state, catSnapshot.mood, catSnapshot.intimacy, catSnapshot.hearts,
        catSnapshot.last_interact_at, catSnapshot.last_actions, catSnapshot.updated_at
      );
    } else {
      db.prepare('DELETE FROM cat_state WHERE id = 1').run();
    }
    // 清理自查：phase2 新表应已清零
    for (const t of ['heart_ledger', 'collection', 'garden_plots', 'letters', 'event_log']) {
      const left = db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get();
      if (left.n !== 0) console.error(`[09-cleanup] ${t} 仍有 ${left.n} 行未清理`);
    }
  } catch (e) {
    console.error('[09-cleanup] 清理失败：', e.message);
  } finally {
    try { db?.close(); } catch { /* ignore */ }
  }
});

async function getCat() {
  const r = await api(server.base, 'GET', '/api/cat');
  assert.equal(r.status, 200, `GET /api/cat 应 200，实际 ${r.status}：${r.text}`);
  return r.json;
}

/** 直接改库设亲密度并清掉互动冷却（last_actions），让下一次互动必定发奖。 */
function resetCat(intimacy) {
  db.prepare("UPDATE cat_state SET intimacy = ?, last_actions = '{}' WHERE id = 1").run(intimacy);
}

async function ledgerTop(limit = 5) {
  const r = await api(server.base, 'GET', `/api/cat/ledger?limit=${limit}`);
  assert.equal(r.status, 200, `GET /api/cat/ledger 应 200：${r.text}`);
  assert.ok(Array.isArray(r.json));
  return r.json;
}

// ---------- 静态：新表存在 ----------

test('phase2-静态：SQLite 与 PG schema 均含 7 张新表及关键列，且无 DROP/DELETE', () => {
  for (const f of ['db/schema.sqlite.sql', 'db/schema.pg.sql']) {
    const sql = fs.readFileSync(path.join(APP_ROOT, f), 'utf8');
    for (const t of ['heart_ledger', 'collection', 'dress_state', 'room_state', 'garden_plots', 'letters', 'event_log']) {
      assert.match(sql, new RegExp(`CREATE TABLE IF NOT EXISTS ${t}\\b`), `${f} 缺少表 ${t}`);
    }
    assert.match(sql, /heart_ledger[\s\S]*?delta INTEGER NOT NULL/, `${f} heart_ledger 应有 delta`);
    assert.match(sql, /collection[\s\S]*?UNIQUE\s*\(\s*kind\s*,\s*item_id\s*\)/, `${f} collection 应有 UNIQUE(kind, item_id)`);
    assert.match(sql, /dress_state[\s\S]*?id INTEGER PRIMARY KEY/, `${f} dress_state 应为单行 id 主键`);
    assert.match(sql, /room_state[\s\S]*?id INTEGER PRIMARY KEY/, `${f} room_state 应为单行 id 主键`);
    assert.match(sql, /garden_plots[\s\S]*?slot INTEGER NOT NULL/, `${f} garden_plots 应有 slot`);
    assert.match(sql, /garden_plots[\s\S]*?harvested_at/, `${f} garden_plots 应有 harvested_at`);
    assert.match(sql, /letters[\s\S]*?ref_memory_id INTEGER/, `${f} letters 应有 ref_memory_id`);
    assert.match(sql, /letters[\s\S]*?status TEXT NOT NULL DEFAULT 'new'/, `${f} letters.status 默认应为 'new'`);
    assert.match(sql, /event_log[\s\S]*?favorited INTEGER NOT NULL DEFAULT 0/, `${f} event_log.favorited 默认应为 0`);
    assert.doesNotMatch(sql, /DROP TABLE|DELETE FROM/i, `${f} 迁移只许新增，不应有 DROP/DELETE`);
  }
  const pg = fs.readFileSync(path.join(APP_ROOT, 'db/schema.pg.sql'), 'utf8');
  for (const t of ['heart_ledger', 'collection', 'garden_plots', 'letters', 'event_log']) {
    assert.match(pg, new RegExp(`${t} \\(\\n  id SERIAL PRIMARY KEY`), `PG 版 ${t}.id 应为 SERIAL PRIMARY KEY`);
  }
});

// ---------- 纯函数：花种 / 生长阶段 / 事件 / 信池 / 校验 ----------

test('phase2-纯函数：FLOWERS 花种与生长时长、EVENTS 6 条、LETTER_POOL 8 条', () => {
  assert.deepEqual(Object.keys(FLOWERS), ['daisy', 'rose', 'tulip', 'sunflower']);
  assert.deepEqual(FLOWERS.daisy, { name: '雏菊', growMs: 2 * 3600 * 1000 });
  assert.deepEqual(FLOWERS.rose, { name: '玫瑰', growMs: 6 * 3600 * 1000 });
  assert.deepEqual(FLOWERS.tulip, { name: '郁金香', growMs: 12 * 3600 * 1000 });
  assert.deepEqual(FLOWERS.sunflower, { name: '向日葵', growMs: 24 * 3600 * 1000 });
  assert.equal(EVENTS.length, 6, '心动事件应为 6 条');
  assert.deepEqual(EVENTS.map((e) => e.id), ['cat-cuddle', 'flower-gift', 'pink-rain', 'mystery-note', 'gift-box', 'heart-appear']);
  for (const e of EVENTS) {
    assert.ok(e.title && e.text && e.anim, `事件 ${e.id} 应含 title/text/anim`);
  }
  assert.equal(LETTER_POOL.length, 8, '通用小纸条池应为 8 条');
  for (const l of LETTER_POOL) {
    assert.ok(l.title && l.text, '纸条应含 title/text');
  }
});

test('phase2-纯函数：flowerStage 按真实时间推进——未浇水 seed，浇水后 sprout/bud/bloom', () => {
  const now = new Date('2026-11-11T12:00:00Z');
  const ago = (h) => new Date(now.getTime() - h * 3600 * 1000).toISOString();
  assert.deepEqual(flowerStage('rose', null, now), { stage: 'seed', progress: 0, ready: false });
  assert.deepEqual(flowerStage('rose', ago(1), now), { stage: 'sprout', progress: 0.1667, ready: false }); // 1/6
  assert.deepEqual(flowerStage('rose', ago(3), now), { stage: 'bud', progress: 0.5, ready: false });
  assert.deepEqual(flowerStage('rose', ago(5), now), { stage: 'bud', progress: 0.8333, ready: false }); // [2/3,1) 仍为 bud
  assert.deepEqual(flowerStage('rose', ago(6), now), { stage: 'bloom', progress: 1, ready: true });
  assert.deepEqual(flowerStage('rose', ago(9), now), { stage: 'bloom', progress: 1, ready: true });
  assert.deepEqual(flowerStage('daisy', ago(2), now), { stage: 'bloom', progress: 1, ready: true });
  assert.throws(() => flowerStage('rose2', ago(1), now), (e) => e.code === 'bad_request');
});

test('phase2-纯函数：validateOutfit/validateRoom 只认白名单，非法值抛 bad_request', () => {
  assert.deepEqual(validateOutfit({}), {});
  assert.deepEqual(validateOutfit({ bow: true, bg: 'moon', pose: 'stand' }), { bow: true, bg: 'moon', pose: 'stand' });
  assert.deepEqual(validateOutfit({ hat: null }), { hat: null });
  for (const bad of [{ bg: 'red' }, { pose: 'jump' }, { bow: 1 }, { hat: 'yes' }, { glasses: 0 }, { unknown: 1 }, { bg: null }]) {
    assert.throws(() => validateOutfit(bad), (e) => e.code === 'bad_request', `outfit ${JSON.stringify(bad)} 应抛 bad_request`);
  }
  assert.deepEqual(validateRoom({}), {});
  assert.deepEqual(
    validateRoom({ wallpaper: 'sakura', bed: 'white', plushies: ['bear', 'cat'], lights: true, flowers: false, painting: 'heart', theme: 'park' }),
    { wallpaper: 'sakura', bed: 'white', plushies: ['bear', 'cat'], lights: true, flowers: false, painting: 'heart', theme: 'park' }
  );
  for (const bad of [
    { wallpaper: 'red' }, { bed: 'black' }, { plushies: ['dog'] }, { plushies: 'bear' },
    { lights: 'yes' }, { flowers: 1 }, { painting: 'dog' }, { theme: 'space' }, { unknown: 1 },
  ]) {
    assert.throws(() => validateRoom(bad), (e) => e.code === 'bad_request', `room ${JSON.stringify(bad)} 应抛 bad_request`);
  }
  assert.deepEqual(DEFAULT_OUTFIT, { bow: null, hat: null, scarf: null, dress: null, glasses: null, bg: 'bedroom', pose: 'sit' });
  assert.deepEqual(DEFAULT_ROOM, { wallpaper: 'pink', bed: 'pink', plushies: [], lights: false, flowers: false, painting: 'none', theme: 'home' });
});

// ---------- HTTP：洗澡互动（必须是第一个 HTTP 测试：依赖“今天只做过 bath”的干净起点） ----------

test('phase2-洗澡：bath 奖励 {hearts:2,intimacy:3}、状态清爽，10 秒内重复不重复给；任务 pet 认 interact:bath', async () => {
  resetCat(0);
  const before = await getCat();
  const r = await api(server.base, 'POST', '/api/cat/interact', { action: 'bath' });
  assert.equal(r.status, 200, `bath 应 200：${r.text}`);
  assert.deepEqual(r.json.gained, { hearts: 2, intimacy: 3 });
  assert.equal(r.json.rewarded, true);
  assert.equal(r.json.cat.state, '清爽');
  const again = await api(server.base, 'POST', '/api/cat/interact', { action: 'bath' });
  assert.equal(again.status, 200);
  assert.deepEqual(again.json.gained, { hearts: 0, intimacy: 0 }, '10 秒内重复 bath 不应再给奖励');
  assert.equal(again.json.rewarded, false);
  const row = db.prepare("SELECT * FROM daily_records WHERE date = ? AND kind = 'interact:bath'").get(today);
  assert.ok(row, 'bath 发奖应在 daily_records 写 interact:bath');
  const daily = await api(server.base, 'GET', '/api/daily');
  const pet = daily.json.tasks.find((t) => t.id === 'pet');
  assert.equal(pet.done, true, '今天只做过 bath，任务 pet 也应算完成');
  const after = await getCat();
  assert.equal(after.hearts, before.hearts + 2, 'bath 只发奖一次，爱心应 +2');
});

// ---------- HTTP：进阶 stageUp ----------

test('phase2-进阶：三档阈值逐档 stageUp 并解锁装饰进收藏，未跨档时 stageUp 为 null', async () => {
  resetCat(0);
  const no = await api(server.base, 'POST', '/api/cat/interact', { action: 'sleep' });
  assert.equal(no.status, 200);
  assert.equal(no.json.stageUp, null, '亲密度 0+2 未跨档，stageUp 应为 null');
  resetCat(28);
  const a = await api(server.base, 'POST', '/api/cat/interact', { action: 'pet' });
  assert.equal(a.status, 200, `pet 应 200：${a.text}`);
  assert.deepEqual(a.json.stageUp, { from: '初次见面', to: '熟悉阶段', unlock: '蝴蝶结' });
  assert.equal(a.json.cat.stage, '熟悉阶段');
  resetCat(78);
  const b = await api(server.base, 'POST', '/api/cat/interact', { action: 'bath' });
  assert.deepEqual(b.json.stageUp, { from: '熟悉阶段', to: '亲密阶段', unlock: '小帽子' });
  assert.equal(b.json.cat.stage, '亲密阶段');
  resetCat(148);
  const c = await api(server.base, 'POST', '/api/cat/interact', { action: 'play' });
  assert.deepEqual(c.json.stageUp, { from: '亲密阶段', to: '最好的伙伴', unlock: '小裙子' });
  assert.equal(c.json.cat.stage, '最好的伙伴');
  const decors = db.prepare("SELECT item_id FROM collection WHERE kind = 'decor' ORDER BY id").all().map((x) => x.item_id);
  assert.deepEqual(decors, ['蝴蝶结', '小帽子', '小裙子'], '三档解锁装饰都应写进 collection');
});

// ---------- HTTP：记账 ----------

test('phase2-记账：每次爱心变化都有 ledger 行；/api/cat/ledger 返回最近记账', async () => {
  resetCat(0);
  const s = await api(server.base, 'POST', '/api/cat/interact', { action: 'sleep' });
  assert.equal(s.status, 200);
  let rows = await ledgerTop(3);
  assert.equal(rows[0].delta, 1);
  assert.equal(rows[0].reason, 'interact:sleep');
  // 任务领奖（假日期 + 直接造的完成记录）
  db.prepare("INSERT INTO daily_records (date, kind, payload, created_at) VALUES (?, 'interact:pet', '{}', ?)").run(D_TASK, new Date().toISOString());
  const claim = await api(server.base, 'POST', '/api/daily/tasks/pet/claim', { date: D_TASK });
  assert.equal(claim.status, 200, `领任务应 200：${claim.text}`);
  rows = await ledgerTop(3);
  assert.equal(rows[0].delta, 3);
  assert.equal(rows[0].reason, 'task:pet');
  // 惊喜（挑一个有爱心的假日期）
  assert.ok(D_SURPRISE, '应在 2032-04 找到有爱心的惊喜日期');
  const reward = seededPick(SURPRISE_POOL, `surprise:${D_SURPRISE}`);
  assert.ok(reward.hearts > 0, '挑出的惊喜日期奖励应带爱心');
  const sur = await api(server.base, 'POST', '/api/daily/surprise', { date: D_SURPRISE });
  assert.equal(sur.status, 200, `领惊喜应 200：${sur.text}`);
  rows = await ledgerTop(3);
  assert.equal(rows[0].delta, reward.hearts);
  assert.equal(rows[0].reason, 'surprise');
  // limit 参数
  const two = await ledgerTop(2);
  assert.equal(two.length, 2, 'limit=2 应只回 2 行');
  assert.ok(two[0].id > two[1].id, '应按 id 倒序');
});

// ---------- HTTP：换装 / 房间 ----------

test('phase2-换装：非法值 400，合法保存后回读一致，未传字段保持原值', async () => {
  const def = await api(server.base, 'GET', '/api/cat/outfit');
  assert.equal(def.status, 200);
  assert.deepEqual(def.json, DEFAULT_OUTFIT, '默认 outfit 应为 DEFAULT_OUTFIT');
  for (const bad of [{ bg: 'red' }, { pose: 'jump' }, { bow: 'yes' }, { hat: 1 }, { unknown: 1 }]) {
    const r = await api(server.base, 'PUT', '/api/cat/outfit', bad);
    assert.equal(r.status, 400, `outfit ${JSON.stringify(bad)} 应 400，实际 ${r.status}`);
    assert.equal(r.json.error, 'bad_request');
  }
  const put = await api(server.base, 'PUT', '/api/cat/outfit', { bow: true, bg: 'starry', pose: 'lie' });
  assert.equal(put.status, 200, `合法换装应 200：${put.text}`);
  assert.deepEqual(put.json, { bow: true, hat: null, scarf: null, dress: null, glasses: null, bg: 'starry', pose: 'lie' });
  const read = await api(server.base, 'GET', '/api/cat/outfit');
  assert.deepEqual(read.json, put.json, 'GET 应读回刚保存的 outfit');
  const patch = await api(server.base, 'PUT', '/api/cat/outfit', { hat: true });
  assert.equal(patch.status, 200);
  assert.equal(patch.json.bow, true, '只传 hat 时 bow 应保持 true');
  assert.equal(patch.json.bg, 'starry', '只传 hat 时 bg 应保持 starry');
  assert.equal(patch.json.hat, true);
});

test('phase2-房间：非法值 400，合法保存后回读一致', async () => {
  const def = await api(server.base, 'GET', '/api/room');
  assert.equal(def.status, 200);
  assert.deepEqual(def.json, DEFAULT_ROOM, '默认 room 应为 DEFAULT_ROOM');
  for (const bad of [{ wallpaper: 'red' }, { bed: 'black' }, { plushies: ['dog'] }, { plushies: 'bear' }, { lights: 'yes' }, { painting: 'dog' }, { theme: 'space' }]) {
    const r = await api(server.base, 'PUT', '/api/room', bad);
    assert.equal(r.status, 400, `room ${JSON.stringify(bad)} 应 400，实际 ${r.status}`);
    assert.equal(r.json.error, 'bad_request');
  }
  const room = { wallpaper: 'sakura', bed: 'white', plushies: ['bear', 'cat'], lights: true, flowers: true, painting: 'heart', theme: 'park' };
  const put = await api(server.base, 'PUT', '/api/room', room);
  assert.equal(put.status, 200, `合法房间应 200：${put.text}`);
  assert.deepEqual(put.json, room);
  const read = await api(server.base, 'GET', '/api/room');
  assert.deepEqual(read.json, room, 'GET 应读回刚保存的 room');
});

// ---------- HTTP：花园 ----------

test('phase2-花园：未浇水不生长、浇水后按时间推进、收获奖励与花盆解锁', async () => {
  const hearts0 = (await getCat()).hearts;
  let g = await api(server.base, 'GET', '/api/garden');
  assert.equal(g.status, 200);
  assert.equal(g.json.plots.length, 3);
  assert.ok(g.json.plots.every((p) => p.stage === 'empty' && p.flower === null && p.ready === false), '初始 3 槽都应为空');
  assert.deepEqual(g.json.pots, [
    { id: 'clay', name: '陶土花盆', unlocked: true },
    { id: 'pink', name: '粉色花盆', unlocked: false },
    { id: 'gold', name: '金色花盆', unlocked: false },
  ]);
  assert.equal(g.json.harvests, 0);
  // 非法
  assert.equal((await api(server.base, 'POST', '/api/garden/plant', { slot: 0, flower: 'rose2' })).status, 400);
  assert.equal((await api(server.base, 'POST', '/api/garden/plant', { slot: 5, flower: 'rose' })).status, 400);
  assert.equal((await api(server.base, 'POST', '/api/garden/water', { slot: 1 })).status, 404);
  assert.equal((await api(server.base, 'POST', '/api/garden/harvest', { slot: 1 })).status, 404);
  // 种雏菊：未浇水 seed，收获应 400 not_ready
  const plant = await api(server.base, 'POST', '/api/garden/plant', { slot: 0, flower: 'daisy' });
  assert.equal(plant.status, 200, `种花应 200：${plant.text}`);
  assert.equal(plant.json.stage, 'seed');
  assert.equal((await api(server.base, 'POST', '/api/garden/plant', { slot: 0, flower: 'rose' })).status, 409, '槽位已有花时再种应 409');
  g = await api(server.base, 'GET', '/api/garden');
  assert.equal(g.json.plots[0].stage, 'seed');
  assert.equal(g.json.plots[0].progress, 0);
  assert.equal(g.json.plots[0].ready, false);
  const early = await api(server.base, 'POST', '/api/garden/harvest', { slot: 0 });
  assert.equal(early.status, 400, '未长好收获应 400');
  assert.equal(early.json.error, 'not_ready');
  // 浇水 + 注入 3 小时前（雏菊 2h）→ bloom
  const w = await api(server.base, 'POST', '/api/garden/water', { slot: 0 });
  assert.equal(w.status, 200, `浇水应 200：${w.text}`);
  db.prepare('UPDATE garden_plots SET watered_at = ? WHERE slot = 0 AND harvested_at IS NULL').run(hoursAgo(3));
  g = await api(server.base, 'GET', '/api/garden');
  assert.equal(g.json.plots[0].stage, 'bloom');
  assert.equal(g.json.plots[0].progress, 1);
  assert.equal(g.json.plots[0].ready, true);
  // 收获第 1 次
  const h1 = await api(server.base, 'POST', '/api/garden/harvest', { slot: 0 });
  assert.equal(h1.status, 200, `收获应 200：${h1.text}`);
  assert.equal(h1.json.hearts, 2);
  assert.equal(h1.json.decor, '花朵·雏菊');
  assert.equal(h1.json.harvests, 1);
  assert.equal(h1.json.pots[1].unlocked, false, '1 次收获不应解锁粉色花盆');
  assert.equal((await getCat()).hearts, hearts0 + 2, '收获 1 次爱心应 +2');
  const led = await ledgerTop(2);
  assert.equal(led[0].delta, 2);
  assert.equal(led[0].reason, 'garden:harvest');
  const col = db.prepare("SELECT * FROM collection WHERE kind = 'decor' AND item_id = '花朵·雏菊'").get();
  assert.ok(col, '收获应把花朵装饰写进收藏');
  // 生长阶段：向日葵未浇水 seed；玫瑰浇水 3h/6h bud；郁金香浇水 2h/12h sprout
  await api(server.base, 'POST', '/api/garden/plant', { slot: 0, flower: 'sunflower' });
  await api(server.base, 'POST', '/api/garden/plant', { slot: 1, flower: 'rose' });
  await api(server.base, 'POST', '/api/garden/plant', { slot: 2, flower: 'tulip' });
  await api(server.base, 'POST', '/api/garden/water', { slot: 1 });
  await api(server.base, 'POST', '/api/garden/water', { slot: 2 });
  db.prepare('UPDATE garden_plots SET watered_at = ? WHERE slot = 1 AND harvested_at IS NULL').run(hoursAgo(3));
  db.prepare('UPDATE garden_plots SET watered_at = ? WHERE slot = 2 AND harvested_at IS NULL').run(hoursAgo(2));
  g = await api(server.base, 'GET', '/api/garden');
  assert.equal(g.json.plots[0].stage, 'seed', '未浇水的向日葵应为 seed');
  assert.equal(g.json.plots[0].progress, 0);
  assert.equal(g.json.plots[1].stage, 'bud', '玫瑰 3h/6h 应为 bud');
  assert.ok(Math.abs(g.json.plots[1].progress - 0.5) < 0.01);
  assert.equal(g.json.plots[2].stage, 'sprout', '郁金香 2h/12h 应为 sprout');
  assert.ok(Math.abs(g.json.plots[2].progress - 2 / 12) < 0.01);
  // 玫瑰注入 7h 前 → bloom，收获第 2 次
  db.prepare('UPDATE garden_plots SET watered_at = ? WHERE slot = 1 AND harvested_at IS NULL').run(hoursAgo(7));
  const h2 = await api(server.base, 'POST', '/api/garden/harvest', { slot: 1 });
  assert.equal(h2.status, 200);
  assert.equal(h2.json.harvests, 2);
  assert.equal(h2.json.decor, '花朵·玫瑰');
  // 郁金香注入 13h 前 → bloom，收获第 3 次，解锁粉色花盆
  db.prepare('UPDATE garden_plots SET watered_at = ? WHERE slot = 2 AND harvested_at IS NULL').run(hoursAgo(13));
  const h3 = await api(server.base, 'POST', '/api/garden/harvest', { slot: 2 });
  assert.equal(h3.status, 200);
  assert.equal(h3.json.harvests, 3);
  assert.equal(h3.json.pots[1].unlocked, true, '累计 3 次收获应解锁粉色花盆');
  assert.equal(h3.json.pots[2].unlocked, false, '3 次收获不应解锁金色花盆');
  // 向日葵注入 25h 前 → bloom，收获第 4 次
  db.prepare('UPDATE garden_plots SET watered_at = ? WHERE slot = 0 AND harvested_at IS NULL').run(hoursAgo(25));
  const h4 = await api(server.base, 'POST', '/api/garden/harvest', { slot: 0 });
  assert.equal(h4.status, 200);
  assert.equal(h4.json.harvests, 4);
  assert.equal(h4.json.decor, '花朵·向日葵');
  // 再收 4 次（雏菊循环），累计 8 次，解锁金色花盆
  for (let i = 0; i < 4; i++) {
    const slot = [1, 2, 0, 1][i];
    const pl = await api(server.base, 'POST', '/api/garden/plant', { slot, flower: 'daisy' });
    assert.equal(pl.status, 200, `第 ${5 + i} 次收获前种花应成功`);
    db.prepare('UPDATE garden_plots SET watered_at = ? WHERE slot = ? AND harvested_at IS NULL').run(hoursAgo(3), slot);
    const hv = await api(server.base, 'POST', '/api/garden/harvest', { slot });
    assert.equal(hv.status, 200, `第 ${5 + i} 次收获应成功`);
    assert.equal(hv.json.harvests, 5 + i);
  }
  g = await api(server.base, 'GET', '/api/garden');
  assert.equal(g.json.harvests, 8);
  assert.equal(g.json.pots[2].unlocked, true, '累计 8 次收获应解锁金色花盆');
  assert.equal((await getCat()).hearts, hearts0 + 16, '8 次花园收获应共 +16 爱心');
});

// ---------- HTTP：转盘收藏 ----------

test('phase2-转盘：非爱心奖进收藏（collected），爱心奖 collected 为 null 且记账', async () => {
  let sawNonHeart = false;
  let sawHeart = false;
  for (let attempt = 0; attempt < 12 && !(sawNonHeart && sawHeart); attempt++) {
    const r = await api(server.base, 'POST', '/api/games/wheel', {});
    assert.equal(r.status, 200, `转盘应 200：${r.text}`);
    assert.ok('collected' in r.json, '转盘返回应含 collected');
    const prize = r.json.prize;
    if (prize.hearts) {
      sawHeart = true;
      assert.equal(r.json.collected, null, '爱心奖 collected 应为 null');
      const led = await ledgerTop(2);
      assert.equal(led[0].reason, 'wheel', '爱心奖应记账 reason=wheel');
      assert.equal(led[0].delta, prize.hearts);
    } else {
      sawNonHeart = true;
      assert.deepEqual(r.json.collected, { kind: 'sticker', item_id: prize.id });
      const row = db.prepare("SELECT * FROM collection WHERE kind = 'sticker' AND item_id = ?").get(prize.id);
      assert.ok(row, `非爱心奖 ${prize.id} 应写进收藏`);
    }
    if (!(sawNonHeart && sawHeart)) await sleep(3100);
  }
  assert.ok(sawNonHeart, '12 次内应至少转到一次非爱心奖');
  assert.ok(sawHeart, '12 次内应至少转到一次爱心奖');
});

// ---------- HTTP：心动事件 ----------

test('phase2-心动事件：每天上限 5 次，超了 409 event_limit；收藏写 event_log', async () => {
  const seen = new Set();
  for (let i = 0; i < 5; i++) {
    const r = await api(server.base, 'GET', '/api/events/next');
    assert.equal(r.status, 200, `第 ${i + 1} 次事件应 200：${r.text}`);
    assert.ok(EVENTS.some((e) => e.id === r.json.id), `事件 id 应在 6 条内：${r.json.id}`);
    assert.ok(r.json.title && r.json.text && r.json.anim, '事件应含 title/text/anim');
    seen.add(r.json.id);
  }
  const over = await api(server.base, 'GET', '/api/events/next');
  assert.equal(over.status, 409, '第 6 次应 409');
  assert.equal(over.json.error, 'event_limit');
  const oneId = [...seen][0];
  const fav = await api(server.base, 'POST', `/api/events/${oneId}/favorite`, { favorite: true });
  assert.equal(fav.status, 200, `收藏应 200：${fav.text}`);
  assert.equal(fav.json.favorited, true);
  const row = db.prepare('SELECT * FROM event_log WHERE event_id = ? ORDER BY id DESC').get(oneId);
  assert.ok(row && row.favorited === 1, '收藏应写进 event_log.favorited');
  const unfav = await api(server.base, 'POST', `/api/events/${oneId}/favorite`, { favorite: false });
  assert.equal(unfav.status, 200);
  assert.equal(unfav.json.favorited, false);
  // 从未抽到过的事件也可以直接收藏（补记一条 event_log）
  const neverDrawn = EVENTS.find((e) => !seen.has(e.id));
  if (neverDrawn) {
    const f2 = await api(server.base, 'POST', `/api/events/${neverDrawn.id}/favorite`, { favorite: true });
    assert.equal(f2.status, 200);
    const row2 = db.prepare('SELECT * FROM event_log WHERE event_id = ? ORDER BY id DESC').get(neverDrawn.id);
    assert.ok(row2 && row2.favorited === 1, '未抽到过的事件收藏也应落库');
  }
  const bad = await api(server.base, 'POST', '/api/events/no-such-event/favorite', { favorite: true });
  assert.equal(bad.status, 404, '未知事件收藏应 404');
});

// ---------- HTTP：神秘信箱 ----------

test('phase2-信箱：无 confirmed 记忆时只出通用池、内容不含记忆原文；保存/删除走 status', async () => {
  const seed = await api(server.base, 'POST', '/api/memories', {
    content: 'PHASE2-LETTER-TEST-记忆原文-XYZ', category: '日常',
  });
  assert.equal(seed.status, 201, `种子记忆应 201：${seed.text}`);
  seedMemoryId = seed.json.id;
  assert.equal(seed.json.status, 'active');
  const drawn = [];
  for (let i = 0; i < 3; i++) {
    const r = await api(server.base, 'POST', '/api/letters/draw', {});
    assert.equal(r.status, 201, `抽信应 201：${r.text}`);
    assert.equal(r.json.source, 'generic', '无 confirmed 记忆时只应出通用池');
    assert.equal(r.json.status, 'new');
    assert.equal(r.json.ref_memory_id, null);
    assert.ok(!r.json.content.includes('PHASE2-LETTER-TEST-记忆原文-XYZ'), '通用池内容不得含记忆原文');
    assert.ok(LETTER_POOL.some((x) => x.text === r.json.content), '通用池内容应来自 LETTER_POOL');
    drawn.push(r.json);
  }
  const list = await api(server.base, 'GET', '/api/letters');
  assert.equal(list.status, 200);
  const ids = list.json.map((x) => x.id);
  assert.ok(drawn.every((d) => ids.includes(d.id)), '抽到的信应立即落库并出现在列表里');
  assert.ok(list.json.every((x) => x.status !== 'deleted'), '列表里不应有已删除的信');
  // 保存第一封
  const save = await api(server.base, 'POST', `/api/letters/${drawn[0].id}/save`, {});
  assert.equal(save.status, 200, `保存应 200：${save.text}`);
  assert.equal(save.json.status, 'saved');
  const list2 = await api(server.base, 'GET', '/api/letters');
  assert.ok(list2.json.some((x) => x.id === drawn[0].id && x.status === 'saved'), '保存后列表里仍可见且 status 为 saved');
  // 删除第二封
  const del = await api(server.base, 'POST', `/api/letters/${drawn[1].id}/delete`, {});
  assert.equal(del.status, 200, `删除应 200：${del.text}`);
  assert.equal(del.json.status, 'deleted');
  const list3 = await api(server.base, 'GET', '/api/letters');
  assert.ok(!list3.json.some((x) => x.id === drawn[1].id), '删除后列表里不应再出现');
  assert.equal((await api(server.base, 'POST', '/api/letters/999999/save', {})).status, 404, '不存在的信保存应 404');
});

test('phase2-信箱：已确认记忆可进 AI 信（原文引用、不改写）；取消确认后不再出 AI 信', async () => {
  // POST 的 status:'confirmed' 写法应落到 confirmed 列，status 本身仍为 active
  const seed = await api(server.base, 'POST', '/api/memories', {
    content: 'PHASE2-LETTER-AI-记忆原文-ABC', category: '日常', status: 'confirmed',
  });
  assert.equal(seed.status, 201, `种子记忆应 201：${seed.text}`);
  assert.equal(seed.json.confirmed, 1, 'status 为 confirmed 时 confirmed 列应为 1');
  assert.equal(seed.json.status, 'active', 'status 本身仍应为 active（CHECK 约束）');
  const myId = seed.json.id;
  try {
    let sawAi = null;
    for (let i = 0; i < 12 && !sawAi; i++) {
      const r = await api(server.base, 'POST', '/api/letters/draw', {});
      assert.equal(r.status, 201, `抽信应 201：${r.text}`);
      if (r.json.source === 'ai') sawAi = r.json;
    }
    assert.ok(sawAi, '12 次内应至少抽到一次 AI 信（每次 50% 概率）');
    assert.equal(sawAi.ref_memory_id, myId, 'AI 信应指回这条已确认记忆');
    assert.ok(sawAi.content.includes('小猪记得：PHASE2-LETTER-AI-记忆原文-ABC'), 'AI 信只能原文引用，不许改写');
    // 取消确认后 AI 分支应消失：PUT confirmed=0，再抽 6 次应全是通用池
    const put = await api(server.base, 'PUT', `/api/memories/${myId}`, { confirmed: 0 });
    assert.equal(put.status, 200, `取消确认应 200：${put.text}`);
    assert.equal(put.json.confirmed, 0, 'PUT confirmed=0 后应为 0');
    for (let i = 0; i < 6; i++) {
      const r = await api(server.base, 'POST', '/api/letters/draw', {});
      assert.equal(r.json.source, 'generic', '取消确认后不应再出 AI 信');
      assert.ok(!r.json.content.includes('PHASE2-LETTER-AI-记忆原文-ABC'), '通用池内容不得含记忆原文');
    }
  } finally {
    await api(server.base, 'DELETE', `/api/memories/${myId}`, {});
  }
});

// ---------- HTTP：备份 ----------

test('phase2-备份：BACKUP_TABLES 含 11 张猫咪/第二阶段表', async () => {
  const r = await api(server.base, 'POST', '/api/backup', {});
  assert.equal(r.status, 200, `备份应 200：${r.text}`);
  for (const t of ['cat_state', 'daily_records', 'game_scores', 'mood_entries', 'heart_ledger', 'collection', 'dress_state', 'room_state', 'garden_plots', 'letters', 'event_log']) {
    assert.ok(t in r.json.tables, `备份应含表 ${t}`);
    assert.ok(Array.isArray(r.json.tables[t]), `备份表 ${t} 应为数组`);
  }
});
