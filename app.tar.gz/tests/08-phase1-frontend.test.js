// 08-phase1-frontend.test.js — V4.0 第一阶段前端静态检查（不跑服务）：
// - index.html 含 5 个导航按钮与三个游戏容器，引用 mimi.js
// - mimi.js 与 app.js 能 node --check 通过
// - 无外链：四个前端文件里无 http://、无 https://cdn、无 <img src="http
// - style.css 含 5 个场景类与粉色变量
// - normalizePersona 对 { sections: [...] } 返回九节且 content 不含 [object Object]
// - app.js 的 auth 流程（checkAuthStatus/openAuth/submitAuth）仍在，mimi.js 不碰 auth
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { execFileSync } from 'node:child_process';
import { APP_ROOT } from './helpers.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');

const SEED_TITLES = ['核心身份', '性格特点', '思维逻辑', '语言风格', '情绪反应', '行为习惯', '关系认知', '真实聊天示例', '人物行为限制'];

// 按括号配对从源码里抠出一段声明（normalizePersona 里有嵌套花括号，正则抠不准）。
function extractBalanced(src, marker, open, close) {
  const s = src.indexOf(marker);
  assert.ok(s >= 0, '源码里找不到 ' + marker);
  let depth = 0;
  for (let i = s; i < src.length; i++) {
    if (src[i] === open) depth++;
    else if (src[i] === close) {
      depth--;
      if (depth === 0) return src.slice(s, i + 1);
    }
  }
  throw new Error('括号不配对：' + marker);
}

function loadPersonaFns() {
  const src = read('public/app.js');
  const ctx = {};
  vm.createContext(ctx);
  const defs = extractBalanced(src, 'const PERSONA_DEFAULTS = ', '[', ']')
    .replace('const PERSONA_DEFAULTS', 'globalThis.PERSONA_DEFAULTS');
  const fn = extractBalanced(src, 'function normalizePersona(data) ', '{', '}');
  vm.runInContext(defs + ';\n' + fn, ctx);
  return ctx;
}

test('V4 导航：index.html 含 5 个导航按钮与 5 页，引用 mimi.js', () => {
  const html = read('public/index.html');
  const navBtns = html.match(/class="nav-btn[^"]*" data-page="(home|chat|memories|park|mine)"/g) || [];
  assert.strictEqual(navBtns.length, 5, '应有 5 个导航按钮，实际 ' + navBtns.length);
  for (const p of ['home', 'chat', 'memories', 'park', 'mine']) {
    assert.match(html, new RegExp(`id="page-${p}"`), `缺少页面 section #page-${p}`);
    assert.match(html, new RegExp(`data-page="${p}"`), `导航缺少 data-page="${p}"`);
  }
  assert.match(html, /<script src="mimi\.js"><\/script>/, 'index.html 须引用 mimi.js');
  assert.match(html, /<section class="page scene-chat" id="page-chat"/, '聊天页须为 section#page-chat');
  for (const id of ['messages', 'input', 'sendBtn', 'settingsOverlay', 'authOverlay', 'toast']) {
    assert.match(html, new RegExp(`id="${id}"`), `聊天/设置关键 id 丢失：${id}`);
  }
});

test('V4 游戏：三个游戏容器齐全', () => {
  const html = read('public/index.html');
  for (const id of ['game-memory', 'game-wheel', 'game-fortune']) {
    assert.match(html, new RegExp(`id="${id}"`), `缺少游戏容器 #${id}`);
  }
  for (const id of ['memoryBoard', 'memoryStartBtn', 'memoryRestartBtn', 'memoryEndBtn', 'wheelSpinBtn', 'wheel', 'fortuneBtn', 'fortuneText']) {
    assert.match(html, new RegExp(`id="${id}"`), `缺少游戏控件 #${id}`);
  }
  const mimi = read('public/mimi.js');
  for (const path of ['/api/games/score', '/api/games/scores', '/api/games/wheel', '/api/daily/fortune']) {
    assert.ok(mimi.includes(path), 'mimi.js 须按契约调用 ' + path);
  }
});

test('V4 猫咪与每日：首页含猫咪 SVG、互动按钮、心情、任务、盲盒', () => {
  const html = read('public/index.html');
  assert.match(html, /<svg[^>]*class="cat-svg"/, '首页须有原创内联 SVG 小猫');
  for (const a of ['pet', 'feed', 'sleep', 'play']) {
    assert.match(html, new RegExp(`data-cat-action="${a}"`), `缺少猫咪互动 ${a}`);
  }
  for (const mood of ['开心', '难过', '委屈', '烦躁', '想被夸', '想撒娇']) {
    assert.match(html, new RegExp(`data-mood="${mood}"`), `缺少心情选项 ${mood}`);
  }
  for (const id of ['homeClock', 'catHearts', 'catIntimacy', 'dailyTasksList', 'surpriseBtn', 'homeRecentMemories', 'sceneThemeSelect', 'myGameScores', 'myDailyRecords']) {
    assert.match(html, new RegExp(`id="${id}"`), `缺少首页/我的页元素 #${id}`);
  }
  const mimi = read('public/mimi.js');
  for (const path of ['/api/cat', '/api/cat/interact', '/api/daily', '/api/daily/surprise', '/api/mood', '/api/memories', '/api/sessions']) {
    assert.ok(mimi.includes(path), 'mimi.js 须按契约调用 ' + path);
  }
});

test('V4 语法：app.js 与 mimi.js 均能 node --check 通过', () => {
  for (const f of ['public/app.js', 'public/mimi.js']) {
    execFileSync('node', ['--check', path.join(APP_ROOT, f)], { stdio: 'pipe' });
  }
});

test('V4 无外链：四个前端文件无 http://、无 https://cdn、无 <img src="http', () => {
  for (const f of ['public/index.html', 'public/app.js', 'public/mimi.js', 'public/style.css']) {
    const src = read(f);
    assert.doesNotMatch(src, /http:\/\//, `${f} 不得含 http:// 外链`);
    assert.doesNotMatch(src, /https:\/\/cdn/i, `${f} 不得含 https://cdn`);
    assert.doesNotMatch(src, /<img[^>]+src="http/i, `${f} 不得有外链 <img>`);
    assert.doesNotMatch(src, /<script[^>]+src="https?:\/\//i, `${f} 不得引用外部脚本`);
    assert.doesNotMatch(src, /<link[^>]+href="https?:\/\//i, `${f} 不得引用外部样式`);
  }
});

test('V4 视觉：style.css 含 5 个场景类与粉色变量', () => {
  const css = read('public/style.css');
  for (const cls of ['scene-home', 'scene-chat', 'scene-memories', 'scene-park', 'scene-mine']) {
    assert.match(css, new RegExp(`\\.${cls}\\b`), `style.css 缺少场景类 .${cls}`);
  }
  for (const cls of ['scene-home', 'scene-chat', 'scene-memories', 'scene-park', 'scene-mine']) {
    assert.match(css, new RegExp(`\\.${cls}\\s*\\{[^}]*linear-gradient`), `场景 .${cls} 须有自己的渐变背景`);
  }
  assert.match(css, /--mimi-pink:\s*#f9a8c0/, 'style.css 须定义樱花粉变量 --mimi-pink');
  assert.match(css, /--mimi-cream/, 'style.css 须定义奶油白变量');
  assert.match(css, /--mimi-lav/, 'style.css 须定义薰衣草紫变量');
  assert.match(css, /@media \(prefers-color-scheme: dark\)/, '深色模式跟随系统的 @media 规则须继续生效');
});

test('人格 bug 修复：normalizePersona 认 { sections: [...] }，返回九节且无 [object Object]', () => {
  const ctx = loadPersonaFns();
  const sections = SEED_TITLES.map((t, i) => ({
    key: String.fromCharCode(65 + i), title: t, content: '正文' + i + '：' + 'x'.repeat(20),
  }));
  ctx.__in = { sections };
  const out = vm.runInContext('normalizePersona(__in)', ctx);
  assert.strictEqual(out.length, 9, '应返回九节，实际 ' + out.length);
  for (let i = 0; i < 9; i++) {
    assert.strictEqual(out[i].key, String.fromCharCode(65 + i));
    assert.strictEqual(out[i].title, SEED_TITLES[i], `第 ${i + 1} 节标题应为 ${SEED_TITLES[i]}`);
    assert.ok(out[i].content && !out[i].content.includes('[object Object]'), `第 ${i + 1} 节 content 不得含 [object Object]`);
    assert.ok(out[i].content.includes('正文' + i), `第 ${i + 1} 节 content 应保留后端原文`);
  }
  // 旧形态仍兼容：纯数组与对象键值
  const arr = vm.runInContext('normalizePersona([{key:"A",title:"核心身份",content:"hello"}])', ctx);
  assert.strictEqual(arr[0].content, 'hello');
  const obj = vm.runInContext('normalizePersona({A:"world"})', ctx);
  assert.strictEqual(obj[0].content, 'world');
});

test('人格兜底标题：PERSONA_DEFAULTS 九条标题与种子一致', () => {
  const ctx = loadPersonaFns();
  // vm 沙箱里的数组与主 realm 原型不同，deepStrictEqual 会误判，改用字符串比较。
  const titles = Array.from(ctx.PERSONA_DEFAULTS, (d) => d.title).join('/');
  assert.strictEqual(titles, SEED_TITLES.join('/'));
  assert.strictEqual(ctx.PERSONA_DEFAULTS.length, 9);
});

test('auth 不动：app.js 保留 auth 流程，mimi.js 不碰 auth', () => {
  const app = read('public/app.js');
  for (const fn of ['function checkAuthStatus()', 'function openAuth(mode)', 'function submitAuth()']) {
    assert.ok(app.includes(fn), 'app.js 须保留 ' + fn);
  }
  const mimi = read('public/mimi.js');
  assert.doesNotMatch(mimi, /checkAuthStatus|openAuth|submitAuth|authOverlay/, 'mimi.js 不得改 auth 流程');
});

test('头像更换：public/assets/avatar.jpg 存在且为方形 JPEG，聊天渲染引用它', () => {
  const p = path.join(APP_ROOT, 'public/assets/avatar.jpg');
  assert.ok(fs.existsSync(p), '缺少 public/assets/avatar.jpg');
  const buf = fs.readFileSync(p);
  assert.ok(buf.length > 5000, '头像文件过小，疑似损坏：' + buf.length + ' 字节');
  assert.strictEqual(buf[0], 0xff, '头像不是 JPEG（缺少 SOI 标记）');
  assert.strictEqual(buf[1], 0xd8, '头像不是 JPEG（缺少 SOI 标记）');
  // 校验方形：解析 JPEG SOF0 段读宽高（不引新依赖）
  let i = 2, w = 0, h = 0;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xff) { i++; continue; }
    const marker = buf[i + 1];
    if (marker === 0xc0 || marker === 0xc2) { h = buf.readUInt16BE(i + 5); w = buf.readUInt16BE(i + 7); break; }
    const len = buf.readUInt16BE(i + 2);
    i += 2 + len;
  }
  assert.ok(w > 0 && w === h, `头像应为方形，实际 ${w}x${h}`);
  const html = read('public/index.html');
  const refs = html.match(/src="assets\/avatar\.jpg"/g) || [];
  assert.ok(refs.length >= 3, 'index.html 顶栏/输入中/资料大头像三处都应用 avatar.jpg，实际 ' + refs.length + ' 处');
  const fallbacks = html.match(/onerror="this\.outerHTML='🐷'"/g) || [];
  assert.ok(fallbacks.length >= 3, '头像加载失败须兜底回 🐷 emoji，实际 ' + fallbacks.length + ' 处');
  const app = read('public/app.js');
  assert.ok(app.includes('msg-avatar'), 'app.js 消息行须加 msg-avatar');
  assert.ok(app.includes('assets/avatar.jpg'), 'app.js 消息行头像须引用 assets/avatar.jpg');
  const css = read('public/style.css');
  assert.match(css, /\.msg-avatar\s*\{/, 'style.css 须定义 .msg-avatar');
  assert.match(css, /\.avatar img\s*\{[^}]*object-fit:\s*cover/, 'style.css 须定义 .avatar img 圆形裁剪');
  // 猫咪吉祥物不动：首页仍是原创 SVG 小猫，不被照片头像替换
  assert.match(html, /<svg[^>]*class="cat-svg"/, '猫咪吉祥物仍须为 SVG，不被头像替换');
});

test('奖励格式化：formatReward 把对象奖品转成文本，杜绝 [object Object]', () => {
  const src = read('public/mimi.js');
  const ctx = {};
  vm.createContext(ctx);
  const fn = extractBalanced(src, 'function formatReward(r) ', '{', '}');
  vm.runInContext(fn + ';', ctx);
  // 参数以 JSON 字面量形式在沙箱内求值，避免跨 realm 传对象
  const run = (v) => vm.runInContext('formatReward(' + JSON.stringify(v) + ')', ctx);
  assert.strictEqual(run({ hearts: 3 }), '爱心 +3');
  const surprise = run({ kind: 'note', title: '小纸条', text: '今天也要开开心心哦', hearts: 0 });
  assert.ok(surprise.includes('小纸条') && surprise.includes('今天也要开开心心哦'), '盲盒奖励应含标题与正文：' + surprise);
  assert.doesNotMatch(surprise, /\[object Object\]/);
  const wheel = run({ id: 'heart10', label: '爱心+10', hearts: 10 });
  assert.ok(wheel.includes('爱心+10') && wheel.includes('爱心 +10'), '转盘奖品应含 label 与得爱心：' + wheel);
  assert.strictEqual(run('小任务'), '小任务');
  // 源码里不得再有对象直接拼字符串的旧写法
  assert.doesNotMatch(src, /'奖励：' \+ t\.reward;/, '任务奖励不得直接拼 t.reward 对象');
  assert.doesNotMatch(src, /\+ \(surprise\.reward \|\|/, '盲盒文本不得直接拼 surprise.reward 对象');
  assert.doesNotMatch(src, /textContent = '抽中：' \+ prize \+/, '转盘结果不得直接拼 prize 对象');
  assert.doesNotMatch(src, /escM\(d\.surprise\.reward/, '我的页盲盒不得直接拼 surprise.reward 对象');
  // 互动反馈按后端实际返回形状读：{gained:{hearts}}，无 message 字段时用本地文案
  assert.ok(src.includes('r.gained && r.gained.hearts'), 'catInteract 须按 {gained:{hearts}} 读奖励');
  assert.ok(src.includes('CAT_ACTION_MESSAGE'), 'catInteract 须有本地互动文案兜底');
});
