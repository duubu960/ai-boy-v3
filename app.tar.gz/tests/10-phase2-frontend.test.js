// 10-phase2-frontend.test.js — V4.0 第二阶段前端 B（房间装扮 / 花园 / 心动事件 / 信箱 / 转盘加深 / 两处修复）
// 静态检查 + jsdom（mock fetch 返回契约数据，不跑服务、不碰后端与数据库）。
// 说明：jsdom 环境没有 AudioContext，测试里先挂最小桩，只验证调用路径，不验证真出声。
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { execFileSync } from 'node:child_process';
import { JSDOM } from 'jsdom';
import { APP_ROOT } from './helpers.js';

const read = (p) => fs.readFileSync(path.join(APP_ROOT, p), 'utf8');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 按括号配对从源码里抠出一段声明（与 08-phase1-frontend.test.js 同款做法）。
function extractBalanced(src, marker, open, close) {
  const s = src.indexOf(marker);
  assert.ok(s >= 0, '源码里找不到 ' + marker);
  let depth = 0;
  for (let i = s; i < src.length; i++) {
    if (src[i] === open) depth++;
    else if (src[i] === close) {
      depth--;
      if (depth === 0) return src.slice(s, i + 1);
    }
  }
  throw new Error('括号不配对：' + marker);
}

/* ================= 静态 ================= */

test('P2B 结构：index.html 含换装/房间/花园/心动事件/信箱卡片与洗澡、音效按钮', () => {
  const html = read('public/index.html');
  for (const id of ['roomCard', 'gardenCard', 'eventCard', 'mailboxCard', 'dressupCard', 'soundToggleBtn']) {
    assert.match(html, new RegExp(`id="${id}"`), `缺少 #${id}`);
  }
  assert.ok(html.includes('data-cat-action="bath"') || html.includes('id="bathBtn"'), '缺少洗澡入口（data-cat-action="bath" 或 #bathBtn）');
  for (const id of ['roomPreview', 'roomWallpaperRow', 'roomBedRow', 'roomPlushRow', 'roomLampBtn', 'roomFlowerBtn', 'roomPaintingRow', 'roomThemeRow', 'gardenSlots', 'gardenPots', 'eventNextBtn', 'eventFavBtn', 'eventCloseBtn', 'eventBody', 'letterDrawBtn', 'letterBody', 'letterList']) {
    assert.match(html, new RegExp(`id="${id}"`), `缺少第二阶段控件 #${id}`);
  }
  assert.match(html, /<script src="mimi\.js"><\/script>/, 'index.html 须引用 mimi.js');
  assert.match(html, /<script src="catfx\.js"><\/script>/, 'index.html 须引用 catfx.js（音效）');
  // 回忆页尾提示已改：不再说信箱是第二/三阶段功能
  assert.doesNotMatch(html, /信箱与信件收藏是第二/, '回忆页尾仍说信箱是第二阶段功能，应已改掉');
  assert.match(html, /纪念日倒计时是第三阶段功能/, '回忆页尾应写明纪念日倒计时是第三阶段功能');
  // 我的页外观设置说明房间主题优先
  assert.match(html, /房间主题优先/, '我的页外观设置须说明房间主题优先');
  // 转盘奖品区下方有收藏说明
  assert.match(html, /抽到的贴纸 \/ 装饰会进入我的收藏，可在换装里使用/, '转盘下方须有“进入我的收藏”说明');
});

test('P2B 语法：app.js、mimi.js、catfx.js 均能 node --check 通过', () => {
  for (const f of ['public/app.js', 'public/mimi.js', 'public/catfx.js']) {
    execFileSync('node', ['--check', path.join(APP_ROOT, f)], { stdio: 'pipe' });
  }
});

test('P2B 无外链：四个前端文件无 http://、无 https://cdn、无 <img src="http（SVG 命名空间字符串除外，它从不被请求）', () => {
  for (const f of ['public/index.html', 'public/app.js', 'public/mimi.js', 'public/style.css']) {
    const src = read(f).replace(/http:\/\/www\.w3\.org\/2000\/svg/g, '');
    assert.doesNotMatch(src, /http:\/\//, `${f} 不得含 http:// 外链`);
    assert.doesNotMatch(src, /https:\/\/cdn/i, `${f} 不得含 https://cdn`);
    assert.doesNotMatch(src, /<img[^>]+src="http/i, `${f} 不得有外链 <img>`);
    assert.doesNotMatch(src, /<script[^>]+src="https?:\/\//i, `${f} 不得引用外部脚本`);
    assert.doesNotMatch(src, /<link[^>]+href="https?:\/\//i, `${f} 不得引用外部样式`);
  }
});

test('P2B 视觉：style.css 含 is-bath、float-up 与房间/花园/事件/信箱相关 class', () => {
  const css = read('public/style.css');
  assert.match(css, /\.is-bath\b/, 'style.css 缺少 .is-bath');
  assert.ok(css.includes('float-up'), 'style.css 缺少 float-up（@keyframes float-up / animation: float-up）');
  assert.match(css, /@keyframes float-up/, 'style.css 须定义 @keyframes float-up');
  for (const cls of ['room-preview', 'room-wp-pink', 'room-wp-sakura', 'room-wp-lavender', 'room-wp-peach', 'room-wp-starry',
    'garden-slot', 'garden-progress', 'garden-pot', '.garden-pot.locked', 'event-anim',
    'anim-cat-cuddle', 'anim-flower-gift', 'anim-pink-rain', 'anim-mystery-note', 'anim-gift-box', 'anim-heart-appear',
    'letter-source', 'letter-text', 'opt-btn']) {
    assert.ok(css.includes(cls), `style.css 缺少 ${cls}`);
  }
  assert.match(css, /@keyframes eventRain/, '粉色雨动画 eventRain 须存在');
  assert.match(css, /@keyframes eventGiftBounce/, '礼物盒弹跳动画 eventGiftBounce 须存在');
  assert.match(css, /@keyframes eventHeartPulse/, '爱心放大脉冲动画 eventHeartPulse 须存在');
});

test('P2B 契约：mimi.js 按约定调房间/花园/事件/信箱后端', () => {
  const mimi = read('public/mimi.js');
  for (const p of ['/api/room', '/api/garden', '/api/garden/plant', '/api/garden/water', '/api/garden/harvest',
    '/api/events/next', '/favorite', '/api/letters/draw', '/api/letters']) {
    assert.ok(mimi.includes(p), 'mimi.js 须按契约调用 ' + p);
  }
  assert.ok(mimi.includes("method: 'PUT'") && mimi.includes('/api/room'), '房间改动须 PUT /api/room 保存');
  assert.ok(mimi.includes('roomTheme ||'), 'applySceneTheme 须以房间主题优先');
});

test('P2B 成绩榜修复：loadScores 不再 JSON.stringify 原始 detail，改走 formatScoreLine', () => {
  const mimi = read('public/mimi.js');
  assert.doesNotMatch(mimi, /JSON\.stringify\(s\.detail\)/, 'loadScores 不得再 JSON.stringify(s.detail)');
  assert.doesNotMatch(mimi, /JSON\.stringify\(detail\)/, '成绩渲染不得再出现 JSON.stringify(detail)');
  assert.ok(mimi.includes('function formatScoreLine'), '须有 formatScoreLine 做可读格式化');
  // 单元级验证：detail 是 JSON 字符串时也能解析成可读文字
  const ctx = {};
  vm.createContext(ctx);
  const src = mimi;
  const gameNames = extractBalanced(src, 'const GAME_NAMES = ', '{', '}').replace('const GAME_NAMES', 'globalThis.GAME_NAMES');
  const parse = extractBalanced(src, 'function parseScoreDetail(detail) ', '{', '}');
  const fmt = extractBalanced(src, 'function formatScoreLine(game, s) ', '{', '}');
  vm.runInContext(gameNames + ';\n' + parse + ';\n' + fmt + ';', ctx);
  const run = (game, s) => vm.runInContext(
    'formatScoreLine(' + JSON.stringify(game) + ', ' + JSON.stringify(s) + ')', ctx);
  const wheel = run('wheel', { score: 10, detail: '{"prize":{"label":"爱心+10","hearts":10}}', created_at: '2026-11-11T10:00:00Z' });
  assert.strictEqual(wheel.title, '幸运转盘 · 得分 10');
  assert.ok(wheel.sub.includes('爱心+10'), '转盘行应含奖品 label：' + wheel.sub);
  const mem = run('memory', { score: 1200, detail: '{"steps":5,"seconds":10}', created_at: '2026-11-11T10:00:00Z' });
  assert.strictEqual(mem.title, '记忆翻牌 · 得分 1200');
  assert.ok(mem.sub.includes('步数 5') && mem.sub.includes('用时 10 秒'), '翻牌行应含步数与用时：' + mem.sub);
  assert.doesNotMatch(wheel.title + wheel.sub + mem.title + mem.sub, /\{"'/, '格式化结果不得含 JSON 原始文本');
});

test('P2B 转盘加深：抽中有 collected 时 toast 补一句“已收入收藏”', () => {
  const mimi = read('public/mimi.js');
  assert.ok(mimi.includes('已收入收藏：'), 'spinWheel 须在 collected 时提示“已收入收藏”');
  assert.ok(mimi.includes('result.collected') || mimi.includes('result && result.collected'), '须从返回里读 collected');
});

test('P2B 恢复修复：app.js 不再用 FormData，改发 JSON { data: { tables } }，非法文件报“这个文件不是有效的备份 JSON”', () => {
  const app = read('public/app.js');
  assert.doesNotMatch(app, /new FormData\(\)/, '恢复不得再用 FormData');
  assert.doesNotMatch(app, /fd\.append\('file'/, '恢复不得再把文件塞进 FormData');
  assert.ok(app.includes("fetch('/api/restore'"), '恢复须调 /api/restore');
  assert.ok(app.includes("'Content-Type': 'application/json'"), '恢复须发 JSON Content-Type');
  assert.ok(app.includes('这个文件不是有效的备份 JSON'), '非法文件须报“这个文件不是有效的备份 JSON”');
  assert.ok(app.includes('restored'), '成功后须用返回的 restored 计数提示恢复了哪些表');
});

/* ================= jsdom ================= */

function resp(status, body, isJson = true) {
  return {
    ok: status >= 200 && status < 300, status,
    headers: { get: (n) => (n.toLowerCase() === 'content-type' ? (isJson ? 'application/json' : 'text/html') : null) },
    json: async () => body,
    text: async () => (typeof body === 'string' ? body : JSON.stringify(body)),
    body: null,
    clone: function () { return this; },
  };
}

const CAT_STATE = { id: 1, state: 'happy', mood: 'happy', intimacy: 0, hearts: 0, level: 1, stage: '初次见面', lastInteractAt: null, lastActions: {}, updatedAt: '2026-11-11T10:00:00Z' };
const DEFAULT_ROOM = { wallpaper: 'pink', bed: 'pink', plushies: ['bear'], lamp: true, flowers: true, painting: 'none', theme: 'home' };
const DEFAULT_GARDEN_SLOTS = [
  { id: 0, flower: 'rose', stage: 'bloom', progress: 100, watered: true },
  { id: 1, flower: null, stage: null, progress: 0 },
  { id: 2, flower: 'daisy', stage: 'sprout', progress: 35, watered: false },
];

function mockFetchFactory(overrides = {}) {
  const calls = [];
  const fetch = async (url, opts = {}) => {
    const method = (opts.method || 'GET').toUpperCase();
    const [p, q] = String(url).split('?');
    calls.push(method + ' ' + p);
    const body = opts.body ? JSON.parse(opts.body) : {};
    const route = method + ' ' + p;
    if (overrides[route]) return overrides[route](body, q);
    if (p === '/api/cat' && method === 'GET') return resp(200, { cat: { ...CAT_STATE } });
    if (p === '/api/cat/interact' && method === 'POST') {
      return resp(200, { cat: { ...CAT_STATE, hearts: 2 }, gained: { hearts: 2, intimacy: 1 } });
    }
    if (p === '/api/cat/outfit' && method === 'GET') return resp(200, { outfit: { bow: false, hat: false, scarf: false, dress: false, glasses: false, bg: 'bedroom', pose: 'sit' } });
    if (p === '/api/cat/outfit' && method === 'PUT') return resp(200, { ok: true });
    if (p === '/api/mood' && method === 'GET') return resp(200, { today: null, recent: [] });
    if (p === '/api/daily' && method === 'GET') return resp(200, { tasks: [], surprise: { claimed: false }, fortune: { drawn: false } });
    if (p === '/api/memories' && method === 'GET') return resp(200, []);
    if (p === '/api/sessions' && method === 'GET') return resp(200, []);
    if (p === '/api/room' && method === 'GET') return resp(200, { room: { ...DEFAULT_ROOM } });
    if (p === '/api/room' && method === 'PUT') return resp(200, { room: { ...DEFAULT_ROOM, ...body } });
    if (p === '/api/garden' && method === 'GET') return resp(200, {
      slots: DEFAULT_GARDEN_SLOTS.map((s) => ({ ...s })),
      pots: [
        { id: 'clay', name: '陶土花盆', emoji: '🪴', unlocked: true, harvests_required: 0 },
        { id: 'pink', name: '粉色花盆', emoji: '🌸', unlocked: false, harvests_required: 3 },
        { id: 'gold', name: '金色花盆', emoji: '🏆', unlocked: false, harvests_required: 10 },
      ],
    });
    if (p === '/api/garden/plant' && method === 'POST') return resp(200, { ok: true, slot: body.slot, flower: body.flower });
    if (p === '/api/garden/water' && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/garden/harvest' && method === 'POST') return resp(200, { ok: true, reward: { hearts: 2 } });
    if (p === '/api/events/next' && method === 'GET') return resp(200, { event: { id: 'ev-1', title: '午后的一阵风', text: '风把一片花瓣吹到了你的窗台上', anim: 'pink-rain' } });
    if (/^\/api\/events\/[^/]+\/favorite$/.test(p) && method === 'POST') return resp(200, { ok: true });
    if (p === '/api/letters/draw' && method === 'POST') return resp(200, { letter: { id: 'l-1', content: '冷死了，记得穿厚一点', source: '来自真实聊天记录', category: '关心对方', date: '2026-11-11T10:00:00Z' } });
    if (p === '/api/letters' && method === 'GET') return resp(200, { letters: [{ id: 'l-1', content: '冷死了，记得穿厚一点', source: '来自真实聊天记录', category: '关心对方', saved: true, created_at: '2026-11-11T10:00:00Z' }] });
    if (/^\/api\/letters\/[^/]+\/save$/.test(p) && method === 'POST') return resp(200, { ok: true });
    if (/^\/api\/letters\/[^/]+$/.test(p) && method === 'DELETE') return resp(200, { ok: true });
    if (p === '/api/games/scores' && method === 'GET') {
      const game = new URLSearchParams(q || '').get('game');
      if (game === 'memory') return resp(200, { scores: [{ score: 1200, detail: '{"steps":5,"seconds":10}', created_at: '2026-11-11T10:00:00Z' }] });
      if (game === 'wheel') return resp(200, { scores: [{ score: 10, detail: '{"prize":{"label":"爱心+10","hearts":10}}', created_at: '2026-11-11T10:00:00Z' }] });
      return resp(200, { scores: [] });
    }
    if (p === '/api/games/wheel' && method === 'POST') return resp(200, { prize: { id: 'heart10', label: '爱心+10', hearts: 10 }, collected: { item_id: 'sticker-heart' }, cat: { ...CAT_STATE }, hearts: 12 });
    if (p === '/api/games/score' && method === 'POST') return resp(201, { id: 1, game: body.game, score: body.score });
    return resp(404, { error: 'not_found' });
  };
  return { fetch, calls };
}

async function makeDom(overrides = {}) {
  const html = read('public/index.html');
  const dom = new JSDOM(html, { url: 'http://127.0.0.1:3199/', runScripts: 'outside-only', pretendToBeVisual: true });
  const { window } = dom;
  // AudioContext 最小桩：只验证调用路径，不验证真出声
  class FakeGain { constructor() { this.gain = { value: 0 }; } connect() {} }
  class FakeOsc { constructor() { this.frequency = { value: 0 }; this.type = 'sine'; } connect() {} start() {} stop() {} }
  class FakeAudioContext {
    constructor() { this.currentTime = 0; this.state = 'running'; this.destination = {}; }
    createOscillator() { return new FakeOsc(); }
    createGain() { return new FakeGain(); }
    resume() { return Promise.resolve(); }
  }
  window.AudioContext = FakeAudioContext;
  window.webkitAudioContext = FakeAudioContext;
  const { fetch, calls } = mockFetchFactory(overrides);
  window.fetch = fetch;
  window.eval(read('public/catfx.js'));
  window.eval(read('public/mimi.js'));
  // 等 DOMContentLoaded 后的 initMimi 与首批 fetch 落定
  await sleep(150);
  return { dom, window, calls };
}
function toastText(window) {
  const t = window.document.getElementById('toast');
  return t ? t.textContent : '';
}

test('P2B 换装：点蝴蝶结按钮后 outfit 状态切换（aria-pressed 与 SVG 配件显隐）', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(150);
  const btn = window.document.querySelector('.dress-acc-btn[data-acc="bow"]');
  assert.ok(btn, '缺少换装按钮 [data-acc="bow"]');
  assert.strictEqual(btn.getAttribute('aria-pressed'), 'false');
  btn.click();
  assert.strictEqual(btn.getAttribute('aria-pressed'), 'true', '点一次后蝴蝶结应为选中');
  const acc = window.document.querySelector('#dressCatSvg .acc-bow');
  assert.ok(acc && acc.style.display === 'block', '蝴蝶结 SVG 配件应显示');
  btn.click();
  assert.strictEqual(btn.getAttribute('aria-pressed'), 'false', '再点一次应取消选中');
});

test('P2B 房间：主题切换改首页 class（房间主题优先于外观选择）', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(150);
  const home = window.document.getElementById('page-home');
  assert.ok(home.className.includes('scene-home'), '房间主题 home 时首页应为 scene-home，实际 ' + home.className);
  const parkBtn = window.document.querySelector('[data-room-theme="park"]');
  assert.ok(parkBtn, '缺少房间主题按钮 [data-room-theme="park"]');
  parkBtn.click();
  assert.ok(home.className.includes('scene-park'), '点梦幻花园后首页 class 应为 scene-park，实际 ' + home.className);
  // 墙纸切换：预览区 class 跟着变
  const sakuraBtn = window.document.querySelector('[data-room-wallpaper="sakura"]');
  sakuraBtn.click();
  assert.ok(window.document.getElementById('roomPreview').className.includes('room-wp-sakura'), '墙纸应切到 room-wp-sakura');
  // 玩偶多选：点小熊取消、点兔子加上
  const bearBtn = window.document.querySelector('[data-room-plush="bear"]');
  bearBtn.click();
  assert.strictEqual(window.document.getElementById('roomPlushBear').style.display, 'none', '取消小熊后预览里不应显示 🧸');
  const bunnyBtn = window.document.querySelector('[data-room-plush="bunny"]');
  bunnyBtn.click();
  assert.notStrictEqual(window.document.getElementById('roomPlushBunny').style.display, 'none', '点兔子后预览里应显示 🐰');
});

test('P2B 花园：开花槽收获按钮可点，收获后 toast 显示奖励', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(200);
  const slots = window.document.querySelectorAll('#gardenSlots .garden-slot');
  assert.strictEqual(slots.length, 3, '应有 3 个花园槽位，实际 ' + slots.length);
  assert.ok(slots[0].textContent.includes('开花'), '第 1 槽应显示“开花”阶段：' + slots[0].textContent.slice(0, 40));
  assert.ok(slots[0].textContent.includes('100%'), '第 1 槽应显示生长 100%');
  assert.ok(slots[1].textContent.includes('种花'), '空槽应有“种花”按钮');
  const pots = window.document.querySelectorAll('#gardenPots .garden-pot');
  assert.strictEqual(pots.length, 3, '应显示陶土/粉色/金色三只花盆，实际 ' + pots.length);
  assert.ok(!pots[0].classList.contains('locked') && pots[0].textContent.includes('已解锁'), '陶土花盆应已解锁亮起');
  assert.ok(pots[1].classList.contains('locked') && pots[1].textContent.includes('收获 3 次解锁'), '粉色花盆未解锁应灰掉并注“收获 3 次解锁”');
  assert.ok(pots[2].textContent.includes('收获 10 次解锁'), '金色花盆应注“收获 10 次解锁”');
  const harvestBtn = Array.from(slots[0].querySelectorAll('button')).find((b) => b.textContent.includes('收获'));
  assert.ok(harvestBtn, '开花槽应有“收获”按钮');
  harvestBtn.click();
  await sleep(150);
  assert.ok(toastText(window).includes('爱心 +2'), '收获后 toast 应显示奖励“爱心 +2”，实际：' + toastText(window));
});

test('P2B 信箱：打开显示信件原文与“来自真实聊天记录”来源标签', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('memories');
  await sleep(200);
  const drawBtn = window.document.getElementById('letterDrawBtn');
  assert.ok(drawBtn, '缺少 #letterDrawBtn');
  drawBtn.click();
  await sleep(200);
  const body = window.document.getElementById('letterBody');
  assert.strictEqual(body.hidden, false, '点开信箱后信件区应显示');
  assert.strictEqual(window.document.getElementById('letterText').textContent, '冷死了，记得穿厚一点', '信件须显示后端原文，不改写');
  const src = window.document.getElementById('letterSource').textContent;
  assert.ok(src.includes('来自真实聊天记录'), '来源标签应含“来自真实聊天记录”：' + src);
  assert.ok(src.includes('关心对方'), '来源标签应含记忆分类“关心对方”：' + src);
  const listText = window.document.getElementById('letterList').textContent;
  assert.ok(listText.includes('♥'), '历史列表里已收藏的信应标 ♥');
});

test('P2B 成绩榜：loadScores 渲染无 JSON 原始文本，转盘/翻牌均为可读文字', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(200);
  const memText = window.document.getElementById('memoryScores').textContent;
  assert.doesNotMatch(memText, /\{"'/, '翻牌成绩榜不得含 JSON 原始文本：' + memText);
  assert.ok(memText.includes('记忆翻牌 · 得分 1200'), '翻牌标题应为“记忆翻牌 · 得分 1200”：' + memText);
  assert.ok(memText.includes('步数 5') && memText.includes('用时 10 秒'), '翻牌行应含步数与用时：' + memText);
  const wheelText = window.document.getElementById('wheelScores').textContent;
  assert.doesNotMatch(wheelText, /\{"'/, '转盘成绩榜不得含 JSON 原始文本：' + wheelText);
  assert.ok(wheelText.includes('幸运转盘 · 得分 10'), '转盘标题应为“幸运转盘 · 得分 10”：' + wheelText);
  assert.ok(wheelText.includes('爱心+10'), '转盘行应含奖品名“爱心+10”：' + wheelText);
});

test('P2B 互动：摸头后 #catFigure 挂上 is-pet class 且 CatFX.play 被调用', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const calls = [];
  const origPlay = window.CatFX.play;
  window.CatFX.play = (action) => { calls.push(action); return origPlay(action); };
  const petBtn = window.document.querySelector('[data-cat-action="pet"]');
  assert.ok(petBtn, '缺少摸头按钮');
  petBtn.click();
  const fig = window.document.getElementById('catFigure');
  assert.ok(fig.classList.contains('is-pet'), '摸头后 #catFigure 应挂 is-pet class');
  assert.deepStrictEqual(calls, ['pet'], 'CatFX.play 应以 pet 被调用');
  await sleep(150);
  assert.strictEqual(window.document.getElementById('catHearts').textContent.trim(), '2', 'mock 返回爱心 2，页面应渲染 2');
});

test('P2B 音效开关：点击切换 localStorage 静音标记', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const btn = window.document.getElementById('soundToggleBtn');
  assert.ok(btn, '缺少 #soundToggleBtn');
  assert.strictEqual(window.localStorage.getItem('v3_sound_muted'), null, '初始不应有静音标记（mock 环境）');
  btn.click();
  assert.strictEqual(window.localStorage.getItem('v3_sound_muted'), '1', '点一次应把 v3_sound_muted 写成 1');
  assert.ok(btn.textContent.includes('音效关'), '按钮文案应变为“音效关”：' + btn.textContent);
  btn.click();
  assert.strictEqual(window.localStorage.getItem('v3_sound_muted'), '0', '再点一次应写回 0');
});

test('P2B 心动事件：点“等一个小心动”显示事件，60 秒内按钮禁用倒计时', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  const nextBtn = window.document.getElementById('eventNextBtn');
  assert.ok(nextBtn, '缺少 #eventNextBtn');
  nextBtn.click();
  await sleep(150);
  const body = window.document.getElementById('eventBody');
  assert.strictEqual(body.hidden, false, '事件应显示');
  assert.strictEqual(window.document.getElementById('eventTitle').textContent, '午后的一阵风');
  assert.strictEqual(window.document.getElementById('eventText').textContent, '风把一片花瓣吹到了你的窗台上');
  assert.ok(window.document.getElementById('eventAnim').className.includes('anim-pink-rain'), 'pink-rain 事件应挂 anim-pink-rain class');
  assert.strictEqual(nextBtn.disabled, true, '60 秒内按钮应禁用');
  assert.match(nextBtn.textContent, /再等 \d+ 秒/, '禁用期间按钮应显示倒计时：' + nextBtn.textContent);
  const favBtn = window.document.getElementById('eventFavBtn');
  favBtn.click();
  await sleep(150);
  assert.ok(toastText(window).includes('已收藏'), '收藏后应提示已收藏：' + toastText(window));
});

test('P2B 心动事件：首页首次打开 30% 概率自动滚一条（Math.random 桩为 0.1 时触发）', async (t) => {
  const { dom, window } = await makeDom();
  t.after(() => dom.window.close());
  window.Math.random = () => 0.1;
  await sleep(2300);
  const body = window.document.getElementById('eventBody');
  assert.strictEqual(body.hidden, false, 'Math.random=0.1（<0.3）时 2 秒后应自动显示事件');
});

test('P2B 转盘加深：抽中且有 collected 时 toast 补“已收入收藏：sticker-heart”', async (t) => {
  const { dom, window, calls } = await makeDom();
  t.after(() => dom.window.close());
  window.MimiCat.showPage('park');
  await sleep(150);
  const spinBtn = window.document.getElementById('wheelSpinBtn');
  spinBtn.click();
  await sleep(3400);
  assert.ok(calls.some((c) => c === 'POST /api/games/wheel'), '应调过 POST /api/games/wheel');
  const result = window.document.getElementById('wheelResult').textContent;
  assert.ok(result.includes('爱心+10'), '转盘结果应显示奖品：' + result);
  assert.ok(toastText(window).includes('已收入收藏：sticker-heart'), 'toast 应补一句“已收入收藏：sticker-heart”，实际：' + toastText(window));
});

/* ---------- 恢复流程：只抽 restoreBackup 做单元验证（不跑服务） ---------- */
function loadRestoreFn() {
  const src = read('public/app.js');
  const ctx = {};
  vm.createContext(ctx);
  const fn = extractBalanced(src, 'async function restoreBackup(file) ', '{', '}');
  vm.runInContext(fn, ctx);
  return ctx;
}

test('P2B 恢复：合法备份 JSON 发 JSON { data: { tables } }，成功提示各表条数', async () => {
  const ctx = loadRestoreFn();
  let captured = null;
  let toasted = '';
  ctx.$ = (id) => ({ value: '' });
  ctx.confirm = () => true;
  ctx.state = { token: 'tok-1' };
  ctx.toast = (m) => { toasted = m; };
  ctx.initChat = async () => {};
  ctx.fetch = async (url, opts) => {
    captured = { url, opts };
    return { ok: true, json: async () => ({ ok: true, restored: { sessions: 2, messages: 5 } }) };
  };
  const file = { text: async () => JSON.stringify({ service: 'ai-boy-v3', version: '1.0.0', tables: { sessions: [{ id: 's1' }], messages: [] } }) };
  ctx.__file = file;
  await vm.runInContext('restoreBackup(__file)', ctx);
  assert.ok(captured, '应调过 fetch');
  assert.strictEqual(captured.url, '/api/restore');
  assert.strictEqual(captured.opts.method, 'POST');
  assert.strictEqual(captured.opts.headers['Content-Type'], 'application/json');
  assert.strictEqual(captured.opts.headers.Authorization, 'Bearer tok-1');
  const sent = JSON.parse(captured.opts.body);
  assert.ok(sent.data && Array.isArray(sent.data.tables.sessions), 'body 应为 { data: { tables } }');
  assert.ok(toasted.includes('sessions 2 条') && toasted.includes('messages 5 条'), '成功提示应拼出各表条数：' + toasted);
});

test('P2B 恢复：不是合法 JSON 或没有 tables 时报“这个文件不是有效的备份 JSON”，且不发请求', async () => {
  const ctx = loadRestoreFn();
  let fetchCount = 0;
  let toasted = '';
  ctx.$ = (id) => ({ value: '' });
  ctx.confirm = () => true;
  ctx.state = { token: '' };
  ctx.toast = (m) => { toasted = m; };
  ctx.initChat = async () => {};
  ctx.fetch = async () => { fetchCount++; return { ok: true, json: async () => ({}) }; };
  ctx.__file = { text: async () => '这不是 JSON {' };
  await vm.runInContext('restoreBackup(__file)', ctx);
  assert.strictEqual(fetchCount, 0, '非法 JSON 不应发请求');
  assert.strictEqual(toasted, '这个文件不是有效的备份 JSON');
  toasted = '';
  ctx.__file = { text: async () => JSON.stringify({ hello: 'world' }) };
  await vm.runInContext('restoreBackup(__file)', ctx);
  assert.strictEqual(fetchCount, 0, '没有 tables 不应发请求');
  assert.strictEqual(toasted, '这个文件不是有效的备份 JSON');
});
