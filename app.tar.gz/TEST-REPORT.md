# TEST-REPORT — V3.0 独立 AI 男生（ai-boy-v3）

> **执行时间**：2026-11-11（第四轮，总协调整合验收，全量重跑）。
> **执行方式**：`npm test`（`node --test --test-concurrency=1 tests/*.test.js`，串行——03 与 05 共用本地 `data/app.db`）。
> **运行环境**：Node v24.22.1；SQLite 本地 `data/app.db`；DeepSeek 上游一律用本地 stub 只返回错误状态（401/402/500/延迟超时），Key 只用测试假值 `test-dummy-key`；**全程无真实 Key、无真实 DeepSeek 调用、无部署**。
> **结论先行**：70 个测试用例，**70 通过、0 失败**。第三轮的 2 个失败（`src/memory.js` 冲突处理 F1/F2，见 §已修复）已由总协调修复并重跑通过：冲突检查提到去重之前、正负翻转不走去重；冲突只认同一话题（提话题 = 极性词后内容）。人工用例 10 项（M1–M10）**全部未执行**——需要真实 Key 与真机，不属于本次自动结果。

## 套件构成

| 套件 | 文件 | 用例数 | 通过 | 失败 | 说明 |
|------|------|--------|------|------|------|
| 静态卫生 | `tests/00-static.test.js` | 4 | 4 | 0 | `.env.example` 空占位、`.gitignore`、render.yaml、8 张表 |
| 漂移防护 | `tests/01-drift.test.js` | 6 | 6 | 0 | drift.js 纯逻辑 |
| 人格与样本种子 | `tests/02-seed-persona.test.js` | 6 | 6 | 0 | seed.js 纯导出 |
| 自动记忆 | `tests/03-memory.test.js` | 9 | 9 | 0 | memory.js + SQLite（F1/F2 已修复，第四轮通过） |
| DeepSeek 错误映射 | `tests/04-deepseek-errors.test.js` | 6 | 6 | 0 | deepseek.js + 本地错误 stub |
| HTTP 端到端 | `tests/05-http.test.js` | 11 | 11 | 0 | 真实 server.js 子进程 + SQLite |
| 本轮 20 项套件小计 | `tests/00–05` | 42 | 42 | 0 | |
| 后端模块单测（后端子代理同期写） | `tests/deepseek.test.js`、`drift.test.js`、`memory.test.js`、`seed.test.js` | 28 | 28 | 0 | 与本套件互补，未改动 |
| **合计** | | **70** | **70** | **0** | `npm test` 退出码 0 |

## 20 项逐项结果

状态说明：**通过** = 自动断言通过；**部分** = 自动部分通过、仍需人工用例补齐；**未通过** = 自动断言失败；**未验证** = 该项的人工部分尚未执行。

| # | 项 | 类型 | 状态 | 证据 |
|---|----|------|------|------|
| 1 | 首次打开网页 | 自动 | **通过** | `05-http`：`GET /` 返回 200、`text/html`，含 `id="messages"`、`id="input"`、`id="sendBtn"`、`id="settingsBtn"`、viewport |
| 2 | 正常发送消息 | 自动+人工 | **部分** | 自动：无 Key 时 SSE 收到 `{type:"error",code:"NO_API_KEY"}`、零 delta、无消息落库（`05-http`）；401 时用户消息落库、无假 AI 回复。人工 M1（真实 Key 成功对话）**未执行** |
| 3 | 连续多条消息不丢不串 | 自动+人工 | **部分** | 自动：3 条用户消息按序落库、内容逐条一致；同 clientId 重复提交不建第二条（`05-http`，上游 401 场景）。真实 AI 回复的多轮顺序需人工 M2，**未执行** |
| 4 | 人格遵循 | 自动+人工 | **部分** | 自动：A–I 九类齐全（`02-seed`、`05-http` 的 `GET /api/persona`）、高频词 16 个与 4 类缺点俱全、红线与"关系未确定"在列。五场景人工评判 M3 **未执行** |
| 5 | 不同情绪回复 | 自动+人工 | **部分** | 自动：drift 命中客套话/超长说教/过度热情/虚构共同经历，人格内回复（好哦姐姐/伞被偷/那冷不冷…）零命中（`01-drift`）。情绪连续性人工 M5/M6 **未执行** |
| 6 | 保留语言习惯 | 自动+人工 | **部分** | 自动：样本库 7 类有原话（日常聊天/主动开启话题/表达不满/生气/表达关心/面对对方撒娇/开玩笑），吃醋/难过/委屈/结束话题/调侃五类为空、零编造；样本≤40 字、无 AI 腔（`02-seed`、`05-http`）。人工 M4 **未执行** |
| 7 | 无普通 AI 腔 | 自动 | **通过** | `01-drift`：`您好/请问有什么可以帮助您/作为AI/我是AI助手/很高兴为您服务` 全部命中 drift |
| 8 | 自动记忆正常 | 自动 | **通过** | `03-memory`：约定（明天下午三点一起去图书馆→约定 70–90）、偏好（我喜欢吃香菇鸡丁→偏好 70–90）被提取；下课啦/接了杯水/打完了/冷死了/嗯呐零候选；"我朋友叫我打王者"亦零候选（后端已把闲聊规则改为非锚定子串匹配 `CHITCHAT_ANY`，误判已修） |
| 9 | 记忆去重 | 自动 | **通过** | `03-memory`：同一内容两次保存，第一次 `saved:1`，第二次 `saved:0`、`updated:1`，库内仅一条 |
| 10 | 冲突处理 | 自动 | **通过** | 第四轮：F1/F2 已修复（见 §已修复），`03-memory` 9/9 通过 |
| 11 | 手动改记忆生效 | 自动 | **通过** | 逻辑（`03-memory`）：手动记忆（source=manual、confidence=1）不被自动提取覆盖；API（`05-http`）：POST 后 PUT 改内容/重要性，GET 一致，来源仍为 manual |
| 12 | 删除记忆后停止调用 | 自动 | **通过** | API：DELETE 后 GET 不再返回它（`05-http`）；逻辑：删除后 `retrieveRelevant` 不再返回它（`03-memory`） |
| 13 | 新建会话读相关旧记忆 | 自动+人工 | **部分** | 自动：`retrieveRelevant` 按"打羽毛球"关键词命中"明天下午三点去打羽毛球"，limit=2 时各最多 2 条（`03-memory`）。跨会话人工验证 M8 **未执行** |
| 14 | 刷新后记录保留 | 自动 | **通过** | `05-http`：停服务再起（同一端口、同一 `data/app.db`），会话列表 id 集与消息逐条一致 |
| 15 | 重新打开恢复 | 自动 | **通过** | `05-http`：与 14 同一轮验证，`GET /api/sessions` 与 `GET /api/sessions/:id/messages` 重启前后一致 |
| 16 | API 断开正确报错 | 自动 | **通过** | 模块级（`04-deepseek`）：无 Key→`NO_API_KEY`、401→`DEEPSEEK_401`、402→`DEEPSEEK_402`、500→`DEEPSEEK_ERROR`、超时→`DEEPSEEK_TIMEOUT`；HTTP 层（`05-http`）：无 Key 的 SSE 报错与上游 401 的 SSE 报错一致，`/api/config` 不返回 Key 值 |
| 17 | 手机端显示 | 自动+人工 | **部分** | 自动：viewport meta（width=device-width, initial-scale=1, viewport-fit=cover）、设置正好六项（人物资料/人格设定/历史聊天/长期记忆/模型配置/数据管理）、底部安全区、触摸滚动、流式窄栏（`05-http` 静态检查）。备注：`style.css` 只有 1 条 `@media`（深色模式），无 max-width 断点，移动端靠流式布局而非断点适配。真机人工 M7 **未执行** |
| 18 | 会话不污染 | 自动 | **通过** | `05-http`：A 会话只含"A的专属消息"，B 会话只含"B的专属消息" |
| 19 | 人格配置稳定 | 自动 | **通过** | `05-http`：PUT 改 C 节后 GET 一致；重启后仍为改后值；改回原值后 GET 与原始内容一致 |
| 20 | 长时间聊天不明显漂移 | 自动+人工 | **部分** | 自动：10 轮人格内回复零漂移；混入客服腔后漂移计数 +1、`driftReinforcement` 返回非空重载文本（含"短句"要求）（`01-drift`）。真实 20 轮人工 M6 **未执行** |

**20 项汇总**：自动完全通过 12 项（1、7、8、9、10、11、12、14、15、16、18、19）；自动部分通过、人工待补 8 项（2、3、4、5、6、13、17、20）；自动未通过 0 项。

## §已修复：第三轮的 2 个真实 bug（均在 `src/memory.js` 冲突处理）

> 第四轮总协调整合时已修复并重跑通过（`npm test` 70/70，`tests/03-memory.test.js` 9/9）。以下保留原始复现记录以备查。

### F1 — 去重先于冲突检查，短句正负翻转走不到冲突分支（item 10 主路径）

- **现象**：先存"我喜欢吃麻辣烫"，再存"我不喜欢吃麻辣烫"，期望旧的变 `conflict`、新的变 `pending`；实际 `saveCandidates` 返回 `{"saved":0,"updated":1,"pending":0,"conflict":0}`——新记忆被当成重复，只更新了旧记忆的 `updated_at`。
- **根因**：两句的 Jaccard 相似度为 **0.75**（> 0.7 阈值），`saveCandidates` 的去重检查在冲突检查之前触发。短句矛盾（同一话题、正负翻转）天然高度相似，冲突分支基本不可达。
- **复现**：`saveCandidates([{content:'我喜欢吃麻辣烫',category:'偏好',…}])` → `saveCandidates([{content:'我不喜欢吃麻辣烫',category:'偏好',…}])` → 查两行状态。
- **建议修复**：冲突检查先于去重检查，或去重时排除正负相反的对子（`hasContradiction` 为真时不走去重分支）。

### F2 — 冲突检测过于宽泛，不同对象也判矛盾（item 10 误伤）

- **现象**：库里有"我不喜欢吃拉面"时，再存"我喜欢打羽毛球"，期望互不相干、正常保存为 `active`；实际 `saveCandidates` 返回 `{"saved":0,"updated":0,"pending":1,"conflict":1}`——旧的被打成 `conflict`，新的被打成 `pending`。
- **根因**：冲突判定只看"双字关键词有交集 + 一正一负"：两句共享"喜欢"这一双字即算话题重叠，未比较正负所指的对象（拉面 vs 羽毛球）是否相同。
- **影响**：正常偏好会被误打成待确认；待确认队列会被大量假冲突污染（item-12/13 的初版用例即因此失败，后改用"约定"类记忆绕开）。
- **建议修复**：冲突判定需同时要求对象/话题核心词相同（例如提及同一食物/活动名），而不只是共享"喜欢/不喜欢"这类极性词。

## 人工测试用例（未执行，0/10）

见 [`tests/06-manual-cases.md`](tests/06-manual-cases.md)：M1 真实对话、M2 多轮不丢不串、M3 人格遵循五场景、M4 语言习惯、M5 情绪连续性、M6 长时间漂移、M7 真机手机端（红米 K70）、M8 跨会话记忆、M9 待确认记忆处理、M10 备份恢复。

**执行前置**：真实 DeepSeek Key（只放 Render 环境变量或本地 `.env`）+ 真机。**通过自动测试 ≠ 人格合格**——漂移检测是规则式，只能拦住"作为 AI/很高兴为您服务"这类明文，拦不住委婉版客服腔与温柔说教；未知项（吃醋/吵架/冷战、严肃话题、家庭/经济/感情史）是否"不编造"，只能人工验证。

## 诚实边界（本次未验证的）

- 真实 DeepSeek 成功对话全程未验证（无真实 Key；按任务要求只测无 Key/错误映射）。
- Neon PostgreSQL 未验证（本地只有 SQLite；`db/schema.pg.sql` 仅做了 8 张表静态检查）。
- 语音 STT/TTS、照片上传：本项目无此功能，不适用。
- Render 部署未执行（按任务要求不部署）；`render.yaml` 仅做静态检查。
- `style.css` 无 max-width 断点（见 item 17 备注）；真机显示以 M7 为准。
- 模型默认值已改为 `deepseek-flash`：2026-11-11 核对 api-docs.deepseek.com 当日抓取，官方当前模型为 `deepseek-flash` / `deepseek-v4-pro`，`deepseek-chat` 已于 2026-07-24 退役；请求体另加 `thinking: {type: "disabled"}`（对应旧 `deepseek-chat` 的非思考快回复）。

## 复现方法

```bash
cd app
npm install
npm test   # node --test --test-concurrency=1 tests/*.test.js
```

测试只用测试假 Key `test-dummy-key` 与本地错误 stub；测试产生的会话/记忆在用例内清理（`after` 钩子删测试会话与记忆、恢复人格 C 节原值与 baseUrl 原值）。测试对 `data/app.db` 的写入限于种子数据与测试行，不含任何真实聊天记录或真实 Key。

---

## V4.0 第一阶段（2026-11-11 22:48，总协调整合验收）

> **结论**：95 个测试用例，**95 通过、0 失败**（原有 79 + 后端新 14 + 前端新 2）。另有 jsdom 前端检查 30/30、真服务器冒烟（本地端口 3199）全部通过。详见 `docs/V4-Phase1-交付说明.md`。

| 套件 | 文件 | 用例数 | 通过 | 失败 | 说明 |
|------|------|--------|------|------|------|
| V4 后端 | `tests/07-phase1-backend.test.js` | 14 | 14 | 0 | 猫咪状态/每日一次/任务领取/转盘冷却/心情 upsert/成绩记录 |
| V4 前端 | `tests/08-phase1-frontend.test.js` | 11 | 11 | 0 | 导航与游戏容器、语法、无外链、场景样式、人格渲染、auth 不动、头像文件与引用、formatReward |
| **V4 小计** | | **25** | **25** | **0** | |
| **全量合计** | | **95** | **95** | **0** | `npm test` 退出码 0 |

**本轮发现并修复的真实 bug**（均有回归测试）：
1. 人格页 `[object Object]`：`normalizePersona` 不认 `{sections}` 形态，已修（标题对齐种子九节）。
2. 奖励对象直接拼字符串：盲盒奖励、任务奖励、转盘奖品三处会显示 `[object Object]`，新增 `formatReward()` 统一格式化。
3. 互动接口契约不一致：后端返回 `{gained:{hearts}}`，前端读不存在的 `gainedHearts`/`message`，导致无文案无 toast；已按实际形状读 + 本地文案兜底。
4. 转盘 `hearts` 是爱心总数而非本次所得，前端旧代码当成“爱心 +总数”显示；已改只取 `prize.hearts`。
5. 聊天头像：`public/assets/avatar.jpg`（512×512 自拍裁图），顶栏/输入中/资料大头像/消息行（双方）引用，加载失败兜底 🐷。

**测试过程说明**：首次全量跑的 3 个失败是两路 `node --test` 并行共用同一 `data/app.db` 的并发干扰，单独重跑后全过——后续全量测试不要多路并行。部署包 `~/workspace/new-ai-persona/deploy/app.tar.gz`（142 KB，sha256 见 deploy/MANIFEST.txt，以清单为准）已解压验证 `npm install` + `npm test` 95/95。**本次未部署到 Render，未动线上库。**

---

## V4.0 第二阶段（2026-11-11 23:20，总协调整合验收）

> **结论**：145 个测试用例，**145 通过、0 失败**。详见 `docs/V4-Phase2-交付说明.md`。

| 套件 | 文件 | 用例数 | 通过 | 失败 | 说明 |
|------|------|--------|------|------|------|
| V4 后端二 | `tests/09-phase2-backend.test.js` | 15 | 15 | 0 | 养成进阶/记账/换装/房间/花园/事件/信箱（含 AI 信分支）/备份 |
| V4 前端二 | `tests/10-phase2-frontend.test.js` | 20 | 20 | 0 | jsdom：房间/花园/事件/信箱/成绩榜/恢复/换装/静音 |
| V4 猫状态机 | `tests/11-cat-state.test.js` | 14 | 14 | 0 | 状态切换无冲突/各态 class/分区点击/换装脸型不变/隐藏暂停 |
| V4 前端一 | `tests/08-phase1-frontend.test.js` | 12 | 12 | 0 | 含新增的头像区分测试（自己 user-avatar.jpg / 小猪 avatar.jpg） |
| **V4 小计** | | **75** | **75** | **0** | 第一阶段 25 + 第二阶段 50 |
| **全量合计** | | **145** | **145** | **0** | `npm test` 退出码 0 |

**本轮发现并修复的真实 bug**（均有回归测试）：
1. 小猫无动作无声：第一阶段动画幅度太小（摸头倾斜 2°、喂食碗淡入、睡觉缩小 6%），且全站零音频代码；本次重做动画幅度与 WebAudio 合成音效，并重构为分层 SVG + 9 态状态机。
2. 成绩榜原始 JSON：`loadScores` 直接 `JSON.stringify(detail)`，已改可读格式化。
3. 恢复流程不匹配：前端发 FormData、后端要 JSON `{data:{tables}}`，已改前端读文件文本发 JSON（兼容裸 `{tables}` 与 `{data:{tables}}` 两种形状）。
4. 信箱 AI 信分支是死的：全站写不出 `confirmed` 状态（POST 写死 `active`，无确认按钮）；新增 `memories.confirmed` 列（启动时幂等迁移，只新增列），POST/PUT 可写，长期记忆页加“✓ 确认”按钮。
5. `tests/08` 无外链断言误报：SVG 命名空间字符串 `http://www.w3.org/2000/svg` 被当成外链，已改为先剔除该标识串再查。

部署包 `~/workspace/new-ai-persona/deploy/app.tar.gz`（sha256 见 deploy/MANIFEST.txt，以清单为准）已解压验证 `npm install` + `npm test` 145/145。**本次未部署到 Render，未动线上库。**

## V4.0 第三阶段（2026-11-11 23:45，总协调整合验收）

> **结论**：189 个测试用例，**189 通过、0 失败**。详见 `docs/V4-Phase3-交付说明.md`。

| 套件 | 文件 | 用例数 | 通过 | 失败 | 说明 |
|------|------|--------|------|------|------|
| V4 后端三 | `tests/15-phase3-backend.test.js` | 16 | 16 | 0 | 手动回忆/收藏/纪念日/情绪三铁律/睡前故事回落/报告诚实/花园百分比 |
| V4 前端三 | `tests/16-phase3-frontend.test.js` | 14 | 14 | 0 | jsdom：回忆/收藏/纪念日倒计时/情绪药丸/睡前层/报告空态/花园 50% |
| **V4 小计** | | **105** | **105** | **0** | 第一阶段 25 + 第二阶段 50 + 第三阶段 30 |
| **全量合计** | | **189** | **189** | **0** | `npm test` 退出码 0 |

**本轮发现并修复的真实 bug**（均有回归测试）：
1. 花园进度 0–1 当百分比显示：后端 `flowerStage` 返回 0–1 小数，前端拼 `'%'` 成 0.5%；已改后端统一 0–100 整数百分比，`tests/09` 与 `tests/13` 旧断言同步更新。
2. `isValidDateStr` 对非法日期抛错走 500：已加 NaN 拦截，非法日期现为 400。
3. 两条因任务本身而过时的旧断言：`tests/10` 要求回忆页保留“纪念日是第三阶段功能”提示（任务明确要求删掉，改为断言纪念日卡片存在）；`tests/05` 断言 style.css 只有 1 条 `@media`（睡前深色样式新增第 2 条同为深色模式的 `@media`，改为断言 2 条且 0 条 max-width 断点）。

**真服务器冒烟**（隔离副本，端口 3222，SQLite）：healthz ok；手动回忆创建+列表；纪念日 2026-12-25 的 days_left=44；花园种雏菊+浇水后 stage=sprout、progress 为整数百分比；无 Key 时睡前故事走本地库（source:'local'）；晚安信件 generic；空报告全 0/null/[]（intimacyToday:null 如实）；带 emotion 的聊天无 Key 时报 NO_API_KEY 且零消息落库；收藏开/关双向可用； served 首页含 emotionCard/bedtimeOverlay/annivList/reportCard 等全部新 id；served JS 里唯一的 "object Object" 是第一阶段的注释行。冒烟后副本已删除，本地库无测试残留数据。

部署包 `~/workspace/new-ai-persona/deploy/app.tar.gz`（sha256 见 deploy/MANIFEST.txt，以清单为准）已解压验证 `npm install` + `npm test` 189/189。**本次未部署到 Render，未动线上库。**
