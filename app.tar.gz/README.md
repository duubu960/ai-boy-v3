# ai-boy-v3 后端（V3.0 独立 AI 男生）

只服务本项目。**不共用**小米 / 可爱的乖乖的 API Key、数据库、记忆或聊天记录。

## 运行

```bash
npm install
npm start          # 默认端口 3100，可用 PORT 环境变量改
```

健康检查：`curl http://localhost:3100/healthz`

## 配置（环境变量）

| 变量 | 说明 |
| --- | --- |
| `PORT` | 默认 3100 |
| `DEEPSEEK_API_KEY` | DeepSeek 官方 API Key，**只放环境变量**，绝不写进代码、前端、日志或 git。无 Key 时聊天接口诚实返回 `NO_API_KEY`，绝不编造假回复 |
| `DATABASE_URL` | 以 `postgres://` 开头时用 Postgres（生产）；否则用本地 SQLite，数据在 `data/app.db` |

`.env.example` 只有空占位。复制为 `.env` 后自行填入（`.env` 已进 `.gitignore`）。

## API（完整契约见 server.js）

- `GET /healthz` / `GET /api/auth/status`
- `POST /api/auth/setup` `{password}`（仅无密码时可设）/ `POST /api/auth/login` `{password}` → `{token}`（token = 密码 sha256 hex；设密码后除 `/healthz`、`/api/auth/*` 外所有 `/api/*` 需 `Authorization: Bearer <token>`；无密码时开放）
- `GET /api/persona` / `PUT /api/persona` `{key, content}`（A–I 九类固定人格）
- `GET /api/config` / `PUT /api/config`（模型配置，绝不返回 Key）
- 会话：`GET/POST /api/sessions`、`GET/DELETE /api/sessions/:id`、`POST /api/sessions/:id/clear`
- 消息：`GET /api/sessions/:id/messages`、`POST /api/sessions/:id/chat`（SSE 流式，`clientId` 去重）、`POST /api/sessions/:id/regenerate`、`DELETE /api/sessions/:id/messages/:mid`
- 记忆：`GET /api/memories`（`?status=&category=`）、`POST/PUT/DELETE /api/memories/:id`、`GET /api/memories/pending`
- 语言样本：`GET /api/samples?category=`、`POST /api/samples`
- 摘要：`GET/POST /api/sessions/:id/summary`（本地生成，不调模型也能出简要摘要）
- 导出/备份：`GET /api/export?sessionId=xxx` 或 `?all=1`（纯文本）、`POST /api/backup`、`POST /api/restore`

聊天 SSE 事件：`data: {"type":"delta","text":"..."}`；结束 `{"type":"done","messageId":"...","memoryCandidates":n}`；错误 `{"type":"error","code":"NO_API_KEY|DEEPSEEK_401|DEEPSEEK_402|DEEPSEEK_TIMEOUT|DEEPSEEK_ERROR","message":"..."}`。

## 记忆（src/memory.js，规则式，不额外调模型）

只在用户消息含以下信号时才产生候选：重要人物/关系、约定（时间/地点/一起做某事）、偏好（喜欢/不喜欢/爱吃/爱玩）、反复话题、重要经历。普通闲聊（下课啦/接了杯水/打王者）不保存。
去重：规范化后包含或 Jaccard > 0.7 则只更新 `updated_at`。同一分类新旧内容矛盾时旧的 `status=conflict`、新记 `status=pending` 待确认。手动记忆 `source="manual"`、`confidence=1`，永不自动覆盖。重要性：约定/偏好 70–90、人物关系 60–80、经历 50–70、普通 0–30，低于 40 不保存。

## 漂移防护（src/drift.js）

`checkDrift(text)` 检测客套话（您好/请问有什么可以帮助您/作为 AI/我是一个 AI/很高兴为您服务）、超长说教（>200 字且含 应该/建议你）、过度热情（连续感叹号/永远陪着你）、虚构共同经历（我们上次一起…且历史无此记录）。聊天路由生成后自查：drift 时记日志，并在下一条系统提示中加强固定人格重载（不自动改提示词文件、不改写已生成的回复）。

## 语言样本不足（不编造）

`language_samples` 按 12 类情境入库，但来源文件只有五类有原话：日常汇报→日常聊天+主动开启话题；吐槽倒霉→表达不满+生气；关心对方→表达关心；撒娇被逗→面对对方撒娇+开玩笑；追问回应→日常聊天。**吃醋、难过、委屈、结束话题、调侃**五类在来源中无原话，种子数据留空，不编造填充；其余未覆盖的情境（严肃话题、对其他朋友的说话方式、错别字习惯）同样未入库，等真实样本补充。

## 测试

```bash
npm test   # tests/ 下的 node:test 套件（纯逻辑 + API 自测，不调真实 DeepSeek）
```

注意：聊天功能需真实 DeepSeek Key 才能验证；无 Key 的自测只验证 `NO_API_KEY` 诚实报错。

自动测试除 `npm test` 的 node:test 套件外，后端另有 `tests/deepseek.test.js`、`drift.test.js`、`memory.test.js`、`seed.test.js`（模块级单测，与本 README 同期的 `tests/0*.test.js` 互补）。
完整结果与 20 项逐项表见 [`TEST-REPORT.md`](TEST-REPORT.md)；人工用例见 [`tests/06-manual-cases.md`](tests/06-manual-cases.md)。

## 功能说明

- 手机端聊天：单页 `public/index.html`，消息流 + 输入框 + 设置抽屉（六项：人物资料 / 人格设定 / 历史聊天 / 长期记忆 / 模型配置 / 数据管理）。
- DeepSeek 真实对话：SSE 流式。无 Key / 401 / 402 / 超时一律返回错误码，绝不编假回复。
- 三层记忆：① 固定人格（persona_config，A–I 九类）② 长期记忆（memories，规则式自动提取 + 手动管理）③ 当前上下文（最近 12 条消息 + 会话摘要）。
- 跨会话检索：新会话按关键词取相关记忆与语言样本，各最多 5 条。
- 漂移防护：`checkDrift` 拦截客服腔 / AI 腔 / 超长说教 / 套路甜话 / 虚构共同经历，命中后记日志并在下一条系统提示中加强人格重载。
- 访问控制：可选设密码（首次在设置里设 4 位以上密码；设后所有 `/api/*` 需 `Authorization: Bearer <token>`，token 即密码 sha256）。
- 备份/恢复/导出：TXT 导出（单会话或全部）、JSON 全量备份与恢复（见下）。

## DeepSeek 配置方法

**Key 只放服务器环境变量，绝不写进代码、前端、日志、git 或本文件。**

| 场景 | 做法 |
| --- | --- |
| Render 部署 | 在 Render 服务页 Environment 里加 `DEEPSEEK_API_KEY`，值贴**新 Key**（与小米 / 可爱的乖乖不共用）。`render.yaml` 里该变量是 `sync: false`，部署时 Render 会让你手动填 |
| 本地开发 | 复制 `.env.example` 为 `.env`，填 `DEEPSEEK_API_KEY=你的新 Key`；`.env` 已在 `.gitignore` 中。启动用 `npm start`（默认端口 3100，可用 `PORT` 改） |
| 换模型 / 换地址 | 页面：设置 → 模型配置，改模型名 / baseUrl / temperature / maxTokens / 超时；或 `PUT /api/config`。默认模型 `deepseek-flash`，默认地址 `https://api.deepseek.com`。改完即时生效，不重启 |
| 验证 | `GET /api/config` 只返回 `hasKey: true/false`，永远不返回 Key 值；无 Key 时聊天返回 `NO_API_KEY` |

> 已核对（2026-11-11，api-docs.deepseek.com 当日抓取）：官方首页当前模型为 `deepseek-flash` 与 `deepseek-v4-pro`，`deepseek-chat` / `deepseek-reasoner` 已于 2026-07-24 退役、不再列出。故默认模型已改为 `deepseek-flash`（思考关闭，对应旧 `deepseek-chat` 的非思考快回复）。如官方日后改名，在模型配置页改掉即可（代码不写死模型名）。

## 数据库说明

| 环境 | 位置 |
| --- | --- |
| 本地开发 | SQLite，`data/app.db`（`data/` 已在 `.gitignore` 中，不进 git） |
| 生产（Render） | PostgreSQL（Neon 免费档），填 `DATABASE_URL`（以 `postgres://` 开头）即切换；不填则用 SQLite |

8 张表（SQLite 与 PG 两套 schema 结构一致，见 `db/schema.sqlite.sql` / `db/schema.pg.sql`）：

| 表 | 用途 |
| --- | --- |
| `users` | 用户（预留，当前单用户使用） |
| `sessions` | 会话（id / 标题 / 时间） |
| `messages` | 消息（session_id / role / content / client_id 去重 / meta） |
| `persona_config` | 固定人格 A–I 九类（key / title / content） |
| `memories` | 长期记忆（content / category / source auto 或 manual / confidence / importance / status active·pending·conflict） |
| `language_samples` | 语言样本库（12 类情境；只有 5 类有原话，其余留空不编造） |
| `summaries` | 会话摘要（每会话一条，本地生成） |
| `model_config` | 模型配置 + 密码 hash（key / value） |

首次启动自动建表并写入种子数据（人格九类、语言样本、默认模型配置）；已有数据时不重复写。

## 人格修改方法

设置 → 人格设定：九类（A 核心身份 / B 性格特点 / C 思维逻辑 / D 语言风格 / E 情绪反应 / F 行为习惯 / G 关系认知 / H 真实聊天示例 / I 人物行为限制）点开一条可改，保存后即时生效，只影响这个独立人设。

- 对应接口：`GET /api/persona`、`PUT /api/persona {key, content}`。
- 红线：不要删 I 类里的未知项禁令与"关系未确定"声明；不要把未知经历（家庭 / 经济 / 感情史 / 课程细节）编进人格。依据见 [`docs/人物分析摘要.md`](docs/人物分析摘要.md)。
- 人格配置稳定：除 `PUT /api/persona` 外没有任何代码会改人格；重启后不变（有自动化测试覆盖）。

## 记忆管理方法

设置 → 长期记忆：

- **查看**：按状态（active / pending / conflict）与分类筛选；`GET /api/memories?status=&category=`，待确认的见 `GET /api/memories/pending`。
- **新增**：手动新增记忆（写内容、选分类、定重要性），来源记为 `manual`，置信度 1。
- **改**：点一条记忆可改内容 / 分类 / 重要性 / 状态；对应 `PUT /api/memories/:id`。手动改完后自动提取**不覆盖**手动记忆。
- **删**：删除后新会话的检索不再返回它；对应 `DELETE /api/memories/:id`。
- **待确认处理**：自动提取遇到矛盾时，旧记忆变 `conflict`、新记忆变 `pending`，都要人来确认：确认无误改回 `active`，错的删掉或改掉。不要放任 pending/conflict 堆积。
- **自动提取规则**：只在用户消息含约定 / 偏好 / 人物关系 / 经历信号时才产生候选；普通闲聊不保存；重要性低于 40 不保存；同一内容去重；手动记忆永不自动覆盖。详见 `src/memory.js` 注释与 `TEST-REPORT.md`。

## 备份恢复方法

设置 → 数据管理（全部在本机下载，不上传到任何第三方）：

| 操作 | 做法 |
| --- | --- |
| 导出当前会话 TXT | 点「导出当前会话 TXT」，下载纯文本聊天记录 |
| 导出全部聊天 TXT | 点「导出全部聊天 TXT」 |
| 备份 JSON 下载 | 点「备份 JSON 下载」，得到 8 张表的全量 JSON（`POST /api/backup`） |
| 恢复上传备份 | 点「恢复上传备份」选之前下载的 JSON；**恢复会全量覆盖现有数据**，操作前先备份当前数据 |
| 清空当前会话聊天 | 点「清空当前会话聊天」（只清该会话消息，不可恢复，操作前先导出） |

建议节奏：每月至少备份一次 JSON；改人格、清记忆、重新部署前各备份一次。备份文件存在自己手机/电脑上，不要发给任何第三方。

## 成本说明

- **服务器与数据库**：Render Web Service Free + Neon Free，均为 0 元（免费档限制见 [`docs/部署准备.md`](docs/部署准备.md)：休眠唤醒、流量、库容量）。
- **DeepSeek 调用**：按 token 计费（输入 + 输出），无月费。每次聊天消耗约：
  - 输入 ≈（固定人格全文 + 相关记忆与样本 + 会话摘要 + 最近 12 条消息）÷ 4 字符；
  - 输出 ≤ `maxTokens`（默认 1000），实际回复一般只有一两句短句，远低于上限。
- **省成本的设计**：记忆提取是规则式，不额外调模型；会话摘要本地生成，不调模型；检索只取相关记忆与样本各最多 5 条，不把全库塞进提示词；回复默认短句。
- **单价**：DeepSeek 官方价目会变，**本文档不写死具体数字**。充值或部署前以 DeepSeek 官方 Models & Pricing 页为准；余额不足时接口返回 `DEEPSEEK_402`，会在页面上诚实报错，不会偷偷降级成假回复。
- **Key 与余额**：新 Key 与小米 / 可爱的乖乖不共用；余额、用量在 DeepSeek 开放平台查看。

## 相关文档

- [`docs/人物分析摘要.md`](docs/人物分析摘要.md) — 以《人物深度分析报告》第一部分为准的人物分析（证据 / 推测 / 无法确定三分法，未知清单）
- [`docs/部署准备.md`](docs/部署准备.md) — Render + Neon 免费路线部署准备（未部署）
- [`TEST-REPORT.md`](TEST-REPORT.md) — 20 项测试逐项结果（自动 + 人工）
