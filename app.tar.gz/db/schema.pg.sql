-- ai-boy-v3 生产 Postgres schema（与 SQLite 版同构，时间戳统一用 TEXT 存 ISO 字符串）
-- 8 张表：users / sessions / messages / persona_config / memories / language_samples / summaries / model_config

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  title TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  session_id TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  client_id TEXT,
  meta TEXT,
  favorite INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, id);
CREATE INDEX IF NOT EXISTS idx_messages_client ON messages(session_id, client_id);

CREATE TABLE IF NOT EXISTS persona_config (
  key TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memories (
  id SERIAL PRIMARY KEY,
  content TEXT NOT NULL,
  category TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'auto',
  confidence DOUBLE PRECISION NOT NULL DEFAULT 0.5,
  importance INTEGER NOT NULL DEFAULT 50,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'pending', 'conflict'))
);
CREATE INDEX IF NOT EXISTS idx_memories_status ON memories(status);
CREATE INDEX IF NOT EXISTS idx_memories_category ON memories(category);

CREATE TABLE IF NOT EXISTS language_samples (
  id SERIAL PRIMARY KEY,
  category TEXT NOT NULL,
  content TEXT NOT NULL,
  context TEXT,
  source TEXT NOT NULL DEFAULT '微信截图转录',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_samples_category ON language_samples(category);

CREATE TABLE IF NOT EXISTS summaries (
  id SERIAL PRIMARY KEY,
  session_id TEXT NOT NULL UNIQUE,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS model_config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- V4.0 第一阶段新增（猫咪小屋 / 每日 / 小游戏 / 心情）：只新增表，不动旧表
CREATE TABLE IF NOT EXISTS cat_state (
  id INTEGER PRIMARY KEY,
  state TEXT,
  mood TEXT,
  intimacy INTEGER NOT NULL DEFAULT 0,
  hearts INTEGER NOT NULL DEFAULT 0,
  last_interact_at TEXT,
  last_actions TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS daily_records (
  date TEXT NOT NULL,
  kind TEXT NOT NULL,
  payload TEXT,
  created_at TEXT NOT NULL,
  PRIMARY KEY (date, kind)
);

CREATE TABLE IF NOT EXISTS game_scores (
  id SERIAL PRIMARY KEY,
  game TEXT NOT NULL,
  score INTEGER NOT NULL DEFAULT 0,
  detail TEXT,
  played_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_game_scores_game ON game_scores(game, played_at);

CREATE TABLE IF NOT EXISTS mood_entries (
  id SERIAL PRIMARY KEY,
  date TEXT NOT NULL UNIQUE,
  mood TEXT NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- V4.0 第二阶段新增（爱心记账 / 收藏 / 换装 / 房间 / 花园 / 信箱 / 心动事件）：只新增表，不动旧表
CREATE TABLE IF NOT EXISTS heart_ledger (
  id SERIAL PRIMARY KEY,
  delta INTEGER NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS collection (
  id SERIAL PRIMARY KEY,
  kind TEXT NOT NULL,
  item_id TEXT NOT NULL,
  acquired_at TEXT NOT NULL,
  UNIQUE(kind, item_id)
);

CREATE TABLE IF NOT EXISTS dress_state (
  id INTEGER PRIMARY KEY,
  outfit TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS room_state (
  id INTEGER PRIMARY KEY,
  room TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS garden_plots (
  id SERIAL PRIMARY KEY,
  slot INTEGER NOT NULL,
  flower TEXT NOT NULL,
  planted_at TEXT NOT NULL,
  watered_at TEXT,
  harvested_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_garden_plots_slot ON garden_plots(slot, harvested_at);

CREATE TABLE IF NOT EXISTS letters (
  id SERIAL PRIMARY KEY,
  source TEXT NOT NULL,
  title TEXT,
  content TEXT NOT NULL,
  ref_memory_id INTEGER,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_log (
  id SERIAL PRIMARY KEY,
  event_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  favorited INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_event_log_event ON event_log(event_id, created_at);

-- V4.0 第三阶段新增（手动回忆 / 纪念日）：只新增表，不动旧表
CREATE TABLE IF NOT EXISTS manual_memories (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_manual_memories_date ON manual_memories(date);

CREATE TABLE IF NOT EXISTS anniversaries (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  date TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_anniversaries_date ON anniversaries(date);
