# V4.0 第一阶段交付说明 — Mimi Cat · 猫咪恋爱小屋

> **交付时间**：2026-11-11 22:48 CST
> **交付对象**：已上线 https://ai-boy-v3.onrender.com 的第一阶段升级（**本次未部署到 Render，线上仍为 V3.0**）
> **部署包**：`~/workspace/new-ai-persona/deploy/app.tar.gz`（142 KB，sha256 见包外 deploy/MANIFEST.txt，以清单为准）
> **注意**：包内文件均以 `./` 开头；解压后 `npm install` + `npm test` 已验证通过 95/95。

## 已完成

### 1. 全新视觉（Mimi Cat · 猫咪恋爱小屋）
- 樱花粉主色（`--mimi-pink: #f9a8c0`）+ 奶油白背景 + 薰衣草紫辅助 + 蜜桃装饰 + 浅金点缀；柔和渐变、圆角卡片、轻微阴影。
- 5 个场景各有不同 CSS 渐变：`scene-home`（卧室）、`scene-chat`（星空房）、`scene-memories`（花园）、`scene-park`（甜品屋）、`scene-mine`（月光窗台）。
- 手机端优先：容器 `max-width: 720px` 居中，无 `100vw`、无超宽固定宽度；按钮 ≥44px；深色模式仍为原有单条 `@media (prefers-color-scheme: dark)`。

### 2. 底部导航 5 个
首页（猫咪小屋）/ 聊天（AI 男生）/ 回忆 / 乐园 / 我的，选中状态明显（`active` + `aria-current`），切换不丢聊天状态。
回忆 / 我的在第一阶段只放已有真实功能（回忆：记忆时间轴、心情记录、最近会话；我的：人物资料/人格设置/语言样本/长期记忆/模型设置/备份、游戏成绩、每日记录），第二/三阶段功能入口诚实标明“第二/三阶段”，无假按钮。

### 3. 首页猫咪小屋
- 原创内联 SVG 小猫（统一画风，不用外链图），当前日期时间、今日心情、猫咪状态（开心/困倦/饥饿/撒娇/好奇/想玩耍，按规则变化并保存）、今日任务、今日惊喜、快速进聊天、最近回忆、互动入口。
- 摸摸头 / 喂食 / 睡觉 / 玩耍：动画反馈 + 状态变化 + 爱心积分（+2/+3/+1/+3），同一动作 10 秒内不重复给奖；状态持久化到后端（`cat_state` 单行）。

### 4. 每日惊喜盲盒
每天一次，按 Asia/Shanghai 真实日期判断；6 种奖励（小纸条/表情卡/爱心/贴纸/幸运语录/小任务）；同日重复领返回 409 `already_claimed`；领取记录持久化（`daily_records`）。

### 5. 每日任务
5 个简单任务（摸摸小猫、和 AI 聊聊天、打开一次惊喜、玩一个小游戏、写一条今日心情），完成条件只查真实记录（互动记录/当日用户消息/已领惊喜/当日游戏成绩/当日心情），完成领少量爱心（3/3/3/3/2），状态按日期持久化。

### 6. 三个基础小游戏（真能玩）
- 记忆翻牌：16 张牌、开始/重开/结束、步数与计时、完成计分（`1600 - 步数×20 - 秒数×5`，最低 100），成绩入库。
- 幸运转盘：8 格、开始后禁用防连点、3 秒旋转动画后出结果、服务端 3 秒冷却（冷却中 429），奖品与爱心记入成绩。
- 今日幸运签：按日期种子确定，同日同签，重复抽返回同一条。

### 7. 聊天页完整保留
DeepSeek、原人格（A–I 九节原样）、59 条样本、长期记忆、多会话、资料、模型设置、TXT 导出、JSON 备份恢复均未动，只做粉色奶油白 UI 优化（气泡、背景、发送动画、时间、复制、输入框）。

### 8. 人格设置页 [object Object] bug 已修
根因：后端 `GET /api/persona` 返回 `{ sections: [...] }`，旧 `normalizePersona` 只认数组或对象键值，`Object.keys` 得到 `['sections']`，内容被 `String(数组)` 拼成 `[object Object]`。
修复：`normalizePersona` 优先认 `data.sections`；`PERSONA_DEFAULTS` 九条标题改成与种子一致（核心身份/性格特点/思维逻辑/语言风格/情绪反应/行为习惯/关系认知/真实聊天示例/人物行为限制），内容原文不动；可编辑、可保存。

### 9. 整合时另发现并修复的同类 bug（前端/后端契约不一致）
- 盲盒奖励、任务奖励、转盘奖品在前端都是对象直接拼字符串，实际会显示 `[object Object]`：新增 `formatReward()` 统一格式化（对象 → “标题 · 正文 · 爱心 +N”），5 处调用点全部改用它；转盘奖品名只取 `label`，不再三重重复。
- 互动接口返回形状：后端是 `{cat, gained:{hearts,intimacy}, rewarded}`，前端旧代码读 `r.gainedHearts` / `r.message`（字段不存在）导致互动后无文案、无 toast：改按实际形状读，并加本地互动文案兜底（摸头“小猫蹭了蹭你的手”等）。
- 转盘 `hearts`：后端返回的是猫咪爱心**总数**，前端旧代码当成本次所得显示“爱心 +总数”：改只取 `prize.hearts`。
- 任务领取 toast 读不存在的 `r.awarded`，只显示通用文案：改读 `r.reward` 显示“已领取奖励：爱心 +3”。
- 以上均有回归测试覆盖（`tests/08-phase1-frontend.test.js`）。

### 10. 聊天头像更换（用户 2026-11-11 22:41 要求，并入第一阶段）
- 来源照片 `~/workspace/user/files/1000038831_0_yd7b.jpg`（戴帽子白 T 恤自拍，手机截图，上下黑边、顶部状态栏 11:47）：已裁掉黑边与状态栏（有效区 y 616–1536），以脸为中心裁成方形 512×512，存为 `public/assets/avatar.jpg`（30 KB JPEG，脸居中、无黑边、无状态栏）。
- 替换位置（只换聊天头像，不改猫咪吉祥物）：聊天页顶栏头像、正在输入头像、人物资料大头像、聊天框消息旁头像（小猪发消息与用户回复两侧都显示这张照片）。
- 兜底：图片加载失败时 `onerror` 回落为 🐷 emoji，不出破图 alt 文字。
- 猫咪吉祥物仍是原创 SVG，不受影响。

## 已测试（全部核实过）

| 检查 | 结果 |
|---|---|
| 全量 `npm test`（单独跑） | **95/95 通过，0 失败**（原有 79 + 后端新 14 + 前端新 2） |
| 后端新测试单跑 | 14/14 通过 |
| 前端新测试（08） | 11 项通过，含人格渲染、头像文件与引用、formatReward |
| 真服务器冒烟（本地端口 3199，SQLite） | healthz ok；`GET /api/cat` 建行；摸头 +2 心/+3 亲密；`GET /api/daily` 任务状态真实；盲盒领一次成功、第二次 409 `already_claimed`；幸运签抽到签文；心情保存成功；转盘抽中“爱心+10”；人格 API 返回 A 节“核心身份”；无 Key 聊天 SSE 诚实返回 `NO_API_KEY` 且零消息落库；重启后猫咪状态持久化（亲密度 3、爱心 12） |
| jsdom 前端检查（/tmp/v4-jsdom，mock fetch） | **30/30 通过**：5 导航切换、摸头爱心+2 与互动文案、任务奖励“爱心 +3”、人格 9 节无 `[object Object]`、翻牌 16 张可翻、转盘禁用防连点且 3 秒后出奖品、幸运签、盲盒奖励、顶栏/资料/消息行头像均为照片 img 且有 🐷 兜底、整页无 `[object Object]`、未请求密码接口 |
| 横向溢出静态审计 | 无 `100vw`、无超宽固定宽度；容器 `max-width: 720px`；`.cat-svg` 最大 `72vw`；转盘 230px 固定；未发现溢出来源（无真机浏览器，布局以静态审计为准） |
| 部署包验证 | 解压后 `npm install` 能装、`npm test` 95/95 通过；包内含 `public/assets/avatar.jpg`；无 `node_modules/`、`data/`、`.env`、`package-lock.json` |

**测试过程说明**：
- 首次全量跑曾出现 3 个失败，后证实是两路 `node --test` 并行共用同一 `data/app.db` 的并发干扰（另一路的 pet 奖励、消息播种、style.css 并行改动），单独重跑后 95/95 全过；**后续全量测试不要多路并行跑同一库**。
- jsdom 首次跑曾有 3 项失败：摸头爱心 4（检查脚本重复触发 DOMContentLoaded 导致处理函数双绑定，是检查脚本问题）、转盘（检查只等了 2.5 秒，动画是 3 秒）、盲盒（检查脚本的 mock 无状态，领后重读仍显示未领）；三项均已在检查脚本中修正，另有 4 处真实 bug 在源码中修复（见“已完成 §9”）。
- 所有冒烟测试数据已清理：`cat_state` / `daily_records` / `game_scores` / `mood_entries` / `sessions` / `messages` / `memories` 均为 0 行；本地库中本就无真实数据。

## 未完成 / 需用户配置 / 注意事项

- **未部署**：本次只交付部署包，未推 GitHub、未部署 Render、未动线上 Neon 库。线上 https://ai-boy-v3.onrender.com 仍为 V3.0（无猫咪小屋、无新头像），需用户确认后另行部署。
- **需用户确认后部署**：部署方式与 V3.0 相同——把 `render.yaml` + `app.tar.gz` 推到 GitHub 仓库 `duubu960/ai-boy-v3`，Render Blueprint 自动部署（V3.0 时 34.6 秒变 Live）；若自动部署 5 分钟内未触发，改手动 Deploy latest commit。部署后需核对：首页猫咪小屋、聊天头像为照片、盲盒/任务/游戏可用。
- **真机未验证**：语音 STT/TTS、照片上传（V3.0 遗留）、本次头像与猫咪动画在真机上的显示、转盘/翻牌在真机手感，仍需 Justin 或女朋友在真机上点一次确认。
- **访问密码**：按用户 2026-11-11 22:25 决定暂缓，本次未做，站保持开放；人格页修复与头像更换已并入本次交付。
- **已知遗留（不在第一阶段范围）**：恢复流程不匹配——前端向 `/api/restore` 发 FormData，后端期望 JSON `{data:{tables}}`；未修，留待后续。
- **付费服务：无**。全程只用现有免费栈（Render + Neon 免费档、DeepSeek 已有 Key），无新增付费第三方。

## 改动文件清单

| 文件 | 改动 |
|---|---|
| `db/schema.sqlite.sql`、`db/schema.pg.sql` | 各追加 4 张新表（`cat_state`、`daily_records`、`game_scores`、`mood_entries`，`CREATE TABLE IF NOT EXISTS`，只新增） |
| `src/cat.js`（新建） | 猫咪/每日/任务/盲盒/幸运签/转盘纯逻辑 + 读写 |
| `server.js` | 只追加 1 行 import + 11 条新路由（`GET /api/cat`、`POST /api/cat/interact`、`GET /api/daily`、`POST /api/daily/surprise`、`POST /api/daily/tasks/:id/claim`、`POST /api/daily/fortune`、`GET/POST /api/mood`、`POST/GET /api/games/score(s)`、`POST /api/games/wheel`），已有路由零改动 |
| `public/index.html` | 5 页 + 底部导航 5 按钮；顶栏/输入中/资料大头像换照片 img；聊天关键 id 全部保留 |
| `public/app.js` | `normalizePersona` 认 `{sections}` + 九标题对齐种子；消息行加照片头像（双方）+ `.msg-body` 包裹；auth 流程未动 |
| `public/mimi.js`（新建，638 行 + 修复） | 导航、时钟、猫咪互动、心情、任务、盲盒、幸运签、回忆页、三游戏、我的页、场景切换；后补 `formatReward()` 与 5 处调用修复、互动返回形状修复、转盘奖品名去重 |
| `public/style.css` | 粉色变量、5 场景渐变、猫咪动画、消息头像样式、`.avatar img` 圆形裁剪；深色模式仍为原有单条 `@media` |
| `public/assets/avatar.jpg`（新建） | 512×512 自拍裁图（30 KB） |
| `tests/07-phase1-backend.test.js`（新建） | 14 个后端测试 |
| `tests/08-phase1-frontend.test.js`（新建） | 11 项前端静态检查（含人格渲染、头像、formatReward） |
| `deploy/app.tar.gz`、`deploy/MANIFEST.txt` | 重打包并更新清单 |
| 未动 | `render.yaml`（buildCommand 仍为 `tar -xzf app.tar.gz && npm install`）、DeepSeek 配置、人格/样本/记忆/漂移逻辑、旧项目（可爱的乖乖）任何数据、线上 Neon |

## 测试与部署命令（供复核）

```bash
cd ~/workspace/new-ai-persona/app
npm test            # 95/95，0 失败（单独跑，勿并行）
# 部署包校验
cd ~/workspace/new-ai-persona
sha256sum deploy/app.tar.gz   # 与 deploy/MANIFEST.txt 核对
```
