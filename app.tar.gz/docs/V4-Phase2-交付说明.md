# V4.0 第二阶段交付说明 — Mimi Cat · 猫咪恋爱小屋

> **交付时间**：2026-11-11 23:20 CST
> **交付对象**：已上线 https://ai-boy-v3.onrender.com 的第二阶段升级（**本次未部署到 Render，线上仍为 V4.0 第一阶段版本**）
> **部署包**：`~/workspace/new-ai-persona/deploy/app.tar.gz`（以 deploy/MANIFEST.txt 为准）
> **注意**：包内文件均以 `./` 开头；解压后 `npm install` + `npm test` 已验证通过 145/145。

## 0. 本次先修的两个第一阶段遗留（用户明确反馈）

### 0.1 首页互动小猫“摸了没什么动作、也没有声音”——根因与修法

**根因（已核实，不是猜测）：**
- 动作幅度太小：第一阶段的摸头只是倾斜 2°+闭眼，喂食只是碗淡入，睡觉只是缩小 6%，只有玩耍的 10px 弹跳能看出来；没有手部动作、没有飘心、没有尾巴摆动。
- 声音：全站根本没有任何音频代码（无 AudioContext、无 audio 标签），不是静音问题，是压根没做。

**修法（第一阶段遗留 0 号任务）：**
- 动画大改：摸头猫头左右蹭动 ±10°/±4° + 尾巴摆动 + 飘爱心；喂食低头两次 + 嘴张合；睡觉缩成一团 + Z 字母逐个上飘；玩耍大跳 -18px；新增洗澡（快抖 + 泡泡上飘）。动作 class 至少保留可见 1.2 秒以上。
- 音效：新建 `public/catfx.js`，WebAudio 合成真实音效（摸头 55Hz 呼噜声、喂食两下咬合音、睡觉摇篮风铃琶音、玩耍三音符、洗澡水花声），零外链音频；只在用户点击后创建 AudioContext（手机自动播放策略）；master gain 0.22；首页加静音开关（localStorage `v3_sound_muted` 持久化）；创建失败静默失败，不显示“已播放”。

### 0.2 另外两个遗留

- **游戏成绩榜显示原始 JSON 文本**：已修。`detail` 先 `JSON.parse` 再格式化成可读文字，如“幸运转盘 · 得分 10 / 爱心+10”、“记忆翻牌 · 步数 5 · 用时 10 秒 · 得分 1200”，源码已无 `JSON.stringify(s.detail)`。
- **恢复流程不匹配**：已修。前端 `restoreBackup` 改为读文件文本 → `JSON.parse` → `POST /api/restore`（`Content-Type: application/json`，body `{data:{tables}}`）；非法 JSON 或无 `tables` 时报错且不发请求；成功后用返回的 `restored` 拼表名与条数提示。兼容本站备份的两种形状（裸 `{tables}` 与 `{data:{tables}}`）。

## 1. 猫咪形象与动画优化（本次核心，用户 23:13 要求）

**先查清为什么呆板**：之前只有一个静态 SVG + 几个幅度有限的 class 动画；没有状态机、没有分部位点击、没有随机待机行为。

**真正实现的动画（JS 状态机驱动的）：**
- 新建 `public/catstate.js`：`window.CatState = { set, get, toIdle, refresh }`，9 态 idle/happy/shy/sad/sleepy/curious/eat/play/sleep；`set` 先清其他 st-* 与互动 class 残留，同一时间只有一个 st-*；happy/shy/curious/eat/play 2 秒后自动回 idle；sleep/sleepy 持久到下一次互动。
- 形象重绘：分层 SVG（耳朵/眼睛睁·闭·开心弧线三组/鼻子/嘴/腮红/身体/尾巴/爪子/蝴蝶结各独立 `<g>` 层），奶白柔软蓬松毛发（radialGradient 明暗层次 + 毛簇路径）、眼睛带高光、粉色鼻子、淡粉腮红；首页猫与换装猫共用同一模板函数 `window.buildCatSVG()`，换装只改饰品组，脸部 group markup 在只改饰品时完全一致（已断言）。
- 眼睛/嘴的显隐由 `set()` 直接改对应层 `style.display`；待机随机行为：JS 定时器每 4–8 秒四选一（歪头/抖耳/伸懒腰/摆尾），每次只播一个，互动或非 idle 时不触发。
- 后端心情联动：`renderCat` 按心情给基础态（开心→happy、困倦→sleepy、饥饿→sad、满足→happy、兴奋→play、好奇→curious），只在 idle 且无 is-* 动画时切换。
- 分区点击（`data-zone` 委托）：点头=摸头（happy + 呼噜音效 + 飘爱心）、点身=扭动、点尾=快摆 1 秒、点爪=抬爪 0.8 秒；点击只做本地动画+音效，不发后端请求（不刷爱心），按钮互动才走后端。

**只是简单 CSS 效果的：**
- 所有动作的执行层都是 CSS Keyframes（呼吸、跳跃、摆尾、哈欠、左右观察、追逐毛线球等，幅度均 ≥1 秒可见）；JS 只负责状态切换、随机触发、显隐。眨眼（5 秒周期）与呼吸是持续 CSS 动画。
- is-*（按钮瞬时动画）与 st-*（状态层）分工在不同元素上：is-* 只动整个 `.cat-svg` 的 transform，st-* 只动内部层。

**还缺什么：**
- 无额外素材需求：只用了分层 SVG + CSS + JS，无外链、无位图、无付费服务/3D 引擎。
- 未验证：真机上的动画手感与音效是否出声（测试只用 `CatFX` 桩断言调用路径）；拍照下载在真机浏览器是否正常；`st-sleep` 内层缩放（0.96）与 `is-sleeping` 整猫缩放（0.86）叠加约 0.83，视觉上只是缩得更小一点，未在真机确认。

**性能**：`visibilitychange` 隐藏时 `#catFigure` 挂 `paused`、待机定时器停，恢复后重启；暂停规则收敛在 `.cat-figure.paused` 之下。

## 2. 猫咪养成（做实）

- 新增洗澡互动（`bath`，爱心+2、亲密度+3，状态“清爽”），任务 pet 的完成条件也认 bath。
- 心情、亲密度、成长等级做实：等级 `floor(亲密度/40)+1`（上限 10），阶段阈值 初次见面 0 / 熟悉 30 / 亲密 80 / 最好的伙伴 150；进阶时 `doInteract` 返回 `stageUp {from, to, unlock}`，解锁装饰（熟悉→蝴蝶结、亲密→小帽子、最好的伙伴→小裙子）并写入收藏。
- 爱心收支真实记账：新表 `heart_ledger`（delta/reason/created_at），所有发爱心处（互动/盲盒/任务/转盘/花园收获）都记 reason；`GET /api/cat/ledger` 可查。
- 同一动作 10 秒内重复不重复给奖（沿用第一阶段规则）。

## 3. 换装拍照

- 换装件（蝴蝶结/小帽子/围巾/小裙子/眼镜，SVG/CSS 画）+ 背景 5 个（卧室/星空/花园/甜品屋/月光窗台）+ 姿势 3 个（坐/趴/站），实时显示在猫身上；`GET/PUT /api/cat/outfit` 保存（白名单校验，非法值 400）。
- 拍照卡片：按钮“📸 拍照下载”把当前换装 SVG 序列化 → Blob → Image → 画到 720×720 Canvas（先画背景渐变，再画猫，含 `<defs>` 渐变，defs id 带后缀不串色），`a[download="mimi-cat.png"]` 触发真下载；失败诚实提示。
- 换装只改饰品，不改脸型、毛色、身体比例（模板同源，已断言）。

## 4. 房间装扮

- 迷你房间预览（墙纸渐变 + 🛏/🧸🐰🐱/💡/🌸/🖼）：墙纸 5 选、床铺 3 选、玩偶多选、灯/花开关、装饰画 4 选、房间主题 5 选；`GET/PUT /api/room` 保存。
- 房间主题与首页小屋联动：主题变化后首页 `#page-home` 的 class 切为对应场景，优先级高于“我的页外观设置”的场景选择（文案已注明）。

## 5. 幸运转盘（加深，不造第二个转盘）

- 奖品池与爱心/贴纸/装饰打通：非爱心奖品写入收藏（`collection`，`collected:{kind,item_id}` 随回包返回），前端 toast 显示“已收入收藏”；防连点（服务端 3 秒冷却）与成绩记录保留。

## 6. 心动事件

- 6 条事件（小猫跑过来蹭你、叼来一朵花、窗外粉色梦幻雨、神秘小纸条、躲进礼物盒、房间出现一颗爱心），各有专属动画 class（粉色雨下落、礼物盒弹跳、爱心脉冲等）与文字反馈；`GET /api/events/next` 随机触发，每天上限 5 次（超了 409）；可关闭、可收藏（`POST /api/events/:id/favorite`）；首页首次打开 2 秒后 30% 概率自动滚一条；另有“等一个小心动”按钮（60 秒连点锁）。

## 7. 神秘信箱

- `POST /api/letters/draw` 抽信即落库（status='new'）；来源只能是两类：(a) 已确认的真实聊天记录（`memories.confirmed=1` 的记忆，内容固定为通用引导句 + “小猪记得：{记忆原文}”原文引用，不改写、不加情节，`ref_memory_id` 记上）；(b) 原创通用小纸条池（8 条）。可收藏、删除、看历史（`GET /api/letters`，已删除的不显示）。
- **本次发现并修好的真问题**：全站原本没有任何路径能写出“已确认”的记忆（POST 把 status 写死 `active`，UI 也没有确认按钮），`status='confirmed'` 的 CHECK 值是个幽灵值，AI 信分支永远触发不了。修法：`memories` 新增 `confirmed` 列（db.js 启动时幂等迁移，只新增列，不动原 CHECK 约束）；POST 的 `status:'confirmed'` 与 PUT `{confirmed:1}` 都会写它；长期记忆页待确认的记忆多了个“✓ 确认”按钮。

## 8. 花园系统

- 3 个槽位，花种：雏菊 2 小时 / 玫瑰 6 小时 / 郁金香 12 小时 / 向日葵 24 小时；种花、浇水、收获；生长按真实时间算（只浇过水才长：未浇水 seed，进度 <1/3 sprout、<2/3 bud、≥1 bloom）；收获给爱心+2（记账）与“花朵·{花名}”装饰进收藏；花盆解锁：累计收获 ≥3 粉色花盆、≥8 金色花盆。
- 前端只显示后端给的 stage/progress，不自己编倒计时。

## 9. 聊天两侧头像区分（用户 23:08 要求，并入第二阶段）

- 右边（用户自己发的消息）头像换成卡通小人图 `public/assets/user-avatar.jpg`（512×512，裁自 `workspace/user/files/1000039113_3_62fw.jpg`：裁掉黑边与状态栏、以脸为中心裁成方形、右下角小红 e 已避开）；左边（小猪发的）、顶栏、正在输入、人物资料仍用自拍照片 `avatar.jpg`；加载失败用户侧兜底 🙂、小猪侧兜底 🐷；历史消息与新消息走同一渲染函数，一次改全覆盖。

## 新增后端（15 条路由 / 7 张新表）

- 表：`heart_ledger`、`collection`（UNIQUE(kind,item_id)）、`dress_state`、`room_state`、`garden_plots`、`letters`、`event_log`（两份 schema 同步，只新增）；另 `memories.confirmed` 列（启动迁移）。
- 路由：`GET /api/cat/ledger`、`GET/PUT /api/cat/outfit`、`GET/PUT /api/room`、`GET /api/garden`、`POST /api/garden/plant|water|harvest`、`GET /api/events/next`、`POST /api/events/:id/favorite`、`GET /api/letters`、`POST /api/letters/draw`、`POST /api/letters/:id/save|delete`；`POST /api/cat/interact` 回包加 `stageUp`，`POST /api/games/wheel` 回包加 `collected`；备份含 11 张猫咪/第二阶段表。

## 测试（全部实测，非自报）

| 检查 | 结果 |
|---|---|
| 全量 `npm test` | **145/145 通过，0 失败**（V3.0 70 + 第一阶段 25 + 第二阶段后端 14 + 前端 20 + 猫状态机 14 + 头像区分 1 + 信箱确认 1） |
| 后端新测试单跑（tests/09） | 15/15（含新增的 AI 信分支测试） |
| 前端新测试单跑（tests/10） | 20/20（jsdom：房间/花园/事件/信箱/成绩榜/恢复） |
| 猫状态机测试单跑（tests/11） | 14/14（状态切换无冲突、各态 class、分区点击、换装脸型不变、隐藏暂停） |
| 本地真服务器冒烟 | 后端自测时跑过（95→130 项全量），整合后又跑全量 145/145；测试数据已清理（新表 0 行，本地库本就无真实数据） |

整合时另修：`tests/08` 的“无外链”断言把 SVG 命名空间字符串 `http://www.w3.org/2000/svg` 误判为外链，已改为先剔除该标识串再查（它从不被请求）。

## 未完成 / 需用户确认

- **未部署**：需 Justin 确认后，把 `render.yaml` + `app.tar.gz` 推到 GitHub 仓库 `duubu960/ai-boy-v3`，Render 自动部署；若 5 分钟内未自动触发，改手动 Deploy latest commit。部署后需核对：小猫动作与音效、换装、房间、花园、信箱、转盘、头像区分。
- **真机未验证**：猫咪动画手感、WebAudio 音效是否出声、拍照下载、换装/花园真机操作，需 Justin 或女朋友在真机上点一次确认。
- **密码**：按用户 22:25 决定暂缓，本次未做，站保持开放。
- **已知遗留**：游戏成绩榜展示已修；恢复流程已修；第三阶段（回忆收藏馆、情绪陪伴中心、纪念日、睡前模式、每日陪伴报告）未做。
- **付费服务：无**。
